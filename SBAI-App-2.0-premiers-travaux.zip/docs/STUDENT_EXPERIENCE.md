# Expérience élève — SBAI-App 2.0

## Principe
Chaque écran doit répondre à une question simple : « Quelle est la prochaine action utile pour progresser ? »

## Accueil
- Salutation et classe de l'élève.
- Carte « Reprendre » liée à la dernière ressource consultée.
- Activités assignées avec statut : À faire, En cours, Rendu, Corrigé.
- Progression récente par matière, sans données d'exemple.
- Accès direct à une notion ou un exercice recommandé.

## Programme
- Sélecteur Physique / Chimie.
- Chapitres conformes au programme, progression et prérequis.
- Dans chaque chapitre : notions, cours, activités expérimentales, méthodes, exercices, simulations et annales.

## Entraînement
- Filtre par matière, chapitre, compétence et difficulté.
- Correction expliquée étape par étape après tentative, selon les règles pédagogiques.
- Historique des tentatives et reprise des questions non maîtrisées.

## Mon suivi
- Compétences : Non maîtrisé / En cours de maîtrise / Maîtrisé.
- Résultats et historique datés.
- Distinguer clairement auto-évaluation, entraînement et note officielle du professeur.

## Règles UX
- Une action principale par écran.
- Réduire les cartes décoratives et les doublons de navigation.
- Afficher les détails à la demande.
- Éviter les petits textes ; respecter le réglage de taille de police Android.
- Prévoir les états vide, chargement, hors-ligne, erreur et synchronisation en attente.
