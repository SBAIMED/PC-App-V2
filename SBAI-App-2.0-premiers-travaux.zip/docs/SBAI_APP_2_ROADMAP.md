# SBAI-App 2.0 — Plan de refonte

## Décisions de produit
- Stratégie : refonte des fondations, conservation des contenus et outils scientifiques réutilisables.
- Identité : scientifique, sobre, premium et accessible.
- Priorité : parcours élève.
- Cible pédagogique initiale : 2ème Bac Sciences Physiques, programme marocain, option français.

## Architecture cible

```text
:app
  core/design          Design system Compose, tokens, composants accessibles
  core/navigation      Navigation élève et routes typées
  core/common          UiState, gestion d'erreurs, formats et utilitaires
  domain/model         Chapitre, notion, activité, exercice, compétence, tentative
  domain/repository    Contrats de repositories
  domain/usecase       Règles métier et calculs indépendants de l'UI
  data/local           Room, DAO, migrations, sources locales
  data/remote          Firebase Auth, Firestore, API sécurisées
  data/repository      Implémentations et synchronisation
  feature/home         Accueil et reprise d'apprentissage
  feature/curriculum   Programme, matières et chapitres
  feature/courses      Cours, fiches, démonstrations
  feature/activities   Activités expérimentales et rendus
  feature/exercises    Exercices, corrections et entraînement
  feature/exams        Examens et simulations
  feature/progress     Compétences, résultats et historique
  feature/profile      Profil et préférences
```

## Navigation élève
1. Accueil : reprendre, prochaines activités, échéances, progression récente.
2. Programme : Physique / Chimie, chapitres, notions et ressources.
3. Entraînement : exercices par difficulté, QCM, examens et corrections.
4. Mon suivi : résultats, historique et maîtrise des compétences.

Les simulations, graphiques, outils de calcul et ressources expérimentales sont intégrés au contexte du chapitre plutôt que regroupés dans une longue liste indépendante.

## Modèle pédagogique à construire
- `Chapter` et `Concept` : structure du programme et prérequis.
- `LearningResource` : cours, fiche, vidéo, démonstration, simulation.
- `ActivityAssignment` : activité attribuée par un professeur à une classe ou à un élève.
- `SubmissionPolicy` : ouverture, fermeture et échéance contrôlées exclusivement par le professeur.
- `StudentSubmission` : réponse, pièces jointes, horodatage et statut.
- `Assessment` / `Attempt` : évaluation, tentatives et résultats vérifiables.
- `Competency` / `CompetencyEvidence` : critères et preuves de maîtrise.

Le client élève ne doit jamais pouvoir ouvrir ou prolonger lui-même une fenêtre de rendu. La règle d'ouverture/fermeture doit être appliquée côté serveur et reflétée dans l'interface.

## Sécurité et données
- Authentification Firebase ; rôle professeur issu d'une autorisation serveur (custom claims ou liste d'autorisations administrée côté serveur), jamais d'un code intégré à l'APK.
- Règles Firestore minimales : l'élève lit ses données ; les notes officielles et scores validés sont écrits par le serveur ou un professeur autorisé.
- Données de démonstration isolées d'un mode démo explicite ; aucun faux progrès dans un compte réel.
- Synchronisation avec états `pending`, `synced`, `failed`, reprise après reconnexion et résolution de conflits.
- Migrations Room versionnées ; stratégie de sauvegarde documentée pour les notes et données personnelles.

## Phasage
### Lot 0 — Sécurisation et fiabilité
- Retirer les secrets codés en dur et les élévations de rôle locales.
- Ne plus annoncer une synchronisation cloud si aucun service n'a été appelé.
- Corriger les retours d'erreur qui annonçaient un succès.
- Séparer les données de démonstration des données réelles.

### Lot 1 — Socle visuel et navigation élève
- Design system, typographie, composants de cartes, boutons, états vides et chargement.
- Navigation à quatre destinations et écrans adaptatifs téléphone/tablette.
- Accueil élève centré sur la prochaine action pédagogique.

### Lot 2 — Architecture applicative
- ViewModels par fonctionnalité, états UI immuables, use cases et repositories.
- Déplacer les calculs scientifiques hors des composables et ajouter des tests unitaires.
- Découper les grands fichiers et supprimer les dépendances réellement inutilisées.

### Lot 3 — Parcours d'apprentissage
- Programme hiérarchisé, prérequis, cours, activités, exercices et corrections.
- Progression par compétence : Non maîtrisé / En cours de maîtrise / Maîtrisé.
- Historique des tentatives et recommandations fondées sur les résultats réels.

### Lot 4 — Services et validation
- Synchronisation Firebase, autorisations et contrôle des rendus côté serveur.
- Tests unitaires, tests Room, tests Compose, tests des règles Firestore et tests scientifiques.
- Vérification sur plusieurs tailles d'écran et génération d'une version release signée.

## Critères de qualité avant publication
- Aucun rôle privilégié attribuable depuis une simple préférence locale.
- Aucun score officiel modifiable librement par l'élève.
- Aucune fausse confirmation de synchronisation/export.
- Pas de données fictives dans les tableaux de bord réels.
- Tests couvrant les calculs scientifiques, unités, conversions, graphes et règles d'accès.
- Accessibilité : taille de police système, contrastes, libellés d'icônes et zones tactiles suffisantes.
