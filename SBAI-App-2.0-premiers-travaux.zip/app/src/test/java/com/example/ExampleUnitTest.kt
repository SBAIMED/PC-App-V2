package com.example

import com.example.data.CurriculumData
import com.example.data.Difficulty
import com.example.data.QuestionType
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun curriculum_chapters_loaded() {
    assertTrue("Chapters should not be empty", CurriculumData.chapters.isNotEmpty())
    assertTrue("Exercises should have hidden solutions", CurriculumData.exercises.all { it.solutionSteps.isNotEmpty() })
  }

  @Test
  fun national_exams_span_2015_to_2026() {
    val years = CurriculumData.nationalExams.map { it.year }.distinct()
    assertTrue("Should include 2026", years.contains(2026))
    assertTrue("Should include 2015", years.contains(2015))
    assertEquals("Should cover exams from 2015 to 2026", 12, years.size)
  }

  @Test
  fun continuous_evaluations_count() {
    val s1 = CurriculumData.evaluations.filter { it.semester == 1 }
    val s2 = CurriculumData.evaluations.filter { it.semester == 2 }
    assertEquals("3 controls in Semester 1", 3, s1.size)
    assertEquals("3 controls in Semester 2", 3, s2.size)
    assertEquals("6 continuous evaluations total per year", 6, CurriculumData.evaluations.size)
  }

  @Test
  fun custom_quiz_structure() {
    assertTrue("Initial custom quizzes should exist", CurriculumData.initialCustomQuizzes.isNotEmpty())
    val quiz = CurriculumData.initialCustomQuizzes.first()
    assertTrue("Quiz total points should be positive", quiz.totalPoints > 0)
    assertTrue("Should contain diverse question formats", quiz.questions.any { it.type == QuestionType.QCM })
    assertTrue("Should contain true/false questions", quiz.questions.any { it.type == QuestionType.VRAI_FAUX })
  }
}
