package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlinx.coroutines.flow.first

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Physique-Chimie", appName)
  }

  @Test
  fun `auth manager initial state is signed out`() {
    assertEquals(false, com.example.data.GoogleAuthManager.isUserSignedIn())
  }

  @Test
  fun `firebase safety manager handles unconfigured environment gracefully`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val summary = com.example.data.FirebaseSafetyManager.getStatusSummary(context)
    org.junit.Assert.assertNotNull(summary)
    // Doesn't crash on Gemini key check
    val hasGemini = com.example.data.FirebaseSafetyManager.isGeminiKeyConfigured()
    org.junit.Assert.assertTrue(hasGemini || !hasGemini)
  }

  @Test
  fun `all 26 chapters have dedicated scientific charts`() {
    val chapters = com.example.data.OfficialCurriculum.allChapters
    assertEquals(26, chapters.size)
    for (ch in chapters) {
      org.junit.Assert.assertNotEquals(
        "Chapter ${ch.id} must have a valid non-NONE chartType",
        com.example.data.ScientificChartType.NONE,
        ch.chartType
      )
      org.junit.Assert.assertTrue("Chapter ${ch.id} must have chartTitle", !ch.chartTitle.isNullOrBlank())
      org.junit.Assert.assertTrue("Chapter ${ch.id} must have chartExploitation", !ch.chartExploitation.isNullOrBlank())
    }
  }

  @Test
  fun `mechanics unit contains all 7 chapters P10 to P16 with charts`() {
    val mechanicsChapters = com.example.data.OfficialCurriculum.allChapters.filter {
      it.unit.contains("Mécanique", ignoreCase = true)
    }
    assertEquals(7, mechanicsChapters.size)
    val ids = mechanicsChapters.map { it.id }
    assertEquals(listOf("P10", "P11", "P12", "P13", "P14", "P15", "P16"), ids)
  }

  @Test
  fun `all exercises have non-NONE scientific charts`() {
    val exercises = com.example.data.CurriculumData.exercises
    for (ex in exercises) {
      org.junit.Assert.assertNotEquals(
        "Exercise ${ex.id} (${ex.title}) must have a valid non-NONE chartType",
        com.example.data.ScientificChartType.NONE,
        ex.chartType
      )
    }
  }

  @Test
  fun `room database in-memory crud operations work reliably`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = androidx.room.Room.inMemoryDatabaseBuilder(
      context,
      com.example.data.local.AppDatabase::class.java
    ).allowMainThreadQueries().build()

    try {
      val chapterDao = db.chapterProgressDao()
      val reminderDao = db.studyReminderDao()
      val quizDao = db.quizAttemptDao()
      val chatDao = db.chatMessageDao()

      // 1. Chapter Progress CRUD
      val p6 = com.example.data.local.entity.ChapterProgressEntity(
        chapterId = "P6",
        title = "Le dipôle RC",
        subject = "PHYSIQUE",
        unit = "Électricité",
        isCompleted = false,
        isBookmarked = true,
        notes = "Méthode des 63%"
      )
      chapterDao.insertOrUpdate(p6)
      assertEquals(1, chapterDao.getCount())

      chapterDao.updateCompletion("P6", true)
      chapterDao.updateNotes("P6", "Constante tau = R*C")

      val firstProgress = chapterDao.getProgressForChapter("P6").first()
      org.junit.Assert.assertNotNull(firstProgress)
      assertEquals(true, firstProgress?.isCompleted)
      assertEquals("Constante tau = R*C", firstProgress?.notes)

      // 2. Study Reminder CRUD
      val reminder = com.example.data.local.entity.StudyReminderEntity(
        id = "rem_test_1",
        title = "Rappel Contrôle 1",
        subject = "PHYSIQUE",
        dueDate = "Demain",
        priority = "URGENT",
        isDone = false
      )
      reminderDao.insertReminder(reminder)
      assertEquals(1, reminderDao.getCount())
      reminderDao.updateDoneStatus("rem_test_1", true)
      val remindersList = reminderDao.getAllReminders().first()
      assertEquals(1, remindersList.size)
      assertEquals(true, remindersList.first().isDone)

      // 3. Quiz Attempt CRUD
      val attempt = com.example.data.local.entity.QuizAttemptEntity(
        quizId = "cc_s1_c1",
        quizTitle = "Contrôle Continu N°1",
        subject = "PHYSIQUE",
        score = 17.5,
        maxScore = 20.0,
        percentage = 87.5,
        studentName = "Yassine El Amrani",
        passed = true
      )
      val attemptId = quizDao.insertAttempt(attempt)
      org.junit.Assert.assertTrue(attemptId > 0)
      val attempts = quizDao.getAllAttempts().first()
      assertEquals(1, attempts.size)
      assertEquals(17.5, attempts.first().score, 0.01)

      // 4. Chat Message CRUD
      val msg = com.example.data.local.entity.ChatMessageEntity(
        id = "msg_test_1",
        senderName = "Professeur SBAI Mohammed",
        isTeacher = true,
        channel = "Annonces",
        message = "Bienvenue dans l'espace 2BAC PC !",
        timestampFormatted = "10:00"
      )
      chatDao.insertMessage(msg)
      assertEquals(1, chatDao.getCount())
    } finally {
      db.close()
    }
  }

  @Test
  fun `repository seedInitialDataIfNeeded populates all 26 chapters and reminders`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = androidx.room.Room.inMemoryDatabaseBuilder(
      context,
      com.example.data.local.AppDatabase::class.java
    ).allowMainThreadQueries().build()

    try {
      val repository = com.example.data.repository.AppLocalRepository(db)
      repository.seedInitialDataIfNeeded()

      val chaptersCount = db.chapterProgressDao().getCount()
      assertEquals(26, chaptersCount)

      val remindersCount = db.studyReminderDao().getCount()
      org.junit.Assert.assertTrue("Should have initial reminders", remindersCount >= 5)

      val messagesCount = db.chatMessageDao().getCount()
      org.junit.Assert.assertTrue("Should have initial messages", messagesCount >= 3)
    } finally {
      db.close()
    }
  }
}
