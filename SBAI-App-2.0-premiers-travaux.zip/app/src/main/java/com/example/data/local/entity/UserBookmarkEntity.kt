package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_bookmarks")
data class UserBookmarkEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val chapterId: String,
  val title: String,
  val contentLatex: String,
  val category: String, // "FORMULE", "DEFINITION", "METHODE", "PIEGE_BAC"
  val notes: String = "",
  val createdAt: Long = System.currentTimeMillis()
)
