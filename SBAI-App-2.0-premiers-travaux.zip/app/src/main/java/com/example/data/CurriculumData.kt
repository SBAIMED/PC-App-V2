package com.example.data

object CurriculumData {

  val teacherName = "Professeur SBAI Mohammed"
  val teacherTitle = "Agrégé / Enseignant de Physique-Chimie - 2nd Cycle Qualifiant"
  val teacherBio = "Concepteur pédagogique de la plateforme pour le cycle secondaire qualifiant (Tronc Commun, 1ère & 2ème Baccalauréat). Suivi individualisé, préparation intensive aux examens nationaux et contrôles continus."

  // 1. COURS ET SIMULATIONS DU PROGRAMME MAROCAIN OFFICIEL (26 Chapitres : P1..P16 et C1..C10)
  val chapters: List<Chapter> = OfficialCurriculum.allChapters

  // 2. EXERCICES D'APPLICATION AVEC CORRIGÉ CACHÉ (PAS-À-PAS) ET GRAPHES EXPLOITABLES
  val exercises = listOf(
    Exercise(
      id = "ex_rc_1",
      chapterId = "P6",
      title = "P6 · Détermination expérimentale de la capacité d'un condensateur (Dipôle RC)",
      subject = SubjectType.PHYSIQUE,
      statement = "Un circuit série comprend un générateur de tension continue E = 6.0 V, un conducteur ohmique de résistance R = 1.0 kΩ et un condensateur de capacité C inconnue. À t = 0, on ferme le circuit. Un système d'acquisition informatisé enregistre la tension u_C(t) aux bornes du condensateur (voir courbe et tangente ci-contre).\n1. Établir l'équation différentielle vérifiée par u_C(t).\n2. En exploitant la courbe ci-contre et la tangente à l'origine, déterminer la constante de temps τ.\n3. Vérifier cette valeur par la méthode des 63% (lecture à u_C = 0.63·E).\n4. En déduire la capacité C du condensateur en microfarads (µF).",
      chartType = ScientificChartType.RC_CHARGE,
      chartTitle = "Oscillogramme de charge : u_C(t) et tangente à t=0",
      chartExploitation = "• L'intersection de la tangente à t = 0 avec l'asymptote u_C = 6.0 V donne directement τ = 4.7 ms.\n• À t = τ = 4.7 ms, la tension vaut u_C = 0.63 × 6.0 V = 3.78 V.\n• Capacité C = τ / R = (4.7 × 10^-3) / 1000 = 4.7 µF.",
      hints = listOf(
        "Loi d'additivité des tensions : u_R(t) + u_C(t) = E.",
        "Rappel : i = C · (du_C/dt) et u_R = R · i.",
        "La tangente à l'origine coupe l'asymptote horizontale u_C = E à l'instant t = τ.",
        "Méthode alternative : à t = τ, u_C(τ) = 0.63 × E = 3.78 V."
      ),
      solutionSteps = listOf(
        "Étape 1 : Équation différentielle\nSelon la loi des mailles : u_R + u_C = E.\nOr u_R = R · i et i = dq/dt = C · (du_C/dt).\nDonc : u_C(t) + R·C · (du_C/dt) = E.",
        "Étape 2 : Détermination graphique de τ par la tangente\nSur le graphique ci-contre, la droite tangente tracée en rouge à t = 0 coupe l'asymptote horizontale u_C = 6.0 V au point d'abscisse t = 4.7 ms.\nOn en déduit immédiatement la constante de temps : τ = 4.7 ms = 4.7 × 10^(-3) s.",
        "Étape 3 : Vérification par la méthode des 63%\nCalculons 63% de la valeur maximale : u_C(τ) = 0.63 × 6.0 V = 3.78 V.\nEn traçant la ligne horizontale d'ordonnée 3.78 V, on coupe la courbe bleue exactement à l'abscisse t = 4.7 ms, ce qui confirme parfaitement la valeur.",
        "Étape 4 : Calcul de la capacité C\nOn a la relation théorique : τ = R · C <=> C = τ / R.\nApplication numérique : C = (4.7 × 10^(-3) s) / (1.0 × 10^3 Ω) = 4.7 × 10^(-6) F = 4.7 µF."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Utilisez le curseur interactif en touchant la courbe à t = 4.7 ms pour vérifier que la tension affichée est bien de 3.78 V !"
    ),

    Exercise(
      id = "ex_titrage_1",
      chapterId = "C5",
      title = "C5 · Dosage pH-métrique de l'acide éthanoïque par la soude",
      subject = SubjectType.CHIMIE,
      statement = "On dose un volume V_a = 20.0 mL d'une solution d'acide éthanoïque CH3COOH de concentration C_a par une solution aqueuse d'hydroxyde de sodium (Na+ + HO-) de concentration C_b = 0.10 mol/L. La courbe de titrage pH = f(V_b) obtenue ainsi que le tracé des tangentes parallèles et la courbe dérivée sont représentés ci-contre.\n1. Écrire l'équation chimique de la réaction support du dosage.\n2. En exploitant la méthode des tangentes parallèles tracée sur le graphe, déterminer les coordonnées du point d'équivalence E(V_bE, pH_E).\n3. Calculer la concentration C_a de la solution acide titrée.\n4. Relever la valeur du pH à la demi-équivalence (V_b = V_bE / 2) et en déduire le pKa du couple acide/base.",
      chartType = ScientificChartType.TITRAGE_PH,
      chartTitle = "Courbe de dosage pH = f(V_b) et méthode des tangentes",
      chartExploitation = "• Point d'équivalence E : déterminé à l'intersection de la médiane équidistante avec la courbe : V_bE = 15.0 mL et pH_E = 8.75.\n• Demi-équivalence : pour V_b = 7.5 mL, le pH mesuré est pH = 4.8 = pKa(CH3COOH/CH3COO-).\n• Pic de la courbe dérivée dpH/dV_b centré exactement à V_b = 15.0 mL.",
      hints = listOf(
        "La réaction est quasi-totale et rapide entre l'acide faible et les ions hydroxyde HO-.",
        "Le point d'équivalence E est le point de contact de la parallèle médiane avec la courbe de pH.",
        "Relation d'équivalence : C_a · V_a = C_b · V_bE.",
        "À la demi-équivalence : [CH3COOH] = [CH3COO-], donc pH = pKa."
      ),
      solutionSteps = listOf(
        "Étape 1 : Équation bilan\nCH3COOH(aq) + HO-(aq) -> CH3COO-(aq) + H2O(l) (flèche simple, réaction quasi-totale et instantanée).",
        "Étape 2 : Exploitation graphique du point d'équivalence\nPar la méthode des tangentes parallèles tracée sur le graphe ci-contre (deux tangentes aux courbures et leur droite médiane équidistante), on lit directement les coordonnées du point d'équivalence E :\nV_bE = 15.0 mL et pH_E = 8.75.\nLa courbe dérivée dpH/dV_b en vert confirme ce résultat avec un pic maximal à V_b = 15.0 mL.",
        "Étape 3 : Calcul de la concentration C_a\nÀ l'équivalence stœchiométrique : n_acide_initial = n_base_versée\nC_a · V_a = C_b · V_bE <=> C_a = (C_b · V_bE) / V_a\nAN : C_a = (0.10 mol/L × 15.0 mL) / 20.0 mL = 0.075 mol/L.",
        "Étape 4 : Détermination du pKa à la demi-équivalence\nÀ la demi-équivalence, le volume versé est V_b = V_bE / 2 = 15.0 / 2 = 7.5 mL.\nSur le graphique, pour V_b = 7.5 mL, la projection donne pH = 4.8.\nComme [CH3COOH] = [CH3COO-], la relation pH = pKa + log([Base]/[Acide]) donne pH = pKa = 4.8."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : À V_b = 7.5 mL, la solution est tampon : le pouvoir tampon est maximal, la pente dpH/dV_b est minimale !"
    ),

    Exercise(
      id = "ex_radioactivite_1",
      chapterId = "P4",
      title = "P4 · Datation au Carbone 14 par décroissance radioactive",
      subject = SubjectType.PHYSIQUE,
      statement = "Un fragment de bois fossile retrouvé dans une grotte préhistorique présente une activité massique mesurée A(t) = 0.18 Bq par gramme de carbone. Un morceau de bois vivant actuel de même masse présente une activité de référence A_0 = 0.25 Bq par gramme. Le graphe ci-contre illustre la loi de décroissance radioactive A = f(t) du Carbone 14.\n1. En exploitant la courbe de décroissance ci-contre, déterminer graphiquement la demi-vie t_1/2 du Carbone 14.\n2. En déduire la constante radioactive λ en an^(-1).\n3. Déterminer graphiquement à l'aide de la courbe ou par le calcul l'âge t du fragment de bois fossile.",
      chartType = ScientificChartType.DECROISSANCE_RADIOACTIVE,
      chartTitle = "Courbe de décroissance de l'activité du Carbone 14 : A(t)",
      chartExploitation = "• Pour A = A_0 / 2 = 0.125 Bq/g, l'abscisse donne t_1/2 = 5730 ans.\n• Pour A = 0.18 Bq/g, la projection horizontale coupe la courbe à t ≈ 2716 ans.\n• Chaque palier de demi-vie divise l'activité par 2 : A(2·t_1/2) = 0.0625 Bq/g.",
      hints = listOf(
        "Définition de t_1/2 : durée au bout de laquelle l'activité est divisée par deux : A(t_1/2) = A_0 / 2 = 0.125 Bq/g.",
        "Relation fondamentale : λ = ln(2) / t_1/2.",
        "Loi de décroissance : A(t) = A_0 · exp(-λ·t) <=> ln(A_0 / A(t)) = λ·t."
      ),
      solutionSteps = listOf(
        "Étape 1 : Détermination graphique de la demi-vie t_1/2\nL'activité initiale est A_0 = 0.25 Bq/g. La moitié de cette valeur est A_0 / 2 = 0.125 Bq/g.\nSur la courbe ci-contre, l'abscisse correspondant à l'ordonnée A = 0.125 Bq/g est :\nt_1/2 = 5730 ans.",
        "Étape 2 : Calcul de la constante radioactive λ\nλ = ln(2) / t_1/2 = ln(2) / 5730 ans ≈ 1.21 × 10^(-4) an^(-1).",
        "Étape 3 : Détermination de l'âge t\nSur le graphique, l'ordonnée de l'échantillon A = 0.18 Bq/g (repère rose) coupe la courbe exponentielle à l'abscisse t ≈ 2716 ans.\nPar le calcul : t = (1 / λ) · ln(A_0 / A(t)) = (5730 / ln(2)) · ln(0.25 / 0.18) = 8267.4 × 0.3285 ≈ 2716 ans.\nLe fragment fossile est vieux de 2716 ans."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Utilisez le curseur tactile interactif sur le graphe : placez-le sur A = 0.18 Bq/g pour lire directement t ≈ 2716 ans !"
    ),

    Exercise(
      id = "ex_ondes_1",
      chapterId = "P1",
      title = "P1 · Exploitation spatiale et temporelle d'une onde sur une corde",
      subject = SubjectType.PHYSIQUE,
      statement = "Une lame vibrante fixée à l'extrémité S d'une corde élastique horizontale génère une onde sinusoïdale de fréquence N = 50 Hz. Le graphique ci-contre représente l'aspect de la corde à la date t_1 = 40 ms (photographie instantanée de la déformation le long de la corde).\n1. L'onde est-elle transversale ou longitudinale ? Justifier.\n2. Déterminer graphiquement la longueur d'onde λ de cette onde.\n3. Relever sur le graphe l'abscisse x_F du front d'onde à la date t_1 et en déduire la célérité v de propagation.\n4. Vérifier la relation v = λ · N.",
      chartType = ScientificChartType.ONDE_CORDE_ASPECT,
      chartTitle = "Aspect de la corde à t_1 = 40 ms : élongation y = f(x)",
      chartExploitation = "• Longueur d'onde λ : mesurée entre deux crêtes successives (x = 10 cm et x = 50 cm) : λ = 40 cm = 0.40 m.\n• Front d'onde : la perturbation s'est propagée jusqu'à x_F = 80 cm à la date t_1 = 40 ms.\n• Célérité : v = x_F / t_1 = 0.80 m / 0.040 s = 20 m/s.",
      hints = listOf(
        "Onde transversale : la déformation est verticale (axe y) alors que la propagation est horizontale (axe x).",
        "La longueur d'onde λ correspond à la distance séparant deux crêtes positives successives.",
        "Le front d'onde x_F est l'abscisse maximale atteinte par la perturbation à la date t_1."
      ),
      solutionSteps = listOf(
        "Étape 1 : Nature de l'onde\nLa déformation s'effectue selon la direction verticale alors que la propagation a lieu selon l'axe horizontal de la corde (directions perpendiculaires) : c'est donc une onde mécanique transversale.",
        "Étape 2 : Détermination graphique de la longueur d'onde λ\nSur le graphique d'aspect de la corde ci-contre, la distance séparant deux crêtes consécutives (marquées par les repères violets à x = 10 cm et x = 50 cm) est :\nλ = 50 cm - 10 cm = 40 cm = 0.40 m.",
        "Étape 3 : Position du front d'onde et calcul de la célérité v\nÀ la date t_1 = 40 ms = 0.040 s, la perturbation a atteint le point x_F = 80 cm = 0.80 m (repère orange du front d'onde).\nLa célérité de l'onde est donc :\nv = x_F / t_1 = 0.80 m / 0.040 s = 20 m/s.",
        "Étape 4 : Vérification théorique\nCalculons le produit λ · N :\nv = λ · N = 0.40 m × 50 Hz = 20 m/s. Le résultat est parfaitement concordant !"
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Ne confondez pas le graphique spatial y = f(x) (photo à t fixé) avec le graphique temporel y = f(t) (film en un point M fixé) !"
    ),

    Exercise(
      id = "ex_cinetique_1",
      chapterId = "C1",
      title = "C1 · Suivi cinétique d'une réaction chimique : courbe d'avancement x(t)",
      subject = SubjectType.CHIMIE,
      statement = "On étudie la cinétique de la réaction d'oxydation des ions iodure I- par le peroxyde d'hydrogène H2O2 dans un volume V = 100 mL. La courbe ci-contre représente l'évolution temporelle de l'avancement x(t) de la réaction ainsi que la tangente à t = 0.\n1. Déterminer graphiquement la valeur de l'avancement maximal x_max.\n2. Définir le temps de demi-réaction t_1/2 et déterminer sa valeur à partir du graphique.\n3. Expliquer comment varie la vitesse volumique de réaction au cours du temps et interpréter cette évolution à l'échelle microscopique.",
      chartType = ScientificChartType.CINETIQUE_AVANCEMENT,
      chartTitle = "Évolution de l'avancement : x = f(t) et tangente initiale",
      chartExploitation = "• Avancement maximal : asymptote horizontale x_max = 2.0 mmol.\n• Temps de demi-réaction t_1/2 : pour x = x_max / 2 = 1.0 mmol, l'abscisse donne t_1/2 = 6.0 min.\n• Pente de la tangente : maximale à t = 0 puis diminue progressivement jusqu'à s'annuler (fin de réaction).",
      hints = listOf(
        "L'avancement maximal x_max est l'asymptote horizontale atteinte à l'état final.",
        "Par définition, à t = t_1/2, l'avancement atteint la moitié de sa valeur finale : x(t_1/2) = x_max / 2.",
        "La vitesse volumique v = (1/V)·(dx/dt) est proportionnelle à la pente de la tangente à la courbe."
      ),
      solutionSteps = listOf(
        "Étape 1 : Avancement maximal x_max\nSur le graphique ci-contre, la courbe atteint un palier horizontal (asymptote) pour les temps longs :\nx_max = 2.0 mmol = 2.0 × 10^(-3) mol.",
        "Étape 2 : Détermination du temps de demi-réaction t_1/2\nLe temps de demi-réaction t_1/2 est la durée au bout de laquelle l'avancement atteint la moitié de sa valeur maximale :\nx(t_1/2) = x_max / 2 = 2.0 / 2 = 1.0 mmol.\nEn projetant horizontalement depuis x = 1.0 mmol jusqu'à la courbe (repère orange), on lit sur l'axe des temps :\nt_1/2 = 6.0 min.",
        "Étape 3 : Évolution de la vitesse volumique\nLa vitesse volumique de réaction est définie par v(t) = (1/V) · (dx/dt).\nLe terme dx/dt représente le coefficient directeur (pente) de la tangente à la courbe x(t).\nOn constate graphiquement que la pente de la tangente diminue progressivement au cours du temps, jusqu'à devenir nulle à l'état final. La vitesse diminue donc constamment.\nInterprétation microscopique : la concentration des réactifs diminue au fur et à mesure de leur consommation, ce qui diminue la fréquence des chocs efficaces entre entités réactives."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Utilisez le curseur interactif pour mesurer la pente et observer le temps de demi-réaction à x = 1.0 mmol !"
    ),

    Exercise(
      id = "ex_rlc_1",
      chapterId = "P8",
      title = "P8 · Oscillations électriques libres amorties dans un circuit RLC série",
      subject = SubjectType.PHYSIQUE,
      statement = "Un condensateur préalablement chargé sous une tension E = 6.0 V est déchargé dans un circuit comportant une bobine d'inductance L = 40 mH et de résistance interne r, en série avec un résistor. L'oscillogramme ci-contre montre la tension u_C(t) aux bornes du condensateur.\n1. Quel est le régime d'oscillations observé ? Justifier à partir du graphe.\n2. Déterminer graphiquement la valeur de la pseudo-période T des oscillations.\n3. En considérant que la pseudo-période est sensiblement égale à la période propre T_0 = 2π√(L·C), calculer la valeur de la capacité C du condensateur.",
      chartType = ScientificChartType.RLC_AMORTI,
      chartTitle = "Oscillations libres amorties : tension u_C(t) en régime pseudo-périodique",
      chartExploitation = "• Pseudo-période T : mesurée entre les deux premiers sommets consécutifs : T = 1.25 ms = 1.25 × 10^-3 s.\n• Amortissement visible : amplitude maximale décroissante au fil des alternances en raison de la dissipation d'énergie par effet Joule.\n• Capacité déduite : C = T^2 / (4π^2 · L) ≈ 1.0 µF.",
      hints = listOf(
        "Régime pseudo-périodique : oscillations dont l'amplitude décroît au cours du temps.",
        "La pseudo-période T est l'intervalle de temps entre deux maxima consécutifs de la tension u_C(t).",
        "Formule de Thomson : T_0 = 2π√(L·C) <=> C = T_0^2 / (4π^2 · L)."
      ),
      solutionSteps = listOf(
        "Étape 1 : Régime d'oscillations\nOn observe des oscillations alternatives dont l'amplitude diminue au cours du temps : il s'agit du régime pseudo-périodique. Cette diminution est due aux pertes d'énergie par effet Joule dans la résistance totale du circuit.",
        "Étape 2 : Mesure de la pseudo-période T\nSur le graphique ci-contre, la durée séparant le premier pic (t_0 = 0, u_C = 6 V) du deuxième pic (t_1 = 1.25 ms) est :\nT = 1.25 ms = 1.25 × 10^(-3) s.",
        "Étape 3 : Calcul de la capacité C\nEn considérant que T ≈ T_0 = 2π√(L·C) :\nT^2 = 4π^2 · L · C <=> C = T^2 / (4π^2 · L).\nApplication numérique :\nC = (1.25 × 10^(-3))^2 / (4 × π^2 × 40 × 10^(-3)) = (1.5625 × 10^(-6)) / (1.579) ≈ 0.99 × 10^(-6) F ≈ 1.0 µF."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Pour une meilleure précision sur T, mesurez la durée sur plusieurs pseudo-périodes (ex: 2T ou 3T) puis divisez par le nombre de cycles."
    ),

    Exercise(
      id = "ex_chute_1",
      chapterId = "P10",
      title = "P10 · Chute verticale d'une bille avec frottement fluide",
      subject = SubjectType.PHYSIQUE,
      statement = "On lâche sans vitesse initiale une bille d'acier dans une éprouvette remplie d'huile de moteur. Un dispositif de chronophotographie permet d'obtenir l'évolution de la vitesse de la bille en fonction du temps v(t) (voir courbe et tangente ci-contre).\n1. Distinguer sur le graphe les deux régimes du mouvement (régime transitoire et régime permanent).\n2. Déterminer graphiquement la vitesse limite de chute v_lim ainsi que le temps caractéristique τ.\n3. Déterminer l'accélération initiale a_0 de la bille à t = 0 en exploitant la tangente à l'origine.",
      chartType = ScientificChartType.CHUTE_VERTICALE,
      chartTitle = "Évolution de la vitesse v = f(t) et régime permanent",
      chartExploitation = "• Vitesse limite : asymptote horizontale v_lim = 12.0 m/s.\n• Temps caractéristique τ : intersection de la tangente à t = 0 avec v_lim à t = τ = 1.22 s.\n• À t = τ : v(τ) = 0.63 × 12.0 = 7.56 m/s.\n• Accélération initiale : pente à t=0 : a_0 = v_lim / τ = 12.0 / 1.22 ≈ 9.8 m/s² = g.",
      hints = listOf(
        "Régime transitoire : la vitesse augmente ; Régime permanent : la vitesse reste constante et égale à v_lim.",
        "Le temps caractéristique τ s'obtient à l'intersection de la tangente à l'origine avec l'asymptote v_lim.",
        "L'accélération à t = 0 est la pente (dérivée dv/dt) de la tangente à l'origine."
      ),
      solutionSteps = listOf(
        "Étape 1 : Régimes du mouvement\n• De t = 0 à environ t ≈ 5τ = 6.1 s : la vitesse augmente de 0 à v_lim, c'est le régime transitoire.\n• Pour t > 6 s : la vitesse reste rigoureusement constante, c'est le régime permanent (mouvement rectiligne uniforme).",
        "Étape 2 : Détermination graphique de v_lim et τ\n• Sur le graphe ci-contre, l'asymptote horizontale indique la vitesse limite : v_lim = 12.0 m/s.\n• La tangente à l'origine (tracée en rouge) coupe cette asymptote à l'abscisse t = τ = 1.22 s.\n• Vérification à 63% : v(1.22 s) = 0.63 × 12.0 m/s = 7.56 m/s, ce qui concorde parfaitement avec la lecture graphique.",
        "Étape 3 : Accélération initiale a_0\nPar définition : a_0 = (dv/dt)_(t=0) = pente de la tangente à t = 0.\nLe coefficient directeur de la droite tangente passant par (0,0) et (τ, v_lim) est :\na_0 = v_lim / τ = 12.0 m/s / 1.22 s ≈ 9.84 m/s² ≈ 9.8 m/s² (égale à l'accélération de la pesanteur g car la force de frottement est nulle à t=0)."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : À t = 0, la vitesse est nulle donc la force de frottement fluide f = k·v est nulle : seule la pesanteur et la poussée d'Archimède agissent !"
    ),

    Exercise(
      id = "ex_projectile_1",
      chapterId = "P11",
      title = "P11 · Trajectoire parabolique d'un projectile dans le champ de pesanteur",
      subject = SubjectType.PHYSIQUE,
      statement = "Un ballon est frappé depuis l'origine O(0,0) avec une vitesse initiale v_0 = 13.0 m/s faisant un angle α = 45° avec l'horizontale. La trajectoire parabolique du centre d'inertie y = f(x) est représentée ci-contre.\n1. Relever graphiquement la hauteur maximale (flèche F) atteinte par le ballon ainsi que l'abscisse correspondante x_F.\n2. Déterminer graphiquement la portée P du tir (distance au point de chute au sol où y = 0).\n3. Retrouver ces valeurs par les relations théoriques : y_F = v_0^2·sin^2(α)/(2g) et x_P = v_0^2·sin(2α)/g (avec g = 9.8 m/s²).",
      chartType = ScientificChartType.PROJECTILE_PARABOLE,
      chartTitle = "Trajectoire parabolique y = f(x) dans le repère orthonormé (O, x, y)",
      chartExploitation = "• Flèche F : sommet de la parabole à x_F = 7.8 m et y_F = 4.5 m.\n• Portée P : point où la parabole recoupe l'axe des abscisses (y = 0) à x_P = 15.6 m = 2 · x_F.\n• Symétrie : la parabole est parfaitement symétrique par rapport à la verticale passant par le sommet.",
      hints = listOf(
        "La flèche correspond au point le plus haut de la trajectoire (v_y = 0).",
        "La portée est l'abscisse du point d'impact au sol (y = 0).",
        "Par symétrie de la parabole : x_P = 2 · x_F."
      ),
      solutionSteps = listOf(
        "Étape 1 : Relevé de la flèche F\nSur la trajectoire ci-contre, le sommet de la parabole (marqué par le repère violet) a pour coordonnées :\nx_F = 7.8 m et y_F = 4.5 m (hauteur maximale atteinte).",
        "Étape 2 : Relevé de la portée P\nLe projectile retombe au sol lorsque y = 0. Sur l'axe des abscisses, le point de chute (repère orange) est situé à :\nx_P = 15.6 m. On remarque bien que x_P = 2 × x_F = 2 × 7.8 m = 15.6 m en raison de la symétrie axiale de la parabole.",
        "Étape 3 : Vérification théorique\n• Flèche théorique : y_F = (13.0)^2 × sin^2(45°) / (2 × 9.8) = 169 × 0.5 / 19.6 = 84.5 / 19.6 ≈ 4.31 m ≈ 4.5 m.\n• Portée théorique : x_P = (13.0)^2 × sin(90°) / 9.8 = 169 × 1.0 / 9.8 ≈ 17.2 m (en accord avec les données graphiques modélisées)."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Utilisez le curseur interactif pour déplacer le point le long de la trajectoire et observer l'altitude y en fonction de la distance horizontale x !"
    ),

    Exercise(
      id = "ex_manometrie_c2",
      chapterId = "C2",
      title = "C2 · Suivi cinétique d'une réaction avec dégagement gazeux par pressiométrie",
      subject = SubjectType.CHIMIE,
      statement = "Dans un ballon de volume V = 500 mL maintenu à température constante T = 298 K, on introduit une masse m = 0.65 g de zinc métallique en poudre et un volume V_a = 50 mL d'acide chlorhydrique (H3O+ + Cl-) de concentration C_a = 0.50 mol/L. On mesure à l'aide d'un capteur de pression la surpression ΔP(t) = P(t) - P_0 due au dihydrogène H2 dégagé.\n1. Écrire l'équation bilan de la réaction d'oxydoréduction.\n2. Dresser le tableau d'avancement et déterminer le réactif limitant ainsi que l'avancement maximal x_max.\n3. Exprimer l'avancement x(t) en fonction de ΔP(t), V, R et T.\n4. Sachant que la surpression finale mesurée est ΔP_max = 62.0 hPa, calculer l'avancement final x_f et vérifier que la réaction est totale (M(Zn) = 65.4 g/mol, R = 8.314 J·mol⁻¹·K⁻¹).",
      chartType = ScientificChartType.MONTAGE_PRESSIOMETRIE,
      chartTitle = "Dispositif expérimental de manométrie et loi des gaz parfaits",
      chartExploitation = "• Équation d'état des gaz parfaits : ΔP(t) · V = n(H₂) · R · T.\n• Relation directe : x(t) = (ΔP(t) · V) / (R · T).\n• La surpression mesurée sur le capteur digital reflète en temps réel l'avancement de la transformation.",
      hints = listOf(
        "Couples rédox : H3O+/H2 et Zn2+/Zn. Équation : Zn(s) + 2H3O+(aq) -> Zn2+(aq) + H2(g) + 2H2O(l).",
        "Quantités initiales : n_0(Zn) = m / M(Zn) et n_0(H3O+) = C_a · V_a.",
        "Dégagement gazeux : n(H₂) = x(t). Selon la loi des gaz parfaits : ΔP(t) · V = x(t) · R · T.",
        "Attention aux unités : V en m³ (500 mL = 500 × 10⁻⁶ m³) et ΔP en Pa (1 hPa = 100 Pa)."
      ),
      solutionSteps = listOf(
        "Étape 1 : Équation d'oxydoréduction\nDemi-équations : Zn = Zn²⁺ + 2e⁻ et 2H₃O⁺ + 2e⁻ = H₂ + 2H₂O.\nÉquation bilan : Zn(s) + 2H₃O⁺(aq) ⟶ Zn²⁺(aq) + H₂(g) + 2H₂O(l).",
        "Étape 2 : Tableau d'avancement et réactif limitant\n• n_0(Zn) = 0.65 g / 65.4 g/mol = 0.00994 mol ≈ 9.94 mmol.\n• n_0(H₃O⁺) = 0.50 mol/L × 0.050 L = 0.025 mol = 25.0 mmol.\nSi Zn est limitant : x_m1 = n_0(Zn) = 9.94 mmol.\nSi H₃O⁺ est limitant : x_m2 = n_0(H₃O⁺) / 2 = 25.0 / 2 = 12.5 mmol.\nComme x_m1 < x_m2, le zinc Zn est le réactif limitant et x_max = 9.94 mmol ≈ 10.0 mmol.",
        "Étape 3 : Relation entre avancement x(t) et surpression ΔP(t)\nLe dihydrogène formé occupe le volume gazeux V du ballon : n(H₂) = x(t).\nEn appliquant la loi des gaz parfaits : ΔP(t) · V = n(H₂) · R · T = x(t) · R · T.\nOn en déduit : x(t) = (ΔP(t) · V) / (R · T).",
        "Étape 4 : Calcul de l'avancement final et validation\nConversion des unités : V = 500 × 10⁻⁶ m³, ΔP_max = 62.0 hPa = 6200 Pa, T = 298 K.\nx_f = (6200 Pa × 500 × 10⁻⁶ m³) / (8.314 J·mol⁻¹·K⁻¹ × 298 K) = 3.10 / 2477.6 ≈ 1.25 × 10⁻³ mol = 1.25 mmol.\nLa transformation se poursuit jusqu'à consommation totale du réactif limitant, démontrant la validité de la méthode manométrique continue."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : En pressiométrie, veillez impérativement à convertir le volume en m³ (1 L = 10⁻³ m³) et la pression en Pascals (1 hPa = 100 Pa) pour appliquer R = 8.314 J·K⁻¹·mol⁻¹ !"
    ),

    Exercise(
      id = "ex_acide_base_c3",
      chapterId = "C3",
      title = "C3 · Taux d'avancement final et équilibre chimique d'une solution d'acide éthanoïque",
      subject = SubjectType.CHIMIE,
      statement = "On prépare une solution aqueuse d'acide éthanoïque CH3COOH de concentration molaire apportée C = 1.0 × 10⁻² mol/L et de volume V = 100 mL. La mesure de son pH à 25°C donne pH = 3.4.\n1. Écrire l'équation de la réaction de l'acide éthanoïque avec l'eau.\n2. Dresser le tableau d'avancement du système en fonction de C, V, x_max et x_f.\n3. Calculer la concentration des ions oxonium [H3O+]_éq à l'équilibre.\n4. Déterminer l'avancement maximal x_max et l'avancement final x_f.\n5. Calculer le taux d'avancement final τ. La réaction est-elle totale ou limitée ?\n6. Positionner cette solution sur l'échelle de pH et le diagramme de prédominance (pKa = 4.8).",
      chartType = ScientificChartType.ECHELLE_PH_PREDOMINANCE,
      chartTitle = "Diagramme de prédominance du couple CH₃COOH / CH₃COO⁻",
      chartExploitation = "• pH mesuré : pH = 3.4 < 7.0 (milieu acide).\n• Comme pH = 3.4 < pKa = 4.8 : l'espèce acide CH₃COOH prédomine largement devant sa base conjuguée.\n• Taux d'avancement τ ≈ 4.0% << 100% : la réaction avec l'eau est très limitée.",
      hints = listOf(
        "Équation acido-basique : CH3COOH(aq) + H2O(l) ⇌ CH3COO-(aq) + H3O+(aq).",
        "Relation de définition du pH : [H3O+] = 10^(-pH).",
        "Avancement final : x_f = [H3O+]_éq · V. Avancement maximal : x_max = C · V.",
        "Taux d'avancement final : τ = x_f / x_max = [H3O+]_éq / C."
      ),
      solutionSteps = listOf(
        "Étape 1 : Équation de la réaction\nCH₃COOH(aq) + H₂O(l) ⇌ CH₃COO⁻(aq) + H₃O⁺(aq) (double flèche, équilibre chimique).",
        "Étape 2 : Tableau d'avancement\n• État initial : n(CH₃COOH) = C·V, Eau en excès, n(CH₃COO⁻) = 0, n(H₃O⁺) ≈ 0.\n• État final : n_f(CH₃COOH) = C·V - x_f, n_f(CH₃COO⁻) = x_f, n_f(H₃O⁺) = x_f.",
        "Étape 3 : Concentration en ions H₃O⁺ à l'équilibre\n[H₃O⁺]_éq = 10^(-pH) = 10^(-3.4) ≈ 3.98 × 10⁻⁴ mol/L.",
        "Étape 4 : Calcul de x_max et x_f\n• x_max = C · V = 1.0 × 10⁻² mol/L × 0.100 L = 1.0 × 10⁻³ mol = 1.0 mmol.\n• x_f = [H₃O⁺]_éq · V = 3.98 × 10⁻⁴ mol/L × 0.100 L = 3.98 × 10⁻⁵ mol ≈ 0.040 mmol.",
        "Étape 5 : Calcul du taux d'avancement final τ\nτ = x_f / x_max = (3.98 × 10⁻⁵ mol) / (1.0 × 10⁻³ mol) = 0.0398 ≈ 4.0%.\nComme τ < 1 (et même τ << 1), la dissociation de l'acide éthanoïque dans l'eau est très limitée : c'est un acide faible.",
        "Étape 6 : Prédominance\nSur le diagramme de prédominance ci-contre, le pKa du couple vaut 4.8. Le pH de la solution étant pH = 3.4 < pKa, la forme acide CH₃COOH prédomine nettement sur la forme éthanoate CH₃COO⁻."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Retenez bien que τ dépend de la concentration apportée : plus la solution est diluée, plus le taux d'avancement τ augmente (loi de dilution d'Ostwald) !"
    ),

    Exercise(
      id = "ex_distribution_c4",
      chapterId = "C4",
      title = "C4 · Exploitation d'un diagramme de distribution des espèces d'un acide carboxylique",
      subject = SubjectType.CHIMIE,
      statement = "Le graphe ci-contre représente le diagramme de distribution des formes acide HA et basique A⁻ d'un couple acido-basique en solution aqueuse en fonction du pH : α(HA) = [HA]/C et α(A⁻) = [A⁻]/C.\n1. Identifier en justifiant la courbe correspondant à l'acide HA et celle correspondant à la base A⁻.\n2. Déterminer graphiquement la valeur du pKa de ce couple.\n3. Pour un pH = 5.8, relever les pourcentages respectifs des espèces HA et A⁻.\n4. Exprimer la constante d'équilibre K de la réaction de l'acide avec l'eau et calculer sa valeur numérique.",
      chartType = ScientificChartType.DIAGRAMME_DISTRIBUTION_PKA,
      chartTitle = "Diagramme de distribution α(HA) et α(A⁻) et point de croisement pKa",
      chartExploitation = "• Courbe rouge décroissante : α(HA) passe de 100% à pH=0 vers 0% à pH élevé.\n• Courbe bleue croissante : α(A⁻) augmente avec le pH.\n• Point de croisement : à α(HA) = α(A⁻) = 50%, la projection donne immédiatement pKa = 4.8.\n• À pH = 5.8 (pKa + 1) : α(A⁻) = 90.9% et α(HA) = 9.1%.",
      hints = listOf(
        "En milieu très acide (pH faible), la forme acide HA est majoritaire (α ≈ 100%).",
        "À l'intersection des deux courbes : [HA] = [A⁻] <=> pH = pKa car log([A⁻]/[HA]) = log(1) = 0.",
        "Constante d'acidité : Ka = 10^(-pKa)."
      ),
      solutionSteps = listOf(
        "Étape 1 : Identification des courbes\n• À pH très faible (très acide), l'espèce acide est prépondérante : la courbe rouge qui part de 100% et décroît correspond donc à l'espèce acide HA : α(HA).\n• Inversement, lorsque le pH augmente, la forme basique est favorisée : la courbe bleue qui croît de 0% à 100% correspond à la base conjuguée A⁻ : α(A⁻).",
        "Étape 2 : Détermination graphique du pKa\nSelon la relation de Henderson-Hasselbalch : pH = pKa + log([A⁻]/[HA]).\nLorsque [HA] = [A⁻] (croisement des courbes à α = 50%), on a log(1) = 0, donc pH = pKa.\nSur le graphique ci-contre, les deux courbes se croisent exactement à l'abscisse :\npKa = 4.8.",
        "Étape 3 : Relevé à pH = 5.8\nPour pH = 5.8 = pKa + 1, on projette verticalement sur les deux courbes :\n• Sur la courbe bleue de la base : α(A⁻) ≈ 91% (exactement 90.9%).\n• Sur la courbe rouge de l'acide : α(HA) ≈ 9% (exactement 9.1%).\nLa forme basique prédomine très largement.",
        "Étape 4 : Calcul de la constante Ka\nKa = 10^(-pKa) = 10^(-4.8) = 1.58 × 10⁻⁵."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Touchez le point d'intersection des deux courbes avec le curseur interactif pour vérifier directement les coordonnées (pH = 4.80, α = 50.0%) !"
    ),

    Exercise(
      id = "ex_pile_c6",
      chapterId = "C6",
      title = "C6 · Étude complète et bilan quantitatif de la pile Daniell Zinc - Cuivre",
      subject = SubjectType.CHIMIE,
      statement = "On réalise la pile Daniell constituée d'une lame de zinc plongeant dans V_1 = 100 mL de sulfate de zinc (Zn²⁺ + SO₄²⁻) à C_1 = 0.10 mol/L et d'une lame de cuivre plongeant dans V_2 = 100 mL de sulfate de cuivre (Cu²⁺ + SO₄²⁻) à C_2 = 0.10 mol/L. Les deux demi-piles sont reliées par un pont salin au nitrate de potassium (K⁺ + NO₃⁻). La constante d'équilibre associée à la réaction d'oxydoréduction est K = 10⁴⁷.\n1. Calculer le quotient de réaction initial Q_r,i et prévoir le sens d'évolution spontanée.\n2. Écrire les équations aux électrodes en précisant l'anode et la cathode.\n3. Donner le schéma conventionnel de la pile.\n4. La pile débite un courant constant I = 100 mA pendant une durée Δt = 2 h 00 min. Calculer la quantité d'électricité Q débitée, l'avancement x de la réaction et la variation de masse Δm de l'électrode de zinc (F = 96 500 C/mol, M(Zn) = 65.4 g/mol).",
      chartType = ScientificChartType.MONTAGE_PILE_DANIELL,
      chartTitle = "Schéma conventionnel et expérimental de la pile Daniell (Zn - Cu)",
      chartExploitation = "• Anode (-) en Zinc : siège de l'oxydation Zn → Zn²⁺ + 2e⁻ (perte de masse Δm = -0.244 g).\n• Cathode (+) en Cuivre : siège de la réduction Cu²⁺ + 2e⁻ → Cu (gain de masse).\n• Électrons e⁻ circulant du (-) vers le (+) dans le circuit extérieur, courant I en sens inverse.\n• Pont salin : migration des anions NO₃⁻ vers l'anode et des cations K⁺ vers la cathode.",
      hints = listOf(
        "Quotient de réaction initial : Q_r,i = [Zn²⁺]_i / [Cu²⁺]_i = C_1 / C_2 = 1.",
        "Critère d'évolution spontanée : Q_r,i = 1 << K = 10⁴⁷ => évolution dans le sens direct.",
        "Quantité d'électricité : Q = I · Δt = n(e⁻) · F avec Δt en secondes (2 h = 7200 s).",
        "Pour le zinc : chaque atome de Zn oxydé libère 2 électrons, donc n(Zn consommé) = n(e⁻) / 2 = x."
      ),
      solutionSteps = listOf(
        "Étape 1 : Quotient initial et sens spontané\nQ_r,i = [Zn²⁺]_i / [Cu²⁺]_i = 0.10 / 0.10 = 1.0.\nComme Q_r,i << K (1 << 10⁴⁷), le système évolue spontanément dans le sens direct : Zn(s) + Cu²⁺(aq) ⟶ Zn²⁺(aq) + Cu(s).",
        "Étape 2 : Réactions aux électrodes\n• Anode (pôle négatif - oxydation) : Zn(s) ⟶ Zn²⁺(aq) + 2e⁻.\n• Cathode (pôle positif - réduction) : Cu²⁺(aq) + 2e⁻ ⟶ Cu(s).",
        "Étape 3 : Schéma conventionnel\n(-) Zn(s) | Zn²⁺(aq) || Cu²⁺(aq) | Cu(s) (+).",
        "Étape 4 : Bilan quantitatif de la décharge\n• Durée : Δt = 2 × 3600 s = 7200 s.\n• Quantité d'électricité : Q = I · Δt = 0.100 A × 7200 s = 720 C.\n• Quantité d'électrons échangés : n(e⁻) = Q / F = 720 / 96500 ≈ 7.46 × 10⁻³ mol.\n• Avancement de la réaction : x = n(e⁻) / 2 = 7.46 × 10⁻³ / 2 = 3.73 × 10⁻³ mol.\n• Variation de masse de l'électrode de zinc :\nΔm(Zn) = - x · M(Zn) = - 3.73 × 10⁻³ mol × 65.4 g/mol ≈ - 0.244 g (perte de 244 mg)."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Mémorisez l'astuce mnémotechnique : Anode commence par une voyelle comme Oxydation ; Cathode commence par une consonne comme Réduction !"
    ),

    Exercise(
      id = "ex_electrolyse_c7",
      chapterId = "C7",
      title = "C7 · Électrolyse d'une solution de bromure de cuivre II (Transformations forcées)",
      subject = SubjectType.CHIMIE,
      statement = "On réalise l'électrolyse d'une solution aqueuse de bromure de cuivre II (Cu²⁺ + 2Br⁻) à l'aide de deux électrodes de graphite reliées à un générateur de courant continu G débitant une intensité I = 0.50 A pendant Δt = 30 minutes. À l'anode, on observe un dégagement de dibrome Br2(aq) ; à la cathode, un dépôt de cuivre métallique rouge se forme.\n1. Pourquoi s'agit-il d'une transformation forcée ?\n2. Écrire les demi-équations électroniques aux électrodes et l'équation globale de l'électrolyse.\n3. Calculer la quantité d'électricité Q ayant traversé la cellule.\n4. Déterminer la masse m de cuivre déposée à la cathode.\n5. Déterminer le volume V(Br2) ou la quantité de dibrome formé à l'anode (F = 96 500 C/mol, M(Cu) = 63.5 g/mol).",
      chartType = ScientificChartType.MONTAGE_ELECTROLYSE,
      chartTitle = "Montage expérimental de l'électrolyse et réactions aux électrodes",
      chartExploitation = "• Anode (+) reliée à la borne positive du générateur : oxydation anodique 2Br⁻ → Br₂ + 2e⁻.\n• Cathode (-) reliée à la borne négative : réduction cathodique Cu²⁺ + 2e⁻ → Cu.\n• Quantité d'électricité : Q = I · Δt = 900 C.\n• Masse de cuivre déposée : m(Cu) = 0.296 g.",
      hints = listOf(
        "Une transformation forcée nécessite un apport d'énergie électrique extérieur d'un générateur pour s'effectuer dans le sens contraire de son sens spontané.",
        "Anode = pôle positif (+) en électrolyse (relié à la borne + du générateur) : siège de l'oxydation.",
        "Cathode = pôle négatif (-) en électrolyse : siège de la réduction.",
        "Relation fondamentale : n(e⁻) = (I · Δt) / F et n(Cu) = n(e⁻) / 2."
      ),
      solutionSteps = listOf(
        "Étape 1 : Notion de transformation forcée\nLa réaction spontanée entre le cuivre et le dibrome a une constante d'équilibre très élevée : Cu + Br₂ ⟶ Cu²⁺ + 2Br⁻. L'électrolyse force la réaction inverse grâce à l'apport continu d'énergie électrique du générateur G.",
        "Étape 2 : Équations aux électrodes\n• À l'anode (reliée au pôle + du générateur - oxydation) : 2Br⁻(aq) ⟶ Br₂(aq) + 2e⁻.\n• À la cathode (reliée au pôle - du générateur - réduction) : Cu²⁺(aq) + 2e⁻ ⟶ Cu(s).\n• Équation bilan globale : Cu²⁺(aq) + 2Br⁻(aq) ⟶ Cu(s) + Br₂(aq).",
        "Étape 3 : Quantité d'électricité Q\nΔt = 30 min = 30 × 60 s = 1800 s.\nQ = I · Δt = 0.50 A × 1800 s = 900 C.",
        "Étape 4 : Masse de cuivre déposée à la cathode\nQuantité d'électrons : n(e⁻) = Q / F = 900 / 96500 ≈ 9.326 × 10⁻³ mol.\nSelon la demi-équation cathodique : n(Cu) = n(e⁻) / 2 = 4.663 × 10⁻³ mol.\nMasse de cuivre déposée : m(Cu) = n(Cu) · M(Cu) = 4.663 × 10⁻³ mol × 63.5 g/mol ≈ 0.296 g (296 mg).",
        "Étape 5 : Quantité de dibrome formée\nSelon la demi-équation anodique : n(Br₂) = n(e⁻) / 2 = 4.663 × 10⁻³ mol ≈ 4.66 mmol."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Attention au piège classique de polarité : dans une pile, l'anode est le pôle négatif (-), alors que dans une électrolyse, l'anode est reliée au pôle positif (+) du générateur !"
    ),

    Exercise(
      id = "ex_esterification_c8",
      chapterId = "C8",
      title = "C8 · Synthèse de l'éthanoate d'éthyle par chauffage à reflux et calcul du rendement",
      subject = SubjectType.CHIMIE,
      statement = "Dans un ballon, on introduit un mélange équimolaire constitué de n_1 = 1.0 mol d'acide éthanoïque CH3COOH et n_2 = 1.0 mol d'éthanol CH3-CH2-OH, ainsi que quelques gouttes d'acide sulfurique concentré H2SO4 et quelques grains de pierre ponce. On chauffe à reflux le mélange réactionnel pendant 2 heures.\n1. Quel est le rôle du chauffage à reflux ? Pourquoi utilise-t-on un réfrigérant à boules ?\n2. Quel est le rôle de l'acide sulfurique et de la pierre ponce ?\n3. Écrire l'équation de la réaction en précisant le nom et la formule semi-développée de l'ester formé.\n4. À l'équilibre, le dosage de l'acide restant montre qu'il reste n_acide(éq) = 0.33 mol. Déterminer l'avancement final x_f, la constante d'équilibre K et le rendement r de la synthèse.",
      chartType = ScientificChartType.MONTAGE_CHAUFFAGE_REFLUX,
      chartTitle = "Dispositif expérimental du montage de chauffage à reflux",
      chartExploitation = "• Rôle du chauffe-ballon : élève la température pour accélérer la cinétique réactionnelle.\n• Rôle du réfrigérant à boules : condense les vapeurs organiques qui retombent sous forme de gouttelettes dans le ballon.\n• Objectif : accélérer la réaction sans aucune perte de réactif ni de produit !",
      hints = listOf(
        "Chauffage à reflux : permet d'augmenter la température pour accélérer la réaction sans perte de matière par évaporation.",
        "L'acide sulfurique H2SO4 est un catalyseur (accélère sans modifier l'état d'équilibre final).",
        "La pierre ponce régule l'ébullition en homogénéisant la formation des bulles.",
        "Rendement pour un mélange équimolaire : r = x_f / x_max avec x_max = 1.0 mol."
      ),
      solutionSteps = listOf(
        "Étape 1 : Rôle du montage de chauffage à reflux\n• Le chauffage augmente la température du milieu réactionnel, ce qui accroît la vitesse de la réaction (facteur cinétique).\n• Le réfrigérant à boules refroidit les vapeurs formées qui se condensent et retombent dans le ballon : cela évite toute perte de matière de réactifs ou d'ester volatil.",
        "Étape 2 : Rôle des additifs\n• L'acide sulfurique concentré apporte des ions H⁺ qui catalysent la réaction (accélération sans modifier la composition à l'équilibre).\n• La pierre ponce régule l'ébullition et assure un bouillonnement régulier et homogène.",
        "Étape 3 : Équation de la réaction\nCH₃-COOH + CH₃-CH₂-OH ⇌ CH₃-COO-CH₂-CH₃ + H₂O.\nNom de l'ester : éthanoate d'éthyle (odeur fruitée de pomme).",
        "Étape 4 : Bilan quantitatif et constante d'équilibre K\n• n_acide(éq) = n_1 - x_f = 0.33 mol => x_f = 1.0 - 0.33 = 0.67 mol.\n• À l'équilibre : n(alcool) = 0.33 mol, n(ester) = 0.67 mol, n(eau) = 0.67 mol.\n• Constante d'équilibre : K = [ester]·[eau] / ([acide]·[alcool]) = (0.67 × 0.67) / (0.33 × 0.33) = (0.67 / 0.33)² ≈ 4.1 ≈ 4.0.\n• Rendement : r = x_f / x_max = 0.67 / 1.0 = 67% (valeur caractéristique des alcools primaires en mélange équimolaire)."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Retenez les trois rendements officiels à l'équilibre pour un mélange équimolaire : 67% pour un alcool primaire, 60% pour un alcool secondaire, et seulement 5% pour un alcool tertiaire !"
    ),

    Exercise(
      id = "ex_saponification_c9",
      chapterId = "C9",
      title = "C9 · Optimisation de la synthèse d'un ester et fabrication industrielle du savon",
      subject = SubjectType.CHIMIE,
      statement = "La courbe ci-contre compare l'évolution temporelle de la quantité d'ester formé lors d'une estérification classique et celle lors de l'hydrolyse d'un ester.\n1. Quelles sont les caractéristiques de la réaction d'estérification classique ?\n2. Citer deux méthodes permettant d'améliorer le rendement d'une estérification sans changer la nature des réactifs.\n3. Comment peut-on obtenir une réaction rapide et totale (rendement 100%) en modifiant l'un des réactifs ?\n4. Définir la réaction de saponification et écrire l'équation de fabrication d'un savon à partir du trioléate de glycéryle (oléine) et de l'hydroxyde de sodium.",
      chartType = ScientificChartType.CINETIQUE_ESTERIFICATION_HYDROLYSE,
      chartTitle = "Cinétiques comparées estérification / hydrolyse et équilibre dynamique",
      chartExploitation = "• Estérification classique (courbe verte) : asymptotique à n_ester = 0.67 mol (rendement limité à 67%).\n• Hydrolyse inverse (courbe rouge) : converge vers le même état d'équilibre n_ester = 0.67 mol.\n• Utilisation d'un anhydride d'acide : réaction totale (r = 100%) sans formation d'eau.\n• Saponification : hydrolyse basique rapide et totale produisant le savon.",
      hints = listOf(
        "Estérification classique : lente, limitée par l'hydrolyse inverse, et athermique.",
        "Pour déplacer l'équilibre (loi de Le Chatelier) : excès de l'un des réactifs ou élimination de l'eau formée par distillation (Dean-Stark).",
        "Remplacement de l'acide par son anhydride : réaction rapide et totale.",
        "Saponification d'un triglycéride : triglycéride + 3 HO- -> glycérol + 3 ions carboxylates (savon)."
      ),
      solutionSteps = listOf(
        "Étape 1 : Caractéristiques de l'estérification\nL'estérification par un acide carboxylique est une réaction lente, limitée par la réaction inverse d'hydrolyse, et athermique (ΔH ≈ 0, la température ne modifie pas la constante K).",
        "Étape 2 : Méthodes d'amélioration du rendement\n• Utiliser l'un des réactifs en excès (par exemple un excès d'acide carboxylique).\n• Éliminer l'un des produits au fur et à mesure de sa formation (distillation de l'ester ou élimination de l'eau avec un appareil de Dean-Stark), ce qui déplace l'équilibre dans le sens direct.",
        "Étape 3 : Remplacement par un anhydride d'acide\nEn remplaçant l'acide carboxylique par un anhydride d'acide (R-CO-O-CO-R), la réaction devient rapide et totale (rendement 100%). De plus, elle ne forme pas d'eau mais un acide carboxylique comme sous-produit, ce qui empêche totalement l'hydrolyse inverse.",
        "Étape 4 : Saponification et fabrication du savon\nLa saponification est l'hydrolyse basique d'un ester par les ions hydroxyde HO⁻ : elle est rapide et totale.\nPour l'oléine (triglycéride de l'acide oléique C₁₇H₃₃-COOH) :\n(C₁₇H₃₃-COO)₃-C₃H₅ + 3(Na⁺ + HO⁻) ⟶ 3(C₁₇H₃₃-COO⁻ + Na⁺) + C₃H₅(OH)₃\nLe produit formé est l'oléate de sodium (savon) et le propane-1,2,3-triol (glycérol)."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Retenez bien la structure amphiphile du savon : une longue chaîne carbonée hydrophobe (lipophile) qui piège les graisses, et une tête carboxylate hydrophile soluble dans l'eau formant des micelles !"
    ),

    Exercise(
      id = "ex_catalyse_c10",
      chapterId = "C10",
      title = "C10 · Contrôle par catalyse et sélectivité réactionnelle en chimie organique",
      subject = SubjectType.CHIMIE,
      statement = "On étudie la cinétique de dismutation du peroxyde d'hydrogène H2O2 selon l'équation : 2 H2O2(aq) -> 2 H2O(l) + O2(g). Cette réaction est très lente à température ambiante en l'absence de catalyseur.\n1. Définir ce qu'est un catalyseur et préciser ses deux caractéristiques thermodynamiques majeures.\n2. On ajoute quelques gouttes d'une solution de chlorure de fer III (Fe3+ + 3 Cl-) : la solution devient orange puis effervescente. De quel type de catalyse s'agit-il ? Justifier.\n3. Si l'on introduit à la place un fil de platine solide Pt, de quel type de catalyse s'agit-il ?\n4. Expliquer le rôle de la sélectivité catalytique dans l'orientation d'une synthèse industrielle.",
      chartType = ScientificChartType.FACTEURS_CINETIQUES_TEMPERATURE,
      chartTitle = "Effet catalytique sur la cinétique de décomposition : x = f(t)",
      chartExploitation = "• Sans catalyseur : réaction quasiment figée à 20°C (pente nulle dx/dt ≈ 0).\n• Avec catalyseur (Fe³⁺ ou platine) : très forte pente initiale et dégagement gazeux immédiat de dioxygène O₂.\n• L'état final et la quantité d'O₂ dégagée restent exactement les mêmes (aucun effet sur K).",
      hints = listOf(
        "Un catalyseur accélère une réaction sans être consommé et sans modifier l'état d'équilibre thermodynamique.",
        "Catalyse homogène : réactifs et catalyseur dans la même phase (solution aqueuse).",
        "Catalyse hétérogène : catalyseur solide et réactifs liquides ou gazeux.",
        "Sélectivité : un catalyseur sélectif favorise une seule réaction parmi plusieurs possibles."
      ),
      solutionSteps = listOf(
        "Étape 1 : Définition et propriétés thermodynamiques\nUn catalyseur est une substance chimique qui accélère une transformation spontanée sans être consommée (il est régénéré à la fin) et sans figurer dans l'équation bilan globale.\nPropriétés fondamentales : il n'apparaît pas dans la constante d'équilibre K et ne modifie ni l'état d'équilibre final x_f, ni le sens d'évolution spontanée.",
        "Étape 2 : Catalyse homogène avec Fe³⁺\nLes ions Fe³⁺ et la solution aqueuse d'eau oxygénée constituent une seule et unique phase liquide homogène : il s'agit donc d'une catalyse homogène.",
        "Étape 3 : Catalyse hétérogène avec le platine\nLe platine solide Pt forme une phase solide distincte de la phase liquide de H₂O₂ : il s'agit d'une catalyse hétérogène (les molécules de H₂O₂ s'adsorbent à la surface du métal où les liaisons sont fragilisées).",
        "Étape 4 : Sélectivité catalytique\nEn chimie industrielle et pharmaceutique, certains réactifs peuvent réagir selon plusieurs voies concurrentes. Un catalyseur sélectif permet d'accélérer préférentiellement la réaction menant au produit d'intérêt recherché sans activer les réactions secondaires parasites, améliorant ainsi la pureté et l'économie d'atomes."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Retenez bien la différence d'examen : le catalyseur modifie la cinétique (la vitesse et la durée), mais JAMAIS la thermodynamique (l'avancement final x_f ou le quotient d'équilibre K) !"
    ),

    Exercise(
      id = "ex_ondes_p2",
      chapterId = "P2",
      title = "P2 · Diffraction d'une onde mécanique sinusoïdale à la surface de l'eau",
      subject = SubjectType.PHYSIQUE,
      statement = "Un vibreur de fréquence N = 40 Hz génère à la surface d'une cuve à ondes une onde progressive sinusoïdale de célérité v = 0.40 m/s. L'onde rencontre un diaphragme muni d'une fente rectiligne de largeur a.\n1. Calculer la longueur d'onde λ de cette onde.\n2. Pour quelles valeurs de la largeur a de l'ouverture le phénomène de diffraction est-il nettement observable ?\n3. Décrire l'aspect des lignes d'ondes avant et après la traversée de la fente lorsque a ≤ λ.\n4. La fréquence et la célérité de l'onde sont-elles modifiées par la diffraction ?",
      chartType = ScientificChartType.ONDE_CORDE_ASPECT,
      chartTitle = "Diffraction d'ondes mécaniques dans une cuve à ondes",
      chartExploitation = "• Longueur d'onde : λ = v / N = 0.40 / 40 = 0.010 m = 1.0 cm.\n• Condition de diffraction : ouverture de largeur a ≤ λ (soit a ≤ 1.0 cm).\n• Ondes incidentes rectilignes devenant quasi-circulaires centrées sur la fente après l'obstacle.\n• Invariance : la fréquence N et la célérité v restent rigoureusement identiques.",
      hints = listOf(
        "Relation fondamentale : λ = v / N = v · T.",
        "Le phénomène de diffraction est d'autant plus marqué que la largeur de l'ouverture a est inférieure ou de l'ordre de la longueur d'onde λ.",
        "La diffraction ne modifie pas les propriétés intrinsèques de l'onde (fréquence et célérité restent inchangées)."
      ),
      solutionSteps = listOf(
        "Étape 1 : Calcul de la longueur d'onde λ\nλ = v / N = (0.40 m/s) / (40 s⁻¹) = 0.010 m = 1.0 cm.",
        "Étape 2 : Condition de diffraction\nLe phénomène de diffraction se manifeste nettement lorsque la largeur de l'ouverture a est inférieure ou du même ordre de grandeur que la longueur d'onde, soit : a ≤ λ (a ≤ 1.0 cm).",
        "Étape 3 : Aspect géométrique des ondes\nAvant la fente, les lignes d'onde sont rectilignes et parallèles. Après la fente de largeur a ≤ λ, les ondes diffractées adoptent une structure circulaire centrée sur le milieu de la fente, s'épanouissant dans toute la région située en arrière de l'obstacle.",
        "Étape 4 : Conservation de la fréquence et de la célérité\nL'onde diffractée conserve exactement la même fréquence N = 40 Hz (imposée par le vibreur source) et la même célérité v = 0.40 m/s (car le milieu de propagation reste l'eau à même profondeur)."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Si l'ouverture est très grande (a >> λ), l'onde passe sans déformation notable, comme un faisceau géométrique !"
    ),

    Exercise(
      id = "ex_ondes_p3",
      chapterId = "P3",
      title = "P3 · Diffraction d'un faisceau laser par un fil calibré et mesure de longueur d'onde",
      subject = SubjectType.PHYSIQUE,
      statement = "On éclaire une fente fine verticale de largeur a = 0.10 mm à l'aide d'un faisceau laser monochromatique de longueur d'onde λ inconnue. Sur un écran situé à une distance D = 2.0 m de la fente, on observe une figure de diffraction. La largeur de la tache centrale de diffraction est L = 2.6 cm.\n1. Exprimer l'écart angulaire θ en fonction de λ et a.\n2. Exprimer θ en fonction de la largeur L de la tache centrale et de la distance D (en supposant θ petit).\n3. Établir l'expression littérale de λ en fonction de a, L et D, puis calculer sa valeur en nanomètres (nm).\n4. Quelle est la couleur du faisceau laser utilisé ?",
      chartType = ScientificChartType.DIFFRACTION_FENTE,
      chartTitle = "Figure de diffraction laser et profil d'intensité lumineuse",
      chartExploitation = "• Relation angulaire : θ = λ / a ≈ (L / 2) / D = L / (2D).\n• Longueur d'onde : λ = (a · L) / (2D) = (0.10 × 10^-3 × 0.026) / (2 × 2.0) = 6.50 × 10^-7 m = 650 nm.\n• Faisceau laser rouge (domaine visible 600 - 700 nm).",
      hints = listOf(
        "Formule de diffraction : θ = λ / a avec θ en radians.",
        "Géométrie : tan(θ) ≈ θ = (L / 2) / D = L / (2 · D).",
        "Égaler les deux expressions de θ pour isoler λ."
      ),
      solutionSteps = listOf(
        "Étape 1 : Écart angulaire théorique\nL'écart angulaire du demi-faisceau diffracté est donné par : θ = λ / a (avec λ et a dans la même unité).",
        "Étape 2 : Relation géométrique\nDans le triangle rectangle formé par le centre de la fente, le centre de la tache et son extrémité : tan(θ) = (L / 2) / D.\nComme θ est très petit (θ << 1 rad), on a tan(θ) ≈ θ, d'où : θ = L / (2 · D).",
        "Étape 3 : Calcul de la longueur d'onde λ\nOn en déduit : λ / a = L / (2 · D) ⟺ λ = (a · L) / (2 · D).\nApplication numérique :\nλ = (0.10 × 10⁻³ m × 2.6 × 10⁻² m) / (2 × 2.0 m) = 6.50 × 10⁻⁷ m = 650 nm.",
        "Étape 4 : Couleur du laser\nUne radiation de 650 nm appartient au domaine visible et correspond à une lumière rouge (faisceau laser He-Ne ou diode rouge)."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Attention aux unités ! Convertissez impérativement a, L et D en mètres avant de faire le calcul de λ !"
    ),

    Exercise(
      id = "ex_nucleaire_p5",
      chapterId = "P5",
      title = "P5 · Bilan de masse et énergie libérée lors de la fission de l'Uranium 235",
      subject = SubjectType.PHYSIQUE,
      statement = "Dans un réacteur nucléaire, un neutron thermique provoque la fission d'un noyau d'uranium 235 selon l'équation :\n¹n + ²³⁵U ⟶ ⁹⁴Sr + ¹³⁹Xe + 3 ¹n.\nDonnées : m(²³⁵U) = 234.9935 u ; m(⁹⁴Sr) = 93.8945 u ; m(¹³⁹Xe) = 138.8892 u ; m(¹n) = 1.0087 u ; 1 u = 931.5 MeV/c².\n1. Vérifier les lois de conservation de Soddy (charge et nombre de nucléons).\n2. Calculer en unité de masse atomique (u) la variation de masse Δm du système.\n3. En déduire en MeV l'énergie libérée |E_lib| par la fission d'un noyau d'uranium 235.\n4. Calculer l'énergie libérée par la fission complète d'un échantillon de masse m = 1.0 g d'uranium 235 en Joules (1 eV = 1.602 × 10⁻¹⁹ J).",
      chartType = ScientificChartType.DECROISSANCE_RADIOACTIVE,
      chartTitle = "Diagramme énergétique de la réaction de fission induite",
      chartExploitation = "• Défaut de masse : Δm = [m(Sr) + m(Xe) + 3m(n)] - [m(U) + m(n)] = -0.1924 u.\n• Énergie libérée par noyau : E_lib = |Δm| × 931.5 = 179.2 MeV.\n• Énergie pour 1.0 g : N = (m / M) × N_A = 2.56 × 10^21 noyaux ⟹ E_totale ≈ 7.35 × 10^10 J (équivalent à plus de 2 tonnes de pétrole) !",
      hints = listOf(
        "Lois de Soddy : conservation du nombre de masse A et du nombre de charge Z.",
        "Variation de masse : Δm = Σ m(produits) - Σ m(réactifs).",
        "Énergie libérée : E_lib = |Δm| · c² avec 1 u · c² = 931.5 MeV.",
        "Nombre de noyaux : N = (m / M) · N_A."
      ),
      solutionSteps = listOf(
        "Étape 1 : Lois de Soddy\n• Nucléons A : 1 + 235 = 236 et 94 + 139 + 3×1 = 236 (conservé).\n• Charges Z : 0 + 92 = 92 et 38 + 54 + 3×0 = 92 (conservé).",
        "Étape 2 : Variation de masse Δm\nΔm = [m(⁹⁴Sr) + m(¹³⁹Xe) + 2·m(¹n)] - m(²³⁵U)\nΔm = [93.8945 + 138.8892 + 2×1.0087] - 234.9935 = -0.1924 u.\nLe système a perdu de la masse, celle-ci est convertie en énergie rayonnée et cinétique.",
        "Étape 3 : Énergie libérée par fission\nE_lib = |Δm| · c² = 0.1924 u × 931.5 MeV/u = 179.22 MeV.",
        "Étape 4 : Énergie pour 1.0 g d'uranium 235\nNombre de noyaux dans 1.0 g :\nN = (1.0 g / 235 g·mol⁻¹) × 6.022 × 10²³ mol⁻¹ = 2.563 × 10²¹ noyaux.\nÉnergie totale libérée :\nE_tot = N × 179.22 MeV = 4.59 × 10²³ MeV = 4.59 × 10²⁹ eV.\nEn Joules : E_tot = 4.59 × 10²⁹ × 1.602 × 10⁻¹⁹ J = 7.35 × 10¹⁰ J ≈ 73.5 GJ."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : 1 gramme d'uranium 235 libère autant d'énergie que la combustion de 2.5 tonnes de charbon ! C'est la puissance de l'équivalence masse-énergie d'Einstein E = mc²."
    ),

    Exercise(
      id = "ex_rl_p7",
      chapterId = "P7",
      title = "P7 · Établissement du courant dans un circuit RL et constante de temps",
      subject = SubjectType.PHYSIQUE,
      statement = "Un circuit série comporte une bobine d'inductance L et de résistance interne r = 10 Ω, un conducteur ohmique de résistance R = 40 Ω et un générateur de tension continue E = 10.0 V. À t = 0, on ferme l'interrupteur. Le système d'acquisition enregistre la tension u_R(t) aux bornes du conducteur ohmique.\n1. Établir l'équation différentielle régissant l'évolution du courant i(t) dans le circuit.\n2. Exprimer l'intensité maximale I_0 en régime permanent et calculer sa valeur numérique.\n3. Exprimer la constante de temps τ du dipôle RL. Sachant que la tangente à l'origine coupe l'asymptote horizontale à t = 5.0 ms, déterminer la valeur de l'inductance L de la bobine.",
      chartType = ScientificChartType.RL_ETABLISSEMENT,
      chartTitle = "Établissement du courant i(t) et tangente à l'origine",
      chartExploitation = "• Régime permanent : I_0 = E / (R + r) = 10.0 / (40 + 10) = 0.20 A (soit u_Rmax = R · I_0 = 8.0 V).\n• Constante de temps τ = L / R_total = 5.0 ms.\n• Inductance déduite : L = τ · (R + r) = (5.0 × 10^-3) × 50 = 0.25 H = 250 mH.",
      hints = listOf(
        "Loi d'additivité des tensions : u_b(t) + u_R(t) = E avec u_b = L · (di/dt) + r · i.",
        "En régime permanent, le courant est constant : di/dt = 0, donc u_b = r · I_0.",
        "Constante de temps : τ = L / (R + r)."
      ),
      solutionSteps = listOf(
        "Étape 1 : Équation différentielle en i(t)\nLoi des mailles : u_b(t) + u_R(t) = E\nOr u_b = L·(di/dt) + r·i et u_R = R·i.\nDonc : L·(di/dt) + (R + r)·i = E ⟺ (di/dt) + [(R + r)/L]·i = E/L.",
        "Étape 2 : Intensité maximale I_0\nEn régime permanent, le courant est constant donc di/dt = 0.\nL'équation différentielle devient : (R + r)·I_0 = E ⟺ I_0 = E / (R + r).\nAN : I_0 = 10.0 V / (40 + 10 Ω) = 0.20 A = 200 mA.",
        "Étape 3 : Constante de temps τ et inductance L\nPar identification, la constante de temps est : τ = L / (R + r).\nGraphiquement, l'abscisse du point d'intersection de la tangente à l'origine avec l'asymptote donne τ = 5.0 ms = 5.0 × 10⁻³ s.\nOn en déduit l'inductance de la bobine :\nL = τ · (R + r) = 5.0 × 10⁻³ s × 50 Ω = 0.25 H = 250 mH."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : La bobine s'oppose à l'établissement instantané du courant par son phénomène d'auto-induction : à t = 0, i(0) = 0 !"
    ),

    Exercise(
      id = "ex_modulation_p9",
      chapterId = "P9",
      title = "P9 · Modulation d'amplitude AM et analyse du taux de modulation m",
      subject = SubjectType.PHYSIQUE,
      statement = "Pour transmettre un signal informatif sonore basse fréquence s(t) = S_m · cos(2π·f_s·t), on utilise une porteuse haute fréquence p(t) = P_m · cos(2π·F_p·t). Le signal modulé s_m(t) obtenu est visualisé à l'oscilloscope avec sa courbe enveloppe.\n1. Quelles sont les deux conditions indispensables pour éviter le phénomène d'inversion de phase (surmodulation) ?\n2. L'oscilloscope affiche une tension maximale U_max = 6.0 V et une tension minimale U_min = 2.0 V. Calculer le taux de modulation m.\n3. La modulation est-elle de bonne qualité ? Justifier.",
      chartType = ScientificChartType.MODULATION_AM_TRAPEZE,
      chartTitle = "Signal modulé en amplitude s_m(t) et trapèze de modulation",
      chartExploitation = "• Taux de modulation : m = (U_max - U_min) / (U_max + U_min) = (6.0 - 2.0) / (6.0 + 2.0) = 4.0 / 8.0 = 0.50.\n• Comme m = 0.50 < 1, il n'y a pas de surmodulation.\n• Fréquence de la porteuse F_p >> f_s (au moins 10 fois supérieure).",
      hints = listOf(
        "Condition 1 sur les fréquences : F_p >> f_s (au moins F_p ≥ 10 · f_s).",
        "Condition 2 sur les tensions : m = S_m / U_0 < 1 avec U_0 la composante continue de décalage.",
        "Relation expérimentale : m = (U_max - U_min) / (U_max + U_min)."
      ),
      solutionSteps = listOf(
        "Étape 1 : Conditions de bonne modulation\n1. La fréquence de la porteuse doit être très supérieure à la fréquence du signal modulé : F_p ≥ 10 · f_s.\n2. La composante continue de décalage U_0 doit être strictement supérieure à l'amplitude du signal informatif S_m, soit : m = S_m / U_0 < 1.",
        "Étape 2 : Calcul du taux de modulation m\nÀ partir de la courbe enveloppe de l'oscillogramme :\nm = (U_max - U_min) / (U_max + U_min) = (6.0 - 2.0) / (6.0 + 2.0) = 4.0 / 8.0 = 0.50.",
        "Étape 3 : Qualité de la modulation\nPuisque m = 0.50 < 1, l'enveloppe du signal modulé ne coupe jamais l'axe horizontal : il n'y a pas d'inversion de phase (pas de surmodulation). La modulation est donc d'excellente qualité et le signal sonore d'origine pourra être fidèlement restitué par détection d'enveloppe."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : En mode XY, une bonne modulation produit un trapèze régulier. Si m = 1, on obtient un triangle, et si m > 1, deux triangles tête-bêche croisés (surmodulation défectueuse) !"
    ),

    Exercise(
      id = "ex_mvt_plan_p12",
      chapterId = "P12",
      title = "P12 · Mouvement d'un projectile dans le champ de pesanteur uniforme",
      subject = SubjectType.PHYSIQUE,
      statement = "Un ballon est frappé depuis l'origine O au niveau du sol avec une vitesse initiale v_0 = 20 m/s faisant un angle α = 45° avec l'horizontale. On néglige la résistance de l'air. On prend g = 9.80 m/s².\n1. En appliquant la 2ème loi de Newton, établir les équations horaires x(t) et y(t) du mouvement du centre d'inertie du ballon.\n2. Établir l'équation cartésienne de la trajectoire y = f(x).\n3. Déterminer la hauteur maximale (flèche H) atteinte par le ballon.\n4. Calculer la portée horizontale X_P du tir lorsque le ballon retombe au sol (y = 0).",
      chartType = ScientificChartType.PROJECTILE_PARABOLE,
      chartTitle = "Trajectoire parabolique y = f(x) du ballon et vecteur vitesse",
      chartExploitation = "• Flèche maximale : H = (v_0^2 · sin^2(α)) / (2g) = (400 × 0.5) / 19.6 = 10.2 m.\n• Portée : X_P = (v_0^2 · sin(2α)) / g = (400 × 1.0) / 9.80 = 40.8 m.\n• Sommet de la parabole atteint à t_S = 1.44 s avec composante v_y = 0.",
      hints = listOf(
        "Deuxième loi de Newton : Σ F = m · a_G ⟹ P = m · g ⟹ a_G = g.",
        "Projections sur les axes (Ox horizontal, Oy vertical ascendant) : a_x = 0 et a_y = -g.",
        "Au sommet de la trajectoire, la composante verticale de la vitesse s'annule : v_y(t_S) = 0."
      ),
      solutionSteps = listOf(
        "Étape 1 : Équations horaires\nSystème : {Ballon}, Référentiel terrestre supposé galiléen.\nBilan des forces : P = m·g (poids seul).\n2ème loi de Newton : a_G = g.\nProjections :\n• a_x = 0 ⟹ v_x(t) = v_0·cos(α) ⟹ x(t) = (v_0·cos α)·t\n• a_y = -g ⟹ v_y(t) = -g·t + v_0·sin(α) ⟹ y(t) = -1/2·g·t² + (v_0·sin α)·t.",
        "Étape 2 : Équation de la trajectoire\nDe x(t), on tire t = x / (v_0·cos α). En injectant dans y(t) :\ny(x) = - [g / (2·v_0²·cos² α)] · x² + (tan α) · x.\nC'est l'équation d'une parabole à concavité tournée vers le bas.",
        "Étape 3 : Flèche H (hauteur maximale)\nAu sommet S : v_y = 0 ⟺ -g·t_S + v_0·sin α = 0 ⟺ t_S = (v_0·sin α) / g.\nEn reportant dans y(t_S) :\nH = (v_0² · sin² α) / (2·g) = (20² × (sin 45°)²) / (2 × 9.80) = (400 × 0.50) / 19.60 = 10.2 m.",
        "Étape 4 : Portée X_P\nLe sol est atteint pour y(X_P) = 0 avec X_P ≠ 0 :\nX_P = (v_0² · sin 2α) / g = (400 × sin 90°) / 9.80 = 400 / 9.80 = 40.8 m."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Pour une vitesse v_0 donnée, la portée X_P est maximale pour un angle de tir α = 45° car sin(2α) = sin(90°) = 1 !"
    ),

    Exercise(
      id = "ex_satellites_p13",
      chapterId = "P13",
      title = "P13 · Mouvement d'un satellite géostationnaire et 3ème loi de Kepler",
      subject = SubjectType.PHYSIQUE,
      statement = "Un satellite de masse m décrit une orbite circulaire de rayon r autour du centre de la Terre (masse M_T, rayon R_T). On note G la constante de gravitation universelle.\n1. Dans quel repère d'étude le mouvement du satellite doit-il être analysé ?\n2. Donner l'expression du vecteur force gravitationnelle exercée par la Terre sur le satellite.\n3. Montrer que le mouvement orbital est circulaire uniforme et établir l'expression de la vitesse v en fonction de G, M_T et r.\n4. Établir la troisième loi de Kepler : T² / r³ = 4π² / (G·M_T). Définir les caractéristiques d'un satellite géostationnaire.",
      chartType = ScientificChartType.SATELLITE_ORBITE_KEPLER,
      chartTitle = "Orbite circulaire d'un satellite dans le repère de Frenet",
      chartExploitation = "• Force centripète pure dans le repère de Frenet : a_n = v^2 / r et a_t = 0 ⟹ mouvement uniforme.\n• Vitesse orbitale : v = √(G · M_T / r).\n• Satellite géostationnaire : période T = 23h 56min 4s, orbite circulaire dans le plan équatorial, sens de rotation identique à la Terre, altitude h ≈ 36 000 km.",
      hints = listOf(
        "Référentiel géocentrique supposé galiléen.",
        "Utiliser le repère de Frenet (T, n) centré sur le satellite avec n dirigé vers le centre de la Terre.",
        "La vitesse scalaire v vérifie v = 2π · r / T."
      ),
      solutionSteps = listOf(
        "Étape 1 : Référentiel d'étude\nLe mouvement est étudié dans le référentiel géocentrique, dont l'origine est le centre de la Terre et les axes pointent vers trois étoiles lointaines fixes. Il est supposé galiléen pour la durée de l'orbite.",
        "Étape 2 : Force gravitationnelle\nF = G · (M_T · m / r²) · n (où n est le vecteur unitaire centripète dirigé vers le centre de la Terre).",
        "Étape 3 : Mouvement circulaire uniforme et vitesse v\n2ème loi de Newton : F = m·a ⟹ a = (G·M_T / r²)·n.\nDans le repère de Frenet : a = a_t·u + a_n·n avec a_t = dv/dt et a_n = v²/r.\nPar identification : dv/dt = 0 (v est constante : mouvement uniforme) et v²/r = G·M_T/r² ⟹ v = √(G·M_T / r).",
        "Étape 4 : 3ème loi de Kepler et satellite géostationnaire\nLa période de révolution est T = 2π·r / v = 2π·r / √(G·M_T / r) = 2π·√(r³ / (G·M_T)).\nEn élevant au carré : T² = (4π² / (G·M_T)) · r³ ⟺ T² / r³ = 4π² / (G·M_T) = Constante.\nUn satellite géostationnaire paraît immobile pour un observateur terrestre : il orbite dans le plan de l'équateur, dans le même sens que la rotation de la Terre, avec une période égale au jour sidéral T = 86164 s (altitude h ≈ 35 786 km)."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Notez bien que la vitesse v et la période T du satellite sont totalement indépendantes de la masse m du satellite : elles ne dépendent que de l'astre attracteur !"
    ),

    Exercise(
      id = "ex_rotation_p14",
      chapterId = "P14",
      title = "P14 · Rotation d'un solide autour d'un axe fixe : relation fondamentale de la dynamique",
      subject = SubjectType.PHYSIQUE,
      statement = "Une poulie homogène de rayon R = 10 cm et de moment d'inertie J_Δ = 2.5 × 10⁻³ kg·m² peut tourner sans frottement autour d'un axe fixe horizontal (Δ). Un fil inextensible et sans masse enroulé sur la gorge de la poulie soutient un corps solide (S) de masse m = 200 g. À t = 0, on libère le système sans vitesse initiale. Prendre g = 9.80 m/s².\n1. Appliquer la relation fondamentale de la dynamique en rotation à la poulie et la 2ème loi de Newton au solide (S).\n2. En déduire l'expression littérale de l'accélération angulaire θ'' de la poulie en fonction de m, g, R et J_Δ.\n3. Calculer la valeur numérique de θ'' et en déduire la vitesse angulaire θ'(t) à t = 2.0 s.",
      chartType = ScientificChartType.ROTATION_SOLIDE_VITESSE,
      chartTitle = "Dispositif poulie-solide suspendu et bilan des moments",
      chartExploitation = "• Moment de la tension : M_Δ(T') = T' · R.\n• Relation de liaison sans glissement : a = R · θ''.\n• Accélération angulaire : θ'' = (m·g·R) / (J_Δ + m·R²) = 43.55 rad/s².\n• Vitesse angulaire à 2 s : θ'(2) = θ'' · 2 = 87.1 rad/s.",
      hints = listOf(
        "Relation fondamentale : Σ M_Δ(F) = J_Δ · θ''.",
        "Pour le solide en translation verticale : P - T = m · a.",
        "Condition de non-glissement du fil sur la poulie : a = R · θ'' et T = T'."
      ),
      solutionSteps = listOf(
        "Étape 1 : Équations dynamiques\n• Pour la poulie en rotation : M_Δ(Poulie) + M_Δ(R_axe) + M_Δ(T') = J_Δ·θ''.\nComme le poids et la réaction coupent l'axe (Δ), leurs moments sont nuls. Il reste : T'·R = J_Δ·θ''.\n• Pour le solide (S) en translation verticale descendante : m·g - T = m·a.\n• Le fil étant sans masse et inextensible : T = T' et l'accélération linéaire vaut a = R·θ''.",
        "Étape 2 : Expression de l'accélération angulaire θ''\nDe l'équation du solide : T = m·(g - a) = m·(g - R·θ'').\nEn reportant dans l'équation de la poulie :\nm·(g - R·θ'')·R = J_Δ·θ'' ⟺ m·g·R - m·R²·θ'' = J_Δ·θ''\n⟺ θ'' · (J_Δ + m·R²) = m·g·R ⟺ θ'' = (m · g · R) / (J_Δ + m · R²).",
        "Étape 3 : Application numérique\nθ'' = (0.200 kg × 9.80 m/s² × 0.10 m) / (2.5 × 10⁻³ + 0.200 × (0.10)²) = 0.196 / (0.0025 + 0.0020) = 0.196 / 0.0045 ≈ 43.56 rad·s⁻².\nLe mouvement est circulaire uniformément varié : θ'(t) = θ'' · t.\nÀ t = 2.0 s : θ'(2.0) = 43.56 × 2.0 = 87.1 rad/s."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Ne confondez pas accélération linéaire a (en m/s²) et accélération angulaire θ'' (en rad/s²) : elles sont liées par la formule a = R · θ'' !"
    ),

    Exercise(
      id = "ex_pendule_p15",
      chapterId = "P15",
      title = "P15 · Oscillations mécaniques libres d'un oscillateur solide-ressort horizontal",
      subject = SubjectType.PHYSIQUE,
      statement = "Un solide (S) de masse m = 100 g glisse sans frottement le long d'une tige horizontale. Il est attaché à un ressort à spires non jointives de raideur K = 25 N/m. On écarte le solide de sa position d'équilibre d'une distance X_m = 4.0 cm et on le lâche sans vitesse initiale à t = 0.\n1. Établir l'équation différentielle régissant le mouvement du centre d'inertie x(t).\n2. Donner l'expression générale de la solution sous la forme x(t) = X_m · cos(2π·t / T_0 + φ). Déterminer la phase à l'origine φ.\n3. Exprimer la période propre T_0 en fonction de m et K, puis calculer sa valeur.",
      chartType = ScientificChartType.OSCILLATEUR_PENDULE_XT,
      chartTitle = "Oscillations sinusoïdales x(t) du pendule élastique horizontal",
      chartExploitation = "• Période propre : T_0 = 2π √(m / K) = 2π √(0.100 / 25) = 2π × 0.0632 = 0.40 s.\n• Équation horaire : x(t) = 0.04 · cos(5π · t) en mètres.\n• Fréquence propre : f_0 = 1 / T_0 = 2.5 Hz.",
      hints = listOf(
        "Force de rappel exercée par le ressort : F = - K · x · i.",
        "Deuxième loi de Newton : Σ F = m · a_x ⟹ - K · x = m · (d²x/dt²).",
        "Conditions initiales à t = 0 : x(0) = X_m et v(0) = 0."
      ),
      solutionSteps = listOf(
        "Étape 1 : Équation différentielle\nSystème : {Solide S}. Bilan des forces : Poids P (vertical), Réaction R de la tige (verticale sans frottement), Force de rappel F = -K·x·i.\n2ème loi de Newton projetée sur l'axe horizontal (Ox) :\n- K · x = m · (d²x/dt²) ⟺ (d²x/dt²) + (K / m) · x = 0.",
        "Étape 2 : Détermination de la phase initiale φ\nÀ t = 0 : x(0) = X_m · cos(φ) = X_m ⟹ cos(φ) = 1 ⟹ φ = 0 rad.\nDe plus v(0) = - (2π/T_0)·X_m·sin(φ) = 0, ce qui confirme φ = 0.\nL'équation horaire est donc : x(t) = X_m · cos(2π·t / T_0).",
        "Étape 3 : Période propre T_0\nEn posant la pulsation propre ω_0 = √(K / m), la période propre est :\nT_0 = 2π / ω_0 = 2π · √(m / K).\nApplication numérique :\nT_0 = 2π · √(0.100 kg / 25 N·m⁻¹) = 2π · √(0.004) = 2π × 0.06325 ≈ 0.397 s ≈ 0.40 s."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Si les frottements ne sont pas négligeables, les oscillations deviennent amorties pseudo-périodiques, puis apériodiques pour un amortissement fort !"
    ),

    Exercise(
      id = "ex_energie_p16",
      chapterId = "P16",
      title = "P16 · Échanges énergétiques dans un oscillateur harmonique : conservation de l'énergie mécanique",
      subject = SubjectType.PHYSIQUE,
      statement = "Pour l'oscillateur solide-ressort horizontal précédent (m = 100 g, K = 25 N/m, amplitude X_m = 4.0 cm), les frottements sont rigoureusement négligeables.\n1. Exprimer l'énergie potentielle élastique E_pe(t) et l'énergie cinétique E_c(t) du système.\n2. Montrer que l'énergie mécanique E_m est une constante du mouvement et calculer sa valeur numérique en Joules.\n3. Déterminer la vitesse maximale V_max atteinte par le solide lors de son passage par la position d'équilibre.\n4. Pour quelle valeur de l'élongation x a-t-on équipartition de l'énergie (E_c = E_pe) ?",
      chartType = ScientificChartType.OSCILLATEUR_ENERGIE_EP_EC,
      chartTitle = "Diagramme énergétique E_c, E_pe et E_m en fonction de l'élongation x",
      chartExploitation = "• Énergie mécanique totale : E_m = 1/2 · K · X_m^2 = 0.5 × 25 × (0.04)^2 = 0.020 J = 20 mJ.\n• Au centre (x = 0) : E_pe = 0 ⟹ E_c = E_m ⟹ V_max = √(2 E_m / m) = 0.63 m/s.\n• Équipartition E_c = E_pe = E_m / 2 : 1/2 K x^2 = 1/4 K X_m^2 ⟹ x = ± X_m / √2 ≈ ± 2.83 cm.",
      hints = listOf(
        "Énergie potentielle élastique : E_pe = 1/2 · K · x² (en prenant E_pe = 0 à x = 0).",
        "Énergie cinétique : E_c = 1/2 · m · v².",
        "Énergie mécanique totale : E_m = E_c + E_pe = Constante en l'absence de frottement."
      ),
      solutionSteps = listOf(
        "Étape 1 : Expressions des énergies\n• E_pe(x) = 1/2 · K · x²\n• E_c(v) = 1/2 · m · v²\n• E_m = E_c + E_pe = 1/2·m·v² + 1/2·K·x².",
        "Étape 2 : Conservation de l'énergie mécanique E_m\nAux positions extrêmes (x = ± X_m), la vitesse est nulle (v = 0) :\nE_m = 1/2 · K · X_m² = Constante.\nApplication numérique :\nE_m = 1/2 × 25 N/m × (0.040 m)² = 0.5 × 25 × 0.0016 = 0.020 J = 20 mJ.",
        "Étape 3 : Vitesse maximale V_max au passage par l'équilibre (x = 0)\nEn x = 0 : E_pe = 0, toute l'énergie mécanique est sous forme cinétique :\nE_c = E_m ⟺ 1/2 · m · V_max² = E_m ⟺ V_max = √(2·E_m / m).\nApplication numérique :\nV_max = √(2 × 0.020 J / 0.100 kg) = √(0.40) ≈ 0.632 m/s = 63.2 cm/s.",
        "Étape 4 : Équipartition de l'énergie (E_c = E_pe)\nLorsque E_c = E_pe, on a : E_m = E_pe + E_pe = 2 · E_pe ⟺ E_pe = E_m / 2.\n1/2 · K · x² = 1/2 · (1/2 · K · X_m²) ⟺ x² = X_m² / 2 ⟺ x = ± X_m / √2.\nAN : x = ± 4.0 cm / 1.414 = ± 2.83 cm."
      ),
      tips = "Conseil du Pr. SBAI Mohammed : Notez bien que les énergies E_c et E_pe oscillent à une fréquence double (2·f_0) de celle du mouvement de l'oscillateur !"
    )
  )

  // 3. EXERCICES INTERACTIFS AVEC GRADIENT DE DIFFICULTÉ (FACILE, MOYEN, DÉFI)
  val interactiveQuizzes = listOf(
    // Facile (Rappels de cours & formules fondamentales)
    InteractiveQuestion(
      id = "q_facile_1",
      chapterTitle = "Le Dipôle RC",
      subject = SubjectType.PHYSIQUE,
      difficulty = Difficulty.FACILE,
      question = "Quelle est l'unité de la constante de temps τ = R · C dans le Système International ?",
      options = listOf("Le Farad (F)", "La Seconde (s)", "L'Ohm (Ω)", "Le Volt par seconde (V/s)"),
      correctOptionIndex = 1,
      explanation = "τ = R · C a la dimension d'un temps ([R·C] = [U/I] · [I·t/U] = [T]), donc son unité internationale est la seconde (s)."
    ),
    InteractiveQuestion(
      id = "q_facile_2",
      chapterTitle = "Transformations Chimiques & pH",
      subject = SubjectType.CHIMIE,
      difficulty = Difficulty.FACILE,
      question = "Une solution aqueuse a une concentration en ions oxonium [H3O+] = 1.0 × 10^(-3) mol/L à 25°C. Son pH vaut :",
      options = listOf("pH = 1.0", "pH = 3.0", "pH = 11.0", "pH = 7.0"),
      correctOptionIndex = 1,
      explanation = "pH = -log([H3O+]) = -log(1.0 × 10^(-3)) = 3.0."
    ),
    InteractiveQuestion(
      id = "q_facile_3",
      chapterTitle = "Décroissance Radioactive",
      subject = SubjectType.PHYSIQUE,
      difficulty = Difficulty.FACILE,
      question = "Au bout d'une durée égale à deux demi-vies (t = 2 · t_1/2), le nombre de noyaux radioactifs restants est :",
      options = listOf("N_0 / 2", "N_0 / 4", "N_0 / 8", "0 (Tous désintégrés)"),
      correctOptionIndex = 1,
      explanation = "À t = t_1/2, il reste N_0/2. À t = 2·t_1/2, la moitié de cette valeur subsiste, soit (N_0/2)/2 = N_0/4."
    ),

    // Moyen (Calculs intermédiaires et raisonnements)
    InteractiveQuestion(
      id = "q_moyen_1",
      chapterTitle = "Le Dipôle RC",
      subject = SubjectType.PHYSIQUE,
      difficulty = Difficulty.MOYEN,
      question = "Lors de la charge d'un condensateur sous une tension continue E, quelle est la tension u_C à l'instant t = τ ?",
      options = listOf("0.50 · E (50%)", "0.63 · E (63%)", "0.86 · E (86%)", "0.99 · E (99%)"),
      correctOptionIndex = 1,
      explanation = "u_C(τ) = E · (1 - e^(-1)) = E · (1 - 0.368) ≈ 0.632 · E, soit 63% de la charge maximale."
    ),
    InteractiveQuestion(
      id = "q_moyen_2",
      chapterTitle = "Titrage Acido-Basique",
      subject = SubjectType.CHIMIE,
      difficulty = Difficulty.MOYEN,
      question = "On titre V_a = 10 mL d'acide chlorhydrique par de la soude à C_b = 0.05 mol/L. L'équivalence est obtenue à V_bE = 20 mL. Quelle est la concentration C_a ?",
      options = listOf("0.025 mol/L", "0.050 mol/L", "0.100 mol/L", "0.200 mol/L"),
      correctOptionIndex = 2,
      explanation = "À l'équivalence : C_a · V_a = C_b · V_bE => C_a = (0.05 × 20) / 10 = 0.100 mol/L."
    ),
    InteractiveQuestion(
      id = "q_moyen_3",
      chapterTitle = "Ondes Mécaniques",
      subject = SubjectType.PHYSIQUE,
      difficulty = Difficulty.MOYEN,
      question = "Une onde sonore de fréquence N = 1000 Hz se propage dans l'air avec une célérité v = 340 m/s. Sa longueur d'onde est :",
      options = listOf("3.4 m", "0.34 m (34 cm)", "34 m", "2.94 m"),
      correctOptionIndex = 1,
      explanation = "λ = v / N = 340 / 1000 = 0.34 m (soit 34 cm)."
    ),

    // Difficile / Défi (Synthèse type Examen National Baccalauréat)
    InteractiveQuestion(
      id = "q_difficile_1",
      chapterTitle = "Oscillations RLC Libres Amorties",
      subject = SubjectType.PHYSIQUE,
      difficulty = Difficulty.DIFFICILE,
      question = "Dans un circuit RLC série de résistance totale négligeable (R ≈ 0), L = 100 mH et C = 10 µF. La pseudo-période des oscillations propres T_0 est égale à :",
      options = listOf("1.98 ms", "6.28 ms", "62.8 ms", "0.314 ms"),
      correctOptionIndex = 1,
      explanation = "T_0 = 2·π·√(L·C) = 2·π·√(0.1 × 10^(-5)) = 2·π·√(10^(-6)) = 2·π × 10^(-3) s ≈ 6.28 ms."
    ),
    InteractiveQuestion(
      id = "q_difficile_2",
      chapterTitle = "Réactions Totales & Constante d'Équilibre",
      subject = SubjectType.CHIMIE,
      difficulty = Difficulty.DIFFICILE,
      question = "Le produit ionique de l'eau à 60°C est Ke = 1.0 × 10^(-13). Le pH d'une eau pure neutre à 60°C vaut :",
      options = listOf("7.00", "6.50", "7.50", "13.00"),
      correctOptionIndex = 1,
      explanation = "Pour une eau pure, [H3O+] = [HO-] => [H3O+]² = Ke => [H3O+] = √(Ke) = 10^(-6.5) mol/L. D'où pH = 6.50."
    ),
    InteractiveQuestion(
      id = "q_difficile_3",
      chapterTitle = "Lois de Newton & Balistique",
      subject = SubjectType.PHYSIQUE,
      difficulty = Difficulty.DIFFICILE,
      question = "Un projectile est lancé depuis le sol avec une vitesse v_0 sous un angle α = 45°. En négligeant les frottements de l'air, la portée maximale atteinte est :",
      options = listOf("v_0² / g", "v_0² / (2·g)", "2·v_0² / g", "v_0 / g"),
      correctOptionIndex = 0,
      explanation = "La portée s'exprime par x_P = (v_0² · sin(2α)) / g. Pour α = 45°, 2α = 90° et sin(90°) = 1, donc x_P = v_0² / g."
    )
  )

  // 4. ANNALES DES EXAMENS NATIONAUX MAROCAINS (2015 à 2026)
  // Complète, structurée pour chaque année avec session normale et session rattrapage
  val nationalExams = listOf(
    NationalExam(
      id = "bac_2026_normale",
      year = 2026,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2026 - Épreuve Officielle Conforme au Cadre de Référence",
      sections = listOf(
        ExamSection(
          domain = "Chimie (7 points)",
          title = "Partie 1 : Cinétique d'oxydoréduction et suivi par conductimétrie\nPartie 2 : Dosage d'un médicament antiseptique",
          points = 7.0,
          statement = "1. Réaction entre l'acide oxalique et les ions permanganate. Établissement du tableau d'avancement et expression de la vitesse volumique.\n2. Titrage acido-basique de l'acide acétylsalicylique par pH-métrie. Détermination de la masse contenue dans un comprimé commercial.",
          detailedCorrection = "1. Équation bilan : 2 MnO4- + 5 H2C2O4 + 6 H+ -> 2 Mn2+ + 10 CO2 + 8 H2O. Vitesse v = (1/V)·dx/dt.\n2. V_bE = 14.2 mL. Masse calculée m = C_b·V_bE·M = 500 mg (conforme à l'indication 'Aspirine 500')."
        ),
        ExamSection(
          domain = "Physique 1 : Ondes & Nucléaire (5.5 points)",
          title = "Diffraction laser et datation géologique par le potassium-argon",
          points = 5.5,
          statement = "1. Faisceau laser rouge (λ = 632.8 nm) traversant une fente de largeur a = 0.10 mm. Écran placé à D = 2.0 m.\n2. Décroissance radioactive du Potassium 40 en Argon 40 pour la datation d'une roche volcanique.",
          detailedCorrection = "1. Largeur de la tache centrale L = 2·λ·D / a = 2 × 6.328×10^(-7) × 2 / 10^(-4) = 2.53 cm.\n2. Âge de la roche calculé t = (1/λ) · ln(1 + N_Ar/N_K) = 1.25 × 10^8 ans."
        ),
        ExamSection(
          domain = "Physique 2 : Électricité & Mécanique (7.5 points)",
          title = "Oscillations électriques libres dans RLC série et mouvement d'un skieur sur plan incliné",
          points = 7.5,
          statement = "1. Régime pseudo-périodique, calcul de l'énergie totale perdue par effet Joule entre t=0 et t=3T.\n2. Étude du mouvement d'un skieur avec frottement solide (f = 0.15·R_N) le long d'une piste inclinée d'angle α = 25°.",
          detailedCorrection = "1. ΔE_totale = E_e(3T) - E_e(0) = -1.42 mJ (perte due à la résistance r du circuit).\n2. Application de la 2ème loi de Newton : a = g·(sin α - f·cos α) = 9.8·(0.422 - 0.15×0.906) = 2.80 m/s²."
        )
      )
    ),
    NationalExam(
      id = "bac_2025_normale",
      year = 2025,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2025 - Session Normale Sciences Physiques",
      sections = listOf(
        ExamSection(
          domain = "Chimie (7 points)",
          title = "Électrolyse de l'eau et constante d'acidité des acides carboxyliques",
          points = 7.0,
          statement = "Étude d'une pile électrochimique zinc-cuivre (pile Daniell) et synthèse d'un ester à odeur fruitée.",
          detailedCorrection = "Force électromotrice standard E° = E°(Cu2+/Cu) - E°(Zn2+/Zn) = 0.34 - (-0.76) = 1.10 V. Rendement de l'estérification r = 67%."
        ),
        ExamSection(
          domain = "Physique : Électricité & Mécanique (13 points)",
          title = "Dipôle RL, modulation d'amplitude et satellite géostationnaire",
          points = 13.0,
          statement = "1. Constante de temps du dipôle RL : τ = L / (R + r).\n2. Mouvement circulaire uniforme d'un satellite météorologique terrestre.",
          detailedCorrection = "1. L = (R+r)·τ = (50 + 10) × 2.5×10^(-3) = 0.15 H = 150 mH.\n2. Troisième loi de Kepler : T² / r³ = 4π² / (G·M_T)."
        )
      )
    ),
    NationalExam(
      id = "bac_2025_rattrapage",
      year = 2025,
      session = "Rattrapage",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2025 - Session de Rattrapage",
      sections = listOf(
        ExamSection(
          domain = "Chimie & Physique (20 points)",
          title = "Cinétique par spectrophotométrie, Ondes ultrasonores, Décroissance de l'Iode 131 et Pendule élastique",
          points = 20.0,
          statement = "Épreuve complète de synthèse de rattrapage couvrant les compétences clés du programme.",
          detailedCorrection = "Corrigé officiel validé par la commission d'examen du MENFP. Détail des notes par question disponible."
        )
      )
    ),
    NationalExam(
      id = "bac_2024_normale",
      year = 2024,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2024 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Chimie (7 points)",
          title = "Cinétique de décomposition de l'eau oxygénée et dosage acido-basique",
          points = 7.0,
          statement = "Mesure de la pression du dioxygène gazeux formé et titrage par les ions permanganate.",
          detailedCorrection = "x_max = 5.0 × 10^(-3) mol. Temps de demi-réaction t_1/2 = 18 min."
        ),
        ExamSection(
          domain = "Physique (13 points)",
          title = "Circuit RC et pendule de torsion",
          points = 13.0,
          statement = "Charge du condensateur à courant constant I_0, puis décharge oscillante dans une bobine.",
          detailedCorrection = "u_C(t) = (I_0 / C) · t. Pente déterminée k = 200 V/s, d'où C = 10 µF."
        )
      )
    ),
    NationalExam(
      id = "bac_2023_normale",
      year = 2023,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2023 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Complète (20 points)",
          title = "Transformations chimiques totales, Ondes périodiques, Radioactivité alpha et Chute verticale dans un liquide visqueux",
          points = 20.0,
          statement = "Sujet officiel de la session normale 2023 comprenant la loi de Stokes pour la force de frottement fluide.",
          detailedCorrection = "Équation différentielle dv/dt + (k/m)·v = g·(1 - ρ_f/ρ_s). Vitesse limite v_lim = 1.45 m/s."
        )
      )
    ),
    NationalExam(
      id = "bac_2022_normale",
      year = 2022,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2022 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Complète (20 points)",
          title = "Dosage conductimétrique, Ondes à la surface de l'eau, Circuit RLC et Mouvement d'une particule chargée dans un champ magnétique B",
          points = 20.0,
          statement = "Force de Lorentz F = q · v ^ B, rayon de la trajectoire circulaire R = m·v / (|q|·B).",
          detailedCorrection = "Corrigé officiel détaillé avec calcul des incertitudes de mesure et tracé graphique des tangentes."
        )
      )
    ),
    NationalExam(
      id = "bac_2021_normale",
      year = 2021,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2021 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Complète (20 points)",
          title = "Piles salines, Fission de l'Uranium 235, Résonance d'intensité dans un circuit RLC et Pendule simple",
          points = 20.0,
          statement = "Condition de résonance électrique : ω_0 = 1 / √(L·C). Bilan énergétique de la fission nucléaire.",
          detailedCorrection = "Énergie libérée par un noyau d'uranium : ΔE = 178 MeV. Facteur de qualité Q = 25."
        )
      )
    ),
    NationalExam(
      id = "bac_2020_normale",
      year = 2020,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2020 - Session Normale Confinée",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Adaptée (20 points)",
          title = "Cinétique chimique, Ondes, Radioactivité et Électricité (Programme restreint 2020)",
          points = 20.0,
          statement = "Sujet centré sur les unités 1 à 3 du programme officiel.",
          detailedCorrection = "Solution intégrale détaillée selon les barèmes ministériels officiels de la session 2020."
        )
      )
    ),
    NationalExam(
      id = "bac_2019_normale",
      year = 2019,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2019 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Complète (20 points)",
          title = "Dosage d'un acide fort par une base, Décroissance du Polonium, Modulation d'amplitude et Chute libre parabolique",
          points = 20.0,
          statement = "Taux de modulation m = (U_max - U_min) / (U_max + U_min) pour une bonne détection d'enveloppe.",
          detailedCorrection = "m = 0.65 < 1 : condition de non surmodulation vérifiée, démodulation réussie."
        )
      )
    ),
    NationalExam(
      id = "bac_2018_normale",
      year = 2018,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2018 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Complète (20 points)",
          title = "Estérification et hydrolyse, Diffraction par un cheveu, Décharge dans une bobine et Plan incliné",
          points = 20.0,
          statement = "Calcul du diamètre d'un cheveu par la formule a = 2·λ·D / L.",
          detailedCorrection = "Diamètre du cheveu a = 75 µm. Rendement limite de l'estérification d'un alcool primaire r = 67%."
        )
      )
    ),
    NationalExam(
      id = "bac_2017_normale",
      year = 2017,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2017 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Complète (20 points)",
          title = "Suivi par manométrie, Énergie de liaison de l'hélium, Charge de deux condensateurs en série et Satellites",
          points = 20.0,
          statement = "Loi des gaz parfaits P·V = n·R·T pour le calcul de l'avancement x(t).",
          detailedCorrection = "x(t) = (ΔP(t) · V) / (R·T). Constante de temps équivalente C_eq = C1·C2/(C1+C2)."
        )
      )
    ),
    NationalExam(
      id = "bac_2016_normale",
      year = 2016,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2016 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Complète (20 points)",
          title = "Dosage de l'aspirine, Ondes le long d'une cuve à ondes, Dipôle RL et Oscillations mécaniques horizontales",
          points = 20.0,
          statement = "Stroboscopie et immobilité apparente pour la cuve à ondes. Raideur k d'un ressort spiral.",
          detailedCorrection = "Fréquence des éclairs N_e = N/k pour l'immobilité apparente. Période propre T_0 = 2π√(m/k)."
        )
      )
    ),
    NationalExam(
      id = "bac_2015_normale",
      year = 2015,
      session = "Normale",
      branch = "PC (Sciences Physiques)",
      title = "Examen National 2015 - Session Normale",
      sections = listOf(
        ExamSection(
          domain = "Épreuve Complète (20 points)",
          title = "Cinétique par conductimétrie, Célérité du son dans l'eau de mer, Énergie d'un condensateur et Mouvement d'un projectile",
          points = 20.0,
          statement = "Mesure de la profondeur marine par écho sonar (d = v · Δt / 2).",
          detailedCorrection = "Célérité du son v = 1500 m/s. Profondeur de la fosse sous-marine d = 1125 m."
        )
      )
    )
  )

  // 5. ÉVALUATIONS CONTINUES (3 CONTRÔLES PAR SEMESTRE = 6 CONTRÔLES OFFICIELS)
  val evaluations = listOf(
    // Semestre 1
    EvaluationContinuous(
      id = "cc_s1_c1",
      semester = 1,
      number = 1,
      title = "Contrôle Continu N°1 - Semestre 1",
      durationMinutes = 120,
      chaptersCovered = listOf("Cinétique Chimique & Suivi Temporel", "Ondes Mécaniques Progressives"),
      questions = listOf(
        InteractiveQuestion(
          id = "eval_q1",
          chapterTitle = "Cinétique Chimique",
          subject = SubjectType.CHIMIE,
          difficulty = Difficulty.MOYEN,
          question = "Comment varie la vitesse volumique d'une réaction chimique au cours du temps ?",
          options = listOf("Elle reste rigoureusement constante", "Elle diminue car les réactifs se consomment", "Elle augmente exponentiellement", "Elle oscille périodiquement"),
          correctOptionIndex = 1,
          explanation = "La vitesse volumique diminue au cours du temps car la concentration des réactifs (facteur cinétique) diminue."
        ),
        InteractiveQuestion(
          id = "eval_q2",
          chapterTitle = "Ondes Mécaniques",
          subject = SubjectType.PHYSIQUE,
          difficulty = Difficulty.FACILE,
          question = "Une onde sonore dans l'air est une onde :",
          options = listOf("Transversale électromagnétique", "Longitudinale mécanique", "Stationnaire lumineuse", "Circulaire sans matière"),
          correctOptionIndex = 1,
          explanation = "Le son est une onde mécanique longitudinale car la direction de la perturbation (compression/dilatation) est parallèle à la direction de propagation."
        )
      ),
      teacherRubric = "Barème officiel : Chimie (8 pts), Ondes progressives (7 pts), Ondes périodiques (5 pts). Total sur 20. Calculatrice autorisée."
    ),
    EvaluationContinuous(
      id = "cc_s1_c2",
      semester = 1,
      number = 2,
      title = "Contrôle Continu N°2 - Semestre 1",
      durationMinutes = 120,
      chaptersCovered = listOf("Décroissance Radioactive & Nucléaire", "Dipôle RC (Charge et Décharge)"),
      questions = listOf(
        InteractiveQuestion(
          id = "eval_q3",
          chapterTitle = "Dipôle RC",
          subject = SubjectType.PHYSIQUE,
          difficulty = Difficulty.MOYEN,
          question = "Lors de la décharge d'un condensateur initialement chargé sous E dans un résistor R, la tension u_C(t) s'écrit :",
          options = listOf("u_C(t) = E · (1 - e^(-t/τ))", "u_C(t) = E · e^(-t/τ)", "u_C(t) = E · ln(t/τ)", "u_C(t) = (E/2) · cos(ω·t)"),
          correctOptionIndex = 1,
          explanation = "À t = 0, u_C = E et lorsque t tend vers l'infini, u_C tend vers 0. L'expression de la décharge est u_C(t) = E · exp(-t/τ)."
        )
      ),
      teacherRubric = "Barème officiel : Nucléaire et datation (7 pts), Dipôle RC et bilan énergétique (13 pts). Total sur 20."
    ),
    EvaluationContinuous(
      id = "cc_s1_c3",
      semester = 1,
      number = 3,
      title = "Contrôle Continu N°3 - Semestre 1",
      durationMinutes = 120,
      chaptersCovered = listOf("Équilibre Chimique & pH", "Dipôle RL & Circuit RLC", "Lois de Newton (Partie 1)"),
      questions = listOf(
        InteractiveQuestion(
          id = "eval_q4",
          chapterTitle = "Circuit RLC",
          subject = SubjectType.PHYSIQUE,
          difficulty = Difficulty.DIFFICILE,
          question = "Dans un circuit RLC série amorti, le régime d'oscillations obtenu lorsque la résistance R est modérée est qualifié de :",
          options = listOf("Régime périodique non amorti", "Régime pseudo-périodique", "Régime apériodique critique", "Régime stationnaire résonant"),
          correctOptionIndex = 1,
          explanation = "Pour une résistance faible ou modérée, l'amplitude décroît exponentiellement tout en oscillant à la pseudo-période T : c'est le régime pseudo-périodique."
        )
      ),
      teacherRubric = "Barème officiel : Équilibre acido-basique (6 pts), RLC série (7 pts), Mouvement rectiligne de Newton (7 pts). Total sur 20."
    ),

    // Semestre 2
    EvaluationContinuous(
      id = "cc_s2_c1",
      semester = 2,
      number = 1,
      title = "Contrôle Continu N°1 - Semestre 2",
      durationMinutes = 120,
      chaptersCovered = listOf("Dosage Acido-Basique & Indicateurs", "Mouvements des Satellites et Projectiles"),
      questions = listOf(
        InteractiveQuestion(
          id = "eval_q5",
          chapterTitle = "Titrage Acido-Basique",
          subject = SubjectType.CHIMIE,
          difficulty = Difficulty.MOYEN,
          question = "Pour doser un acide fort par une base forte (pH à l'équivalence pH_E = 7.0), quel indicateur coloré convient le mieux ?",
          options = listOf("Hélianthine (zone de virage 3.1 - 4.4)", "Bleu de bromothymol - BBT (zone 6.0 - 7.6)", "Phénolphtaléine (zone 8.2 - 10.0)", "Rouge de méthyle (zone 4.2 - 6.2)"),
          correctOptionIndex = 1,
          explanation = "La zone de virage du BBT (6.0 - 7.6) contient la valeur de pH_E = 7.0 à 25°C pour un dosage fort/fort."
        )
      ),
      teacherRubric = "Barème officiel : Chimie analytique et titrage (7 pts), Balistique et gravitation universelle (13 pts)."
    ),
    EvaluationContinuous(
      id = "cc_s2_c2",
      semester = 2,
      number = 2,
      title = "Contrôle Continu N°2 - Semestre 2",
      durationMinutes = 120,
      chaptersCovered = listOf("Piles Électrochimiques & Électrolyse", "Systèmes Mécaniques Oscillants (Pendules)"),
      questions = listOf(
        InteractiveQuestion(
          id = "eval_q6",
          chapterTitle = "Piles Électrochimiques",
          subject = SubjectType.CHIMIE,
          difficulty = Difficulty.MOYEN,
          question = "Dans une pile électrochimique, l'électrode où se déroule l'oxydation est :",
          options = listOf("La cathode (pôle positif)", "L'anode (pôle négatif)", "Le pont salin neutre", "Le voltmètre"),
          correctOptionIndex = 1,
          explanation = "Moyen mnémotechnique : Anode = Oxydation (deux voyelles), Cathode = Réduction (deux consonnes). Dans une pile spontanée, l'anode est le pôle négatif."
        )
      ),
      teacherRubric = "Barème officiel : Piles et électrolyse forcée (7.5 pts), Pendule élastique et énergétique (12.5 pts)."
    ),
    EvaluationContinuous(
      id = "cc_s2_c3",
      semester = 2,
      number = 3,
      title = "Contrôle Continu N°3 - Semestre 2 (Synthèse Bac)",
      durationMinutes = 120,
      chaptersCovered = listOf("Estérification et Hydrolyse", "Atome et Mécanique de Newton", "Révision Globale Nationale"),
      questions = listOf(
        InteractiveQuestion(
          id = "eval_q7",
          chapterTitle = "Chimie Organique",
          subject = SubjectType.CHIMIE,
          difficulty = Difficulty.FACILE,
          question = "La réaction d'estérification entre un acide carboxylique et un alcool est une transformation :",
          options = listOf("Totale et très rapide", "Lente, limitée et athermique", "Explosive et exothermique", "Impossible sans catalyseur nucléaire"),
          correctOptionIndex = 1,
          explanation = "L'estérification est lente, limitée par sa réaction inverse (l'hydrolyse de l'ester) et athermique (elle n'absorbe ni ne dégage de chaleur notable)."
        )
      ),
      teacherRubric = "Barème officiel conforme à l'épreuve de synthèse finale : Chimie organique (7 pts), Mécanique et énergie (13 pts)."
    )
  )

  // Échantillon de classe pour le tableau de bord professeur
  val initialStudents = listOf(
    StudentRecord(
      id = "std_1",
      name = "Yassine El Amrani",
      classGroup = "2ème Bac PC 1",
      s1c1 = 16.5, s1c2 = 17.0, s1c3 = 18.0,
      s2c1 = 17.5, s2c2 = 18.5, s2c3 = 19.0,
      interactiveScore = 320,
      exercisesDone = 14,
      badges = listOf("Major Physique", "As du Circuit RC", "Expert Bac 2025")
    ),
    StudentRecord(
      id = "std_2",
      name = "Fatima-Zahra Benjelloun",
      classGroup = "2ème Bac PC 1",
      s1c1 = 18.0, s1c2 = 19.0, s1c3 = 18.5,
      s2c1 = 19.0, s2c2 = 19.5, s2c3 = 20.0,
      interactiveScore = 380,
      exercisesDone = 18,
      badges = listOf("Excellence Chimie", "Championne Titrage", "Mention Très Bien")
    ),
    StudentRecord(
      id = "std_3",
      name = "Amine Tazi",
      classGroup = "2ème Bac PC 1",
      s1c1 = 13.0, s1c2 = 14.5, s1c3 = 14.0,
      s2c1 = 15.0, s2c2 = 15.5, s2c3 = 16.0,
      interactiveScore = 210,
      exercisesDone = 9,
      badges = listOf("Progression Rapide", "Maître des Ondes")
    ),
    StudentRecord(
      id = "std_4",
      name = "Salma Chraibi",
      classGroup = "2ème Bac PC 1",
      s1c1 = 14.5, s1c2 = 15.0, s1c3 = 16.0,
      s2c1 = 16.0, s2c2 = 17.0, s2c3 = 17.5,
      interactiveScore = 260,
      exercisesDone = 12,
      badges = listOf("Régularité", "Nucléaire Validé")
    ),
    StudentRecord(
      id = "std_5",
      name = "Mehdi Alami",
      classGroup = "2ème Bac PC 1",
      s1c1 = 11.5, s1c2 = 12.0, s1c3 = 13.0,
      s2c1 = 13.5, s2c2 = 14.0, s2c3 = 14.5,
      interactiveScore = 180,
      exercisesDone = 7,
      badges = listOf("Effort Continu", "Défi Relevé")
    ),
    StudentRecord(
      id = "std_6",
      name = "Khadija Idrissi",
      classGroup = "2ème Bac PC 1",
      s1c1 = 15.5, s1c2 = 16.0, s1c3 = 17.0,
      s2c1 = 17.0, s2c2 = 17.5, s2c3 = 18.0,
      interactiveScore = 290,
      exercisesDone = 13,
      badges = listOf("Top 5 Classe", "Génie de Newton")
    )
  )

  // Messages initiaux
  val initialMessages = listOf(
    MessageItem(
      id = "msg_1",
      senderName = "Professeur SBAI Mohammed",
      isTeacher = true,
      channel = "Annonces",
      message = "Bonjour à tous chers élèves de 2ème Bac. Les fiches de révision et les annales du Baccalauréat 2015 à 2026 sont désormais disponibles hors-ligne. Bon courage pour les préparations du Contrôle Continu N°1 !",
      timestamp = "Hier à 18:30"
    ),
    MessageItem(
      id = "msg_2",
      senderName = "Yassine El Amrani",
      isTeacher = false,
      channel = "Q&A Pr. SBAI",
      message = "Bonjour Monsieur le Professeur, pour le circuit RC à l'instant t = tau, peut-on toujours utiliser l'intersection de la tangente à l'origine avec l'asymptote E pour trouver la constante de temps ?",
      timestamp = "Ce matin à 09:15"
    ),
    MessageItem(
      id = "msg_3",
      senderName = "Professeur SBAI Mohammed",
      isTeacher = true,
      channel = "Q&A Pr. SBAI",
      message = "Oui absolument Yassine ! C'est la méthode géométrique standard recommandée dans le cadre de référence. Vous pouvez également vérifier avec u_C(tau) = 0.63 * E pour confirmer votre lecture.",
      timestamp = "Ce matin à 09:40"
    )
  )

  // Notifications initiales
  val initialNotifications = listOf(
    NotificationItem(
      id = "notif_1",
      title = "Nouveau Cours & Simulation Disponibles",
      message = "Le laboratoire virtuel 'Titrage Acido-Basique et pH-métrie' est accessible. Testez l'ajout de soude à la burette !",
      timeAgo = "Il y a 2h",
      category = "Cours"
    ),
    NotificationItem(
      id = "notif_2",
      title = "Rappel Contrôle Continu N°1",
      message = "Le Contrôle Continu N°1 du Semestre 1 est planifié. Révisez la cinétique et les ondes mécaniques.",
      timeAgo = "Hier",
      category = "Contrôle"
    ),
    NotificationItem(
      id = "notif_3",
      title = "Annales Nationales Mises à Jour",
      message = "Ajout des corrigés officiels détaillés des sessions 2025 et 2026 blanche par Pr. SBAI Mohammed.",
      timeAgo = "Il y a 3 jours",
      category = "Examen"
    )
  )

  // Constantes physiques
  val physicalConstants = listOf(
    PhysicalConstant("c", "Célérité de la lumière dans le vide", "2.998 × 10^8", "m·s^(-1)"),
    PhysicalConstant("h", "Constante de Planck", "6.626 × 10^(-34)", "J·s"),
    PhysicalConstant("e", "Charge élémentaire", "1.602 × 10^(-19)", "C"),
    PhysicalConstant("N_A", "Constante d'Avogadro", "6.022 × 10^23", "mol^(-1)"),
    PhysicalConstant("g", "Intensité de la pesanteur (Maroc)", "9.80", "m·s^(-2)"),
    PhysicalConstant("F", "Constante de Faraday", "9.65 × 10^4", "C·mol^(-1)"),
    PhysicalConstant("R", "Constante des gaz parfaits", "8.314", "J·K^(-1)·mol^(-1)"),
    PhysicalConstant("Ke", "Produit ionique de l'eau (25°C)", "1.0 × 10^(-14)", "Sans unité")
  )

  val driveLibraryUrl = "https://drive.google.com/drive/folders/1jLMMiSIeySEj5ycCaKe4vD5e-V9zXYbX"

  val initialCustomQuizzes = listOf(
    CustomQuiz(
      id = "quiz_prof_1",
      title = "Évaluation Flash : Circuit RC & Ondes Périodiques",
      subject = SubjectType.PHYSIQUE,
      targetClass = "2ème Bac PC 1",
      durationMinutes = 20,
      driveResourceUrl = driveLibraryUrl,
      questions = listOf(
        CustomQuizQuestion(
          id = "cq_1",
          type = QuestionType.QCM,
          prompt = "Dans un dipôle RC soumis à un échelon de tension E, quelle relation lie la constante de temps τ à R et C ?",
          options = listOf("τ = R / C", "τ = R · C", "τ = 1 / (R · C)", "τ = C / R"),
          correctOptionIndex = 1,
          explanation = "τ = R · C est la constante de temps caractéristique du dipôle RC.",
          points = 4.0
        ),
        CustomQuizQuestion(
          id = "cq_2",
          type = QuestionType.VRAI_FAUX,
          prompt = "Une onde sonore dans l'air est une onde mécanique transversale.",
          correctBoolean = false,
          explanation = "Faux : L'onde sonore dans l'air est longitudinale car la direction de propagation est parallèle à la direction de la compression des tranches d'air.",
          points = 3.0
        ),
        CustomQuizQuestion(
          id = "cq_3",
          type = QuestionType.REPONSE_COURTE,
          prompt = "Donner la valeur numérique du pH d'une solution neutre à 25°C :",
          correctAnswerText = "7",
          explanation = "À 25°C, pour l'eau pure, [H3O+] = 10^(-7) mol/L d'où pH = 7.0.",
          points = 3.0
        )
      )
    ),
    CustomQuiz(
      id = "quiz_prof_2",
      title = "Quiz Chimie : Titrage & Vitesse de Réaction",
      subject = SubjectType.CHIMIE,
      targetClass = "2ème Bac PC 1",
      durationMinutes = 25,
      driveResourceUrl = driveLibraryUrl,
      questions = listOf(
        CustomQuizQuestion(
          id = "cq_4",
          type = QuestionType.QCM,
          prompt = "À l'équivalence d'un titrage d'acide fort par base forte, les réactifs ont réagi selon quel rapport ?",
          options = listOf("Uniquement en présence d'excès d'acide", "Dans les proportions stœchiométriques", "Avec un taux d'avancement τ = 0", "À volume égal uniquement"),
          correctOptionIndex = 1,
          explanation = "À l'équivalence, la quantité de matière du réactif titré et celle du réactif titrant ajouté sont dans les proportions stœchiométriques de l'équation.",
          points = 5.0
        ),
        CustomQuizQuestion(
          id = "cq_5",
          type = QuestionType.VRAI_FAUX,
          prompt = "La vitesse volumique de réaction diminue généralement au cours du temps car la concentration des réactifs diminue.",
          correctBoolean = true,
          explanation = "Vrai : La concentration des réactifs est un facteur cinétique majeur. En diminuant, le nombre de chocs efficaces diminue.",
          points = 5.0
        )
      )
    )
  )

  // 7. RAPPELS D'ÉTUDE & PLANNING DE RÉVISION (POUR LE DASHBOARD ÉLÈVE)
  val initialStudyReminders = listOf(
    StudyReminder(
      id = "rem_1",
      title = "Contrôle Continu N°2 : Circuit RC & Radioactivité",
      subject = SubjectType.PHYSIQUE,
      dueDate = "Dans 2 jours",
      priority = ReminderPriority.URGENT,
      chapterOrTheme = "P6 (Dipôle RC) & P4 (Décroissance radioactive)",
      estimatedMinutes = 60,
      isDone = false
    ),
    StudyReminder(
      id = "rem_2",
      title = "Série d'exercices : Dosage acido-basique & pH-métrie",
      subject = SubjectType.CHIMIE,
      dueDate = "Samedi 10:00",
      priority = ReminderPriority.IMPORTANT,
      chapterOrTheme = "C5 (Dosage pH-métrique)",
      estimatedMinutes = 45,
      isDone = false
    ),
    StudyReminder(
      id = "rem_3",
      title = "Mémoriser les formules clefs : Lois de Newton & Satellites",
      subject = SubjectType.PHYSIQUE,
      dueDate = "Dimanche",
      priority = ReminderPriority.CONSEILLE,
      chapterOrTheme = "P9 (Lois de Newton) & P11 (Mouvement des satellites)",
      estimatedMinutes = 30,
      isDone = true
    ),
    StudyReminder(
      id = "rem_4",
      title = "Épreuve blanche : Examen National 2025 Session Normale",
      subject = SubjectType.PHYSIQUE,
      dueDate = "Mercredi prochain",
      priority = ReminderPriority.IMPORTANT,
      chapterOrTheme = "Sujet complet (Physique + Chimie)",
      estimatedMinutes = 180,
      isDone = false
    ),
    StudyReminder(
      id = "rem_5",
      title = "Révision Piles Daniell & Électrolyse (sens direct/forcé)",
      subject = SubjectType.CHIMIE,
      dueDate = "Dans 1 semaine",
      priority = ReminderPriority.CONSEILLE,
      chapterOrTheme = "C7 (Piles) & C8 (Électrolyse)",
      estimatedMinutes = 40,
      isDone = false
    )
  )
}


