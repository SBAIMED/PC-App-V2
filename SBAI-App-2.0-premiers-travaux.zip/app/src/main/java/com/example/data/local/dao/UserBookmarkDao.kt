package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.UserBookmarkEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserBookmarkDao {

  @Query("SELECT * FROM user_bookmarks ORDER BY createdAt DESC")
  fun getAllBookmarks(): Flow<List<UserBookmarkEntity>>

  @Query("SELECT * FROM user_bookmarks WHERE chapterId = :chapterId ORDER BY createdAt DESC")
  fun getBookmarksForChapter(chapterId: String): Flow<List<UserBookmarkEntity>>

  @Query("SELECT * FROM user_bookmarks WHERE category = :category ORDER BY createdAt DESC")
  fun getBookmarksByCategory(category: String): Flow<List<UserBookmarkEntity>>

  @Query("SELECT COUNT(*) FROM user_bookmarks")
  fun getBookmarksCount(): Flow<Int>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBookmark(bookmark: UserBookmarkEntity): Long

  @Query("DELETE FROM user_bookmarks WHERE id = :id")
  suspend fun deleteBookmark(id: Long)

  @Query("DELETE FROM user_bookmarks WHERE chapterId = :chapterId AND title = :title")
  suspend fun deleteBookmarkByTitle(chapterId: String, title: String)

  @Query("SELECT COUNT(*) FROM user_bookmarks WHERE chapterId = :chapterId AND title = :title")
  suspend fun isBookmarked(chapterId: String, title: String): Int
}
