package com.example.data

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseApp

data class SystemStatusSummary(
  val isFirebaseInitialized: Boolean,
  val hasGoogleServicesConfig: Boolean,
  val hasGeminiApiKey: Boolean,
  val isStandaloneMode: Boolean
)

/**
 * Gestionnaire de tolérance aux pannes et résilience au lancement :
 * Permet à l'application de démarrer et de fonctionner à 100% de ses capacités
 * même si google-services.json est manquant ou si la clé Gemini n'est pas encore renseignée.
 */
object FirebaseSafetyManager {
  private const val TAG = "FirebaseSafetyManager"

  /**
   * Vérifie de façon sécurisée (sans exception) si FirebaseApp est initialisé.
   */
  fun isFirebaseAvailable(context: Context): Boolean {
    return try {
      val apps = FirebaseApp.getApps(context)
      if (apps.isNotEmpty()) {
        true
      } else {
        FirebaseApp.initializeApp(context) != null
      }
    } catch (t: Throwable) {
      Log.w(TAG, "Firebase non disponible ou non initialisé (Mode Local): ${t.message}")
      false
    }
  }

  /**
   * Résout l'identifiant Web Client pour Google Sign-In sans lever Resources.NotFoundException.
   */
  fun resolveWebClientId(context: Context): String? {
    return try {
      val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
      if (resId != 0) {
        val str = context.getString(resId)
        if (str.isNotBlank()) str else null
      } else {
        null
      }
    } catch (t: Throwable) {
      Log.d(TAG, "default_web_client_id non résolu (google-services.json absent ou partiel): ${t.message}")
      null
    }
  }

  /**
   * Résout l'identifiant Firestore Database ID de façon sécurisée.
   */
  fun resolveFirestoreDatabaseId(context: Context): String? {
    return try {
      val resId = context.resources.getIdentifier("firestore_database_id", "string", context.packageName)
      if (resId != 0) {
        val str = context.getString(resId)
        if (str.isNotBlank()) str else null
      } else {
        null
      }
    } catch (t: Throwable) {
      null
    }
  }

  /**
   * Indique si l'écosystème Cloud Firebase + Google Sign-In est pleinement prêt.
   */
  fun isCloudReady(context: Context): Boolean {
    return isFirebaseAvailable(context) && !resolveWebClientId(context).isNullOrBlank()
  }

  /**
   * Vérifie si une clé API Gemini valide a été injectée au build ou runtime.
   */
  fun isGeminiKeyConfigured(): Boolean {
    return try {
      val key = BuildConfig.GEMINI_API_KEY
      key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    } catch (t: Throwable) {
      false
    }
  }

  /**
   * Récupère la clé Gemini de manière sûre (retourne "" si inexistante).
   */
  fun getGeminiApiKey(): String {
    return try {
      BuildConfig.GEMINI_API_KEY
    } catch (t: Throwable) {
      ""
    }
  }

  /**
   * Fournit un résumé d'état pour les diagnostics UI.
   */
  fun getStatusSummary(context: Context): SystemStatusSummary {
    val firebaseOk = isFirebaseAvailable(context)
    val googleServicesOk = resolveWebClientId(context) != null
    val geminiOk = isGeminiKeyConfigured()
    return SystemStatusSummary(
      isFirebaseInitialized = firebaseOk,
      hasGoogleServicesConfig = googleServicesOk,
      hasGeminiApiKey = geminiOk,
      isStandaloneMode = !firebaseOk || !googleServicesOk
    )
  }
}
