package com.example.data.local.converters

import androidx.room.TypeConverter
import com.example.data.QuestionType
import com.example.data.ReminderPriority
import com.example.data.SubjectType
import com.example.data.UserRole

class AppTypeConverters {

  @TypeConverter
  fun fromStringList(value: List<String>?): String {
    return value?.joinToString("|||") ?: ""
  }

  @TypeConverter
  fun toStringList(value: String?): List<String> {
    if (value.isNullOrBlank()) return emptyList()
    return value.split("|||")
  }

  @TypeConverter
  fun fromSubjectType(value: SubjectType?): String {
    return value?.name ?: SubjectType.ALL.name
  }

  @TypeConverter
  fun toSubjectType(value: String?): SubjectType {
    return try {
      SubjectType.valueOf(value ?: SubjectType.ALL.name)
    } catch (_: Exception) {
      SubjectType.ALL
    }
  }

  @TypeConverter
  fun fromReminderPriority(value: ReminderPriority?): String {
    return value?.name ?: ReminderPriority.IMPORTANT.name
  }

  @TypeConverter
  fun toReminderPriority(value: String?): ReminderPriority {
    return try {
      ReminderPriority.valueOf(value ?: ReminderPriority.IMPORTANT.name)
    } catch (_: Exception) {
      ReminderPriority.IMPORTANT
    }
  }

  @TypeConverter
  fun fromUserRole(value: UserRole?): String {
    return value?.name ?: UserRole.ELEVE.name
  }

  @TypeConverter
  fun toUserRole(value: String?): UserRole {
    return try {
      UserRole.valueOf(value ?: UserRole.ELEVE.name)
    } catch (_: Exception) {
      UserRole.ELEVE
    }
  }
}
