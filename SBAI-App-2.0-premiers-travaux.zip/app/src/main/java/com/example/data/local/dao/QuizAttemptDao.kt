package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.QuizAttemptEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface QuizAttemptDao {

  @Query("SELECT * FROM quiz_attempts ORDER BY timestamp DESC")
  fun getAllAttempts(): Flow<List<QuizAttemptEntity>>

  @Query("SELECT * FROM quiz_attempts WHERE quizId = :quizId ORDER BY timestamp DESC")
  fun getAttemptsForQuiz(quizId: String): Flow<List<QuizAttemptEntity>>

  @Query("SELECT * FROM quiz_attempts ORDER BY timestamp DESC LIMIT :limit")
  fun getRecentAttempts(limit: Int = 10): Flow<List<QuizAttemptEntity>>

  @Query("SELECT AVG(percentage) FROM quiz_attempts")
  fun getAveragePercentage(): Flow<Double?>

  @Query("SELECT COUNT(*) FROM quiz_attempts WHERE passed = 1")
  fun getPassedCount(): Flow<Int>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAttempt(attempt: QuizAttemptEntity): Long

  @Query("DELETE FROM quiz_attempts WHERE id = :id")
  suspend fun deleteAttempt(id: Long)

  @Query("DELETE FROM quiz_attempts")
  suspend fun clearAllAttempts()
}
