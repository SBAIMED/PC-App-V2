package com.example.data

enum class UserRole(val label: String, val badge: String) {
  PROFESSEUR("Professeur", "Espace Enseignant"),
  ELEVE("Élève", "Espace Apprenant")
}

data class UserProfile(
  val id: String = "",
  val displayName: String = "",
  val email: String = "",
  val role: UserRole = UserRole.ELEVE,
  val userClass: String = "2ème Bac Sciences Physiques 1",
  val photoUrl: String? = null
)

enum class SubjectType(val label: String) {
  ALL("Tous"),
  PHYSIQUE("Physique"),
  CHIMIE("Chimie")
}

enum class Difficulty(val label: String, val stars: String, val points: Int) {
  FACILE("Facile", "★☆☆", 10),
  MOYEN("Moyen", "★★☆", 20),
  DIFFICILE("Défi / Difficile", "★★★", 35)
}

enum class SimulationType {
  CIRCUIT_RC,
  TITRAGE_ACIDO_BASIQUE,
  ONDES_PROGRESSIVES,
  DECROISSANCE_RADIOACTIVE,
  NONE
}

enum class ScientificChartType {
  NONE,
  RC_CHARGE,
  RC_DECHARGE,
  RL_ETABLISSEMENT,
  RLC_AMORTI,
  TITRAGE_PH,
  CINETIQUE_AVANCEMENT,
  DECROISSANCE_RADIOACTIVE,
  ONDE_CORDE_ASPECT,
  ONDE_ELONGATION_TEMPS,
  DIFFRACTION_FENTE,
  CHUTE_VERTICALE,
  PROJECTILE_PARABOLE,
  MONTAGE_CIRCUIT_RC,
  MONTAGE_TITRAGE,
  FACTEURS_CINETIQUES_TEMPERATURE,
  FACTEURS_CINETIQUES_CONCENTRATION,
  MONTAGE_PRESSIOMETRIE,
  ECHELLE_PH_PREDOMINANCE,
  DIAGRAMME_DISTRIBUTION_PKA,
  MONTAGE_PILE_DANIELL,
  MONTAGE_ELECTROLYSE,
  MONTAGE_CHAUFFAGE_REFLUX,
  CINETIQUE_ESTERIFICATION_HYDROLYSE,
  COURBE_ASTON_ENERGIE,
  MODULATION_AM_TRAPEZE,
  NEWTON_CINEMATIQUE_VT,
  SATELLITE_ORBITE_KEPLER,
  ROTATION_SOLIDE_VITESSE,
  OSCILLATEUR_PENDULE_XT,
  OSCILLATEUR_ENERGIE_EP_EC
}

data class Chapter(
  val id: String,
  val title: String,
  val subject: SubjectType,
  val level: String = "2ème Bac Sciences Physiques",
  val unit: String,
  val keywords: List<String> = emptyList(),
  val problematic: String = "",
  val contentSections: List<String> = emptyList(),
  val summary: String,
  val keyFormulas: List<String>,
  val activities: List<String> = emptyList(),
  val application: String = "",
  val simulationType: SimulationType = SimulationType.NONE,
  val simulationTitle: String? = null,
  val chartType: ScientificChartType = ScientificChartType.NONE,
  val chartTitle: String? = null,
  val chartExploitation: String? = null
)

data class Exercise(
  val id: String,
  val chapterId: String,
  val title: String,
  val subject: SubjectType,
  val statement: String,
  val chartType: ScientificChartType = ScientificChartType.NONE,
  val chartTitle: String? = null,
  val chartExploitation: String? = null,
  val hints: List<String>,
  val solutionSteps: List<String>,
  val tips: String
)

data class InteractiveQuestion(
  val id: String,
  val chapterTitle: String,
  val subject: SubjectType,
  val difficulty: Difficulty,
  val question: String,
  val options: List<String>,
  val correctOptionIndex: Int,
  val explanation: String
)

data class ExamSection(
  val domain: String, // "Chimie", "Physique - Ondes", "Physique - Électricité", "Physique - Mécanique"
  val title: String,
  val points: Double,
  val statement: String,
  val detailedCorrection: String
)

data class NationalExam(
  val id: String,
  val year: Int,
  val session: String, // "Normale", "Rattrapage"
  val branch: String, // "PC (Sciences Physiques)", "SVT", "SM (Sciences Maths)"
  val title: String,
  val durationHours: Double = 3.0,
  val coefficient: Int = 7,
  val sections: List<ExamSection>,
  val isOfflineDownloaded: Boolean = true
)

data class EvaluationContinuous(
  val id: String,
  val semester: Int, // 1 or 2
  val number: Int, // 1, 2, or 3
  val title: String,
  val durationMinutes: Int = 120,
  val coefficients: Double = 1.0,
  val chaptersCovered: List<String>,
  val questions: List<InteractiveQuestion>,
  val teacherRubric: String
)

data class StudentRecord(
  val id: String,
  val name: String,
  val classGroup: String, // ex: "2ème Bac PC 1"
  val s1c1: Double, // Semestre 1 Contrôle 1
  val s1c2: Double, // Semestre 1 Contrôle 2
  val s1c3: Double, // Semestre 1 Contrôle 3
  val s2c1: Double, // Semestre 2 Contrôle 1
  val s2c2: Double, // Semestre 2 Contrôle 2
  val s2c3: Double, // Semestre 2 Contrôle 3
  val interactiveScore: Int,
  val exercisesDone: Int,
  val badges: List<String>
) {
  val averageS1: Double
    get() = (s1c1 + s1c2 + s1c3) / 3.0

  val averageS2: Double
    get() = (s2c1 + s2c2 + s2c3) / 3.0

  val overallAverage: Double
    get() = (averageS1 + averageS2) / 2.0
}

data class MessageItem(
  val id: String,
  val senderName: String,
  val isTeacher: Boolean,
  val channel: String, // "Général", "Q&A Pr. SBAI", "Annonces"
  val message: String,
  val timestamp: String
)

data class NotificationItem(
  val id: String,
  val title: String,
  val message: String,
  val timeAgo: String,
  val category: String, // "Cours", "Contrôle", "Examen", "Annonce"
  var isRead: Boolean = false
)

data class PhysicalConstant(
  val symbol: String,
  val name: String,
  val value: String,
  val unit: String
)

enum class QuestionType(val label: String) {
  QCM("Choix Multiple (QCM)"),
  VRAI_FAUX("Vrai / Faux"),
  REPONSE_COURTE("Réponse Courte / Valeur")
}

data class CustomQuizQuestion(
  val id: String,
  val type: QuestionType,
  val prompt: String,
  val options: List<String> = emptyList(),
  val correctOptionIndex: Int = 0,
  val correctBoolean: Boolean = true,
  val correctAnswerText: String = "",
  val explanation: String = "",
  val points: Double = 2.0
)

data class CustomQuiz(
  val id: String,
  val title: String,
  val subject: SubjectType,
  val targetClass: String,
  val createdBy: String = "Professeur SBAI Mohammed",
  val durationMinutes: Int = 30,
  val questions: List<CustomQuizQuestion>,
  val driveResourceUrl: String = "https://drive.google.com/drive/folders/1jLMMiSIeySEj5ycCaKe4vD5e-V9zXYbX",
  val isPublished: Boolean = true
) {
  val totalPoints: Double
    get() = questions.sumOf { it.points }
}

data class QuizSubmission(
  val quizId: String,
  val studentName: String,
  val score: Double,
  val maxScore: Double,
  val submittedAt: String,
  val isGradedAutomatically: Boolean = true
)

enum class ReminderPriority(val label: String) {
  URGENT("Urgent"),
  IMPORTANT("Important"),
  CONSEILLE("Conseillé")
}

data class StudyReminder(
  val id: String,
  val title: String,
  val subject: SubjectType,
  val dueDate: String,
  val priority: ReminderPriority = ReminderPriority.IMPORTANT,
  val chapterOrTheme: String = "",
  val estimatedMinutes: Int = 45,
  val isDone: Boolean = false
)


