package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_records")
data class StudentRecordEntity(
  @PrimaryKey val id: String, // e.g. "std_1"
  val name: String,
  val classGroup: String,
  val s1c1: Double,
  val s1c2: Double,
  val s1c3: Double,
  val s2c1: Double,
  val s2c2: Double,
  val s2c3: Double,
  val interactiveScore: Int,
  val exercisesDone: Int,
  val badges: List<String> = emptyList(),
  val lastUpdated: Long = System.currentTimeMillis()
) {
  val averageS1: Double
    get() = (s1c1 + s1c2 + s1c3) / 3.0

  val averageS2: Double
    get() = (s2c1 + s2c2 + s2c3) / 3.0

  val overallAverage: Double
    get() = (averageS1 + averageS2) / 2.0
}
