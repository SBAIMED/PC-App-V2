package com.example.data.repository

import android.content.Context
import com.example.data.CurriculumData
import com.example.data.OfficialCurriculum
import com.example.data.local.AppDatabase
import com.example.data.local.entity.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppLocalRepository(private val database: AppDatabase) {

  private val chapterProgressDao = database.chapterProgressDao()
  private val quizAttemptDao = database.quizAttemptDao()
  private val studyReminderDao = database.studyReminderDao()
  private val chatMessageDao = database.chatMessageDao()
  private val customQuizDao = database.customQuizDao()
  private val userBookmarkDao = database.userBookmarkDao()
  private val studentRecordDao = database.studentRecordDao()

  // --- Chapter Progress Flows ---
  val allChapterProgress: Flow<List<ChapterProgressEntity>> = chapterProgressDao.getAllProgress()
  val bookmarkedChapters: Flow<List<ChapterProgressEntity>> = chapterProgressDao.getBookmarkedChapters()
  val physicsCompletedCount: Flow<Int> = chapterProgressDao.getCompletedCount("PHYSIQUE")
  val chemistryCompletedCount: Flow<Int> = chapterProgressDao.getCompletedCount("CHIMIE")
  val totalCompletedCount: Flow<Int> = chapterProgressDao.getTotalCompletedCount()

  fun getProgressForChapter(chapterId: String): Flow<ChapterProgressEntity?> =
    chapterProgressDao.getProgressForChapter(chapterId)

  suspend fun setChapterCompletion(chapterId: String, completed: Boolean) = withContext(Dispatchers.IO) {
    chapterProgressDao.updateCompletion(chapterId, completed)
  }

  suspend fun toggleChapterBookmark(chapterId: String, currentBookmarked: Boolean) = withContext(Dispatchers.IO) {
    chapterProgressDao.updateBookmark(chapterId, !currentBookmarked)
  }

  suspend fun saveChapterNotes(chapterId: String, notes: String) = withContext(Dispatchers.IO) {
    chapterProgressDao.updateNotes(chapterId, notes)
  }

  suspend fun saveChapterQuizScore(chapterId: String, score: Int) = withContext(Dispatchers.IO) {
    chapterProgressDao.updateQuizScore(chapterId, score)
  }

  // --- Quiz Attempts Flows ---
  val allQuizAttempts: Flow<List<QuizAttemptEntity>> = quizAttemptDao.getAllAttempts()
  val recentQuizAttempts: Flow<List<QuizAttemptEntity>> = quizAttemptDao.getRecentAttempts(10)
  val averageQuizPercentage: Flow<Double?> = quizAttemptDao.getAveragePercentage()
  val passedQuizCount: Flow<Int> = quizAttemptDao.getPassedCount()

  suspend fun recordQuizAttempt(
    quizId: String,
    quizTitle: String,
    subject: String,
    score: Double,
    maxScore: Double,
    studentName: String,
    timeSpentSeconds: Int = 0
  ): Long = withContext(Dispatchers.IO) {
    val percentage = if (maxScore > 0) (score / maxScore) * 100.0 else 0.0
    val passed = percentage >= 50.0
    val entity = QuizAttemptEntity(
      quizId = quizId,
      quizTitle = quizTitle,
      subject = subject,
      score = score,
      maxScore = maxScore,
      percentage = percentage,
      studentName = studentName,
      passed = passed,
      timeSpentSeconds = timeSpentSeconds
    )
    quizAttemptDao.insertAttempt(entity)
  }

  // --- Study Reminders Flows ---
  val allReminders: Flow<List<StudyReminderEntity>> = studyReminderDao.getAllReminders()
  val activeReminders: Flow<List<StudyReminderEntity>> = studyReminderDao.getActiveReminders()
  val activeRemindersCount: Flow<Int> = studyReminderDao.getActiveRemindersCount()

  suspend fun addStudyReminder(
    title: String,
    subject: String,
    dueDate: String,
    priority: String,
    chapterOrTheme: String = "",
    estimatedMinutes: Int = 45
  ) = withContext(Dispatchers.IO) {
    val uniqueId = "rem_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(6)}"
    val entity = StudyReminderEntity(
      id = uniqueId,
      title = title,
      subject = subject,
      dueDate = dueDate,
      priority = priority,
      chapterOrTheme = chapterOrTheme,
      estimatedMinutes = estimatedMinutes,
      isDone = false
    )
    studyReminderDao.insertReminder(entity)
  }

  suspend fun toggleReminderDone(id: String, currentDone: Boolean) = withContext(Dispatchers.IO) {
    studyReminderDao.updateDoneStatus(id, !currentDone)
  }

  suspend fun deleteStudyReminder(id: String) = withContext(Dispatchers.IO) {
    studyReminderDao.deleteReminder(id)
  }

  // --- Chat Messages Flows ---
  val allMessages: Flow<List<ChatMessageEntity>> = chatMessageDao.getAllMessages()

  fun getMessagesByChannel(channel: String): Flow<List<ChatMessageEntity>> {
    return if (channel == "Tous" || channel.isBlank()) {
      chatMessageDao.getAllMessages()
    } else {
      chatMessageDao.getMessagesByChannel(channel)
    }
  }

  suspend fun sendChatMessage(
    senderName: String,
    message: String,
    channel: String,
    isTeacher: Boolean
  ) = withContext(Dispatchers.IO) {
    val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
    val formattedTime = "Aujourd'hui à ${formatter.format(Date())}"
    val uniqueId = "msg_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(6)}"
    val entity = ChatMessageEntity(
      id = uniqueId,
      senderName = senderName,
      isTeacher = isTeacher,
      channel = channel,
      message = message,
      timestampFormatted = formattedTime,
      timestampMillis = System.currentTimeMillis()
    )
    chatMessageDao.insertMessage(entity)
  }

  suspend fun deleteChatMessage(id: String) = withContext(Dispatchers.IO) {
    chatMessageDao.deleteMessage(id)
  }

  // --- Custom Quizzes Flows ---
  val allCustomQuizzes: Flow<List<CustomQuizEntity>> = customQuizDao.getAllQuizzes()

  suspend fun saveCustomQuiz(
    title: String,
    subject: String,
    targetClass: String,
    createdBy: String,
    durationMinutes: Int,
    questionsJson: String,
    driveResourceUrl: String = ""
  ) = withContext(Dispatchers.IO) {
    val uniqueId = "quiz_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(6)}"
    val entity = CustomQuizEntity(
      id = uniqueId,
      title = title,
      subject = subject,
      targetClass = targetClass,
      createdBy = createdBy,
      durationMinutes = durationMinutes,
      questionsJson = questionsJson,
      driveResourceUrl = driveResourceUrl,
      isPublished = true
    )
    customQuizDao.insertQuiz(entity)
  }

  suspend fun deleteCustomQuiz(id: String) = withContext(Dispatchers.IO) {
    customQuizDao.deleteQuiz(id)
  }

  // --- User Bookmarks Flows ---
  val allBookmarks: Flow<List<UserBookmarkEntity>> = userBookmarkDao.getAllBookmarks()
  val bookmarksCount: Flow<Int> = userBookmarkDao.getBookmarksCount()

  suspend fun addBookmark(
    chapterId: String,
    title: String,
    contentLatex: String,
    category: String,
    notes: String = ""
  ): Long = withContext(Dispatchers.IO) {
    userBookmarkDao.insertBookmark(
      UserBookmarkEntity(
        chapterId = chapterId,
        title = title,
        contentLatex = contentLatex,
        category = category,
        notes = notes
      )
    )
  }

  suspend fun removeBookmark(id: Long) = withContext(Dispatchers.IO) {
    userBookmarkDao.deleteBookmark(id)
  }

  suspend fun toggleFormulaBookmark(
    chapterId: String,
    title: String,
    contentLatex: String
  ) = withContext(Dispatchers.IO) {
    val exists = userBookmarkDao.isBookmarked(chapterId, title) > 0
    if (exists) {
      userBookmarkDao.deleteBookmarkByTitle(chapterId, title)
    } else {
      userBookmarkDao.insertBookmark(
        UserBookmarkEntity(
          chapterId = chapterId,
          title = title,
          contentLatex = contentLatex,
          category = "FORMULE"
        )
      )
    }
  }

  // --- Student Records Flows ---
  val allStudentRecords: Flow<List<StudentRecordEntity>> = studentRecordDao.getAllStudents()

  suspend fun saveStudentRecord(record: StudentRecordEntity) = withContext(Dispatchers.IO) {
    studentRecordDao.insertOrUpdate(record)
  }

  // --- Automatic Seed on First Boot ---
  suspend fun seedInitialDataIfNeeded() = withContext(Dispatchers.IO) {
    // 1. Seed Chapter Progress if empty
    if (chapterProgressDao.getCount() == 0) {
      val initialChapters = OfficialCurriculum.allChapters.mapIndexed { index, ch ->
        val isPhysique = ch.id.startsWith("P")
        val num = ch.id.drop(1).toIntOrNull() ?: 0
        // Seed realistic initial completion: first 12 Physics and first 7 Chemistry completed
        val completed = if (isPhysique) num <= 12 else num <= 7
        val bookmarked = ch.id in listOf("P6", "P9", "C5", "C8")
        val score = if (completed) (70 + (index * 7) % 30) else 0
        ChapterProgressEntity(
          chapterId = ch.id,
          title = ch.title,
          subject = ch.subject.name,
          unit = ch.unit,
          isCompleted = completed,
          isBookmarked = bookmarked,
          notes = if (ch.id == "P6") "Bien maîtriser la méthode des tangentes pour tau = R*C et l'énergie emmagasinée 1/2 C*u_C^2." else "",
          quizScore = score,
          exercisesDoneCount = if (completed) 2 else 0
        )
      }
      chapterProgressDao.insertAll(initialChapters)
    }

    // 2. Seed Study Reminders if empty
    if (studyReminderDao.getCount() == 0) {
      val reminders = CurriculumData.initialStudyReminders.map { rem ->
        StudyReminderEntity(
          id = rem.id,
          title = rem.title,
          subject = rem.subject.name,
          dueDate = rem.dueDate,
          priority = rem.priority.name,
          chapterOrTheme = rem.chapterOrTheme,
          estimatedMinutes = rem.estimatedMinutes,
          isDone = rem.isDone
        )
      }
      studyReminderDao.insertAll(reminders)
    }

    // 3. Seed Chat Messages if empty
    if (chatMessageDao.getCount() == 0) {
      val msgs = CurriculumData.initialMessages.mapIndexed { index, m ->
        ChatMessageEntity(
          id = m.id,
          senderName = m.senderName,
          isTeacher = m.isTeacher,
          channel = m.channel,
          message = m.message,
          timestampFormatted = m.timestamp,
          timestampMillis = System.currentTimeMillis() - ((3 - index) * 3600_000L)
        )
      }
      chatMessageDao.insertAll(msgs)
    }

    // 4. Seed Student Records if empty
    if (studentRecordDao.getCount() == 0) {
      val students = CurriculumData.initialStudents.map { s ->
        StudentRecordEntity(
          id = s.id,
          name = s.name,
          classGroup = s.classGroup,
          s1c1 = s.s1c1,
          s1c2 = s.s1c2,
          s1c3 = s.s1c3,
          s2c1 = s.s2c1,
          s2c2 = s.s2c2,
          s2c3 = s.s2c3,
          interactiveScore = s.interactiveScore,
          exercisesDone = s.exercisesDone,
          badges = s.badges
        )
      }
      studentRecordDao.insertAll(students)
    }

    // 5. Seed initial Custom Quizzes if empty
    if (customQuizDao.getCount() == 0) {
      val initialQuizzes = CurriculumData.initialCustomQuizzes.map { q ->
        CustomQuizEntity(
          id = q.id,
          title = q.title,
          subject = q.subject.name,
          targetClass = q.targetClass,
          createdBy = q.createdBy,
          durationMinutes = q.durationMinutes,
          questionsJson = com.example.data.QuizJsonUtils.serializeQuestionsToJson(q.questions),
          driveResourceUrl = q.driveResourceUrl,
          isPublished = q.isPublished
        )
      }
      customQuizDao.insertAll(initialQuizzes)
    }
  }

  companion object {
    @Volatile
    private var INSTANCE: AppLocalRepository? = null

    fun getInstance(context: Context): AppLocalRepository {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: AppLocalRepository(AppDatabase.getInstance(context)).also { INSTANCE = it }
      }
    }
  }
}
