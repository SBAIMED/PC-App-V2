package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quiz_attempts")
data class QuizAttemptEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val quizId: String, // e.g. "cc_s1_c1", "quiz_p6", "custom_1"
  val quizTitle: String,
  val subject: String, // "PHYSIQUE", "CHIMIE", "ALL"
  val score: Double,
  val maxScore: Double,
  val percentage: Double,
  val studentName: String,
  val passed: Boolean,
  val timeSpentSeconds: Int = 0,
  val timestamp: Long = System.currentTimeMillis()
)
