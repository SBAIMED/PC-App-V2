package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_reminders")
data class StudyReminderEntity(
  @PrimaryKey val id: String,
  val title: String,
  val subject: String, // "PHYSIQUE", "CHIMIE", "ALL"
  val dueDate: String,
  val priority: String, // "URGENT", "IMPORTANT", "CONSEILLE"
  val chapterOrTheme: String = "",
  val estimatedMinutes: Int = 45,
  val isDone: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)
