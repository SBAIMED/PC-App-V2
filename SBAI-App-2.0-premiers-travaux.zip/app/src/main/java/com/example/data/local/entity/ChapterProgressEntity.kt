package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chapter_progress")
data class ChapterProgressEntity(
  @PrimaryKey val chapterId: String, // e.g. "P1", "P6", "C5"
  val title: String,
  val subject: String, // "PHYSIQUE" or "CHIMIE"
  val unit: String,
  val isCompleted: Boolean = false,
  val isBookmarked: Boolean = false,
  val notes: String = "",
  val quizScore: Int = 0, // Best quiz score (0..100)
  val exercisesDoneCount: Int = 0,
  val lastStudiedTimestamp: Long = System.currentTimeMillis()
)
