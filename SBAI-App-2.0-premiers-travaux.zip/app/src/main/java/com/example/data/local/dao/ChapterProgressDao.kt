package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.ChapterProgressEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChapterProgressDao {

  @Query("SELECT * FROM chapter_progress ORDER BY chapterId ASC")
  fun getAllProgress(): Flow<List<ChapterProgressEntity>>

  @Query("SELECT * FROM chapter_progress WHERE chapterId = :chapterId LIMIT 1")
  fun getProgressForChapter(chapterId: String): Flow<ChapterProgressEntity?>

  @Query("SELECT * FROM chapter_progress WHERE subject = :subject ORDER BY chapterId ASC")
  fun getProgressBySubject(subject: String): Flow<List<ChapterProgressEntity>>

  @Query("SELECT * FROM chapter_progress WHERE isBookmarked = 1")
  fun getBookmarkedChapters(): Flow<List<ChapterProgressEntity>>

  @Query("SELECT COUNT(*) FROM chapter_progress WHERE subject = :subject AND isCompleted = 1")
  fun getCompletedCount(subject: String): Flow<Int>

  @Query("SELECT COUNT(*) FROM chapter_progress WHERE isCompleted = 1")
  fun getTotalCompletedCount(): Flow<Int>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdate(progress: ChapterProgressEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(list: List<ChapterProgressEntity>)

  @Query("UPDATE chapter_progress SET isCompleted = :completed, lastStudiedTimestamp = :timestamp WHERE chapterId = :chapterId")
  suspend fun updateCompletion(chapterId: String, completed: Boolean, timestamp: Long = System.currentTimeMillis())

  @Query("UPDATE chapter_progress SET isBookmarked = :bookmarked WHERE chapterId = :chapterId")
  suspend fun updateBookmark(chapterId: String, bookmarked: Boolean)

  @Query("UPDATE chapter_progress SET notes = :notes WHERE chapterId = :chapterId")
  suspend fun updateNotes(chapterId: String, notes: String)

  @Query("UPDATE chapter_progress SET quizScore = :score, lastStudiedTimestamp = :timestamp WHERE chapterId = :chapterId")
  suspend fun updateQuizScore(chapterId: String, score: Int, timestamp: Long = System.currentTimeMillis())

  @Query("SELECT COUNT(*) FROM chapter_progress")
  suspend fun getCount(): Int
}
