package com.example.data

import org.json.JSONArray
import org.json.JSONObject

object QuizJsonUtils {

  fun serializeQuestionsToJson(questions: List<CustomQuizQuestion>): String {
    val array = JSONArray()
    for (q in questions) {
      val obj = JSONObject()
      obj.put("id", q.id)
      obj.put("type", q.type.name)
      obj.put("prompt", q.prompt)
      val optArr = JSONArray()
      q.options.forEach { optArr.put(it) }
      obj.put("options", optArr)
      obj.put("correctOptionIndex", q.correctOptionIndex)
      obj.put("correctBoolean", q.correctBoolean)
      obj.put("correctAnswerText", q.correctAnswerText)
      obj.put("explanation", q.explanation)
      obj.put("points", q.points)
      array.put(obj)
    }
    return array.toString()
  }

  fun parseQuestionsFromJson(json: String): List<CustomQuizQuestion> {
    if (json.isBlank() || json == "[]") return emptyList()
    val list = mutableListOf<CustomQuizQuestion>()
    try {
      val array = JSONArray(json)
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val typeStr = obj.optString("type", "QCM")
        val type = runCatching { QuestionType.valueOf(typeStr) }.getOrDefault(QuestionType.QCM)
        val optArr = obj.optJSONArray("options")
        val options = mutableListOf<String>()
        if (optArr != null) {
          for (j in 0 until optArr.length()) {
            options.add(optArr.getString(j))
          }
        }
        list.add(
          CustomQuizQuestion(
            id = obj.optString("id", "cq_$i"),
            type = type,
            prompt = obj.optString("prompt", ""),
            options = options,
            correctOptionIndex = obj.optInt("correctOptionIndex", 0),
            correctBoolean = obj.optBoolean("correctBoolean", true),
            correctAnswerText = obj.optString("correctAnswerText", ""),
            explanation = obj.optString("explanation", ""),
            points = obj.optDouble("points", 2.0)
          )
        )
      }
    } catch (e: Exception) {
      // Fallback in case of parsing issue
    }
    return list
  }
}
