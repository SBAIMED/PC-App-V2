package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.ChatMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {

  @Query("SELECT * FROM chat_messages ORDER BY timestampMillis ASC")
  fun getAllMessages(): Flow<List<ChatMessageEntity>>

  @Query("SELECT * FROM chat_messages WHERE channel = :channel ORDER BY timestampMillis ASC")
  fun getMessagesByChannel(channel: String): Flow<List<ChatMessageEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessage(message: ChatMessageEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(messages: List<ChatMessageEntity>)

  @Query("DELETE FROM chat_messages WHERE id = :id")
  suspend fun deleteMessage(id: String)

  @Query("SELECT COUNT(*) FROM chat_messages")
  suspend fun getCount(): Int
}
