package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
  @PrimaryKey val id: String,
  val senderName: String,
  val isTeacher: Boolean,
  val channel: String, // "Tous", "Annonces", "Q&A Pr. SBAI"
  val message: String,
  val timestampFormatted: String,
  val timestampMillis: Long = System.currentTimeMillis()
)
