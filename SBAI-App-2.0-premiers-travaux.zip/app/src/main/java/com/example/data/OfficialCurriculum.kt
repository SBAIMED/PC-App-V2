package com.example.data

object OfficialCurriculum {

  val allChapters: List<Chapter> = listOf(
    // =========================================================================
    // PARTIE I — PHYSIQUE (16 Chapitres : P1 à P16)
    // =========================================================================

    // --- UNITÉ 1 : ONDES ---
    Chapter(
      id = "P1",
      title = "P1 · Ondes mécaniques progressives",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 1 — Ondes",
      keywords = listOf("onde mécanique", "perturbation", "milieu élastique", "onde longitudinale", "onde transversale", "superposition", "célérité", "retard temporel"),
      problematic = "Qu’est-ce qu’une onde mécanique progressive ? Quels sont les différents types d’ondes progressives ? Quelles sont les caractéristiques d’une onde progressive ?",
      contentSections = listOf(
        "1. Onde mécanique progressive : propagation d'une perturbation dans un milieu élastique sans transport de matière mais avec transport d'énergie. Le son est une onde mécanique qui ne se propage pas dans le vide.",
        "2. Types d’ondes : Onde longitudinale (perturbation parallèle à la propagation : ressort, son) ; Onde transversale (perturbation perpendiculaire : corde, surface de l'eau).",
        "3. Propriétés générales : Principe de superposition sans déformation ; Célérité indépendante de l'amplitude mais dépendante du milieu (température, élasticité, inertie).",
        "4. Retard temporel : Tout point M reproduit le mouvement de la source S avec un retard \\tau = \\frac{SM}{v}. Relation d'élongation : y_M(t) = y_S(t - \\tau)."
      ),
      summary = "Propagation d’une perturbation dans un milieu élastique avec transport d’énergie sans transport de matière. Types transversal et longitudinal, célérité et retard temporel.",
      keyFormulas = listOf(
        "v = \\frac{d}{\\Delta t} \\quad (\\text{Célérité en m}\\cdot\\text{s}^{-1})",
        "v = \\sqrt{\\frac{T}{\\mu}} \\quad \\text{avec } \\mu = \\frac{m}{\\ell} \\quad (\\text{Corde})",
        "\\tau = \\frac{SM}{v} \\quad (\\text{Retard temporel})",
        "y_M(t) = y_S(t - \\tau) \\quad (\\text{Élongation})"
      ),
      activities = listOf(
        "Activité 1 — Trois expériences (corde tendue, ressort comprimé, cuve à eau) : observation du transport d'énergie sans transport de matière.",
        "Activité 2 — Onde sonore : diapason, balle de liège et cloche à vide concluant sur l'impossibilité de propagation dans le vide.",
        "Activité 3 — Superposition de deux déformations transversales se croisant sur une corde.",
        "Activité 4 — Célérité sur une corde : mesure avec cavaliers, photocapteurs et chronomètre en fonction de T et μ."
      ),
      application = "Utilisation du retard temporel pour le sonar et l'échographie ; exploitation des oscillogrammes d'élongation y(t) de deux points.",
      simulationType = SimulationType.ONDES_PROGRESSIVES,
      simulationTitle = "Laboratoire d'Ondes Mécaniques Progressives",
      chartType = ScientificChartType.ONDE_CORDE_ASPECT,
      chartTitle = "Aspect de la corde à date fixée : élongation spatiale y = f(x)",
      chartExploitation = "Mesure de la longueur d'onde λ = 40 cm entre deux crêtes et position du front d'onde x_F = 80 cm à t_1 = 40 ms pour calculer la célérité v = x_F/t_1 = 20 m/s."
    ),

    Chapter(
      id = "P2",
      title = "P2 · Ondes mécaniques progressives périodiques",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 1 — Ondes",
      keywords = listOf("période", "fréquence", "longueur d'onde", "double périodicité", "diffraction", "dispersion", "milieu dispersif"),
      problematic = "Comment caractériser une onde progressive périodique ? Que se passe-t-il lorsqu’elle rencontre un obstacle ?",
      contentSections = listOf(
        "1. Périodicité temporelle : Période T (durée minimale de répétition), fréquence \\nu = 1/T indépendante du milieu. Onde sinusoïdale y(t) = A \\cos(2\\pi t/T + \\varphi).",
        "2. Périodicité spatiale : Longueur d’onde \\lambda = v \\cdot T = v/\\nu. Deux points vibrent en phase si d = n \\lambda, en opposition de phase si d = (2n+1)\\lambda/2.",
        "3. Diffraction : Manifestation lorsque la largeur a d’une ouverture ou d'un obstacle vérifie a \\le \\lambda. L'onde diffractée conserve même fréquence et même célérité.",
        "4. Dispersion : Milieu dispersif si la célérité v dépend de la fréquence \\nu (ex : la surface de l'eau dans une cuve à ondes)."
      ),
      summary = "Double périodicité temporelle (T) et spatiale (λ). Phénomènes de diffraction (a ≤ λ) et de dispersion de l’onde progressive sinusoïdale.",
      keyFormulas = listOf(
        "\\nu = \\frac{1}{T} \\quad (\\text{Fréquence en Hz})",
        "\\lambda = v \\cdot T = \\frac{v}{\\nu} \\quad (\\text{Longueur d'onde})",
        "y(t) = A \\cos\\left(\\frac{2\\pi t}{T} + \\varphi\\right) \\quad (\\text{Onde sinusoïdale})",
        "d = n \\cdot \\lambda \\quad (\\text{En phase}) \\quad / \\quad d = (2n+1)\\frac{\\lambda}{2} \\quad (\\text{Opposition})",
        "a \\le \\lambda \\quad (\\text{Condition de diffraction marquée})"
      ),
      activities = listOf(
        "Activité 1 — Périodicité temporelle : son d'un diapason visualisé à l'oscilloscope.",
        "Activité 2 — Périodicité spatiale : haut-parleur GBF (3 kHz) et deux microphones M1 et M2 mobiles sur règle.",
        "Activité 3 — Diffraction à la surface de l'eau avec fente réglable dans une cuve à ondes.",
        "Activité 4 — Dispersion : mesure de la longueur d'onde λ pour différentes fréquences ν."
      ),
      application = "Exercices sur la houle marine et sa diffraction à l'entrée d'un port ; mesure expérimentale de la célérité du son dans l'air.",
      simulationType = SimulationType.ONDES_PROGRESSIVES,
      simulationTitle = "Oscilloscope Virtuel : Fréquence et Longueur d'Onde",
      chartType = ScientificChartType.ONDE_ELONGATION_TEMPS,
      chartTitle = "Élongation d'un point M en fonction du temps : y_M = f(t)",
      chartExploitation = "Mesure de la période temporelle T = 20 ms et du retard temporel τ = 40 ms du point M par rapport à la source S."
    ),

    Chapter(
      id = "P3",
      title = "P3 · Propagation d’une onde lumineuse",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 1 — Ondes",
      keywords = listOf("diffraction lumière", "écart angulaire", "célérité", "indice de réfraction", "Descartes", "prisme", "dispersion"),
      problematic = "Quelle est la nature de la lumière ? Comment expliquer le phénomène de l’arc-en-ciel ?",
      contentSections = listOf(
        "1. Nature ondulatoire de la lumière : La diffraction d'un faisceau laser par une fente de largeur a prouve la nature ondulatoire. Écart angulaire \\theta = \\lambda/a \\approx L/(2D).",
        "2. Propagation dans le vide : Célérité universelle c = 299\\,792\\,458\\text{ m}\\cdot\\text{s}^{-1} \\approx 3\\times 10^8\\text{ m}\\cdot\\text{s}^{-1}. Longueur d'onde dans le vide \\lambda_0 = c/\\nu.",
        "3. Propagation dans un milieu transparent : Indice de réfraction n = c/v > 1. Lois de Descartes pour le prisme : \\sin i = n \\sin r, A = r + r', D = i + i' - A.",
        "4. Dispersion par un prisme : L'indice n dépend de la fréquence (formule de Cauchy). Le violet est plus dévié que le rouge."
      ),
      summary = "Nature ondulatoire électromagnétique de la lumière, diffraction par une fente (θ = λ/a), réfraction et dispersion par un prisme.",
      keyFormulas = listOf(
        "\\theta = \\frac{\\lambda}{a} \\approx \\frac{L}{2D} \\quad (\\text{Diffraction par une fente})",
        "c = 299\\,792\\,458\\text{ m}\\cdot\\text{s}^{-1}, \\quad \\lambda_0 = \\frac{c}{\\nu}",
        "n = \\frac{c}{v} \\quad (\\text{Indice de réfraction})",
        "\\sin i = n \\sin r \\quad \\text{et} \\quad \\sin i' = n \\sin r' \\quad (\\text{Prisme})",
        "A = r + r' \\quad \\text{et} \\quad D = i + i' - A \\quad (\\text{Déviation})"
      ),
      activities = listOf(
        "Activité 1 — Diffraction d'un laser par une fente, un fil calibré et un trou circulaire.",
        "Activité 2 — Étude de l'écart angulaire θ en fonction de 1/a pour deux lasers (rouge 633 nm et vert 530 nm).",
        "Activité 3 — Faisceau laser traversant un prisme : vérification expérimentale des lois de Descartes.",
        "Activité 4 — Décomposition de la lumière blanche par un prisme en verre dispersif."
      ),
      application = "Mesure du diamètre d'un cheveu par diffraction ; calcul de l'indice de réfraction d'un bloc de verre ou de plexiglas.",
      chartType = ScientificChartType.DIFFRACTION_FENTE,
      chartTitle = "Dispositif expérimental et figure de diffraction laser",
      chartExploitation = "Relation entre la largeur de la tache centrale L, la longueur d'onde λ, la distance fente-écran D et la largeur de fente a : L = 2·λ·D / a."
    ),

    // --- UNITÉ 2 : TRANSFORMATIONS NUCLÉAIRES ---
    Chapter(
      id = "P4",
      title = "P4 · Décroissance radioactive",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 2 — Transformations nucléaires",
      keywords = listOf("noyau", "isotopes", "diagramme Segré", "radioactivité", "lois de Soddy", "décroissance", "demi-vie", "activité", "datation"),
      problematic = "Qu’est-ce qu’une substance radioactive ? Quels sont les différents types de rayonnement qu’elle peut émettre ?",
      contentSections = listOf(
        "1. Stabilité et instabilité : Noyau constitué de Z protons et N neutrons (A = Z + N). Diagramme de Segré (N, Z). Radioactivités alpha, bêta moins, bêta plus et désexcitation gamma.",
        "2. Lois de conservation de Soddy : Conservation du nombre de nucléons A et de la charge électrique Z.",
        "3. Loi de décroissance : N(t) = N_0 e^{-\\lambda t}. Constante de temps \\tau = 1/\\lambda. Demi-vie t_{1/2} = \\frac{\\ln 2}{\\lambda}.",
        "4. Activité radioactive : a(t) = -\\frac{dN}{dt} = \\lambda N(t) = a_0 e^{-\\lambda t} exprimée en Becquerels (1 Bq = 1 désintégration/seconde).",
        "5. Datation radioactive : Détermination de l'âge d'un échantillon par datation au Carbone 14 : t = \\frac{t_{1/2}}{\\ln 2} \\ln\\left(\\frac{a_0}{a(t)}\\right)."
      ),
      summary = "Stabilité des noyaux, types de rayonnements (α, β⁻, β⁺, γ), loi de décroissance N(t) = N₀exp(-λt), demi-vie et datation au carbone 14.",
      keyFormulas = listOf(
        "N(t) = N_0 \\cdot e^{-\\lambda t} \\quad (\\text{Loi de décroissance})",
        "t_{1/2} = \\frac{\\ln 2}{\\lambda} = \\tau \\ln 2 \\quad (\\text{Demi-vie})",
        "a(t) = \\lambda N(t) = a_0 \\cdot e^{-\\lambda t} \\quad (\\text{Activité en Bq})",
        "t = -\\frac{t_{1/2}}{\\ln 2} \\ln\\left(\\frac{a(t)}{a_0}\\right) \\quad (\\text{Datation au Carbone 14})"
      ),
      activities = listOf(
        "Activité 1 — Composition du noyau atomique et calcul de sa masse volumique (2×10¹⁷ kg·m⁻³).",
        "Activité 2 — Lecture du diagramme de Segré (N,Z) et identification des zones de stabilité.",
        "Activité 3 — Écriture des équations de désintégration avec les lois de Soddy pour le Polonium et le Cobalt.",
        "Activité 4 — Simulation de la loi de décroissance radioactive et tracé de la courbe N(t)."
      ),
      application = "Datation archéologique d'un fragment de charbon de bois préhistorique ; calcul de la décroissance de l'Iode 131 médical.",
      simulationType = SimulationType.DECROISSANCE_RADIOACTIVE,
      simulationTitle = "Compteur Geiger & Simulation de Décroissance Nucléaire",
      chartType = ScientificChartType.DECROISSANCE_RADIOACTIVE,
      chartTitle = "Courbe exponentielle de décroissance de l'activité A(t)",
      chartExploitation = "Détermination graphique de la demi-vie t_1/2 à A = A_0 / 2 et lecture de l'activité restante aux dates successives."
    ),

    Chapter(
      id = "P5",
      title = "P5 · Noyaux, masse et énergie",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 2 — Transformations nucléaires",
      keywords = listOf("E=mc²", "unité de masse atomique", "défaut de masse", "énergie de liaison", "courbe d'Aston", "fission", "fusion"),
      problematic = "Comment produit-on de l’énergie nucléaire ? Quels sont les avantages et les inconvénients de l’énergie nucléaire ?",
      contentSections = listOf(
        "1. Équivalence masse-énergie d'Einstein : E = m c^2. Unité de masse atomique 1 u = 1,66054×10⁻²⁷ kg = 931,5 MeV/c².",
        "2. Énergie de liaison du noyau : Défaut de masse \\Delta m = [Z m_p + (A-Z) m_n] - m(\\text{noyau}). Énergie de liaison E_\\ell = \\Delta m c^2.",
        "3. Stabilité et courbe d’Aston : Énergie de liaison par nucléon \\xi = E_\\ell/A. Les noyaux les plus stables ont A compris entre 50 et 75 (environ 8,7 MeV/nucléon, ex : Fer 56).",
        "4. Réactions nucléaires provoquées : Fission (éclatement d'un noyau lourd comme l'Uranium 235) et Fusion (union de noyaux légers deutérium et tritium)."
      ),
      summary = "Équivalence masse-énergie d'Einstein (E = mc²), défaut de masse, énergie de liaison par nucléon, courbe d'Aston, réactions de fission et de fusion.",
      keyFormulas = listOf(
        "E = m \\cdot c^2 \\quad (\\text{Énergie de masse d'Einstein})",
        "\\Delta m = [Z m_p + (A - Z) m_n] - m(\\text{noyau}) \\quad (\\text{Défaut de masse})",
        "E_\\ell = \\Delta m \\cdot c^2 \\quad (\\text{Énergie de liaison})",
        "\\xi = \\frac{E_\\ell}{A} \\quad (\\text{Énergie de liaison par nucléon})",
        "\\Delta E = [\\sum m(\\text{produits}) - \\sum m(\\text{réactifs})] c^2",
        "E_{\\text{libérée}} = |\\Delta E|"
      ),
      activities = listOf(
        "Activité 1 — Conversions entre kg, joules, eV et MeV/c².",
        "Activité 2 — Calcul du défaut de masse et de l'énergie de liaison de l'hélium 4.",
        "Activité 3 — Bilan d'énergie libérée lors de la désintégration alpha du Radium 226.",
        "Activité 4 — Équation de fission de l'Uranium 235 bombardé par un neutron lent.",
        "Activité 5 — Bilan énergétique de la fusion thermonucléaire deutérium-tritium."
      ),
      application = "Calcul de l'énergie libérée par 1 kg d'uranium 235 fissile, équivalente à 1700 tonnes de pétrole.",
      chartType = ScientificChartType.COURBE_ASTON_ENERGIE,
      chartTitle = "Courbe d'Aston : Énergie de liaison par nucléon -E_ℓ/A = f(A)",
      chartExploitation = "• Le creux de la courbe d'Aston (-8.8 MeV/nucléon) est atteint autour du fer 56 (²⁶Fe), noyau le plus stable.\n• Zone de fusion nucléaire : pour les noyaux légers (A < 20), la fusion libère de l'énergie en formant des noyaux plus stables.\n• Zone de fission nucléaire : pour les noyaux lourds (A > 200, comme ²³⁵U), la scission libère une énergie colossale."
    ),

    // --- UNITÉ 3 : ÉLECTRICITÉ ---
    Chapter(
      id = "P6",
      title = "P6 · Dipôle RC",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 3 — Électricité",
      keywords = listOf("condensateur", "capacité", "échelon de tension", "charge", "décharge", "constante de temps", "énergie électrique"),
      problematic = "Qu’est-ce qu’un condensateur ? Comment se comporte-t-il dans un circuit électrique ?",
      contentSections = listOf(
        "1. Le condensateur : Deux armatures séparées par un isolant. Charge q = C · u_C, courant i(t) = dq/dt = C du_C/dt. Associations série et parallèle.",
        "2. Échelon de tension et charge : Équation différentielle \\tau \\frac{du_C}{dt} + u_C = E avec constante de temps \\tau = R C. Solution : u_C(t) = E(1 - e^{-t/\\tau}).",
        "3. Décharge dans un résistor : Équation différentielle \\tau \\frac{du_C}{dt} + u_C = 0. Solution : u_C(t) = E e^{-t/\\tau}.",
        "4. Détermination de tau : Tangente à l'origine à t=0 coupant l'asymptote E en t=\\tau ; ou valeur u_C(\\tau) = 0,63 E en charge et 0,37 E en décharge.",
        "5. Énergie emmagasinée : E_e = \\frac{1}{2} C u_C^2 = \\frac{q^2}{2C} restituée lors de la décharge."
      ),
      summary = "Comportement du condensateur, réponse à un échelon de tension montant et descendant, constante de temps τ = RC et stockage d'énergie électrique.",
      keyFormulas = listOf(
        "q(t) = C \\cdot u_C(t) \\quad \\text{et} \\quad i(t) = \\frac{dq}{dt} = C \\frac{du_C}{dt}",
        "\\tau \\frac{du_C}{dt} + u_C = E \\quad \\text{avec} \\quad \\tau = R \\cdot C \\quad (\\text{Charge})",
        "u_C(t) = E\\left(1 - e^{-\\frac{t}{\\tau}}\\right), \\quad i(t) = \\frac{E}{R} e^{-\\frac{t}{\\tau}}",
        "u_C(t) = E \\cdot e^{-\\frac{t}{\\tau}} \\quad (\\text{Décharge})",
        "E_e = \\frac{1}{2} C u_C^2 = \\frac{q^2}{2C} \\quad (\\text{Énergie emmagasinée})"
      ),
      activities = listOf(
        "Activité 1 — Signe des charges sur les armatures d'un condensateur plan.",
        "Activité 2 — Charge à courant constant I₀ = 80 µA et tracé de q = f(u_C).",
        "Activité 3 — Associations de condensateurs en série et en parallèle.",
        "Activité 4 — Étude expérimentale de la charge (E = 6 V, R = 2 kΩ, C = 100 µF).",
        "Activité 5 — Étude de la décharge et vérification de la constante de temps τ.",
        "Activité 6 — Fonctionnement d'un moteur alimenté par l'énergie du condensateur."
      ),
      application = "Étude du circuit flash d'appareil photo : charge lente par pile puis décharge instantanée dans la lampe flash.",
      simulationType = SimulationType.CIRCUIT_RC,
      simulationTitle = "Laboratoire Virtuel : Circuit RC & Constante de Temps",
      chartType = ScientificChartType.RC_CHARGE,
      chartTitle = "Courbe de charge du condensateur u_C(t) et tangente à t=0",
      chartExploitation = "Exploitation graphique de la constante de temps τ = R·C par l'intersection de la tangente à l'origine avec l'asymptote E = 6.0 V (τ = 4.7 ms) et vérification à 63% (u_C = 3.78 V)."
    ),

    Chapter(
      id = "P7",
      title = "P7 · Dipôle RL",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 3 — Électricité",
      keywords = listOf("bobine", "inductance", "résistance interne", "établissement courant", "rupture", "énergie magnétique", "surtension"),
      problematic = "Qu’est-ce qu’une bobine ? Comment se comporte-t-elle dans un circuit électrique ?",
      contentSections = listOf(
        "1. La bobine d'inductance L et résistance interne r : Elle s'oppose aux variations du courant électrique. Tension u_L = r i + L \\frac{di}{dt}.",
        "2. Établissement du courant : Équation différentielle \\tau \\frac{di}{dt} + i = \\frac{E}{R_t} avec constante de temps \\tau = \\frac{L}{R_t} (R_t = R + r). Courant i(t) = I_p(1 - e^{-t/\\tau}).",
        "3. Rupture du courant : \\tau \\frac{di}{dt} + i = 0. Courant i(t) = I_0 e^{-t/\\tau}. Risque de surtension à l'ouverture (diode de roue libre).",
        "4. Énergie magnétique emmagasinée : E_m = \\frac{1}{2} L i^2."
      ),
      summary = "Propriétés inductives de la bobine, retard à l'établissement et à l'annulation du courant, constante de temps τ = L/R et énergie magnétique.",
      keyFormulas = listOf(
        "u_L(t) = r \\cdot i + L \\frac{di}{dt} \\quad (\\text{Tension aux bornes de la bobine})",
        "\\tau = \\frac{L}{R_t} \\quad \\text{avec } R_t = R + r \\quad (\\text{Constante de temps})",
        "i(t) = \\frac{E}{R_t}\\left(1 - e^{-\\frac{t}{\\tau}}\\right) \\quad (\\text{Établissement du courant})",
        "i(t) = \\frac{E}{R_t} e^{-\\frac{t}{\\tau}} \\quad (\\text{Rupture du courant})",
        "E_m = \\frac{1}{2} L i^2 \\quad (\\text{Énergie magnétique})"
      ),
      activities = listOf(
        "Activité 1 — Allumage décalé de deux lampes pour mettre en évidence le retard inductif.",
        "Activité 2 — Mesure de r en courant continu et de L en tension triangulaire avec oscilloscope.",
        "Activité 3 — Établissement du courant dans un dipôle RL (E=6V, L=1H, Rt=100 Ohm).",
        "Activité 4 — Rupture du courant et observation de l'étincelle de surtension.",
        "Activité 5 — Restitution de l'énergie magnétique emmagasinée."
      ),
      application = "Détermination des paramètres (L, r) d'une bobine réelle à partir des courbes u(t) et de la tangente à l'origine.",
      chartType = ScientificChartType.RL_ETABLISSEMENT,
      chartTitle = "Établissement du courant i(t) dans le dipôle RL",
      chartExploitation = "Asymptote I_0 = 50 mA et constante de temps τ = L/(R+r) = 2.5 ms déterminée par la tangente à t = 0."
    ),

    Chapter(
      id = "P8",
      title = "P8 · Oscillations libres dans un circuit RLC série",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 3 — Électricité",
      keywords = listOf("circuit RLC", "oscillations libres", "pseudo-périodique", "apériodique", "critique", "circuit LC", "période propre", "entretien"),
      problematic = "Que se passe-t-il lorsqu’un condensateur chargé est branché aux bornes d’une bobine ? Comment s’effectuent les échanges d’énergie dans le circuit ?",
      contentSections = listOf(
        "1. Régimes d'oscillations : Régime pseudo-périodique (R faible, oscillations amorties de pseudo-période T), apériodique (R forte, retour sans oscillation), critique pour R = R_c = 2\\sqrt{L/C}.",
        "2. Équation différentielle du circuit RLC : \\frac{d^2u_C}{dt^2} + \\frac{R}{L}\\frac{du_C}{dt} + \\frac{1}{LC}u_C = 0.",
        "3. Circuit LC idéal non amorti : Période propre T_0 = 2\\pi \\sqrt{LC}. Tension u_C(t) = U_m \\cos(2\\pi t/T_0 + \\varphi).",
        "4. Bilan énergétique : Énergie totale E_t = \\frac{1}{2} C u_C^2 + \\frac{1}{2} L i^2. Dans le circuit LC idéal, E_t est constante ; dans le circuit RLC, \\frac{dE_t}{dt} = -R i^2 < 0 (perte par effet Joule).",
        "5. Dispositif d'entretien des oscillations : Insertion d'un dipôle à résistance négative compensant la résistance R."
      ),
      summary = "Oscillations libres amorties dans RLC série, régimes pseudo-périodique, apériodique et critique. Oscillateur LC harmonique et transfert d'énergie.",
      keyFormulas = listOf(
        "\\frac{d^2u_C}{dt^2} + \\frac{R}{L}\\frac{du_C}{dt} + \\frac{1}{LC}u_C = 0 \\quad (\\text{RLC série})",
        "R_c = 2 \\sqrt{\\frac{L}{C}} \\quad (\\text{Résistance critique})",
        "T_0 = 2\\pi \\sqrt{L \\cdot C} \\quad (\\text{Période propre du circuit LC})",
        "E_t = \\frac{1}{2} C u_C^2 + \\frac{1}{2} L i^2 \\quad (\\text{Énergie totale})",
        "\\frac{dE_t}{dt} = -R \\cdot i^2 \\le 0 \\quad (\\text{Dissipation par effet Joule})",
        "Q_m = C \\cdot U_m, \\quad I_m = \\sqrt{\\frac{C}{L}} U_m"
      ),
      activities = listOf(
        "Activité 1 — Décharge d'un condensateur de 10 µF dans une bobine de 10 mH avec résistance réglable.",
        "Activité 2 — Étude de la période propre T₀ du circuit LC idéal et lecture graphique de l'amplitude.",
        "Activité 3 — Évolution conjointe des énergies électrique E_e et magnétique E_m.",
        "Activité 4 — Décroissance de l'énergie totale par effet Joule dans le circuit RLC.",
        "Activité 5 — Entretien des oscillations à l'aide d'un amplificateur opérationnel monté en résistance négative."
      ),
      application = "Calcul de la pseudo-période T, de la résistance critique et détermination des pertes énergétiques sur plusieurs pseudo-périodes.",
      chartType = ScientificChartType.RLC_AMORTI,
      chartTitle = "Oscillations libres amorties : u_C(t) en régime pseudo-périodique",
      chartExploitation = "Mesure de la pseudo-période T = 1.25 ms entre deux crêtes et calcul de la capacité C = T^2 / (4π^2 L) ≈ 1.0 µF."
    ),

    Chapter(
      id = "P9",
      title = "P9 · Transmission d’informations : modulation et démodulation d’amplitude",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 3 — Électricité",
      keywords = listOf("porteuse", "signal modulant", "modulation d'amplitude", "taux de modulation", "spectre", "démodulation", "détecteur enveloppe"),
      problematic = "Quelles sont les principales opérations nécessaires à la transmission d’informations ? Quels sont les constituants d’un récepteur radio AM ?",
      contentSections = listOf(
        "1. Nécessité de la modulation : Un signal sonore basse fréquence s'amortit rapidement et exigerait une antenne géante (\\lambda/2). On le superpose à une onde porteuse haute fréquence.",
        "2. Modulation d'amplitude : Multiplieur u_s(t) = A[1 + m \\cos(2\\pi f_s t)] \\cos(2\\pi F_p t) avec taux de modulation m = \\frac{S_m}{U_0} = \\frac{U_{m,\\max} - U_{m,\\min}}{U_{m,\\max} + U_{m,\\min}}.",
        "3. Condition de bonne modulation : F_p > 10 f_s et m < 1 (pas de surmodulation). Méthode du trapèze en mode XY.",
        "4. Démodulation d'amplitude : Détecteur d'enveloppe (diode + circuit RC parallèle avec condition T_p \\ll \\tau = RC < T_s), puis filtre passe-haut pour éliminer la composante continue U0.",
        "5. Circuit d'accord radio AM : Antenne reliée à un circuit LC parallèle accordé sur la fréquence F_p = \\frac{1}{2\\pi \\sqrt{LC}}."
      ),
      summary = "Transmission par ondes hertziennes, principe de la modulation d'amplitude AM, détection d'enveloppe et constitution du récepteur radio.",
      keyFormulas = listOf(
        "u_s(t) = A[1 + m \\cos(2\\pi f_s t)] \\cos(2\\pi F_p t) \\quad (\\text{Tension modulée})",
        "m = \\frac{S_m}{U_0} = \\frac{U_{m,\\max} - U_{m,\\min}}{U_{m,\\max} + U_{m,\\min}} \\quad (\\text{Taux de modulation})",
        "T_p \\ll \\tau = R \\cdot C < T_s \\quad (\\text{Condition de bonne détection d'enveloppe})",
        "F_0 = \\frac{1}{2\\pi\\sqrt{LC}} = F_p \\quad (\\text{Fréquence d'accord})"
      ),
      activities = listOf(
        "Activité 1 — Transmission d'un signal audio par faisceau lumineux et récepteur photodiode.",
        "Activité 2 — Émission et réception d'ondes électromagnétiques par deux antennes filaires.",
        "Activité 3 — Réalisation de la modulation d'amplitude à l'aide d'un composant multiplieur analogique.",
        "Activité 4 — Réglage du filtre RC détecteur d'enveloppe pour restituer le signal BF."
      ),
      application = "Choix des composants R et C pour démoduler un signal de 1 kHz avec une porteuse de 100 kHz.",
      chartType = ScientificChartType.MODULATION_AM_TRAPEZE,
      chartTitle = "Oscillogramme du signal modulé AM u_s(t) et méthode du trapèze",
      chartExploitation = "• Taux de modulation : m = (U_max - U_min) / (U_max + U_min) = (6.0 - 2.0) / (6.0 + 2.0) = 0.50.\n• Comme m < 1, il n'y a pas d'inversion de phase ni surmodulation.\n• Trapèze régulier en mode XY confirmant une excellente restitution du signal sonore."
    ),

    // --- UNITÉ 4 : MÉCANIQUE ---
    Chapter(
      id = "P10",
      title = "P10 · Les lois de Newton",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 4 — Mécanique",
      keywords = listOf("vecteur position", "vitesse", "accélération", "base de Frenet", "inertie", "relation fondamentale dynamique", "actions réciproques"),
      problematic = "Qu’est-ce qu’une accélération ? Quelle est la relation entre l’accélération et les forces appliquées à un système ?",
      contentSections = listOf(
        "1. Vecteurs cinématiques : Vecteur position \\vec{OG}, vitesse \\vec{v} = \\frac{d\\vec{OG}}{dt}, accélération \\vec{a} = \\frac{d\\vec{v}}{dt}.",
        "2. Base de Frenet : \\vec{a} = a_T \\vec{u} + a_N \\vec{n} avec a_T = \\frac{dv}{dt} et a_N = \\frac{v^2}{\\rho}.",
        "3. Première loi (principe d'inertie) : Dans un référentiel galiléen, \\sum \\vec{F}_{\\text{ext}} = \\vec{0} \\iff \\vec{v}_G = \\vec{\\text{cte}}.",
        "4. Deuxième loi (relation fondamentale de la dynamique) : \\sum \\vec{F}_{\\text{ext}} = m \\cdot \\vec{a}_G.",
        "5. Troisième loi (actions réciproques) : \\vec{F}_{A\\to B} = -\\vec{F}_{B\\to A}."
      ),
      summary = "Cinématique du point (position, vitesse, accélération, repère de Frenet) et les trois lois fondamentales de Newton.",
      keyFormulas = listOf(
        "\\vec{v}_G = \\frac{d\\vec{OG}}{dt}, \\quad \\vec{a}_G = \\frac{d\\vec{v}_G}{dt} = \\frac{d^2\\vec{OG}}{dt^2}",
        "a_T = \\frac{dv}{dt}, \\quad a_N = \\frac{v^2}{\\rho} \\quad (\\text{Repère de Frenet})",
        "\\sum \\vec{F}_{\\text{ext}} = m \\cdot \\vec{a}_G \\quad (\\text{2ème Loi de Newton})",
        "\\vec{F}_{A\\to B} = -\\vec{F}_{B\\to A} \\quad (\\text{Actions réciproques})",
        "x(t) = \\frac{1}{2} a t^2 + v_0 t + x_0 \\quad (\\text{MRUV})"
      ),
      activities = listOf(
        "Activité 1 — Étude du mouvement d'un mobile sur table à coussin d'air tiré par une masse suspendue et vérification de Sigma F = m a."
      ),
      application = "Tracé des vecteurs vitesse et accélération sur un enregistrement chronophotographique ; calcul de la force de freinage d'un véhicule.",
      chartType = ScientificChartType.NEWTON_CINEMATIQUE_VT,
      chartTitle = "Graphe cinématique v = f(t) : accélération et distance parcourue",
      chartExploitation = "• Phase 1 (0 à 4 s) : accélération constante a₁ = Δv / Δt = (10 - 0) / 4 = 2.5 m·s⁻².\n• Phase 2 (4 à 7 s) : mouvement rectiligne uniforme à v = 10 m·s⁻¹ (a = 0).\n• Phase 3 (7 à 9 s) : décélération de freinage a₃ = -5.0 m·s⁻².\n• Distance totale = aire sous la courbe : d = 20 + 30 + 10 = 60 m."
    ),

    Chapter(
      id = "P11",
      title = "P11 · Applications : chute verticale d’un solide",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 4 — Mécanique",
      keywords = listOf("champ de pesanteur", "chute libre", "Archimède", "frottement fluide", "vitesse limite", "temps caractéristique", "méthode Euler"),
      problematic = "Qu’est-ce qu’une chute libre ? Comment interpréter le mouvement d’un parachutiste avec la deuxième loi de Newton ?",
      contentSections = listOf(
        "1. Chute libre verticale : Solide soumis uniquement à son poids P = mg. Accélération a_G = g indépendante de la masse. Équations : v(t) = gt + v_0, z(t) = 1/2 gt^2 + v_0 t + z_0.",
        "2. Chute verticale dans un fluide : Poids P, poussée d'Archimède F_A = \\rho_f V g, force de frottement fluide f = k v^n opposée à la vitesse.",
        "3. Équation différentielle : \\frac{dv}{dt} = A - B v^n. Deux régimes : transitoire puis permanent avec vitesse limite v_\\ell = (A/B)^{1/n}.",
        "4. Résolution numérique par la méthode d'Euler : a_i = A - B v_i^n et v_{i+1} = v_i + a_i \\Delta t avec pas \\Delta t \\approx \\tau/10."
      ),
      summary = "Chute libre dans le vide et chute dans un fluide visqueux (frottement laminaire ou turbulent), vitesse limite et algorithme d'Euler.",
      keyFormulas = listOf(
        "a_G = g \\quad \\text{et} \\quad z(t) = \\frac{1}{2} g t^2 + v_0 t + z_0 \\quad (\\text{Chute libre})",
        "F_A = \\rho_f \\cdot V \\cdot g \\quad (\\text{Poussée d'Archimède})",
        "f = k \\cdot v^n \\quad (\\text{Frottement fluide})",
        "\\frac{dv}{dt} = A - B v^n \\quad \\text{avec } A = \\frac{m - m_f}{m} g, \\quad B = \\frac{k}{m}",
        "v_\\ell = \\left(\\frac{A}{B}\\right)^{1/n}, \\quad \\tau = \\frac{v_\\ell}{a_0}",
        "v_{i+1} = v_i + a_i \\cdot \\Delta t \\quad (\\text{Algorithme d'Euler})"
      ),
      activities = listOf(
        "Activité 1 — Chute libre d'une bille d'acier dans l'air enregistrée par capteurs optiques.",
        "Activité 2 — Chute d'une bille dans une éprouvette d'huile végétale et détermination de la vitesse limite v_ell."
      ),
      application = "Mise en œuvre numérique de la méthode d'Euler sur tableur pour simuler le saut d'un parachutiste.",
      chartType = ScientificChartType.CHUTE_VERTICALE,
      chartTitle = "Chute verticale dans un fluide : vitesse v(t) et méthode d'Euler",
      chartExploitation = "• Vitesse limite asymptotique v_ℓ = 12.0 m/s en régime permanent.\n• Tangente à l'origine (t=0) : pente égale à l'accélération initiale a₀ = g = 9.8 m/s².\n• Temps caractéristique : τ = v_ℓ / a₀ = 1.22 s (à t = τ, v = 0.63 v_ℓ = 7.56 m/s)."
    ),

    Chapter(
      id = "P12",
      title = "P12 · Applications : mouvements plans",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 4 — Mécanique",
      keywords = listOf("projectile", "trajectoire parabolique", "portée", "flèche", "force de Lorentz", "mouvement circulaire uniforme", "spectroscope masse"),
      problematic = "Qu’est-ce qu’un projectile ? Quelle est l’influence des conditions initiales sur la distance du lancer ?",
      contentSections = listOf(
        "1. Projectile dans un champ de pesanteur uniforme : Accélération \\vec{a} = \\vec{g}. Équations horaires : x(t) = (v_0 \\cos\\alpha)t, z(t) = -1/2 gt^2 + (v_0 \\sin\\alpha)t.",
        "2. Trajectoire parabolique : z(x) = -\\frac{g}{2 v_0^2 \\cos^2\\alpha} x^2 + (\\tan\\alpha) x. Flèche z_F = \\frac{v_0^2 \\sin^2\\alpha}{2g}, portée x_P = \\frac{v_0^2 \\sin(2\\alpha)}{g} (maximale pour \\alpha = 45^\\circ).",
        "3. Particule chargée dans un champ magnétique uniforme B : Force de Lorentz \\vec{F} = q \\vec{v} \\wedge \\vec{B}. Si \\vec{v}_0 \\perp \\vec{B}, le mouvement est plan, circulaire et uniforme de rayon r = \\frac{m v_0}{|q| B}.",
        "4. Application au spectroscope de masse : Séparation d'isotopes selon leur rapport masse sur charge m/q."
      ),
      summary = "Mouvement parabolique d'un projectile dans le champ de pesanteur et déviation d'une particule chargée dans un champ magnétique B (force de Lorentz).",
      keyFormulas = listOf(
        "z(x) = -\\frac{g}{2 v_0^2 \\cos^2(\\alpha)} x^2 + \\tan(\\alpha) x \\quad (\\text{Trajectoire parabolique})",
        "x_P = \\frac{v_0^2 \\sin(2\\alpha)}{g} \\quad (\\text{Portée}), \\quad z_F = \\frac{v_0^2 \\sin^2(\\alpha)}{2g} \\quad (\\text{Flèche})",
        "\\vec{F} = q \\vec{v} \\wedge \\vec{B}, \\quad F = |q| v B \\sin\\alpha \\quad (\\text{Force de Lorentz})",
        "r = \\frac{m v_0}{|q| B} \\quad (\\text{Rayon de la trajectoire circulaire})",
        "T = \\frac{2\\pi m}{|q| B} \\quad (\\text{Période de révolution})"
      ),
      activities = listOf(
        "Activité 1 — Chronophotographie du lancer d'un ballon et validation de l'équation parabolique z(x).",
        "Activité 2 — Déviation d'un faisceau d'électrons dans les bobines de Helmholtz et mesure de la déflexion magnétique."
      ),
      application = "Calcul de la vitesse initiale minimale pour franchir un obstacle en saut d'obstacles ou football ; principe de séparation des ions uranium 235 et 238.",
      chartType = ScientificChartType.PROJECTILE_PARABOLE,
      chartTitle = "Trajectoire parabolique y = f(x) : flèche H et portée X_P",
      chartExploitation = "• Sommet de la parabole (Flèche) : y_F = 4.5 m à x = 7.8 m (vitesse verticale v_y = 0).\n• Portée horizontale : x_P = 15.6 m au retour au sol (y = 0).\n• La portée est maximale pour un angle de tir α = 45°."
    ),

    Chapter(
      id = "P13",
      title = "P13 · Applications : mouvement des planètes et des satellites",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 4 — Mécanique",
      keywords = listOf("Kepler", "gravitation universelle", "mouvement circulaire uniforme", "période révolution", "satellite géostationnaire", "satellisation"),
      problematic = "Qu’en est-il pour un mobile (planète, satellite) soumis à une force de gravitation qui varie au cours du mouvement ?",
      contentSections = listOf(
        "1. Les trois lois de Kepler : (1) Orbites elliptiques avec le Soleil à l'un des foyers ; (2) Loi des aires (vitesse maximale au périhélie) ; (3) Loi des périodes \\frac{T^2}{a^3} = \\text{cte}.",
        "2. Loi de gravitation universelle de Newton : F = G \\frac{m_A m_B}{r^2} avec G = 6,67\\times 10^{-11}\\text{ N}\\cdot\\text{m}^2\\cdot\\text{kg}^{-2}.",
        "3. Mouvement circulaire uniforme d'un satellite : Vitesse v = \\sqrt{\\frac{G M}{r}}, période T = 2\\pi \\sqrt{\\frac{r^3}{G M}}, et vérification de \\frac{T^2}{r^3} = \\frac{4\\pi^2}{G M}.",
        "4. Satellite géostationnaire : Orbite circulaire équatoriale à altitude h \\approx 36\\,000\\text{ km}, même sens de rotation et période égale au jour sidéral (T = 86\\,164 s)."
      ),
      summary = "Lois de Kepler, gravitation universelle, vitesse orbitale, période de révolution et conditions d'orbite d'un satellite géostationnaire.",
      keyFormulas = listOf(
        "F = G \\frac{m_A m_B}{r^2} \\quad \\text{avec } G = 6,67\\times 10^{-11}\\text{ N}\\cdot\\text{m}^2\\cdot\\text{kg}^{-2}",
        "v = \\sqrt{\\frac{G M}{r}} \\quad (\\text{Vitesse orbitale circulaire})",
        "T = 2\\pi \\sqrt{\\frac{r^3}{G M}} \\quad \\text{d'où} \\quad \\frac{T^2}{r^3} = \\frac{4\\pi^2}{G M} \\quad (\\text{3ème Loi de Kepler})",
        "h = \\left(\\frac{G M_T T^2}{4\\pi^2}\\right)^{1/3} - R_T \\approx 36\\,000\\text{ km} \\quad (\\text{Altitude géostationnaire})"
      ),
      activities = listOf(
        "Activité 1 — Vérification de la troisième loi de Kepler sur les données des planètes du système solaire.",
        "Activité 2 — Étude de l'accélération d'un satellite artificiel en orbite circulaire basse.",
        "Activité 3 — Calcul précis de l'altitude du satellite géostationnaire de télécommunication (Mohammed VI-A/B)."
      ),
      application = "Calcul de la vitesse de satellisation en orbite basse (environ 7,9 km/s) et étude des satellites météo.",
      chartType = ScientificChartType.SATELLITE_ORBITE_KEPLER,
      chartTitle = "Orbite circulaire de satellite, repère de Frenet et 3ème loi de Kepler",
      chartExploitation = "• Force gravitationnelle centripète : F = G·M_T·m / r² (accélération tangentielle a_t = 0).\n• Vitesse orbitale : v = √(G·M_T / r).\n• 3ème loi de Kepler : T² / r³ = 4π² / (G·M_T) = constante universelle.\n• Satellite géostationnaire : orbite équatoriale à altitude h ≈ 35 786 km avec période T = 86 164 s."
    ),

    Chapter(
      id = "P14",
      title = "P14 · Mouvement de rotation d’un solide autour d’un axe fixe",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 4 — Mécanique",
      keywords = listOf("abscisse angulaire", "vitesse angulaire", "accélération angulaire", "moment de force", "moment d'inertie", "relation fondamentale dynamique"),
      problematic = "Qu’est-ce que l’accélération angulaire ? Quelle est la relation entre l’accélération angulaire et la somme algébrique des moments des forces appliquées ?",
      contentSections = listOf(
        "1. Cinématique de rotation : Abscisse angulaire \\theta(t), vitesse angulaire \\omega = \\dot{\\theta} (rad/s), accélération angulaire \\alpha = \\ddot{\\theta} (rad/s²). Relations linéaires : s = r \\theta, v = r \\omega.",
        "2. Moment d'une force : M_\\Delta(\\vec{F}) = \\pm F \\cdot d (N·m).",
        "3. Relation fondamentale de la dynamique en rotation : \\sum M_\\Delta(\\vec{F}_i) = J_\\Delta \\cdot \\ddot{\\theta} où J_\\Delta est le moment d'inertie du solide.",
        "4. Moments d'inertie classiques : Cylindre ou disque homogène J_\\Delta = \\frac{1}{2} m r^2 ; Tige mince J_\\Delta = \\frac{1}{12} m \\ell^2 ; Sphère J_\\Delta = \\frac{2}{5} m r^2."
      ),
      summary = "Grandeurs cinématiques angulaires, moment d'une force, moment d'inertie JΔ et relation fondamentale de la dynamique en rotation.",
      keyFormulas = listOf(
        "s(t) = r \\cdot \\theta(t), \\quad v = r \\cdot \\omega, \\quad a_T = r \\cdot \\ddot{\\theta}, \\quad a_N = r \\cdot \\dot{\\theta}^2",
        "M_\\Delta(\\vec{F}) = \\pm F \\cdot d \\quad (\\text{Moment en N}\\cdot\\text{m})",
        "\\sum M_\\Delta(\\vec{F}_i) = J_\\Delta \\cdot \\ddot{\\theta} \\quad (\\text{RFD en rotation})",
        "\\theta(t) = \\frac{1}{2} \\ddot{\\theta} t^2 + \\dot{\\theta}_0 t + \\theta_0 \\quad (\\text{Rotation uniformément variée})"
      ),
      activities = listOf(
        "Activité 1 — Mobile monté sur axe vertical tiré par un fil portant une masse suspendue et calcul de l'accélération angulaire."
      ),
      application = "Système poulie-masse glissant sur plan incliné ; calcul du temps d'arrêt d'un volant d'inertie sous l'effet d'un couple résistant de frottement.",
      chartType = ScientificChartType.ROTATION_SOLIDE_VITESSE,
      chartTitle = "Rotation d'un solide autour d'un axe fixe : ω = f(t) et relation fondamentale",
      chartExploitation = "• Accélération angulaire constante θ'' = Δω / Δt = 43.6 rad·s⁻².\n• Relation fondamentale : Σ M_Δ = J_Δ · θ''.\n• Angle de rotation : θ(t) = 1/2 θ'' t²."
    ),

    Chapter(
      id = "P15",
      title = "P15 · Systèmes mécaniques oscillants",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 4 — Mécanique",
      keywords = listOf("oscillateur mécanique", "pendule élastique", "pendule torsion", "pendule pesant", "pendule simple", "amortissement", "résonance"),
      problematic = "Quelles sont les caractéristiques du mouvement d’un système mécanique oscillant ? Quelle est l’influence de l’amortissement sur ce mouvement ?",
      contentSections = listOf(
        "1. Pendule élastique horizontal : Masse-ressort sans frottement. Équation : \\ddot{x} + \\frac{k}{m} x = 0. Solution : x(t) = X_m \\cos\\left(\\frac{2\\pi t}{T_0} + \\varphi\\right) avec T_0 = 2\\pi \\sqrt{\\frac{m}{k}}.",
        "2. Pendule de torsion : Couple de rappel M_c = -C \\theta. Équation : \\ddot{\\theta} + \\frac{C}{J_\\Delta} \\theta = 0, Période T_0 = 2\\pi \\sqrt{\\frac{J_\\Delta}{C}}.",
        "3. Pendule pesant et pendule simple : Pour les petites oscillations, \\ddot{\\theta} + \\frac{m g d}{J_\\Delta} \\theta = 0. Pour le pendule simple de longueur \\ell : T_0 = 2\\pi \\sqrt{\\frac{\\ell}{g}}.",
        "4. Oscillations forcées et résonance mécanique : Phénomène de résonance quand la fréquence de l'excitateur f est proche de la fréquence propre f_0."
      ),
      summary = "Oscillateurs mécaniques (pendules élastique, de torsion, pesant et simple), équations différentielles harmoniques, période propre et résonance.",
      keyFormulas = listOf(
        "\\ddot{x} + \\frac{k}{m} x = 0 \\implies T_0 = 2\\pi \\sqrt{\\frac{m}{k}} \\quad (\\text{Pendule élastique})",
        "\\ddot{\\theta} + \\frac{C}{J_\\Delta} \\theta = 0 \\implies T_0 = 2\\pi \\sqrt{\\frac{J_\\Delta}{C}} \\quad (\\text{Pendule de torsion})",
        "\\ddot{\\theta} + \\frac{g}{\\ell} \\theta = 0 \\implies T_0 = 2\\pi \\sqrt{\\frac{\\ell}{g}} \\quad (\\text{Pendule simple})",
        "f_0 = \\frac{1}{T_0} \\quad (\\text{Fréquence propre})"
      ),
      activities = listOf(
        "Activité 1 — Pendule élastique horizontal : enregistrement du mouvement et mesure de la raideur k.",
        "Activité 2 — Pendule de torsion : étude de la période propre en fonction de la constante de torsion C.",
        "Activité 3 — Pendule pesant : influence de la longueur et de la masse sur la période.",
        "Activité 4 — Pendule simple : mesure expérimentale de l'intensité de la pesanteur g.",
        "Activité 5 — Résonance mécanique : excitation d'un oscillateur amorti et tracé de la courbe de résonance."
      ),
      application = "Détermination de la masse d'un spationaute en apesanteur à l'aide d'un plateau oscillant relié à un ressort étalonné.",
      chartType = ScientificChartType.OSCILLATEUR_PENDULE_XT,
      chartTitle = "Élongation x(t) du pendule élastique et courbe de résonance mécanique",
      chartExploitation = "• Période propre des oscillations libres : T₀ = 2π √(m / K) = 0.40 s (fréquence propre f₀ = 2.5 Hz).\n• Amplitude maximale X_m = 4.0 cm en l'absence d'amortissement.\n• Résonance mécanique : amplitude maximale obtenue lorsque la fréquence d'excitation f = f₀."
    ),

    Chapter(
      id = "P16",
      title = "P16 · Aspects énergétiques des oscillateurs mécaniques",
      subject = SubjectType.PHYSIQUE,
      unit = "Unité 4 — Mécanique",
      keywords = listOf("énergie potentielle élastique", "énergie potentielle torsion", "énergie potentielle pesanteur", "énergie cinétique", "conservation", "dissipation"),
      problematic = "Quelles sont les formes d’énergie emmagasinées par un système (par exemple perchiste-perche) ?",
      contentSections = listOf(
        "1. Pendule élastique horizontal : Énergie potentielle élastique E_{pe} = \\frac{1}{2} k x^2, énergie cinétique E_c = \\frac{1}{2} m v^2. Énergie mécanique E_m = E_c + E_{pe} = \\frac{1}{2} k X_m^2.",
        "2. Conservation et échange : Sans frottement, E_m = \\text{constante}. Échange perpétuel entre énergie cinétique et potentielle. Avec frottement, \\Delta E_m = W(\\vec{f}) < 0 (dissipation thermique).",
        "3. Pendule de torsion : Énergie potentielle de torsion E_{pt} = \\frac{1}{2} C \\theta^2, énergie cinétique E_c = \\frac{1}{2} J_\\Delta \\dot{\\theta}^2. E_m = E_c + E_{pt} = \\text{cte}.",
        "4. Pendule pesant : Énergie potentielle de pesanteur E_{pp} = m g z = m g d(1 - \\cos\\theta) \\approx \\frac{1}{2} m g d \\theta^2 (petites oscillations)."
      ),
      summary = "Énergie cinétique, potentielle (élastique, de torsion, de pesanteur) et énergie mécanique des oscillateurs. Conservation et dissipation par frottement.",
      keyFormulas = listOf(
        "E_{pe} = \\frac{1}{2} k x^2 \\quad (\\text{Énergie potentielle élastique})",
        "E_{pt} = \\frac{1}{2} C \\theta^2 \\quad (\\text{Énergie potentielle de torsion})",
        "E_{pp} = m g z \\approx \\frac{1}{2} m g d \\theta^2 \\quad (\\text{Énergie potentielle de pesanteur})",
        "E_c = \\frac{1}{2} m v^2 \\quad \\text{ou} \\quad E_c = \\frac{1}{2} J_\\Delta \\dot{\\theta}^2 \\quad (\\text{Énergie cinétique})",
        "E_m = E_c + E_p = \\text{cte} \\quad (\\text{Conservation sans frottement})",
        "\\Delta E_m = W(\\vec{f}) \\le 0 \\quad (\\text{Dissipation thermique})"
      ),
      activities = listOf(
        "Activité 1 — Tracé informatisé des courbes E_c(t), E_p(t) et E_m(t) pour un oscillateur élastique horizontal et vérification de la conservation."
      ),
      application = "Étude énergétique du saut à la perche et de l'amortisseur de suspension d'un véhicule automobile.",
      chartType = ScientificChartType.OSCILLATEUR_ENERGIE_EP_EC,
      chartTitle = "Diagramme énergétique de l'oscillateur : E_pe, E_c et conservation de E_m",
      chartExploitation = "• Conservation de l'énergie mécanique : E_m = E_c(x) + E_pe(x) = 20 mJ = constante.\n• Énergie potentielle élastique : parabole E_pe(x) = 1/2 K x².\n• Équipartition de l'énergie (E_c = E_pe = 10 mJ) pour x = ± X_m / √2 = ± 2.83 cm."
    ),

    // =========================================================================
    // PARTIE II — CHIMIE (9 Chapitres : C1 à C9)
    // =========================================================================

    // --- UNITÉ 1 : TRANSFORMATIONS LENTES ET RAPIDES ---
    Chapter(
      id = "C1",
      title = "C1 · Transformations lentes et transformations rapides",
      subject = SubjectType.CHIMIE,
      unit = "Unité 1 — Transformations lentes et rapides",
      keywords = listOf("oxydoréduction", "couple Ox/Red", "demi-équation", "transformation rapide", "transformation lente", "facteurs cinétiques"),
      problematic = "Qu’est-ce qu’une transformation lente ? Une transformation rapide ? Quels sont les paramètres qui influencent l’évolution temporelle d’une transformation chimique ?",
      contentSections = listOf(
        "1. Réactions d'oxydoréduction : Transfert d'électrons entre l'oxydant d'un couple et le réducteur d'un autre couple : a \\text{Red}_1 + b \\text{Ox}_2 \\to c \\text{Ox}_1 + d \\text{Red}_2.",
        "2. Transformations rapides et lentes : Rapide si l'évolution est quasi-instantanée (décoloration du permanganate par le sel de Mohr, précipitation) ; Lente si elle est mesurable sur plusieurs secondes ou minutes (diiode avec eau oxygénée).",
        "3. Facteurs cinétiques : Concentration initiale des réactifs, température du milieu, solvant, éclairement et présence de catalyseurs. La vitesse croît avec la concentration et la température.",
        "4. Applications pratiques : Accélérer (chauffage, autocuiseur) ou ralentir/bloquer (trempe par eau glacée, réfrigération des aliments)."
      ),
      summary = "Couples d'oxydoréduction, équilibrage des demi-équations électroniques, distinction cinétique rapide/lente et facteurs cinétiques régulateurs.",
      keyFormulas = listOf(
        "\\text{Ox} + n e^- \\rightleftharpoons \\text{Red} \\quad (\\text{Demi-équation d'oxydoréduction})",
        "a \\text{Red}_1 + b \\text{Ox}_2 \\longrightarrow c \\text{Ox}_1 + d \\text{Red}_2 \\quad (\\text{Équation bilan})",
        "\\text{Concentration} \\uparrow \\text{ ou } \\text{Température} \\uparrow \\implies \\text{Vitesse de réaction} \\uparrow"
      ),
      activities = listOf(
        "Activité 1 — Fil de cuivre dans une solution de nitrate d'argent et formation de cristaux d'argent.",
        "Activité 2 — Décoloration instantanée du diiode par les ions thiosulfate (transformation rapide).",
        "Activité 3 — Réaction lente entre l'eau oxygénée acidifiée et les ions iodure.",
        "Activité 4 — Influence de la concentration en acide oxalique sur la décoloration du permanganate.",
        "Activité 5 — Influence de la température (bain tiède vs bain glacé)."
      ),
      application = "Interprétation de la technique de trempe chimique pour figer un mélange réactionnel avant dosage.",
      chartType = ScientificChartType.FACTEURS_CINETIQUES_TEMPERATURE,
      chartTitle = "Facteurs cinétiques : Effet de la température T₂ > T₁ sur la vitesse",
      chartExploitation = "• Même état final x_f = 2.0 mmol pour les deux températures (la température n'affecte pas l'état d'équilibre).\n• Vitesse initiale plus grande à T₂ = 45°C (pente à l'origine 2.5× plus élevée).\n• Temps de demi-réaction réduit : t_1/2(T₂) = 2.5 min contre t_1/2(T₁) = 6.0 min."
    ),

    Chapter(
      id = "C2",
      title = "C2 · Suivi temporel d’une transformation chimique – Vitesse de réaction",
      subject = SubjectType.CHIMIE,
      unit = "Unité 1 — Transformations lentes et rapides",
      keywords = listOf("suivi temporel", "titrage", "trempe", "avancement", "vitesse volumique", "temps demi-réaction", "conductimétrie", "manométrie"),
      problematic = "Comment procède-t-on à un suivi temporel de l’évolution d’un système chimique ? Comment contrôler sa vitesse d’évolution ?",
      contentSections = listOf(
        "1. Suivi chimique par titrage successif : Prélèvements à intervalles réguliers, trempe dans l'eau glacée et dosage du réactif ou du produit pour tracer x = f(t).",
        "2. Vitesse volumique de réaction : v(t) = \\frac{1}{V} \\frac{dx}{dt} (en mol·L⁻¹·s⁻¹). Déterminée graphiquement par la pente de la tangente divisée par le volume V. La vitesse diminue au cours du temps.",
        "3. Temps de demi-réaction t_{1/2} : Durée au bout de laquelle l'avancement atteint la moitié de sa valeur finale : x(t_{1/2}) = x_f/2.",
        "4. Suivi par méthodes physiques continues : Conductimétrie (variation de conductivité \\sigma(t) liée aux ions) et Manométrie (variation de pression P(t) des gaz formés avec P V = n R T)."
      ),
      summary = "Méthodes de suivi temporel de l'avancement x(t), vitesse volumique de réaction v = (1/V)dx/dt, temps de demi-réaction t1/2, conductimétrie et manométrie.",
      keyFormulas = listOf(
        "v(t) = \\frac{1}{V} \\frac{dx}{dt} \\quad (\\text{Vitesse volumique en mol}\\cdot\\text{L}^{-1}\\cdot\\text{s}^{-1})",
        "x(t_{1/2}) = \\frac{x_f}{2} \\quad (\\text{Temps de demi-réaction})",
        "x(t) = \\frac{C_4 V_E}{2} \\quad (\\text{Suivi par titrage du diiode})",
        "x(t) = C \\cdot V \\frac{\\sigma(0) - \\sigma(t)}{\\sigma(0) - \\sigma(\\infty)} \\quad (\\text{Suivi conductimétrique})",
        "x(t) = \\frac{\\Delta P(t) \\cdot V}{R \\cdot T} \\quad (\\text{Suivi manométrique des gaz})"
      ),
      activities = listOf(
        "Activité 1 — Suivi de la cinétique eau oxygénée + iodure par dosage du diiode formé.",
        "Activité 2 — Tracé de la courbe x = f(t) et calcul des tangentes aux temps t = 0 et t = 360 s.",
        "Activité 3 — Suivi conductimétrique de la saponification d'un ester.",
        "Activité 4 — Suivi manométrique de la décomposition thermique d'un gaz."
      ),
      application = "Exploitation graphique complète d'une courbe de cinétique : calcul de la vitesse initiale et lecture de t_{1/2}.",
      chartType = ScientificChartType.MONTAGE_PRESSIOMETRIE,
      chartTitle = "Dispositif expérimental de suivi cinétique par pressiométrie (P·V = n·R·T)",
      chartExploitation = "• Loi des gaz parfaits : ΔP(t) = (R·T / V) · x(t).\n• Mesure continue et précise de la pression sans prélèvement ni perturbation du milieu réactionnel."
    ),

    // --- UNITÉ 2 : TRANSFORMATIONS CHIMIQUES S'EFFECTUANT DANS LES DEUX SENS ---
    Chapter(
      id = "C3",
      title = "C3 · Transformations chimiques qui ont lieu dans les deux sens",
      subject = SubjectType.CHIMIE,
      unit = "Unité 2 — Transformations chimiques à deux sens",
      keywords = listOf("acide", "base", "couple acide/base", "pH", "pH-mètre", "taux avancement final", "transformation limitée", "équilibre dynamique"),
      problematic = "Comment définir et mesurer le pH ? Une transformation chimique est-elle toujours totale ?",
      contentSections = listOf(
        "1. Acides et bases selon Brønsted : Acide donneur de proton H⁺, base accepteur de proton. Couple HA / A⁻ avec HA \\rightleftharpoons A^- + H^+.",
        "2. Mesure du pH : \\text{pH} = -\\log[H_3O^+] \\iff [H_3O^+] = 10^{-\\text{pH}} mol/L.",
        "3. Taux d'avancement final \\tau = x_f / x_{\\max} : Si \\tau = 1 la réaction est totale ; si \\tau < 1 la réaction est limitée (équilibre chimique).",
        "4. Équilibre dynamique : À l'état d'équilibre, la réaction directe et la réaction inverse se produisent simultanément à la même vitesse (v_1 = v_2)."
      ),
      summary = "Définition du pH, acides et bases de Brønsted, transformations chimiques limitées et taux d’avancement final τ = xf/xmax.",
      keyFormulas = listOf(
        "\\text{pH} = -\\log[H_3O^+] \\iff [H_3O^+] = 10^{-\\text{pH}}",
        "\\tau = \\frac{x_f}{x_{\\max}} \\quad (0 \\le \\tau \\le 1)",
        "\\tau = 1 \\implies \\text{Réaction totale}, \\quad \\tau < 1 \\implies \\text{Réaction limitée}",
        "A + B \\rightleftharpoons C + D \\quad (v_1 = v_2 \\text{ à l'équilibre})"
      ),
      activities = listOf(
        "Activité 1 — Dissolution de l'acide éthanoïque dans l'eau, mesure du pH et calcul de τ prouvant que la dissociation est limitée.",
        "Activité 2 — Déplacement d'équilibre par ajout d'éthanoate de sodium solide."
      ),
      application = "Comparaison du taux d'avancement d'un acide fort (HCl, τ = 1) et d'un acide faible (CH₃COOH, τ ≪ 1).",
      chartType = ScientificChartType.ECHELLE_PH_PREDOMINANCE,
      chartTitle = "Échelle de pH et diagramme de prédominance des espèces acido-basiques",
      chartExploitation = "• Milieu acide : 0 ≤ pH < 7 ([H₃O⁺] > [HO⁻]).\n• Neutre : pH = 7.0 à 25°C ([H₃O⁺] = [HO⁻] = 10⁻⁷ M).\n• Prédominance de l'acide acétique (pKa = 4.8) : si pH < 4.8, [HA] > [A⁻] ; si pH > 4.8, [A⁻] > [HA]."
    ),

    Chapter(
      id = "C4",
      title = "C4 · État d’équilibre d’un système chimique",
      subject = SubjectType.CHIMIE,
      unit = "Unité 2 — Transformations chimiques à deux sens",
      keywords = listOf("quotient de réaction", "constante d'équilibre", "taux avancement", "conductivité", "état d'équilibre"),
      problematic = "Qu’est-ce que le quotient de réaction ? Qu’est-ce que la constante d’équilibre ?",
      contentSections = listOf(
        "1. Quotient de réaction Q_r : Pour a A + b B \\rightleftharpoons c C + d D, Q_r = \\frac{[C]^c [D]^d}{[A]^a [B]^b}. Les solides et le solvant (eau) n'interviennent pas.",
        "2. Constante d'équilibre K : À l'état d'équilibre, Q_{r,\\text{éq}} = K(T) ne dépend que de la température.",
        "3. Relation entre K, C et \\tau : Pour un acide faible dans l'eau, K = \\frac{C \\tau^2}{1 - \\tau}. Le taux d'avancement \\tau augmente avec la dilution.",
        "4. Détermination par conductimétrie : \\sigma_{\\text{éq}} = \\lambda_{H_3O^+} [H_3O^+]_{\\text{éq}} + \\lambda_{A^-} [A^-]_{\\text{éq}}."
      ),
      summary = "Expression du quotient de réaction Qr, constante d'équilibre thermodynamique K, conductimétrie et loi de dilution d'Ostwald.",
      keyFormulas = listOf(
        "Q_r = \\frac{[C]^c [D]^d}{[A]^a [B]^b} \\quad (\\text{Quotient de réaction})",
        "K = Q_{r,\\text{éq}} \\quad (\\text{Constante d'équilibre à température T})",
        "\\sigma_{\\text{éq}} = \\lambda_{H_3O^+} [H_3O^+]_{\\text{éq}} + \\lambda_{A^-} [A^-]_{\\text{éq}}",
        "K = \\frac{C \\cdot \\tau^2}{1 - \\tau} \\quad (\\text{Relation d'Ostwald})"
      ),
      activities = listOf(
        "Activité 1 — Mesure de conductivité sur trois solutions d'acide éthanoïque à différentes concentrations et vérification de la constance de K.",
        "Activité 2 — Comparaison des constantes d'équilibre d'acides différents (éthanoïque, benzoïque, méthanoïque)."
      ),
      application = "Calcul de la constante d'équilibre K d'un acide carboxylique à partir de la mesure de conductivité d'une solution.",
      chartType = ScientificChartType.DIAGRAMME_DISTRIBUTION_PKA,
      chartTitle = "Diagramme de distribution des espèces : α(HA) et α(A⁻) = f(pH)",
      chartExploitation = "• Croisement exact à α = 50% identifiant graphiquement le pKa = 4.8 du couple.\n• Pour pH = pKa + 1 = 5.8, la base prédomine à plus de 90% (α(A⁻) ≈ 91%)."
    ),

    Chapter(
      id = "C5",
      title = "C5 · Transformations associées à des réactions acido-basiques en solution aqueuse",
      subject = SubjectType.CHIMIE,
      unit = "Unité 2 — Transformations chimiques à deux sens",
      keywords = listOf("autoprotolyse eau", "produit ionique", "constante d'acidité KA", "pKA", "domaine prédominance", "indicateur coloré", "dosage acido-basique"),
      problematic = "Quelles sont les espèces responsables de la couleur des fleurs d’hortensia ? Comment peut-on conserver cette couleur ?",
      contentSections = listOf(
        "1. Autoprotolyse de l'eau : 2 H_2O \\rightleftharpoons H_3O^+ + HO^-. Produit ionique K_e = [H_3O^+][HO^-] = 1,0\\times 10^{-14} à 25°C (pK_e = 14).",
        "2. Constante d'acidité K_A et pK_A : K_A = \\frac{[A^-][H_3O^+]}{[HA]} ; \\text{pH} = \\text{pK}_A + \\log\\left(\\frac{[A^-]}{[HA]}\\right).",
        "3. Diagramme de prédominance : Si pH < pKA, l'acide HA prédomine ; si pH > pKA, la base conjuguée A⁻ prédomine.",
        "4. Indicateurs colorés : Acide faible dont la forme acide et la forme basique ont des teintes différentes. Zone de virage [pKA - 1 ; pKA + 1].",
        "5. Titrage acido-basique : À l'équivalence stœchiométrique C_A V_A = C_B V_{BE}. Détection par méthode des tangentes ou extremum de dpH/dV."
      ),
      summary = "Produit ionique de l'eau Ke, constante d'acidité KA, diagramme de prédominance, indicateurs colorés et titrage acido-basique pH-métrique.",
      keyFormulas = listOf(
        "K_e = [H_3O^+] \\cdot [HO^-] = 1,0 \\times 10^{-14} \\quad (\\text{à } 25^\\circ\\text{C}), \\quad \\text{pK}_e = 14",
        "K_A = \\frac{[A^-][H_3O^+]}{[HA]}, \\quad \\text{pK}_A = -\\log K_A",
        "\\text{pH} = \\text{pK}_A + \\log\\left(\\frac{[A^-]}{[HA]}\\right) \\quad (\\text{Henderson-Hasselbalch})",
        "K = \\frac{K_{A1}}{K_{A2}} = 10^{\\text{pK}_{A2} - \\text{pK}_{A1}} \\quad (\\text{Constante de réaction acido-basique})",
        "C_A \\cdot V_A = C_B \\cdot V_{BE} \\quad (\\text{Relation d'équivalence})"
      ),
      activities = listOf(
        "Activité 1 — Autoprotolyse de l'eau pure et calcul des concentrations à 25°C.",
        "Activité 2 — Comparaison de la force de deux acides (éthanoïque et méthanoïque) à même concentration.",
        "Activité 3 — Dosage pH-métrique de l'acide éthanoïque par la soude avec détection du point équivalent.",
        "Activité 4 — Choix de l'indicateur coloré convenable pour le dosage de l'aspirine."
      ),
      application = "Dosage d'un vinaigre commercial ou d'un médicament ; tracé du diagramme de prédominance d'un acide aminé.",
      simulationType = SimulationType.TITRAGE_ACIDO_BASIQUE,
      simulationTitle = "Burette Virtuelle : Courbe de Titrage pH et Indicateur Coloré",
      chartType = ScientificChartType.TITRAGE_PH,
      chartTitle = "Courbe de dosage pH = f(V_b) et méthode des tangentes",
      chartExploitation = "• Point d'équivalence E : déterminé à l'intersection de la médiane avec la courbe : V_bE = 15.0 mL et pH_E = 8.75.\n• Demi-équivalence : pour V_b = 7.5 mL, le pH mesuré est pH = 4.8 = pKa(CH₃COOH/CH₃COO⁻).\n• Pic de dérivée dpH/dV_b exactement centré à V_b = 15.0 mL."
    ),

    // --- UNITÉ 3 : SENS D'ÉVOLUTION SPONTANÉ ---
    Chapter(
      id = "C6",
      title = "C6 · Transformations spontanées dans les piles et récupération de l’énergie",
      subject = SubjectType.CHIMIE,
      unit = "Unité 3 — Sens d'évolution spontané",
      keywords = listOf("critère évolution spontanée", "transfert électrons", "pile Daniell", "pont salin", "force électromotrice", "faraday", "capacité pile"),
      problematic = "De quel type de réaction chimique s’agit-il dans une pile ? Quel est son principe de fonctionnement ?",
      contentSections = listOf(
        "1. Critère d'évolution spontanée : Comparaison de Q_{r,i} et K. Si Q_{r,i} < K, évolution dans le sens direct ; si Q_{r,i} > K, sens inverse.",
        "2. Transfert indirect d'électrons dans une pile : Deux demi-piles reliées par un pont salin assurant la continuité électrique et la neutralité ionique.",
        "3. Électrodes : Anode = siège de l'oxydation (pôle négatif) ; Cathode = siège de la réduction (pôle positif). F.é.m. E = V_C - V_A > 0.",
        "4. Bilan quantitatif : Quantité d'électricité débitée Q = I \\Delta t = n(e^-) F avec F = N_A e = 96\\,500 C/mol. Capacité maximale Q_{\\max} = I \\Delta t_{\\max}."
      ),
      summary = "Critère d'évolution spontanée (Qr,i vs K), constitution de la pile électrochimique (Daniell), polarité anode/cathode et calcul de la quantité d'électricité débitée.",
      keyFormulas = listOf(
        "Q_{r,i} < K \\implies \\text{Sens direct}, \\quad Q_{r,i} > K \\implies \\text{Sens inverse}",
        "E = U = V_{\\text{cathode}} - V_{\\text{anode}} > 0 \\quad (\\text{Force électromotrice})",
        "U_{PN} = E - r \\cdot I \\quad (\\text{Tension aux bornes d'une pile débitant I})",
        "Q = I \\cdot \\Delta t = n(e^-) \\cdot F \\quad \\text{avec } F = 96\\,500\\text{ C}\\cdot\\text{mol}^{-1}",
        "x = \\frac{I \\cdot \\Delta t}{n_e \\cdot F} \\quad (\\text{Avancement de la réaction de pile})"
      ),
      activities = listOf(
        "Activité 1 — Évolution spontanée d'un mélange de solutions selon la valeur initiale Q_{r,i} comparée à K.",
        "Activité 2 — Réaction spontanée zinc métal + ions cuivre II en contact direct.",
        "Activité 3 — Réalisation de la pile Daniell Zn-Cu avec pont salin au chlorure de potassium.",
        "Activité 4 — Mesure de la force électromotrice et détermination de la polarité au voltmètre."
      ),
      application = "Calcul de la durée de fonctionnement d'une pile bouton de montre et variation de masse des électrodes.",
      chartType = ScientificChartType.MONTAGE_PILE_DANIELL,
      chartTitle = "Schéma expérimental vectoriel de la pile Daniell (Zn - Cu) avec pont salin",
      chartExploitation = "• Pôle négatif (-) = Anode : Zn → Zn²⁺ + 2e⁻ (oxydation avec perte de masse).\n• Pôle positif (+) = Cathode : Cu²⁺ + 2e⁻ → Cu (réduction avec dépôt de cuivre).\n• Pont salin : migration des cations (K⁺) vers la cathode et des anions (NO₃⁻) vers l'anode pour maintenir la neutralité électrique."
    ),

    Chapter(
      id = "C7",
      title = "C7 · Transformations forcées – Électrolyse",
      subject = SubjectType.CHIMIE,
      unit = "Unité 3 — Sens d'évolution spontané",
      keywords = listOf("transformation forcée", "électrolyse", "anode", "cathode", "quantité électricité", "chlorure de sodium"),
      problematic = "Qu’est-ce que l’électrolyse ? Quel est son principe ?",
      contentSections = listOf(
        "1. Transformation forcée : Réaction provoquée dans le sens inverse de son sens spontané par l'apport d'énergie électrique d'un générateur de tension continue.",
        "2. Électrolyse : Anode reliée au pôle positif (+) où se déroule l'oxydation ; Cathode reliée au pôle négatif (-) où se déroule la réduction.",
        "3. Analyse des réactions aux électrodes : Compétition entre les ions du soluté et les molécules du solvant (eau).",
        "4. Quantité d'électricité : Q = I \\Delta t = n(e^-) F. Calcul des masses de métal déposé m = \\frac{I \\Delta t M}{n_e F} ou volumes de gaz dégagé."
      ),
      summary = "Principe de l'électrolyse (transformation d'oxydoréduction forcée par générateur), identification des réactions aux électrodes et applications industrielles.",
      keyFormulas = listOf(
        "\\text{Anode (borne +)} : \\text{Oxydation}, \\quad \\text{Cathode (borne -)} : \\text{Réduction}",
        "Q = I \\cdot \\Delta t = n(e^-) \\cdot F \\quad (\\text{Faraday})",
        "m = \\frac{I \\cdot \\Delta t \\cdot M}{n_e \\cdot F} \\quad (\\text{Masse déposée à l'électrode})",
        "V = \\frac{I \\cdot \\Delta t \\cdot V_m}{n_e \\cdot F} \\quad (\\text{Volume de gaz dégagé})"
      ),
      activities = listOf(
        "Activité 1 — Électrolyse d'une solution de bromure de cuivre II (U = 1,2 V, électrodes de graphite).",
        "Activité 2 — Électrolyse du chlorure de sodium (saumure) : dégagement de dichlore à l'anode et de dihydrogène à la cathode.",
        "Activité 3 — Dépôt électrolytique d'argent (argenture d'un objet métallique)."
      ),
      application = "Purification industrielle du cuivre par électrolyse à anode soluble ; rechargement des accumulateurs au plomb.",
      chartType = ScientificChartType.MONTAGE_ELECTROLYSE,
      chartTitle = "Dispositif expérimental d'électrolyse (Transformations forcées)",
      chartExploitation = "• Sens de réaction forcé par le générateur continu G (sens inverse de l'évolution spontanée).\n• Anode (+) : dégagement gazeux de dibrome Br₂ (2Br⁻ → Br₂ + 2e⁻).\n• Cathode (-) : dépôt métallique rouge de cuivre (Cu²⁺ + 2e⁻ → Cu)."
    ),

    // --- UNITÉ 4 : CONTRÔLE DE L'ÉVOLUTION DES SYSTÈMES CHIMIQUES ---
    Chapter(
      id = "C8",
      title = "C8 · Les réactions d’estérification et d’hydrolyse",
      subject = SubjectType.CHIMIE,
      unit = "Unité 4 — Contrôle de l'évolution",
      keywords = listOf("alcool", "acide carboxylique", "anhydride", "ester", "estérification", "hydrolyse", "équilibre", "rendement", "catalyseur"),
      problematic = "Qu’est-ce qu’un ester ? Comment synthétise-t-on un ester ? Quelles sont les caractéristiques de cette synthèse ?",
      contentSections = listOf(
        "1. Familles organiques : Alcools R-OH (primaire, secondaire, tertiaire), acides carboxyliques R-COOH, anhydrides d'acide R-CO-O-CO-R et esters R-COO-R'. Nomenclature IUPAC.",
        "2. Équilibre d'estérification-hydrolyse : Réactions très lentes, limitées et athermiques. R-COOH + R'-OH \\rightleftharpoons R-COO-R' + H2O.",
        "3. Constante d'équilibre : K = \\frac{[\\text{ester}][\\text{eau}]}{[\\text{acide}][\\text{alcool}]} = 4 pour un alcool primaire (rendement 67 % en mélange équimolaire).",
        "4. Méthodes d'optimisation : Chauffage et catalyse acide (accélération cinétique sans modifier K) ; Excès d'un réactif ou élimination de l'eau/ester par appareil de Dean-Stark ou distillation fractionnée (déplacement de l'équilibre)."
      ),
      summary = "Nomenclature des alcools, acides et esters. Réactions lentes et limitées d'estérification-hydrolyse (K=4), calcul du rendement et optimisation de la synthèse.",
      keyFormulas = listOf(
        "\\text{R-COOH} + \\text{R'-OH} \\rightleftharpoons \\text{R-COO-R'} + \\text{H}_2\\text{O} \\quad (\\text{Équilibre estérification-hydrolyse})",
        "K = \\frac{[\\text{ester}]_{\\text{éq}} [\\text{eau}]_{\\text{éq}}}{[\\text{acide}]_{\\text{éq}} [\\text{alcool}]_{\\text{éq}}} = 4 \\quad (\\text{Alcool primaire})",
        "\\rho = \\frac{n_{\\text{exp}}(\\text{ester})}{n_{\\text{th}}(\\text{ester})} \\quad (\\text{Rendement de la synthèse})",
        "\\text{Rendements équimolaires : Primaire (67%), Secondaire (60%), Tertiaire (5%)}"
      ),
      activities = listOf(
        "Activité 1 — Synthèse de l'éthanoate d'éthyle à odeur fruitée avec chauffage à reflux.",
        "Activité 2 — Dosage de l'acide restant au cours du temps pour tracer la courbe d'avancement.",
        "Activité 3 — Utilisation de l'appareil de Dean-Stark pour déplacer l'équilibre vers un rendement de 100%."
      ),
      application = "Exercices de nomenclature systématique et calcul du rendement d'une synthèse en fonction des proportions molaires initiales.",
      chartType = ScientificChartType.MONTAGE_CHAUFFAGE_REFLUX,
      chartTitle = "Dispositif expérimental du chauffage à reflux avec réfrigérant à boules",
      chartExploitation = "• Le chauffage augmente la température pour accélérer considérablement la réaction d'estérification.\n• Le réfrigérant à boules condense les vapeurs qui retombent sous forme de gouttelettes dans le ballon : aucune perte de matière !"
    ),

    Chapter(
      id = "C9",
      title = "C9 · Contrôle de l’évolution par changement d’un réactif (Anhydrides & Saponification)",
      subject = SubjectType.CHIMIE,
      unit = "Unité 4 — Contrôle de l'évolution",
      keywords = listOf("anhydride acide", "aspirine", "saponification", "savon", "triglycéride", "rendement 100%"),
      problematic = "Comment remplacer un réactif pour rendre la synthèse d'un ester totale et rapide, et comment fabriquer des savons par saponification ?",
      contentSections = listOf(
        "1. Remplacement de l'acide carboxylique par un anhydride d'acide : Réaction rapide et totale avec un alcool, car l'absence d'eau empêche toute hydrolyse inverse. Exemple type : synthèse de l'aspirine à partir de l'acide salicylique.",
        "2. Hydrolyse basique des esters (saponification) : Réaction d'un ester avec les ions hydroxyde HO⁻ conduisant à un ion carboxylate et un alcool. Réaction totale et athermique.",
        "3. Fabrication industrielle et au laboratoire des savons : Saponification des triglycérides (corps gras) par un excès d'hydroxyde de sodium ou de potassium. Relargage du savon dans l'eau salée.",
        "4. Structure et propriétés détergentes des savons : Molécules amphiphiles possédant une chaîne carbonée lipophile (hydrophobe) et un groupe carboxylate hydrophile, formant des micelles emprisonnant les graisses."
      ),
      summary = "Synthèse rapide et totale d'esters par anhydrides d'acide (synthèse de l'aspirine) et saponification totale des corps gras pour la production de savons amphiphiles.",
      keyFormulas = listOf(
        "\\text{R-CO-O-CO-R} + \\text{R'-OH} \\longrightarrow \\text{R-COO-R'} + \\text{R-COOH} \\quad (\\text{Rapide et totale})",
        "\\text{R-COO-R'} + \\text{HO}^- \\longrightarrow \\text{R-COO}^- + \\text{R'-OH} \\quad (\\text{Saponification totale})",
        "\\text{Triglycéride} + 3(\\text{Na}^+ + \\text{HO}^-) \\longrightarrow 3(\\text{R-COO}^- + \\text{Na}^+) + \\text{Glycérol} \\quad (\\text{Savon})"
      ),
      activities = listOf(
        "Activité 1 — Synthèse de l'aspirine au laboratoire à partir de l'acide salicylique et de l'anhydride éthanoïque avec recristallisation.",
        "Activité 2 — Préparation d'un savon de ménage par saponification de l'huile d'olive avec soude concentrée et relargage par eau saturée en NaCl."
      ),
      application = "Calcul de la masse de savon produit lors d'une saponification et détermination du rendement d'extraction après filtration sous vide (Büchner).",
      chartType = ScientificChartType.CINETIQUE_ESTERIFICATION_HYDROLYSE,
      chartTitle = "Cinétiques comparées de l'estérification et de l'hydrolyse : n = f(t)",
      chartExploitation = "• Équilibre dynamique atteint à n_ester = 0.67 mol (rendement 67% avec alcool primaire).\n• Constante d'équilibre K = 4.\n• Optimisation par anhydride d'acide : rendement de 100% et réaction quasi-instantanée."
    ),

    Chapter(
      id = "C10",
      title = "C10 · Contrôle de l’évolution par catalyse et sélectivité des réactions",
      subject = SubjectType.CHIMIE,
      unit = "Unité 4 — Contrôle de l'évolution",
      keywords = listOf("catalyse homogène", "catalyse hétérogène", "catalyse enzymatique", "sélectivité catalytique", "chimiosélectivité"),
      problematic = "Qu'est-ce qu'un catalyseur et comment permet-il d'orienter sélectivement l'évolution d'une transformation chimique ?",
      contentSections = listOf(
        "1. Définition du catalyseur : Espèce chimique qui accélère une transformation spontanée sans figurer dans l'équation bilan et sans modifier l'état d'équilibre thermodynamique du système.",
        "2. Types de catalyse : Catalyse homogène (catalyseur et réactifs dans la même phase, ex : ions H⁺ en solution) ; Catalyse hétérogène (phases distinctes, catalyseur solide avec adsorption, ex : mousse de platine) ; Catalyse enzymatique (macromolécules protéiques hautement spécifiques).",
        "3. Sélectivité d'un catalyseur : Capacité d'un catalyseur à orienter un ensemble de réactifs vers un produit d'intérêt particulier parmi plusieurs voies réactionnelles possibles.",
        "4. Bilan d'optimisation d'une synthèse chimique : Différenciation nette entre optimisation cinétique (température, catalyseur, concentration) et déplacement thermodynamique de l'équilibre (excès d'un réactif, élimination continue d'un produit)."
      ),
      summary = "Propriétés générales des catalyseurs, classification (homogène, hétérogène, enzymatique), sélectivité réactionnelle et méthodes industrielles d'optimisation.",
      keyFormulas = listOf(
        "\\text{Vitesse } v_{\\text{avec catalyseur}} \\gg v_{\\text{sans catalyseur}} \\quad (\\text{Accélération cinétique})",
        "K_{\\text{équilibre}}(\\text{avec catalyseur}) = K_{\\text{équilibre}}(\\text{sans catalyseur}) \\quad (\\text{Invariance de l'équilibre})",
        "\\text{Chimiosélectivité} : \\text{Réaction sélective sur une seule fonction sans toucher aux autres}"
      ),
      activities = listOf(
        "Activité 1 — Mise en évidence de la catalyse de la dismutation de l'eau oxygénée par les ions Fe³⁺ (homogène) et par le platine (hétérogène).",
        "Activité 2 — Étude de la spécificité de la catalase (enzyme de navet ou de foie) vis-à-vis de la décomposition de H₂O₂."
      ),
      application = "Exercice type Bac : comparaison de la déshydratation catalytique de l'éthanol sur alumine (formation d'éthène à 350°C) ou sur cuivre (formation d'éthanal).",
      chartType = ScientificChartType.FACTEURS_CINETIQUES_TEMPERATURE,
      chartTitle = "Effet d'un catalyseur et de la température sur la vitesse de transformation",
      chartExploitation = "• La présence d'un catalyseur abaisse l'énergie d'activation et augmente considérablement la pente de la tangente à l'origine dx/dt.\n• L'état d'avancement final x_f reste rigoureusement identique avec ou sans catalyseur."
    )
  )

  // Annexe officielle complète des constantes et données numériques (Page 47 du document officiel)
  val officialConstants: List<PhysicalConstant> = listOf(
    PhysicalConstant("c", "Célérité de la lumière dans le vide", "299 792 458 m·s⁻¹ ≈ 3×10⁸", "m·s⁻¹"),
    PhysicalConstant("G", "Constante de gravitation universelle", "6,67 × 10⁻¹¹", "N·m²·kg⁻²"),
    PhysicalConstant("g", "Intensité de la pesanteur (énoncés)", "10", "N·kg⁻¹"),
    PhysicalConstant("m_T", "Masse de la Terre", "5,98 × 10²⁴", "kg"),
    PhysicalConstant("R_T", "Rayon moyen de la Terre", "6 378", "km"),
    PhysicalConstant("T_{\\text{sidéral}}", "Durée du jour sidéral terrestre", "23 h 56 min 4 s = 86 164", "s"),
    PhysicalConstant("N_A", "Constante d'Avogadro", "6,02214 × 10²³", "mol⁻¹"),
    PhysicalConstant("e", "Charge élémentaire", "1,602 × 10⁻¹⁹", "C"),
    PhysicalConstant("F", "Constante de Faraday (F = N_A · e)", "9,65 × 10⁴", "C·mol⁻¹"),
    PhysicalConstant("R", "Constante des gaz parfaits", "8,314", "J·K⁻¹·mol⁻¹"),
    PhysicalConstant("u", "Unité de masse atomique (1 u·c² = 931,5 MeV)", "1,66054 × 10⁻²⁷", "kg"),
    PhysicalConstant("1\\text{ eV}", "Électronvolt", "1,602177 × 10⁻¹⁹", "J"),
    PhysicalConstant("m_p", "Masse du proton", "1,00728 u (938,272 MeV)", "u"),
    PhysicalConstant("m_n", "Masse du neutron", "1,00866 u (939,565 MeV)", "u"),
    PhysicalConstant("m_e", "Masse de l'électron", "0,00055 u (0,511 MeV)", "u"),
    PhysicalConstant("r_0", "Rayon nucléaire fondamental (r = r_0 · A^{1/3})", "1,2 × 10⁻¹⁵", "m"),
    PhysicalConstant("K_e", "Produit ionique de l'eau (à 25°C, pK_e = 14)", "1,0 × 10⁻¹⁴", "Sans unité"),
    PhysicalConstant("\\lambda(H_3O^+)", "Conductivité molaire ionique oxonium (25°C)", "35,0", "mS·m²·mol⁻¹"),
    PhysicalConstant("\\lambda(CH_3CO_2^-)", "Conductivité molaire ionique éthanoate (25°C)", "4,09", "mS·m²·mol⁻¹"),
    PhysicalConstant("\\lambda(HCO_2^-)", "Conductivité molaire ionique méthanoate (25°C)", "5,46", "mS·m²·mol⁻¹"),
    PhysicalConstant("\\lambda(C_6H_5CO_2^-)", "Conductivité molaire ionique benzoate (25°C)", "3,23", "mS·m²·mol⁻¹"),
    PhysicalConstant("\\lambda(CH_2ClCO_2^-)", "Conductivité molaire chloroéthanoate (25°C)", "4,22", "mS·m²·mol⁻¹"),
    PhysicalConstant("E_{\\text{pétrole}}", "Énergie de combustion d'un kilogramme de pétrole", "42", "MJ")
  )
}
