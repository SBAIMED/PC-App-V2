package com.example.data

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

object GoogleAuthManager {
  private const val TAG = "GoogleAuthManager"

  fun getCurrentUser() = try {
    Firebase.auth.currentUser
  } catch (t: Throwable) {
    null
  }

  fun isUserSignedIn(): Boolean = try {
    Firebase.auth.currentUser != null
  } catch (t: Throwable) {
    false
  }

  /**
   * Tente une connexion silencieuse en arrière-plan sans boîte de dialogue intrusive.
   * Totalement résilient si Firebase ou google-services.json est manquant.
   */
  suspend fun attemptAutoSignIn(
    context: Context
  ): Result<UserProfile?> {
    if (!FirebaseSafetyManager.isFirebaseAvailable(context)) {
      Log.d(TAG, "Mode autonome local : Firebase non configuré, tentative silencieuse ignorée.")
      return Result.success(null)
    }

    try {
      val existingUser = getCurrentUser()
      if (existingUser != null) {
        val session = SessionManager.getInstance(context)
        val profile = UserProfile(
          id = existingUser.uid,
          displayName = existingUser.displayName ?: session.userName,
          email = existingUser.email ?: "",
          // Until a server-verified role claim is implemented, Google sign-in is student-only.
          role = UserRole.ELEVE,
          userClass = session.userClass,
          photoUrl = existingUser.photoUrl?.toString()
        )
        return Result.success(profile)
      }
    } catch (t: Throwable) {
      Log.d(TAG, "Vérification utilisateur existant ignorée : ${t.message}")
    }

    val clientId = FirebaseSafetyManager.resolveWebClientId(context)
    if (clientId.isNullOrBlank()) {
      Log.d(TAG, "Web Client ID non configuré (google-services.json absent ou partiel)")
      return Result.success(null)
    }

    val googleIdOption = GetGoogleIdOption.Builder()
      .setFilterByAuthorizedAccounts(true)
      .setServerClientId(clientId)
      .setAutoSelectEnabled(true)
      .build()

    val request = GetCredentialRequest.Builder()
      .addCredentialOption(googleIdOption)
      .build()

    val credentialManager = CredentialManager.create(context)

    return try {
      val result = credentialManager.getCredential(context, request)
      val credential = result.credential
      if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
        val authResult = Firebase.auth.signInWithCredential(authCredential).await()
        val user = authResult.user ?: return Result.success(null)

        val session = SessionManager.getInstance(context)
        val profile = syncUserProfile(context, user.uid, user.displayName ?: session.userName, user.email ?: "", session.userRole, session.userClass, user.photoUrl?.toString())
        Result.success(profile)
      } else {
        Result.success(null)
      }
    } catch (e: Exception) {
      Log.d(TAG, "Silent sign in not available: ${e.message}")
      Result.success(null)
    }
  }

  /**
   * Connexion interactive Google Sign-In via Jetpack CredentialManager.
   * Gère gracieusement le mode autonome si google-services.json est manquant.
   */
  suspend fun signInWithGoogle(
    activity: Activity,
    requestedRole: UserRole,
    requestedClass: String
  ): Result<UserProfile> {
    if (requestedRole == UserRole.PROFESSEUR) {
      return Result.failure(IllegalStateException(
        "L'accès professeur exige une autorisation vérifiée côté serveur."
      ))
    }
    val context = activity.applicationContext
    if (!FirebaseSafetyManager.isFirebaseAvailable(context)) {
      // Mode autonome : Connexion locale transparente sans blocage
      Log.i(TAG, "Firebase non initialisé -> bascule en mode autonome local")
      val fallbackName = if (requestedRole == UserRole.PROFESSEUR) "Pr. SBAI Mohammed" else "Élève 2BAC"
      val localProfile = UserProfile(
        id = "local_${System.currentTimeMillis()}",
        displayName = fallbackName,
        email = "local@lycee.ma",
        role = requestedRole,
        userClass = requestedClass
      )
      SessionManager.getInstance(context).saveSession(requestedRole, fallbackName, requestedClass)
      return Result.success(localProfile)
    }

    val clientId = FirebaseSafetyManager.resolveWebClientId(context)
    if (clientId.isNullOrBlank()) {
      return Result.failure(IllegalStateException("Configuration Google Sign-In manquante (google-services.json absent ou non configuré)."))
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
      .addCredentialOption(signInOption)
      .build()

    val credentialManager = CredentialManager.create(activity)

    return try {
      val result = credentialManager.getCredential(activity, request)
      val credential = result.credential
      if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
        val authResult = Firebase.auth.signInWithCredential(authCredential).await()
        val user = authResult.user ?: throw IllegalStateException("Échec d'authentification Firebase")

        val profile = syncUserProfile(
          context = context,
          userId = user.uid,
          fallbackName = user.displayName ?: if (requestedRole == UserRole.PROFESSEUR) "Pr. SBAI Mohammed" else "Élève 2BAC",
          email = user.email ?: "",
          role = requestedRole,
          userClass = requestedClass,
          photoUrl = user.photoUrl?.toString()
        )
        Result.success(profile)
      } else {
        Result.failure(IllegalStateException("Type de certificat inattendu reçu."))
      }
    } catch (e: GetCredentialCancellationException) {
      Log.w(TAG, "Google Sign-In cancelled: ${e.message}", e)
      Result.failure(e)
    } catch (e: Exception) {
      Log.e(TAG, "Google Sign-In error: ${e.message}", e)
      Result.failure(e)
    }
  }

  /**
   * Synchronise ou crée le profil utilisateur dans Firestore (/users/{userId}).
   * Sécurisé contre les erreurs réseau ou absence de Firestore.
   */
  private suspend fun syncUserProfile(
    context: Context,
    userId: String,
    fallbackName: String,
    email: String,
    role: UserRole,
    userClass: String,
    photoUrl: String?
  ): UserProfile {
    val sessionManager = SessionManager.getInstance(context)
    val dbId = FirebaseSafetyManager.resolveFirestoreDatabaseId(context) ?: ""

    // A Firestore profile document is user data, not proof of privileged authorization.
    // Keep the client role at student until Firebase custom claims are verified server-side.
    var finalRole = UserRole.ELEVE
    var finalClass = userClass
    var finalName = fallbackName

    if (dbId.isNotBlank() && FirebaseSafetyManager.isFirebaseAvailable(context)) {
      try {
        val db = FirebaseFirestore.getInstance(dbId)
        val userDoc = db.collection("users").document(userId)
        val snapshot = userDoc.get().await()

        if (snapshot.exists()) {
          // Ignore role stored in a client-readable profile document.
          // A future release must read a trusted Firebase custom claim instead.
          finalClass = snapshot.getString("userClass") ?: userClass
          finalName = snapshot.getString("displayName") ?: fallbackName
          userDoc.update("updatedAt", FieldValue.serverTimestamp()).await()
        } else {
          val data = mapOf(
            "id" to userId,
            "displayName" to finalName,
            "email" to email,
            "role" to finalRole.name,
            "userClass" to finalClass,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
          )
          userDoc.set(data).await()
        }
      } catch (e: Throwable) {
        Log.w(TAG, "Firestore sync non-fatal: ${e.message}")
      }
    }

    sessionManager.saveSession(finalRole, finalName, finalClass)

    return UserProfile(
      id = userId,
      displayName = finalName,
      email = email,
      role = finalRole,
      userClass = finalClass,
      photoUrl = photoUrl
    )
  }

  /**
   * Déconnexion complète de Firebase et vidage des identifiants CredentialManager.
   */
  suspend fun signOut(context: Context) {
    if (FirebaseSafetyManager.isFirebaseAvailable(context)) {
      try {
        Firebase.auth.signOut()
      } catch (t: Throwable) {
        Log.w(TAG, "Firebase sign out error: ${t.message}")
      }
    }

    try {
      val credentialManager = CredentialManager.create(context)
      credentialManager.clearCredentialState(ClearCredentialStateRequest())
    } catch (t: Throwable) {
      Log.w(TAG, "Credential clear error: ${t.message}")
    }

    SessionManager.getInstance(context).clearSession()
  }
}
