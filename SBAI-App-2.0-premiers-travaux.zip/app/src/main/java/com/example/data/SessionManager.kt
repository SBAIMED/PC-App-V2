package com.example.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages user session persistence, student profile data, and exam score records
 * using Android SharedPreferences. Ensures that login sessions survive app restarts
 * and configuration changes.
 */
class SessionManager private constructor(context: Context) {

  private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
    PREFS_NAME,
    Context.MODE_PRIVATE
  )

  var isLoggedIn: Boolean
    get() = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    set(value) = prefs.edit().putBoolean(KEY_IS_LOGGED_IN, value).apply()

  var userRole: UserRole
    get() {
      val roleStr = prefs.getString(KEY_USER_ROLE, UserRole.ELEVE.name) ?: UserRole.ELEVE.name
      return try {
        UserRole.valueOf(roleStr)
      } catch (e: Exception) {
        UserRole.ELEVE
      }
    }
    set(value) = prefs.edit().putString(KEY_USER_ROLE, value.name).apply()

  var userName: String
    get() = prefs.getString(KEY_USER_NAME, "Élève 2BAC") ?: "Élève 2BAC"
    set(value) = prefs.edit().putString(KEY_USER_NAME, value).apply()

  var userClass: String
    get() = prefs.getString(KEY_USER_CLASS, "2ème Bac Sciences Physiques") ?: "2ème Bac Sciences Physiques"
    set(value) = prefs.edit().putString(KEY_USER_CLASS, value).apply()

  var studentScore: Int
    get() = prefs.getInt(KEY_STUDENT_SCORE, 0)
    set(value) = prefs.edit().putInt(KEY_STUDENT_SCORE, value).apply()

  fun saveSession(role: UserRole, name: String, userClass: String) {
    prefs.edit()
      .putBoolean(KEY_IS_LOGGED_IN, true)
      .putString(KEY_USER_ROLE, role.name)
      .putString(KEY_USER_NAME, name)
      .putString(KEY_USER_CLASS, userClass)
      .apply()
  }

  fun clearSession() {
    prefs.edit()
      .putBoolean(KEY_IS_LOGGED_IN, false)
      .putString(KEY_USER_ROLE, UserRole.ELEVE.name)
      .putString(KEY_USER_NAME, "Élève 2BAC")
      .putString(KEY_USER_CLASS, "2ème Bac Sciences Physiques")
      .putInt(KEY_STUDENT_SCORE, 0)
      .apply()
  }

  // Record an exam simulation grade
  fun recordExamGrade(examId: String, grade: Double) {
    prefs.edit().putFloat("grade_$examId", grade.toFloat()).apply()
  }

  fun getExamGrade(examId: String): Float? {
    return if (prefs.contains("grade_$examId")) {
      prefs.getFloat("grade_$examId", 0f)
    } else null
  }

  companion object {
    private const val PREFS_NAME = "bac_pc_session_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_USER_ROLE = "user_role"
    private const val KEY_USER_NAME = "user_name"
    private const val KEY_USER_CLASS = "user_class"
    private const val KEY_STUDENT_SCORE = "student_score"

    @Volatile
    private var INSTANCE: SessionManager? = null

    fun getInstance(context: Context): SessionManager {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: SessionManager(context).also { INSTANCE = it }
      }
    }
  }
}
