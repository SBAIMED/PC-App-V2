package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.StudyReminderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyReminderDao {

  @Query("SELECT * FROM study_reminders ORDER BY isDone ASC, createdAt DESC")
  fun getAllReminders(): Flow<List<StudyReminderEntity>>

  @Query("SELECT * FROM study_reminders WHERE isDone = 0 ORDER BY createdAt DESC")
  fun getActiveReminders(): Flow<List<StudyReminderEntity>>

  @Query("SELECT * FROM study_reminders WHERE subject = :subject ORDER BY isDone ASC, createdAt DESC")
  fun getRemindersBySubject(subject: String): Flow<List<StudyReminderEntity>>

  @Query("SELECT COUNT(*) FROM study_reminders WHERE isDone = 0")
  fun getActiveRemindersCount(): Flow<Int>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReminder(reminder: StudyReminderEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(reminders: List<StudyReminderEntity>)

  @Query("UPDATE study_reminders SET isDone = :isDone WHERE id = :id")
  suspend fun updateDoneStatus(id: String, isDone: Boolean)

  @Query("DELETE FROM study_reminders WHERE id = :id")
  suspend fun deleteReminder(id: String)

  @Query("SELECT COUNT(*) FROM study_reminders")
  suspend fun getCount(): Int
}
