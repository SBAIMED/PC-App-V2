package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.StudentRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentRecordDao {

  @Query("SELECT * FROM student_records ORDER BY name ASC")
  fun getAllStudents(): Flow<List<StudentRecordEntity>>

  @Query("SELECT * FROM student_records WHERE id = :id LIMIT 1")
  fun getStudentById(id: String): Flow<StudentRecordEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdate(student: StudentRecordEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(students: List<StudentRecordEntity>)

  @Query("DELETE FROM student_records WHERE id = :id")
  suspend fun deleteStudent(id: String)

  @Query("SELECT COUNT(*) FROM student_records")
  suspend fun getCount(): Int
}
