package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.local.converters.AppTypeConverters
import com.example.data.local.dao.*
import com.example.data.local.entity.*

@Database(
  entities = [
    ChapterProgressEntity::class,
    QuizAttemptEntity::class,
    StudyReminderEntity::class,
    ChatMessageEntity::class,
    CustomQuizEntity::class,
    UserBookmarkEntity::class,
    StudentRecordEntity::class
  ],
  version = 1,
  exportSchema = false
)
@TypeConverters(AppTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {

  abstract fun chapterProgressDao(): ChapterProgressDao
  abstract fun quizAttemptDao(): QuizAttemptDao
  abstract fun studyReminderDao(): StudyReminderDao
  abstract fun chatMessageDao(): ChatMessageDao
  abstract fun customQuizDao(): CustomQuizDao
  abstract fun userBookmarkDao(): UserBookmarkDao
  abstract fun studentRecordDao(): StudentRecordDao

  companion object {
    private const val DATABASE_NAME = "physique_chimie_2bac.db"

    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getInstance(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          DATABASE_NAME
        )
          .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = true)
          .build()
          .also { INSTANCE = it }
      }
    }
  }
}
