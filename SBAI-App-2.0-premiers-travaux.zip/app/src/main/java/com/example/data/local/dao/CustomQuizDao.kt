package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.CustomQuizEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomQuizDao {

  @Query("SELECT * FROM custom_quizzes ORDER BY createdAt DESC")
  fun getAllQuizzes(): Flow<List<CustomQuizEntity>>

  @Query("SELECT * FROM custom_quizzes WHERE id = :id LIMIT 1")
  fun getQuizById(id: String): Flow<CustomQuizEntity?>

  @Query("SELECT * FROM custom_quizzes WHERE subject = :subject ORDER BY createdAt DESC")
  fun getQuizzesBySubject(subject: String): Flow<List<CustomQuizEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQuiz(quiz: CustomQuizEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(quizzes: List<CustomQuizEntity>)

  @Query("DELETE FROM custom_quizzes WHERE id = :id")
  suspend fun deleteQuiz(id: String)

  @Query("SELECT COUNT(*) FROM custom_quizzes")
  suspend fun getCount(): Int
}
