package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "custom_quizzes")
data class CustomQuizEntity(
  @PrimaryKey val id: String,
  val title: String,
  val subject: String, // "PHYSIQUE", "CHIMIE"
  val targetClass: String,
  val createdBy: String,
  val durationMinutes: Int,
  val questionsJson: String, // Serialized questions JSON
  val driveResourceUrl: String = "",
  val isPublished: Boolean = true,
  val createdAt: Long = System.currentTimeMillis()
)
