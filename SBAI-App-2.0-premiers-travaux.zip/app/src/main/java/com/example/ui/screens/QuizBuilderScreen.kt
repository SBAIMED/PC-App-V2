package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.data.repository.AppLocalRepository
import com.example.ui.theme.ScienceGreen
import com.example.ui.theme.ScienceRed
import kotlinx.coroutines.launch

@Composable
fun QuizBuilderScreen(
  currentUserRole: UserRole = UserRole.PROFESSEUR,
  onQuizSubmittedByStudent: (QuizSubmission) -> Unit = {}
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val repository = remember { AppLocalRepository.getInstance(context) }
  val dbQuizzes by repository.allCustomQuizzes.collectAsStateWithLifecycle(initialValue = emptyList())

  val quizzesList = remember(dbQuizzes) {
    if (dbQuizzes.isNotEmpty()) {
      dbQuizzes.map { entity ->
        val parsed = QuizJsonUtils.parseQuestionsFromJson(entity.questionsJson)
        CustomQuiz(
          id = entity.id,
          title = entity.title,
          subject = runCatching { SubjectType.valueOf(entity.subject) }.getOrDefault(SubjectType.PHYSIQUE),
          targetClass = entity.targetClass,
          createdBy = entity.createdBy,
          durationMinutes = entity.durationMinutes,
          questions = parsed.ifEmpty {
            CurriculumData.initialCustomQuizzes.find { it.id == entity.id }?.questions ?: emptyList()
          },
          driveResourceUrl = entity.driveResourceUrl,
          isPublished = entity.isPublished
        )
      }
    } else {
      CurriculumData.initialCustomQuizzes
    }
  }

  var isCreatingQuiz by remember { mutableStateOf(false) }
  var activeTakingQuizId by remember { mutableStateOf<String?>(null) }

  // Student answer tracking for active taking quiz: questionId -> answer string
  val activeStudentAnswers = remember { mutableStateMapOf<String, String>() }
  var latestSubmissionResult by remember { mutableStateOf<QuizSubmission?>(null) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("quiz_builder_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Banner
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
          containerColor = if (currentUserRole == UserRole.PROFESSEUR) MaterialTheme.colorScheme.primaryContainer
          else MaterialTheme.colorScheme.secondaryContainer
        ),
        shape = RoundedCornerShape(16.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .background(
                  if (currentUserRole == UserRole.PROFESSEUR) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                  CircleShape
                ),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Psychology, contentDescription = null, tint = Color.White)
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(
                if (currentUserRole == UserRole.PROFESSEUR) "Concepteur de Quiz & Évaluations" else "Mes Quiz Attribués & Auto-Correction",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                if (currentUserRole == UserRole.PROFESSEUR) "Création sur-mesure (QCM, Vrai/Faux, Réponses courtes) avec barèmes et attribution"
                else "Répondez aux quiz interactifs avec retour immédiat et correction automatique",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          // Link to Pr. SBAI's Drive documents library
          Surface(
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(CurriculumData.driveLibraryUrl))
                try {
                  context.startActivity(intent)
                } catch (e: Exception) {
                  // Fallback
                }
              }
              .testTag("btn_open_drive_library")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
              ) {
                Icon(Icons.Default.FolderShared, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Column {
                  Text(
                    "Bibliothèque Professionnelle Pr. SBAI (Google Drive)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    "Documents de cours, exercices et banques de questions officielles",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
              Icon(Icons.Default.OpenInNew, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            }
          }
        }
      }
    }

    // Professor Action: Create New Quiz Button
    if (currentUserRole == UserRole.PROFESSEUR && !isCreatingQuiz) {
      item {
        Button(
          onClick = { isCreatingQuiz = true },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("btn_create_new_quiz"),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Concevoir un nouveau quiz interactif")
        }
      }
    }

    // Professor Quiz Creation Form
    if (currentUserRole == UserRole.PROFESSEUR && isCreatingQuiz) {
      item {
        QuizCreationForm(
          onCancel = { isCreatingQuiz = false },
          onSaveQuiz = { newQuiz ->
            coroutineScope.launch {
              val questionsJson = QuizJsonUtils.serializeQuestionsToJson(newQuiz.questions)
              repository.saveCustomQuiz(
                title = newQuiz.title,
                subject = newQuiz.subject.name,
                targetClass = newQuiz.targetClass,
                createdBy = newQuiz.createdBy,
                durationMinutes = newQuiz.durationMinutes,
                questionsJson = questionsJson,
                driveResourceUrl = newQuiz.driveResourceUrl
              )
            }
            isCreatingQuiz = false
          }
        )
      }
    }

    // Section Title
    item {
      Text(
        "Quiz Disponibles (${quizzesList.size}) :",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold
      )
    }

    // Quizzes List
    items(quizzesList, key = { it.id }) { quiz ->
      val isTakingThisQuiz = activeTakingQuizId == quiz.id

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("custom_quiz_card_${quiz.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          // Header info
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = if (quiz.subject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                quiz.subject.label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (quiz.subject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }

            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                "Classe : ${quiz.targetClass}",
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Text(quiz.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            Text(
              "• ${quiz.questions.size} questions",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              "• Barème : ${quiz.totalPoints} points",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.tertiary
            )
            Text(
              "• Durée : ${quiz.durationMinutes} min",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          // Student takes quiz action
          if (!isTakingThisQuiz) {
            Button(
              onClick = {
                activeTakingQuizId = quiz.id
                activeStudentAnswers.clear()
                latestSubmissionResult = null
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_take_quiz_${quiz.id}"),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (currentUserRole == UserRole.PROFESSEUR) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
              )
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (currentUserRole == UserRole.PROFESSEUR) "Tester le quiz (Aperçu)" else "Lancer le quiz interactif")
            }
          } else {
            // Interactive taking container
            InteractiveQuizRunner(
              quiz = quiz,
              answers = activeStudentAnswers,
              onAnswerChanged = { qId, ans -> activeStudentAnswers[qId] = ans },
              onClose = { activeTakingQuizId = null },
              onSubmit = { submission ->
                latestSubmissionResult = submission
                onQuizSubmittedByStudent(submission)
                coroutineScope.launch {
                  val scoreOutOf20 = if (submission.maxScore > 0) (submission.score / submission.maxScore) * 20.0 else 0.0
                  repository.recordQuizAttempt(
                    quizId = submission.quizId,
                    quizTitle = quiz.title,
                    subject = quiz.subject.name,
                    score = scoreOutOf20,
                    maxScore = 20.0,
                    studentName = submission.studentName
                  )
                }
              }
            )
          }
        }
      }
    }
  }
}

@Composable
fun InteractiveQuizRunner(
  quiz: CustomQuiz,
  answers: MutableMap<String, String>,
  onAnswerChanged: (String, String) -> Unit,
  onClose: () -> Unit,
  onSubmit: (QuizSubmission) -> Unit
) {
  val context = LocalContext.current
  var isSubmitted by remember { mutableStateOf(false) }
  var calculatedScore by remember { mutableDoubleStateOf(0.0) }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
      .padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        "Épreuve en cours :",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
      )
      IconButton(onClick = onClose) {
        Icon(Icons.Default.Close, contentDescription = "Fermer")
      }
    }

    quiz.questions.forEachIndexed { qIdx, question ->
      val studentAns = answers[question.id] ?: ""

      // Check correctness when submitted
      val isCorrect = when (question.type) {
        QuestionType.QCM -> studentAns == question.correctOptionIndex.toString()
        QuestionType.VRAI_FAUX -> studentAns.equals(question.correctBoolean.toString(), ignoreCase = true)
        QuestionType.REPONSE_COURTE -> studentAns.trim().contains(question.correctAnswerText.trim(), ignoreCase = true)
      }

      Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(4.dp)) {
                Text(
                  question.type.label,
                  style = MaterialTheme.typography.labelSmall,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
              Text("Q${qIdx + 1}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
            }
            Text(
              "${question.points} pts",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.tertiary
            )
          }

          Text(question.prompt, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)

          // Formats rendering
          when (question.type) {
            QuestionType.QCM -> {
              question.options.forEachIndexed { optIdx, optText ->
                val isSelected = studentAns == optIdx.toString()
                Surface(
                  color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = !isSubmitted) {
                      onAnswerChanged(question.id, optIdx.toString())
                    }
                ) {
                  Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    RadioButton(
                      selected = isSelected,
                      onClick = { if (!isSubmitted) onAnswerChanged(question.id, optIdx.toString()) },
                      enabled = !isSubmitted
                    )
                    Text(optText, style = MaterialTheme.typography.bodySmall)
                  }
                }
              }
            }

            QuestionType.VRAI_FAUX -> {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(true to "Vrai", false to "Faux").forEach { (boolVal, label) ->
                  val isSelected = studentAns == boolVal.toString()
                  FilterChip(
                    selected = isSelected,
                    onClick = { if (!isSubmitted) onAnswerChanged(question.id, boolVal.toString()) },
                    label = { Text(label) },
                    modifier = Modifier.weight(1f)
                  )
                }
              }
            }

            QuestionType.REPONSE_COURTE -> {
              OutlinedTextField(
                value = studentAns,
                onValueChange = { if (!isSubmitted) onAnswerChanged(question.id, it) },
                label = { Text("Votre réponse ou valeur") },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isSubmitted,
                singleLine = true
              )
            }
          }

          // Feedback when submitted
          if (isSubmitted) {
            Surface(
              color = if (isCorrect) ScienceGreen.copy(alpha = 0.15f) else ScienceRed.copy(alpha = 0.15f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Icon(
                    if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Cancel,
                    contentDescription = null,
                    tint = if (isCorrect) ScienceGreen else ScienceRed,
                    modifier = Modifier.size(16.dp)
                  )
                  Text(
                    if (isCorrect) "+${question.points} pts (Bonne réponse)" else "0 pt (Réponse incorrecte)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isCorrect) ScienceGreen else ScienceRed
                  )
                }
                Text(
                  "Correction : ${question.explanation}",
                  style = MaterialTheme.typography.bodySmall
                )
              }
            }
          }
        }
      }
    }

    if (!isSubmitted) {
      Button(
        onClick = {
          var totalScored = 0.0
          quiz.questions.forEach { q ->
            val ans = answers[q.id] ?: ""
            val ok = when (q.type) {
              QuestionType.QCM -> ans == q.correctOptionIndex.toString()
              QuestionType.VRAI_FAUX -> ans.equals(q.correctBoolean.toString(), ignoreCase = true)
              QuestionType.REPONSE_COURTE -> {
                val expected = q.correctAnswerText.trim()
                val submitted = ans.trim()
                expected.isNotBlank() && (submitted.equals(expected, ignoreCase = true) || submitted.contains(expected, ignoreCase = true))
              }
            }
            if (ok) totalScored += q.points
          }
          calculatedScore = totalScored
          isSubmitted = true
          val currentName = SessionManager.getInstance(context).userName.ifBlank { "Élève 2BAC" }
          onSubmit(
            QuizSubmission(
              quizId = quiz.id,
              studentName = currentName,
              score = calculatedScore,
              maxScore = quiz.totalPoints,
              submittedAt = "À l'instant"
            )
          )
        },
        modifier = Modifier.fillMaxWidth().testTag("btn_submit_quiz_answers")
      ) {
        Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Soumettre pour correction automatique instantanée")
      }
    } else {
      Surface(
        color = ScienceGreen.copy(alpha = 0.2f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text("Résultat du Quiz :", fontWeight = FontWeight.Bold, color = ScienceGreen)
            Text("Note enregistrée dans votre carnet de bord", style = MaterialTheme.typography.bodySmall)
          }
          Text(
            "${"%.1f".format(calculatedScore)} / ${"%.1f".format(quiz.totalPoints)}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = ScienceGreen
          )
        }
      }
    }
  }
}

@Composable
fun QuizCreationForm(
  onCancel: () -> Unit,
  onSaveQuiz: (CustomQuiz) -> Unit
) {
  var quizTitle by remember { mutableStateOf("") }
  var subjectType by remember { mutableStateOf(SubjectType.PHYSIQUE) }
  var targetClass by remember { mutableStateOf("2ème Bac PC 1") }
  var durationMinutesText by remember { mutableStateOf("25") }

  // Questions to add to the quiz
  val questionsBuilder = remember {
    mutableStateListOf(
      CustomQuizQuestion(
        id = "q_new_1",
        type = QuestionType.QCM,
        prompt = "Ex: Quelle est l'expression de l'impédance Z dans un circuit RLC ?",
        options = listOf("Z = R", "Z = √(R² + (Lω - 1/(Cω))²)", "Z = L·ω", "Z = 1/(C·ω)"),
        correctOptionIndex = 1,
        explanation = "Z = √(R² + (Lω - 1/(Cω))²) est l'impédance caractéristique à la fréquence f.",
        points = 5.0
      ),
      CustomQuizQuestion(
        id = "q_new_2",
        type = QuestionType.VRAI_FAUX,
        prompt = "Ex: Lors d'une désintégration radioactive alpha, le noyau fils perd 2 protons et 2 neutrons.",
        correctBoolean = true,
        explanation = "Vrai : La particule alpha est un noyau d'Hélium-4 (2 protons et 2 neutrons).",
        points = 5.0
      )
    )
  }

  // Adding a question sub-state
  var newPrompt by remember { mutableStateOf("") }
  var newType by remember { mutableStateOf(QuestionType.QCM) }
  var newPointsText by remember { mutableStateOf("5.0") }
  var newExplanation by remember { mutableStateOf("") }
  var newCorrectShortAnswer by remember { mutableStateOf("") }
  var optA by remember { mutableStateOf("Proposition A") }
  var optB by remember { mutableStateOf("Proposition B") }
  var optC by remember { mutableStateOf("Proposition C") }
  var optD by remember { mutableStateOf("Proposition D") }
  var correctOptIdx by remember { mutableIntStateOf(0) }
  var correctBoolVal by remember { mutableStateOf(true) }

  Card(
    modifier = Modifier.fillMaxWidth().testTag("quiz_creation_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Text(
        "Nouveau Quiz : Paramètres Pédagogiques",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
      )

      OutlinedTextField(
        value = quizTitle,
        onValueChange = { quizTitle = it },
        label = { Text("Titre du quiz (ex: Contrôle express Ondes & Électricité)") },
        modifier = Modifier.fillMaxWidth().testTag("input_quiz_title")
      )

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = targetClass,
          onValueChange = { targetClass = it },
          label = { Text("Classe cible") },
          modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
          value = durationMinutesText,
          onValueChange = { durationMinutesText = it },
          label = { Text("Durée (min)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.weight(1f)
        )
      }

      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FilterChip(
          selected = subjectType == SubjectType.PHYSIQUE,
          onClick = { subjectType = SubjectType.PHYSIQUE },
          label = { Text("Physique") },
          modifier = Modifier.weight(1f)
        )
        FilterChip(
          selected = subjectType == SubjectType.CHIMIE,
          onClick = { subjectType = SubjectType.CHIMIE },
          label = { Text("Chimie") },
          modifier = Modifier.weight(1f)
        )
      }

      HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

      Text(
        "Questions incluses (${questionsBuilder.size}) - Barème total : ${questionsBuilder.sumOf { it.points }} pts :",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold
      )

      // List of questions drafted
      questionsBuilder.forEachIndexed { idx, q ->
        Surface(
          color = MaterialTheme.colorScheme.surface,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("${idx + 1}. [${q.type.label}] ${q.prompt}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
              Text("Barème : ${q.points} pts", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
            }
            IconButton(onClick = { questionsBuilder.removeAt(idx) }) {
              Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = ScienceRed)
            }
          }
        }
      }

      // Quick add question panel
      Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Ajouter une question supplémentaire :", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            QuestionType.values().forEach { t ->
              FilterChip(
                selected = newType == t,
                onClick = { newType = t },
                label = { Text(t.label.take(10) + "...") }
              )
            }
          }

          OutlinedTextField(
            value = newPrompt,
            onValueChange = { newPrompt = it },
            label = { Text("Énoncé de la question") },
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = newPointsText,
            onValueChange = { newPointsText = it },
            label = { Text("Points pour cette question (ex: 4.0)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
          )

          if (newType == QuestionType.QCM) {
            Text("Choix du QCM (sélectionnez le bouton radio de la bonne réponse) :", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            val optionsList = listOf(optA to 0, optB to 1, optC to 2, optD to 3)
            optionsList.forEach { (textVal, idx) ->
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                RadioButton(
                  selected = correctOptIdx == idx,
                  onClick = { correctOptIdx = idx }
                )
                OutlinedTextField(
                  value = when (idx) {
                    0 -> optA
                    1 -> optB
                    2 -> optC
                    else -> optD
                  },
                  onValueChange = { str ->
                    when (idx) {
                      0 -> optA = str
                      1 -> optB = str
                      2 -> optC = str
                      else -> optD = str
                    }
                  },
                  label = { Text("Proposition ${('A' + idx)} ${if (correctOptIdx == idx) "(Bonne réponse)" else ""}") },
                  modifier = Modifier.weight(1f)
                )
              }
            }
          }

          if (newType == QuestionType.VRAI_FAUX) {
            Text("Réponse attendue :", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = correctBoolVal, onClick = { correctBoolVal = true })
                Text("Vrai", modifier = Modifier.padding(start = 4.dp))
              }
              Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = !correctBoolVal, onClick = { correctBoolVal = false })
                Text("Faux", modifier = Modifier.padding(start = 4.dp))
              }
            }
          }

          if (newType == QuestionType.REPONSE_COURTE) {
            OutlinedTextField(
              value = newCorrectShortAnswer,
              onValueChange = { newCorrectShortAnswer = it },
              label = { Text("Réponse exacte attendue") },
              modifier = Modifier.fillMaxWidth()
            )
          }

          OutlinedTextField(
            value = newExplanation,
            onValueChange = { newExplanation = it },
            label = { Text("Explication pédagogique pour la correction") },
            modifier = Modifier.fillMaxWidth()
          )

          Button(
            onClick = {
              if (newPrompt.isNotBlank()) {
                val opts = if (newType == QuestionType.QCM) listOf(optA.trim(), optB.trim(), optC.trim(), optD.trim()) else emptyList()
                questionsBuilder.add(
                  CustomQuizQuestion(
                    id = "q_added_${System.currentTimeMillis()}",
                    type = newType,
                    prompt = newPrompt.trim(),
                    options = opts,
                    correctOptionIndex = correctOptIdx,
                    correctBoolean = correctBoolVal,
                    correctAnswerText = newCorrectShortAnswer.trim(),
                    explanation = newExplanation.ifBlank { "Corrigé officiel validé par Pr. SBAI Mohammed." },
                    points = newPointsText.toDoubleOrNull() ?: 5.0
                  )
                )
                newPrompt = ""
                newExplanation = ""
                newCorrectShortAnswer = ""
              }
            },
            enabled = newPrompt.isNotBlank(),
            modifier = Modifier.align(Alignment.End)
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Ajouter la question")
          }
        }
      }

      // Actions Bottom
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(
          onClick = onCancel,
          modifier = Modifier.weight(1f)
        ) {
          Text("Annuler")
        }

        Button(
          onClick = {
            if (quizTitle.isNotBlank() && questionsBuilder.isNotEmpty()) {
              val created = CustomQuiz(
                id = "quiz_${System.currentTimeMillis()}",
                title = quizTitle.trim(),
                subject = subjectType,
                targetClass = targetClass.trim(),
                durationMinutes = durationMinutesText.toIntOrNull() ?: 25,
                questions = questionsBuilder.toList()
              )
              onSaveQuiz(created)
            }
          },
          enabled = quizTitle.isNotBlank() && questionsBuilder.isNotEmpty(),
          modifier = Modifier.weight(1.5f).testTag("btn_publish_quiz")
        ) {
          Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Publier & Attribuer")
        }
      }
    }
  }
}
