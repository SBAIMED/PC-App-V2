package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Chapter
import com.example.data.CurriculumData
import com.example.data.SubjectType
import com.example.data.SimulationType
import com.example.data.repository.AppLocalRepository
import kotlinx.coroutines.launch
import com.example.ui.components.MathFormattedText
import com.example.ui.components.MathJaxFormulaCardList
import com.example.ui.simulations.CircuitRCSimulation
import com.example.ui.simulations.OndesSimulation
import com.example.ui.simulations.RadioactiveSimulation
import com.example.ui.simulations.TitrageSimulation

@Composable
fun CoursesScreen(
  initialSubject: SubjectType = SubjectType.PHYSIQUE,
  onNavigateToExercisesForChapter: (String) -> Unit = {},
  onOpenDashboard: () -> Unit = {}
) {
  val context = LocalContext.current
  val repository = remember { AppLocalRepository.getInstance(context) }
  val coroutineScope = rememberCoroutineScope()
  val allProgressList by repository.allChapterProgress.collectAsStateWithLifecycle(initialValue = emptyList())
  val progressMap = remember(allProgressList) { allProgressList.associateBy { it.chapterId } }

  var selectedSubject by remember(initialSubject) { mutableStateOf(initialSubject) }
  var selectedUnitFilter by remember { mutableStateOf("Tous") }
  var searchQuery by remember { mutableStateOf("") }
  var expandedChapterId by remember(selectedSubject) {
    mutableStateOf<String?>(if (selectedSubject == SubjectType.PHYSIQUE) "P1" else "C1")
  }

  // Strict Chronological Sorting Helper (P1..P16, then C1..C10)
  fun chapterChronologicalOrder(id: String): Int {
    val prefix = id.take(1)
    val number = id.drop(1).toIntOrNull() ?: 0
    return if (prefix == "P") number else 100 + number
  }

  // Helper for matching unit filters accurately
  fun matchesUnitFilter(chapter: Chapter, filter: String): Boolean {
    if (filter.startsWith("Tous")) return true
    return when {
      filter.contains("Ondes") -> chapter.id in listOf("P1", "P2", "P3")
      filter.contains("Nucléaire") -> chapter.id in listOf("P4", "P5")
      filter.contains("Électricité") -> chapter.id in listOf("P6", "P7", "P8", "P9")
      filter.contains("Mécanique") -> chapter.id in listOf("P10", "P11", "P12", "P13", "P14", "P15", "P16")
      filter.contains("Cinétique") -> chapter.id in listOf("C1", "C2")
      filter.contains("Équilibre") -> chapter.id in listOf("C3", "C4", "C5")
      filter.contains("Piles") -> chapter.id in listOf("C6", "C7")
      filter.contains("Organique") -> chapter.id in listOf("C8", "C9", "C10")
      else -> chapter.unit.contains(filter, ignoreCase = true)
    }
  }

  val sortedChapters = remember(selectedSubject, selectedUnitFilter, searchQuery) {
    var list = CurriculumData.chapters
      .filter { it.subject == selectedSubject }
      .sortedBy { chapterChronologicalOrder(it.id) }

    if (selectedUnitFilter != "Tous") {
      list = list.filter { matchesUnitFilter(it, selectedUnitFilter) }
    }

    if (searchQuery.isNotBlank()) {
      val q = searchQuery.trim().lowercase()
      list = list.filter {
        it.title.lowercase().contains(q) ||
        it.id.lowercase().contains(q) ||
        it.unit.lowercase().contains(q) ||
        it.summary.lowercase().contains(q) ||
        it.keyFormulas.any { f -> f.lowercase().contains(q) }
      }
    }
    list
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("courses_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Quick Dashboard Access Card
    item {
      ElevatedCard(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onOpenDashboard() }
          .testTag("courses_quick_dashboard_banner"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
          containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .background(MaterialTheme.colorScheme.tertiaryContainer, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.Dashboard,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.tertiary,
              modifier = Modifier.size(22.dp)
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "Mon Suivi & Rappels d'Étude",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
            Text(
              "76% complété • 17.75/20 • J-48 Bac 2026",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          FilledTonalButton(
            onClick = onOpenDashboard,
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text("Voir", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
          }
        }
      }
    }

    // Search bar for courses
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("courses_search_input"),
        placeholder = { Text("Rechercher un chapitre, formule, notion (ex: Newton, RC, titrage)...", fontSize = 13.sp) },
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "Effacer")
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surface
        )
      )
    }

    // BOUTONS DISTINCTS SÉPARÉS : PHYSIQUE À PART & CHIMIE À PART
    item {
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            "Choix de la Matière (Programmes Séparés) :",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Bouton 1 : PHYSIQUE (P1 à P16)
            Button(
              onClick = {
                selectedSubject = SubjectType.PHYSIQUE
                selectedUnitFilter = "Tous"
                expandedChapterId = "P1"
              },
              modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .testTag("btn_select_physique"),
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedSubject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (selectedSubject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
              ),
              elevation = ButtonDefaults.buttonElevation(defaultElevation = if (selectedSubject == SubjectType.PHYSIQUE) 4.dp else 0.dp)
            ) {
              Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Column(horizontalAlignment = Alignment.Start) {
                Text("Physique", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("16 Chapitres (P1 à P16)", fontSize = 10.sp)
              }
            }

            // Bouton 2 : CHIMIE (C1 à C9)
            Button(
              onClick = {
                selectedSubject = SubjectType.CHIMIE
                selectedUnitFilter = "Tous"
                expandedChapterId = "C1"
              },
              modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .testTag("btn_select_chimie"),
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedSubject == SubjectType.CHIMIE) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (selectedSubject == SubjectType.CHIMIE) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurfaceVariant
              ),
              elevation = ButtonDefaults.buttonElevation(defaultElevation = if (selectedSubject == SubjectType.CHIMIE) 4.dp else 0.dp)
            ) {
              Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Column(horizontalAlignment = Alignment.Start) {
                Text("Chimie", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("10 Chapitres (C1 à C10)", fontSize = 10.sp)
              }
            }
          }

          // Filtres d'unités pédagogiques officielles
          val unitOptions = if (selectedSubject == SubjectType.PHYSIQUE) {
            listOf("Tous", "Ondes (P1-P3)", "Nucléaire (P4-P5)", "Électricité (P6-P9)", "Mécanique (P10-P16)")
          } else {
            listOf("Tous", "Cinétique (C1-C2)", "Équilibre & pH (C3-C5)", "Piles & Électrolyse (C6-C7)", "Organique & Contrôle (C8-C10)")
          }

          LazyRow(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("courses_unit_filter_row"),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
          ) {
            items(unitOptions) { unitOpt ->
              val isSelected = selectedUnitFilter == unitOpt
              FilterChip(
                selected = isSelected,
                onClick = { selectedUnitFilter = unitOpt },
                label = {
                  Text(
                    unitOpt,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                  )
                },
                leadingIcon = if (isSelected) {
                  { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                } else null,
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = if (selectedSubject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                  selectedLabelColor = if (selectedSubject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                )
              )
            }
          }
        }
      }
    }

    // List of Chapters
    items(sortedChapters, key = { it.id }) { chapter ->
      val progress = progressMap[chapter.id]
      val isCompleted = progress?.isCompleted == true
      val isBookmarked = progress?.isBookmarked == true
      val savedNotes = progress?.notes ?: ""
      ChapterCard(
        chapter = chapter,
        isExpanded = expandedChapterId == chapter.id,
        isCompleted = isCompleted,
        isBookmarked = isBookmarked,
        savedNotes = savedNotes,
        onToggleExpand = {
          expandedChapterId = if (expandedChapterId == chapter.id) null else chapter.id
        },
        onToggleComplete = {
          coroutineScope.launch { repository.setChapterCompletion(chapter.id, !isCompleted) }
        },
        onToggleBookmark = {
          coroutineScope.launch { repository.toggleChapterBookmark(chapter.id, isBookmarked) }
        },
        onSaveNotes = { newNotes ->
          coroutineScope.launch { repository.saveChapterNotes(chapter.id, newNotes) }
        },
        onGoToExercises = { onNavigateToExercisesForChapter(chapter.id) }
      )
    }
  }
}

@Composable
fun ChapterCard(
  chapter: Chapter,
  isExpanded: Boolean,
  isCompleted: Boolean,
  isBookmarked: Boolean,
  savedNotes: String,
  onToggleExpand: () -> Unit,
  onToggleComplete: () -> Unit,
  onToggleBookmark: () -> Unit,
  onSaveNotes: (String) -> Unit,
  onGoToExercises: () -> Unit
) {
  val isPhysics = chapter.subject == SubjectType.PHYSIQUE
  var notesText by remember(savedNotes) { mutableStateOf(savedNotes) }
  var isEditingNotes by remember { mutableStateOf(false) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("chapter_card_${chapter.id}"),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    shape = RoundedCornerShape(16.dp),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onToggleExpand() },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Surface(
              color = if (isPhysics) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                chapter.id,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isPhysics) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
            Text(
              chapter.unit,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Medium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Spacer(modifier = Modifier.height(4.dp))
          MathFormattedText(
            text = chapter.title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            chapter.level,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Row(
            modifier = Modifier.padding(top = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            FilterChip(
              selected = isCompleted,
              onClick = onToggleComplete,
              label = {
                Text(
                  if (isCompleted) "✓ Chapitre Assimilé" else "Marquer comme assimilé",
                  fontSize = 11.sp,
                  fontWeight = if (isCompleted) FontWeight.Bold else FontWeight.Normal
                )
              },
              leadingIcon = if (isCompleted) {
                { Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp), tint = com.example.ui.theme.ScienceGreen) }
              } else null,
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = com.example.ui.theme.ScienceGreen.copy(alpha = 0.15f),
                selectedLabelColor = com.example.ui.theme.ScienceGreen
              ),
              modifier = Modifier.testTag("chip_complete_${chapter.id}")
            )
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onToggleBookmark,
            modifier = Modifier.testTag("btn_bookmark_${chapter.id}")
          ) {
            Icon(
              if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = if (isBookmarked) "Retirer des signets" else "Ajouter aux signets",
              tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          IconButton(onClick = onToggleExpand) {
            Icon(
              if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
              contentDescription = if (isExpanded) "Réduire" else "Dérouler"
            )
          }
        }
      }

      AnimatedVisibility(visible = isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Problématique du chapitre
          if (chapter.problematic.isNotBlank()) {
            Surface(
              color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Icon(Icons.Default.HelpOutline, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                Column {
                  Text("Problématique d'accroche :", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                  MathFormattedText(chapter.problematic, style = MaterialTheme.typography.bodySmall)
                }
              }
            }
          }

          // Mots-clés
          if (chapter.keywords.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              items(chapter.keywords) { kw ->
                Surface(
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  shape = RoundedCornerShape(6.dp)
                ) {
                  Text(
                    "#$kw",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }
          }

          // Contenu du cours & sections détaillées
          if (chapter.contentSections.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                "Contenu du cours officiel :",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              chapter.contentSections.forEach { section ->
                Surface(
                  color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  MathFormattedText(
                    text = section,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(10.dp)
                  )
                }
              }
            }
          } else {
            // Résumé fallback
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              shape = RoundedCornerShape(12.dp)
            ) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                  "Résumé du cours & compétences exigibles :",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
                MathFormattedText(
                  text = chapter.summary,
                  style = MaterialTheme.typography.bodyMedium
                )
              }
            }
          }

          // Lois et Formules à retenir (MathJax LaTeX)
          if (chapter.keyFormulas.isNotEmpty()) {
            MathJaxFormulaCardList(
              title = "Lois et formules à retenir (MathJax) :",
              formulas = chapter.keyFormulas
            )
          }

          // Activités expérimentales du chapitre
          if (chapter.activities.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.Biotech, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                Text(
                  "Activités du chapitre :",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.secondary
                )
              }
              chapter.activities.forEach { act ->
                Surface(
                  color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  MathFormattedText(
                    text = act,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(8.dp)
                  )
                }
              }
            }
          }

          // Applications / Exercices types
          if (chapter.application.isNotBlank()) {
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Applications & Exercices types :", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                MathFormattedText(chapter.application, style = MaterialTheme.typography.bodySmall)
              }
            }
          }

          // Graphe ou figure expérimentale du programme officiel
          if (chapter.chartType != com.example.data.ScientificChartType.NONE) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.ShowChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Text(
                  "Graphe et figure expérimentale officielle :",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              com.example.ui.components.ScientificChartViewer(
                chartType = chapter.chartType,
                title = chapter.chartTitle,
                exploitationGuide = chapter.chartExploitation
              )
            }
          }

          // Simulation interactive intégrée si disponible
          if (chapter.simulationType != SimulationType.NONE) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.Science, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Text(
                  chapter.simulationTitle ?: "Expérience interactive du programme",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              when (chapter.simulationType) {
                SimulationType.CIRCUIT_RC -> CircuitRCSimulation()
                SimulationType.TITRAGE_ACIDO_BASIQUE -> TitrageSimulation()
                SimulationType.ONDES_PROGRESSIVES -> OndesSimulation()
                SimulationType.DECROISSANCE_RADIOACTIVE -> RadioactiveSimulation()
                SimulationType.NONE -> Unit
              }
            }
          }

          // Section Notes Personnelles (Persistées en base SQLite / Room)
          Card(
            modifier = Modifier.fillMaxWidth().testTag("notes_card_${chapter.id}"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
            shape = RoundedCornerShape(12.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Icon(Icons.Default.EditNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                  Text("Mes notes de révision (Base Room)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                if (!isEditingNotes && savedNotes.isNotBlank()) {
                  TextButton(onClick = { isEditingNotes = true }) {
                    Text("Modifier", fontSize = 11.sp)
                  }
                }
              }

              if (isEditingNotes || savedNotes.isBlank()) {
                OutlinedTextField(
                  value = notesText,
                  onValueChange = { notesText = it },
                  placeholder = { Text("Écrivez vos remarques, pièges d'examen ou formules à retenir...") },
                  modifier = Modifier.fillMaxWidth().testTag("input_notes_${chapter.id}"),
                  minLines = 2,
                  maxLines = 4
                )
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                  Button(
                    onClick = {
                      onSaveNotes(notesText)
                      isEditingNotes = false
                    },
                    modifier = Modifier.testTag("btn_save_notes_${chapter.id}")
                  ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Enregistrer en BDD", fontSize = 12.sp)
                  }
                }
              } else {
                Text(
                  savedNotes,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }

          // Bouton d'accès aux exercices
          Button(
            onClick = onGoToExercises,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("btn_exercises_for_${chapter.id}"),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
          ) {
            Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Consulter les exercices d'application corrigés")
          }
        }
      }
    }
  }
}
