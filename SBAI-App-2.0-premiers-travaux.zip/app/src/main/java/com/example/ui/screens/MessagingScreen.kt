package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CurriculumData
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.MessageItem
import com.example.data.UserRole
import com.example.data.repository.AppLocalRepository
import kotlinx.coroutines.launch

@Composable
fun MessagingScreen(
  currentUserRole: UserRole = UserRole.ELEVE
) {
  val context = LocalContext.current
  val repository = remember { AppLocalRepository.getInstance(context) }
  val coroutineScope = rememberCoroutineScope()

  var activeChannel by remember { mutableStateOf("Tous") }
  val dbMessages by repository.getMessagesByChannel(activeChannel).collectAsStateWithLifecycle(initialValue = emptyList())
  var inputMessageText by remember { mutableStateOf("") }

  // Map Room ChatMessageEntity to MessageItem for rendering
  val displayMessages = remember(dbMessages) {
    if (dbMessages.isNotEmpty()) {
      dbMessages.map { entity ->
        MessageItem(
          id = entity.id,
          senderName = entity.senderName,
          isTeacher = entity.isTeacher,
          channel = entity.channel,
          message = entity.message,
          timestamp = entity.timestampFormatted
        )
      }
    } else {
      if (activeChannel == "Tous") CurriculumData.initialMessages
      else CurriculumData.initialMessages.filter { it.channel.equals(activeChannel, ignoreCase = true) }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .testTag("messaging_screen")
  ) {
    // Top channel tabs
    Surface(
      color = MaterialTheme.colorScheme.surface,
      shadowElevation = 2.dp
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("Tous", "Annonces", "Q&A Pr. SBAI").forEach { channel ->
          FilterChip(
            selected = activeChannel == channel,
            onClick = { activeChannel = channel },
            label = { Text(channel) },
            leadingIcon = {
              Icon(
                if (channel == "Annonces") Icons.Default.Campaign else Icons.Default.Forum,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
            }
          )
        }
      }
    }

    // Messages list
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(vertical = 12.dp)
    ) {
      items(displayMessages, key = { it.id }) { msg ->
        val isSenderTeacher = msg.isTeacher
        val myName = remember { com.example.data.SessionManager.getInstance(context).userName }
        val isMe = (currentUserRole == UserRole.PROFESSEUR && isSenderTeacher) ||
            (currentUserRole == UserRole.ELEVE && !isSenderTeacher && (msg.senderName == myName || msg.senderName == "Moi"))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
        ) {
          if (!isMe) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .background(
                  if (isSenderTeacher) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                  CircleShape
                ),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                if (isSenderTeacher) Icons.Default.School else Icons.Default.Person,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
          }

          Surface(
            color = if (isMe) MaterialTheme.colorScheme.primaryContainer
            else if (isSenderTeacher) MaterialTheme.colorScheme.surfaceVariant
            else MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.widthIn(max = 280.dp),
            shadowElevation = 1.dp
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  msg.senderName,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = if (isSenderTeacher) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                )
                Text(
                  msg.timestamp,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
              }

              Text(
                msg.message,
                style = MaterialTheme.typography.bodyMedium
              )
            }
          }
        }
      }
    }

    // Input bar
    Surface(
      color = MaterialTheme.colorScheme.surface,
      shadowElevation = 8.dp
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
          value = inputMessageText,
          onValueChange = { inputMessageText = it },
          placeholder = {
            Text(if (currentUserRole == UserRole.PROFESSEUR) "Écrire une consigne ou répondre..." else "Poser une question à Pr. SBAI...")
          },
          modifier = Modifier
            .weight(1f)
            .testTag("chat_input_field"),
          maxLines = 3,
          shape = RoundedCornerShape(20.dp)
        )

        IconButton(
          onClick = {
            if (inputMessageText.isNotBlank()) {
              val text = inputMessageText.trim()
              val currentStudent = com.example.data.SessionManager.getInstance(context).userName.ifBlank { "Élève 2BAC" }
              val sender = if (currentUserRole == UserRole.PROFESSEUR) CurriculumData.teacherName else currentStudent
              val isTeacher = currentUserRole == UserRole.PROFESSEUR
              val ch = if (activeChannel != "Tous") activeChannel else (if (isTeacher) "Annonces" else "Q&A Pr. SBAI")
              inputMessageText = ""
              coroutineScope.launch {
                repository.sendChatMessage(
                  senderName = sender,
                  message = text,
                  channel = ch,
                  isTeacher = isTeacher
                )
              }
            }
          },
          enabled = inputMessageText.isNotBlank(),
          modifier = Modifier
            .size(44.dp)
            .background(
              if (inputMessageText.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
              CircleShape
            )
            .testTag("chat_send_button")
        ) {
          Icon(
            Icons.Default.Send,
            contentDescription = "Envoyer",
            tint = if (inputMessageText.isNotBlank()) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
