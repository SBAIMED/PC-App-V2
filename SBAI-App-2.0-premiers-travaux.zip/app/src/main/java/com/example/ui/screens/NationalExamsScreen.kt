package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.CurriculumData
import com.example.data.NationalExam
import com.example.data.SessionManager
import com.example.ui.components.MathFormattedText
import com.example.ui.theme.ScienceGreen
import kotlinx.coroutines.delay

@Composable
fun NationalExamsScreen() {
  val context = LocalContext.current
  val sessionManager = remember { SessionManager.getInstance(context) }

  var selectedYear by remember { mutableStateOf<Int?>(null) }
  var selectedSession by remember { mutableStateOf("Tous") }
  var expandedExamId by remember { mutableStateOf<String?>("bac_2026_normale") }
  var activeSimulationExam by remember { mutableStateOf<NationalExam?>(null) }
  var refreshTrigger by remember { mutableIntStateOf(0) }

  val years = listOf(2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015)

  val filteredExams = remember(selectedYear, selectedSession) {
    var list = CurriculumData.nationalExams
    if (selectedYear != null) {
      list = list.filter { it.year == selectedYear }
    }
    if (selectedSession != "Tous") {
      list = list.filter { it.session.equals(selectedSession, ignoreCase = true) }
    }
    list
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("national_exams_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Banner
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(16.dp)
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Icon(
              Icons.Default.WorkspacePremium,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(36.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(
                "Volet 4 : Examens Nationaux (2015 - 2026)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
              Text(
                "Baccalauréat marocain Sciences Physiques, SVT & Sciences Maths",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = ScienceGreen.copy(alpha = 0.15f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(Icons.Default.CloudDone, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(14.dp))
                Text(
                  "100% Disponible Hors-Ligne",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = ScienceGreen
                )
              }
            }
            Text(
              "Session Normale & Rattrapage",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
          }
        }
      }
    }

    // Year horizontal selector
    item {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Année du Baccalauréat (2015 - 2026) :", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          item {
            FilterChip(
              selected = selectedYear == null,
              onClick = { selectedYear = null },
              label = { Text("Toutes") }
            )
          }
          items(years) { yr ->
            FilterChip(
              selected = selectedYear == yr,
              onClick = { selectedYear = yr },
              label = {
                Text(
                  if (yr == 2026) "2026 (Modèle)" else yr.toString(),
                  fontWeight = if (yr >= 2025) FontWeight.Bold else FontWeight.Normal
                )
              }
            )
          }
        }
      }
    }

    // Session filter
    item {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Tous", "Normale", "Rattrapage").forEach { sess ->
          FilterChip(
            selected = selectedSession == sess,
            onClick = { selectedSession = sess },
            label = { Text(sess) }
          )
        }
      }
    }

    // List of Exams
    items(filteredExams, key = { it.id }) { exam ->
      val isExpanded = expandedExamId == exam.id

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("exam_card_${exam.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { expandedExamId = if (isExpanded) null else exam.id },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Badge(containerColor = MaterialTheme.colorScheme.primary) {
                  Text(
                    "${exam.year} • ${exam.session}",
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                  )
                }
                Surface(
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  shape = RoundedCornerShape(6.dp)
                ) {
                  Text(
                    exam.branch,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(4.dp))
              Text(
                exam.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                "Durée : ${exam.durationHours.toInt()}h | Coefficient : ${exam.coefficient} | Barème : 20/20",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )

              // Recorded grade if any
              val pastGrade = remember(refreshTrigger, exam.id) { sessionManager.getExamGrade(exam.id) }
              if (pastGrade != null) {
                val mentionText = when {
                  pastGrade >= 16.0 -> "Très Bien"
                  pastGrade >= 14.0 -> "Bien"
                  pastGrade >= 12.0 -> "Assez Bien"
                  pastGrade >= 10.0 -> "Admis"
                  else -> "À perfectionner"
                }
                Surface(
                  color = ScienceGreen.copy(alpha = 0.15f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.padding(top = 4.dp)
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(16.dp))
                    Text(
                      "Simulation effectuée : ${"%.2f".format(pastGrade)} / 20 ($mentionText)",
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.Bold,
                      color = ScienceGreen
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(4.dp))
              FilledTonalButton(
                onClick = { activeSimulationExam = exam },
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("btn_simulate_exam_${exam.id}")
              ) {
                Icon(Icons.Default.Timer, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Passer en condition réelle (Chrono)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }

            IconButton(onClick = { expandedExamId = if (isExpanded) null else exam.id }) {
              Icon(
                if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null
              )
            }
          }

          AnimatedVisibility(visible = isExpanded) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
              verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
              exam.sections.forEach { section ->
                Surface(
                  color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Text(
                        section.domain,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                      )
                      Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(6.dp)
                      ) {
                        Text(
                          "${section.points} pts",
                          style = MaterialTheme.typography.labelSmall,
                          fontWeight = FontWeight.Bold,
                          color = MaterialTheme.colorScheme.onPrimaryContainer,
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }

                    MathFormattedText(section.title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))

                    Text("Extrait du sujet :", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    MathFormattedText(section.statement, style = MaterialTheme.typography.bodySmall)

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    Text(
                      "Éléments de réponse officiels & barème :",
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.Bold,
                      color = ScienceGreen
                    )
                    MathFormattedText(
                      text = section.detailedCorrection,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }

              // Teacher annotation
              Surface(
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Icon(Icons.Default.Verified, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                  Text(
                    "Sujet vérifié conforme au cadre de référence officiel marocain par Pr. SBAI Mohammed.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  // Active Simulation Dialog
  activeSimulationExam?.let { exam ->
    NationalExamSimulationDialog(
      exam = exam,
      onDismiss = { activeSimulationExam = null },
      onSaveGrade = { grade ->
        sessionManager.recordExamGrade(exam.id, grade)
        refreshTrigger++
        activeSimulationExam = null
      }
    )
  }
}

/**
 * Full-featured real-time exam simulation modal with countdown timer,
 * official Moroccan rubric scoring, and grade recording.
 */
@Composable
fun NationalExamSimulationDialog(
  exam: NationalExam,
  onDismiss: () -> Unit,
  onSaveGrade: (Double) -> Unit
) {
  var remainingSeconds by remember { mutableIntStateOf(10800) } // 3 hours (official Moroccan Bac PC duration)
  var isTimerRunning by remember { mutableStateOf(true) }
  val sectionScores = remember {
    mutableStateMapOf<String, Float>().apply {
      exam.sections.forEach { put(it.title, (it.points * 0.8).toFloat().coerceAtLeast(0f)) }
    }
  }
  var showCorrectionKey by remember { mutableStateOf(false) }

  // Countdown timer coroutine
  LaunchedEffect(isTimerRunning) {
    while (isTimerRunning && remainingSeconds > 0) {
      delay(1000L)
      remainingSeconds--
    }
  }

  val hours = remainingSeconds / 3600
  val minutes = (remainingSeconds % 3600) / 60
  val seconds = remainingSeconds % 60
  val formattedTime = "%02d:%02d:%02d".format(hours, minutes, seconds)

  val totalScore = sectionScores.values.sum().toDouble()
  val mention = when {
    totalScore >= 16.0 -> "Très Bien (>= 16)" to ScienceGreen
    totalScore >= 14.0 -> "Bien (>= 14)" to MaterialTheme.colorScheme.primary
    totalScore >= 12.0 -> "Assez Bien (>= 12)" to MaterialTheme.colorScheme.secondary
    totalScore >= 10.0 -> "Admis (>= 10)" to MaterialTheme.colorScheme.tertiary
    else -> "À perfectionner (< 10)" to MaterialTheme.colorScheme.error
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.96f)
        .fillMaxHeight(0.94f),
      shape = RoundedCornerShape(20.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp)
      ) {
        // Dialog Top Bar: Title & Close
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "Épreuve Blanche Chronométrée",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
            Text(
              "${exam.title} • Barème 20/20",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Fermer")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Timer HUD Banner
        Card(
          colors = CardDefaults.cardColors(
            containerColor = if (remainingSeconds < 900) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.primaryContainer
          ),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                Icons.Default.Timer,
                contentDescription = null,
                tint = if (remainingSeconds < 900) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(24.dp)
              )
              Column {
                Text(
                  "Temps Restant :",
                  style = MaterialTheme.typography.labelSmall,
                  color = if (remainingSeconds < 900) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                  formattedTime,
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = if (remainingSeconds < 900) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer
                )
              }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              FilledTonalIconButton(
                onClick = { isTimerRunning = !isTimerRunning },
                shape = CircleShape
              ) {
                Icon(
                  if (isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                  contentDescription = if (isTimerRunning) "Pause" else "Reprendre"
                )
              }

              OutlinedButton(
                onClick = { remainingSeconds = 10800 },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text("Reset", fontSize = 11.sp)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Toggle Key toggle button
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "Auto-évaluation par domaine (Cadre officiel) :",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
          )
          FilterChip(
            selected = showCorrectionKey,
            onClick = { showCorrectionKey = !showCorrectionKey },
            label = { Text("Voir le corrigé", fontSize = 11.sp) },
            leadingIcon = if (showCorrectionKey) {
              { Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp)) }
            } else {
              { Icon(Icons.Default.VisibilityOff, contentDescription = null, modifier = Modifier.size(14.dp)) }
            }
          )
        }

        // Section list with scoring
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(vertical = 8.dp)
        ) {
          items(exam.sections) { sec ->
            val curScore = sectionScores[sec.title] ?: 0f

            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    sec.domain,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                  )
                  Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text(
                      "Max : ${sec.points} pts",
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }

                MathFormattedText(sec.title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                MathFormattedText(sec.statement, style = MaterialTheme.typography.bodySmall, maxLines = if (showCorrectionKey) Int.MAX_VALUE else 3)

                if (showCorrectionKey) {
                  Surface(
                    color = ScienceGreen.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                      Text("Éléments de réponse :", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = ScienceGreen)
                      MathFormattedText(sec.detailedCorrection, style = MaterialTheme.typography.bodySmall)
                    }
                  }
                }

                // Interactive Score Adjustment
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    "Ma note sur cette partie :",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                  )

                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    IconButton(
                      onClick = {
                        val newScore = (curScore - 0.25f).coerceAtLeast(0f)
                        sectionScores[sec.title] = newScore
                      },
                      modifier = Modifier.size(28.dp),
                      enabled = curScore > 0f
                    ) {
                      Icon(Icons.Default.Remove, contentDescription = "Diminuer", modifier = Modifier.size(16.dp))
                    }

                    Text(
                      text = "${"%.2f".format(curScore)} / ${sec.points}",
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.primary
                    )

                    IconButton(
                      onClick = {
                        val newScore = (curScore + 0.25f).coerceAtMost(sec.points.toFloat())
                        sectionScores[sec.title] = newScore
                      },
                      modifier = Modifier.size(28.dp),
                      enabled = curScore < sec.points.toFloat()
                    ) {
                      Icon(Icons.Default.Add, contentDescription = "Augmenter", modifier = Modifier.size(16.dp))
                    }
                  }
                }
              }
            }
          }
        }

        // Live Total Bar & Submit
        Surface(
          color = MaterialTheme.colorScheme.surfaceVariant,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                "Total : ${"%.2f".format(totalScore)} / 20.0",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                mention.first,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = mention.second
              )
            }

            Button(
              onClick = { onSaveGrade(totalScore) },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.testTag("btn_save_simulation_grade")
            ) {
              Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Valider la copie", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}
