package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val BluePrimaryLight = Color(0xFF1D4ED8) // Deep Royal Blue (Physics/Current)
val BlueOnPrimaryLight = Color(0xFFFFFFFF)
val BluePrimaryContainerLight = Color(0xFFDBEAFE)
val BlueOnPrimaryContainerLight = Color(0xFF1E3A8A)

val CyanSecondaryLight = Color(0xFF0284C7) // Electric Cyan (Chemistry solution/waves)
val CyanOnSecondaryLight = Color(0xFFFFFFFF)
val CyanSecondaryContainerLight = Color(0xFFE0F2FE)
val CyanOnSecondaryContainerLight = Color(0xFF0369A1)

val AmberTertiaryLight = Color(0xFFD97706) // Warm Amber (Energy/Quanta)
val AmberOnTertiaryLight = Color(0xFFFFFFFF)
val AmberTertiaryContainerLight = Color(0xFFFEF3C7)
val AmberOnTertiaryContainerLight = Color(0xFF92400E)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnBackgroundLight = Color(0xFF0F172A)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Colors
val BluePrimaryDark = Color(0xFF60A5FA)
val BlueOnPrimaryDark = Color(0xFF0F172A)
val BluePrimaryContainerDark = Color(0xFF1E3A8A)
val BlueOnPrimaryContainerDark = Color(0xFFDBEAFE)

val CyanSecondaryDark = Color(0xFF38BDF8)
val CyanOnSecondaryDark = Color(0xFF0F172A)
val CyanSecondaryContainerDark = Color(0xFF075985)
val CyanOnSecondaryContainerDark = Color(0xFFE0F2FE)

val AmberTertiaryDark = Color(0xFFFBBF24)
val AmberOnTertiaryDark = Color(0xFF78350F)
val AmberTertiaryContainerDark = Color(0xFF78350F)
val AmberOnTertiaryContainerDark = Color(0xFFFEF3C7)

val BackgroundDark = Color(0xFF0B0F19)
val SurfaceDark = Color(0xFF111827)
val SurfaceVariantDark = Color(0xFF1F2937)
val OnBackgroundDark = Color(0xFFF1F5F9)
val OnSurfaceDark = Color(0xFFF1F5F9)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)

// Accent badges
val ScienceGreen = Color(0xFF10B981)
val ScienceRed = Color(0xFFEF4444)
val SciencePurple = Color(0xFF8B5CF6)
