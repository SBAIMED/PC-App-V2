package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurriculumData
import com.example.data.Exercise
import com.example.data.SubjectType
import com.example.ui.components.MathFormattedText
import com.example.ui.components.MathJaxRichText
import com.example.ui.components.MathJaxSolutionSteps
import com.example.ui.theme.ScienceGreen

@Composable
fun ExercisesScreen(
  initialSubject: SubjectType? = null,
  initialChapterFilter: String? = null
) {
  var selectedSubject by remember(initialSubject, initialChapterFilter) {
    mutableStateOf(
      initialSubject ?: if (initialChapterFilter != null && initialChapterFilter.startsWith("C")) SubjectType.CHIMIE else SubjectType.PHYSIQUE
    )
  }
  var selectedChapterFilter by remember(initialChapterFilter) { mutableStateOf(initialChapterFilter) }
  var searchQuery by remember { mutableStateOf("") }
  var visibleSolutions by remember { mutableStateOf(setOf<String>()) }
  var visibleHints by remember { mutableStateOf(setOf<String>()) }

  // Strict Chronological Sorting Helper (P1..P16, then C1..C10)
  fun exerciseChronologicalOrder(chapterId: String): Int {
    val prefix = chapterId.take(1)
    val number = chapterId.drop(1).toIntOrNull() ?: 0
    return if (prefix == "P") number else 100 + number
  }

  val sortedExercises = remember(selectedSubject, selectedChapterFilter, searchQuery) {
    var list = CurriculumData.exercises
      .filter { it.subject == selectedSubject }
      .sortedBy { exerciseChronologicalOrder(it.chapterId) }

    if (selectedChapterFilter != null && selectedChapterFilter != "Tous") {
      list = list.filter { it.chapterId == selectedChapterFilter }
    }

    if (searchQuery.isNotBlank()) {
      val q = searchQuery.trim().lowercase()
      list = list.filter {
        it.title.lowercase().contains(q) ||
        it.chapterId.lowercase().contains(q) ||
        it.statement.lowercase().contains(q) ||
        it.solutionSteps.any { step -> step.lowercase().contains(q) }
      }
    }
    list
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("exercises_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Banner
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        shape = RoundedCornerShape(16.dp)
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Icon(
            Icons.Default.EditNote,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(36.dp)
          )
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "Exercices d'Application & Annales",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSecondaryContainer
            )
            Text(
              "Classés dans l'ordre chronologique du programme marocain officiel (P1 à P16 & C1 à C10)",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
            )
          }
        }
      }
    }

    // Search Bar for Exercises
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("exercises_search_input"),
        placeholder = { Text("Rechercher un exercice (ex: RC, Newton, pH, P3, C5)...", fontSize = 13.sp) },
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "Effacer")
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surface
        )
      )
    }

    // BOUTONS DISTINCTS SÉPARÉS : PHYSIQUE (P1-P16) & CHIMIE (C1-C10)
    item {
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            "Choix de la Matière :",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Bouton 1 : PHYSIQUE (P1 à P16)
            Button(
              onClick = {
                selectedSubject = SubjectType.PHYSIQUE
                selectedChapterFilter = "Tous"
              },
              modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .testTag("btn_exercises_physique"),
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedSubject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (selectedSubject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
              ),
              elevation = ButtonDefaults.buttonElevation(defaultElevation = if (selectedSubject == SubjectType.PHYSIQUE) 4.dp else 0.dp)
            ) {
              Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Column(horizontalAlignment = Alignment.Start) {
                Text("Physique", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Ordre P1 à P16", fontSize = 10.sp)
              }
            }

            // Bouton 2 : CHIMIE (C1 à C9)
            Button(
              onClick = {
                selectedSubject = SubjectType.CHIMIE
                selectedChapterFilter = "Tous"
              },
              modifier = Modifier
                .weight(1f)
                .height(52.dp)
                .testTag("btn_exercises_chimie"),
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedSubject == SubjectType.CHIMIE) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (selectedSubject == SubjectType.CHIMIE) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurfaceVariant
              ),
              elevation = ButtonDefaults.buttonElevation(defaultElevation = if (selectedSubject == SubjectType.CHIMIE) 4.dp else 0.dp)
            ) {
              Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Column(horizontalAlignment = Alignment.Start) {
                Text("Chimie", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("10 Chapitres (C1 à C10)", fontSize = 10.sp)
              }
            }
          }

          // Chapitres chronologiques rapides
          val chapterChips = if (selectedSubject == SubjectType.PHYSIQUE) {
            listOf("Tous") + (1..16).map { "P$it" }
          } else {
            listOf("Tous") + (1..10).map { "C$it" }
          }

          androidx.compose.foundation.lazy.LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            items(chapterChips) { chId ->
              val isSelected = (selectedChapterFilter == chId) || (selectedChapterFilter == null && chId == "Tous")
              FilterChip(
                selected = isSelected,
                onClick = { selectedChapterFilter = chId },
                label = { Text(chId, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                leadingIcon = if (isSelected) {
                  { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                } else null
              )
            }
          }
        }
      }
    }

    // List of Exercises
    items(sortedExercises, key = { it.id }) { exercise ->
      val isSolutionVisible = visibleSolutions.contains(exercise.id)
      val areHintsVisible = visibleHints.contains(exercise.id)

      ExerciseCard(
        exercise = exercise,
        isSolutionVisible = isSolutionVisible,
        areHintsVisible = areHintsVisible,
        onToggleSolution = {
          visibleSolutions = if (isSolutionVisible) {
            visibleSolutions - exercise.id
          } else {
            visibleSolutions + exercise.id
          }
        },
        onToggleHints = {
          visibleHints = if (areHintsVisible) {
            visibleHints - exercise.id
          } else {
            visibleHints + exercise.id
          }
        }
      )
    }
  }
}

@Composable
fun ExerciseCard(
  exercise: Exercise,
  isSolutionVisible: Boolean,
  areHintsVisible: Boolean,
  onToggleSolution: () -> Unit,
  onToggleHints: () -> Unit
) {
  val isPhysics = exercise.subject == SubjectType.PHYSIQUE

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("exercise_card_${exercise.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Header row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = if (isPhysics) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            exercise.subject.label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (isPhysics) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }

        Surface(
          color = MaterialTheme.colorScheme.surfaceVariant,
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            "Exercice d'application",
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }
      }

      MathFormattedText(
        text = exercise.title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
      )

      // Statement box
      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            "Énoncé :",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          MathFormattedText(
            text = exercise.statement,
            style = MaterialTheme.typography.bodyMedium
          )
        }
      }

      // Graphe ou figure expérimentale exploitable pour l'exercice
      if (exercise.chartType != com.example.data.ScientificChartType.NONE) {
        com.example.ui.components.ScientificChartViewer(
          chartType = exercise.chartType,
          title = exercise.chartTitle,
          exploitationGuide = exercise.chartExploitation
        )
      }

      // Action row: Show Hints & Show Solution
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedButton(
          onClick = onToggleHints,
          modifier = Modifier.weight(1f).testTag("btn_hints_${exercise.id}")
        ) {
          Icon(
            Icons.Default.Lightbulb,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (areHintsVisible) "Masquer indices" else "Indices (${exercise.hints.size})")
        }

        Button(
          onClick = onToggleSolution,
          modifier = Modifier.weight(1.3f).testTag("btn_solution_${exercise.id}"),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isSolutionVisible) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
          )
        ) {
          Icon(
            if (isSolutionVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isSolutionVisible) "Masquer corrigé" else "Voir le corrigé")
        }
      }

      // Hints section
      AnimatedVisibility(visible = areHintsVisible) {
        Surface(
          color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              "Indices méthodologiques :",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.tertiary
            )
            exercise.hints.forEachIndexed { idx, hint ->
              MathFormattedText(
                text = "${idx + 1}. $hint",
                style = MaterialTheme.typography.bodySmall
              )
            }
          }
        }
      }

      // Hidden Solution Section
      AnimatedVisibility(visible = isSolutionVisible) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ScienceGreen.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(20.dp))
            Text(
              "Corrigé Détaillé Officiel Pas-à-Pas :",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = ScienceGreen
            )
          }

          // Unified high-performance single WebView for all solution steps and tips
          MathJaxSolutionSteps(
            steps = exercise.solutionSteps,
            tips = exercise.tips,
            fontSizeSp = 13
          )
        }
      }
    }
  }
}
