package com.example.ui.components

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.RenderProcessGoneDetail
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Javascript Interface for two-way communication between WebView MathJax and Compose.
 * Automatically communicates dynamic height back to Compose to prevent clipping or excessive space.
 */
class MathJaxJavascriptInterface(
  private val onHeightMeasured: (Int) -> Unit
) {
  @JavascriptInterface
  fun onHeightChanged(heightPx: Int) {
    Handler(Looper.getMainLooper()).post {
      onHeightMeasured(heightPx)
    }
  }
}

/**
 * Reusable Composable wrapper that renders a single LaTeX formula using MathJax v3 in a WebView.
 * Features:
 * - Offline vector SVG rendering via local bundled tex-svg.js
 * - Theme-aware styling (adapts dynamically to Light & Dark themes)
 * - Auto-resizing height with zero clipping
 * - Smooth fallback while rendering
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MathJaxView(
  formula: String,
  modifier: Modifier = Modifier,
  isDisplayMode: Boolean = true,
  fontSizeSp: Int = 16,
  textColor: Color = MaterialTheme.colorScheme.onSurface,
  backgroundColor: Color = Color.Transparent,
  centerFormula: Boolean = true
) {
  val density = LocalDensity.current
  var measuredHeightDp by remember { mutableStateOf<Int?>(null) }

  val hexColor = remember(textColor) {
    val argb = textColor.toArgb()
    String.format("#%06X", 0xFFFFFF and argb)
  }

  val cleanLatex = remember(formula) {
    formula.trim()
      .removePrefix("$$").removeSuffix("$$")
      .removePrefix("$").removeSuffix("$")
      .trim()
  }

  val htmlContent = remember(cleanLatex, hexColor, fontSizeSp, isDisplayMode, centerFormula) {
    val mathTag = if (isDisplayMode) "$$$cleanLatex$$$" else "$$cleanLatex$"
    val textAlign = if (centerFormula) "center" else "left"

    """
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <style>
        * {
          box-sizing: border-box;
          -webkit-user-select: none;
        }
        html, body {
          margin: 0;
          padding: 2px 4px;
          background-color: transparent;
          color: $hexColor;
          font-family: 'STIX Two Math', 'Latin Modern Math', 'Cambria Math', 'Times New Roman', serif;
          font-size: ${fontSizeSp}px;
          line-height: 1.4;
          width: 100%;
          overflow-x: auto;
          overflow-y: hidden;
        }
        #math-wrapper {
          width: 100%;
          text-align: $textAlign;
          padding: 4px 0;
        }
        mjx-container {
          color: $hexColor !important;
          outline: none !important;
          margin: 0 !important;
        }
        mjx-container svg {
          fill: $hexColor !important;
          stroke: $hexColor !important;
          max-width: 100% !important;
        }
      </style>
      <script>
        window.MathJax = {
          tex: {
            inlineMath: [['$', '$'], ['\\(', '\\)']],
            displayMath: [['$$', '$$'], ['\\[', '\\]']],
            processEscapes: true
          },
          svg: {
            fontCache: 'local',
            scale: 1.05
          },
          options: {
            enableMenu: false
          },
          startup: {
            typeset: true,
            ready: () => {
              MathJax.startup.defaultReady();
              MathJax.startup.promise.then(() => {
                reportHeight();
                setTimeout(reportHeight, 100);
                setTimeout(reportHeight, 300);
              });
            }
          }
        };

        function reportHeight() {
          if (window.AndroidInterface && window.AndroidInterface.onHeightChanged) {
            var container = document.getElementById('math-wrapper');
            var h = container ? container.scrollHeight : document.body.scrollHeight;
            window.AndroidInterface.onHeightChanged(h);
          }
        }
        window.addEventListener('resize', reportHeight);
      </script>
      <script type="text/javascript" id="MathJax-script" async
        src="file:///android_asset/mathjax/tex-svg.js">
      </script>
    </head>
    <body>
      <div id="math-wrapper">$mathTag</div>
    </body>
    </html>
    """.trimIndent()
  }

  val finalHeight = (measuredHeightDp ?: if (isDisplayMode) 52 else 38).coerceIn(36, 300)

  AndroidView(
    modifier = modifier
      .fillMaxWidth()
      .height(finalHeight.dp)
      .animateContentSize(),
    factory = { ctx ->
      WebView(ctx).apply {
        setBackgroundColor(AndroidColor.TRANSPARENT)
        settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = false
          allowFileAccess = true
          allowContentAccess = false
          setGeolocationEnabled(false)
          databaseEnabled = false
          blockNetworkLoads = true
          blockNetworkImage = true
          if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            safeBrowsingEnabled = false
          }
          cacheMode = WebSettings.LOAD_NO_CACHE
          loadWithOverviewMode = true
          useWideViewPort = false
          builtInZoomControls = false
          displayZoomControls = false
        }

        addJavascriptInterface(
          MathJaxJavascriptInterface { heightPx ->
            val heightDp = (heightPx / density.density).toInt()
            if (heightDp > 15) {
              measuredHeightDp = heightDp + 8
            }
          },
          "AndroidInterface"
        )

        webViewClient = object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            view?.setBackgroundColor(AndroidColor.TRANSPARENT)
          }
          override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {}
          override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            return true
          }
        }

        tag = htmlContent
        loadDataWithBaseURL("file:///android_asset/", htmlContent, "text/html", "UTF-8", null)
      }
    },
    update = { webView ->
      val currentTag = webView.tag as? String
      if (currentTag != htmlContent) {
        webView.tag = htmlContent
        webView.loadDataWithBaseURL("file:///android_asset/", htmlContent, "text/html", "UTF-8", null)
      }
    }
  )
}

/**
 * Renders an entire list of LaTeX formulas inside a single, unified MathJax WebView.
 * Perfect for chapter key formulas summaries without spawning multiple WebViews per card.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MathJaxFormulaList(
  formulas: List<String>,
  modifier: Modifier = Modifier,
  textColor: Color = MaterialTheme.colorScheme.onSurface,
  fontSizeSp: Int = 15
) {
  val density = LocalDensity.current
  var measuredHeightDp by remember { mutableStateOf<Int?>(null) }

  val hexColor = remember(textColor) {
    val argb = textColor.toArgb()
    String.format("#%06X", 0xFFFFFF and argb)
  }

  val combinedLatexHtml = remember(formulas, hexColor, fontSizeSp) {
    val bodyItems = formulas.joinToString("\n") { f ->
      val trimmed = f.trim()
      val math = when {
        trimmed.startsWith("$$") -> trimmed
        trimmed.startsWith("$") -> "$$$trimmed$$$"
        else -> "$$$trimmed$$$"
      }
      "<div class=\"formula-row\">$math</div>"
    }

    """
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <style>
        * {
          box-sizing: border-box;
          -webkit-user-select: none;
        }
        html, body {
          margin: 0;
          padding: 4px;
          background-color: transparent;
          color: $hexColor;
          font-family: 'STIX Two Math', 'Latin Modern Math', 'Cambria Math', 'Times New Roman', serif;
          font-size: ${fontSizeSp}px;
          line-height: 1.4;
          width: 100%;
          overflow-x: auto;
          overflow-y: hidden;
        }
        #formula-container {
          width: 100%;
        }
        .formula-row {
          padding: 8px 12px;
          margin-bottom: 8px;
          background: rgba(128, 128, 128, 0.08);
          border-radius: 8px;
          text-align: center;
        }
        mjx-container {
          color: $hexColor !important;
          outline: none !important;
          margin: 0 !important;
        }
        mjx-container svg {
          fill: $hexColor !important;
          stroke: $hexColor !important;
          max-width: 100% !important;
        }
      </style>
      <script>
        window.MathJax = {
          tex: {
            inlineMath: [['$', '$'], ['\\(', '\\)']],
            displayMath: [['$$', '$$'], ['\\[', '\\]']],
            processEscapes: true
          },
          svg: {
            fontCache: 'local',
            scale: 1.05
          },
          options: {
            enableMenu: false
          },
          startup: {
            typeset: true,
            ready: () => {
              MathJax.startup.defaultReady();
              MathJax.startup.promise.then(() => {
                reportHeight();
                setTimeout(reportHeight, 100);
                setTimeout(reportHeight, 350);
              });
            }
          }
        };

        function reportHeight() {
          if (window.AndroidInterface && window.AndroidInterface.onHeightChanged) {
            var container = document.getElementById('formula-container');
            var h = container ? container.scrollHeight : document.body.scrollHeight;
            window.AndroidInterface.onHeightChanged(h);
          }
        }
        window.addEventListener('resize', reportHeight);
      </script>
      <script type="text/javascript" id="MathJax-script" async
        src="file:///android_asset/mathjax/tex-svg.js">
      </script>
    </head>
    <body>
      <div id="formula-container">
        $bodyItems
      </div>
    </body>
    </html>
    """.trimIndent()
  }

  val defaultEstimatedHeight = (formulas.size * 56 + 18).coerceIn(60, 600)
  val finalHeight = (measuredHeightDp ?: defaultEstimatedHeight).coerceIn(50, 700)

  AndroidView(
    modifier = modifier
      .fillMaxWidth()
      .height(finalHeight.dp)
      .animateContentSize(),
    factory = { ctx ->
      WebView(ctx).apply {
        setBackgroundColor(AndroidColor.TRANSPARENT)
        settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = false
          allowFileAccess = true
          allowContentAccess = false
          setGeolocationEnabled(false)
          databaseEnabled = false
          blockNetworkLoads = true
          blockNetworkImage = true
          if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            safeBrowsingEnabled = false
          }
          cacheMode = WebSettings.LOAD_NO_CACHE
          loadWithOverviewMode = true
          useWideViewPort = false
          builtInZoomControls = false
          displayZoomControls = false
        }

        addJavascriptInterface(
          MathJaxJavascriptInterface { heightPx ->
            val heightDp = (heightPx / density.density).toInt()
            if (heightDp > 20) {
              measuredHeightDp = heightDp + 8
            }
          },
          "AndroidInterface"
        )

        webViewClient = object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            view?.setBackgroundColor(AndroidColor.TRANSPARENT)
          }
          override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {}
          override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            return true
          }
        }
        tag = combinedLatexHtml
        loadDataWithBaseURL("file:///android_asset/", combinedLatexHtml, "text/html", "UTF-8", null)
      }
    },
    update = { webView ->
      val currentTag = webView.tag as? String
      if (currentTag != combinedLatexHtml) {
        webView.tag = combinedLatexHtml
        webView.loadDataWithBaseURL("file:///android_asset/", combinedLatexHtml, "text/html", "UTF-8", null)
      }
    }
  )
}

/**
 * Reusable Composable that renders rich text with inline and display LaTeX math equations.
 * Designed for exercise statements, methodological hints, and step-by-step solution steps.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MathJaxRichText(
  text: String,
  modifier: Modifier = Modifier,
  fontSizeSp: Int = 14,
  textColor: Color = MaterialTheme.colorScheme.onSurface
) {
  val density = LocalDensity.current
  var measuredHeightDp by remember { mutableStateOf<Int?>(null) }

  val hexColor = remember(textColor) {
    val argb = textColor.toArgb()
    String.format("#%06X", 0xFFFFFF and argb)
  }

  val formattedHtml = remember(text, hexColor, fontSizeSp) {
    // Convert newlines to HTML <br/> while preserving math blocks
    val contentHtml = text
      .replace("&", "&amp;")
      .replace("<", "&lt;")
      .replace(">", "&gt;")
      .replace("\n", "<br/>")

    """
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <style>
        * {
          box-sizing: border-box;
          -webkit-user-select: text;
        }
        html, body {
          margin: 0;
          padding: 2px 4px;
          background-color: transparent;
          color: $hexColor;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          font-size: ${fontSizeSp}px;
          line-height: 1.5;
          width: 100%;
          overflow-x: auto;
          overflow-y: hidden;
        }
        #rich-content {
          width: 100%;
        }
        mjx-container {
          color: $hexColor !important;
          outline: none !important;
          margin: 2px 0 !important;
        }
        mjx-container svg {
          fill: $hexColor !important;
          stroke: $hexColor !important;
        }
      </style>
      <script>
        window.MathJax = {
          tex: {
            inlineMath: [['$', '$'], ['\\(', '\\)']],
            displayMath: [['$$', '$$'], ['\\[', '\\]']],
            processEscapes: true
          },
          svg: {
            fontCache: 'local',
            scale: 1.03
          },
          options: {
            enableMenu: false
          },
          startup: {
            typeset: true,
            ready: () => {
              MathJax.startup.defaultReady();
              MathJax.startup.promise.then(() => {
                reportHeight();
                setTimeout(reportHeight, 100);
                setTimeout(reportHeight, 300);
              });
            }
          }
        };

        function reportHeight() {
          if (window.AndroidInterface && window.AndroidInterface.onHeightChanged) {
            var container = document.getElementById('rich-content');
            var h = container ? container.scrollHeight : document.body.scrollHeight;
            window.AndroidInterface.onHeightChanged(h);
          }
        }
        window.addEventListener('resize', reportHeight);
      </script>
      <script type="text/javascript" id="MathJax-script" async
        src="file:///android_asset/mathjax/tex-svg.js">
      </script>
    </head>
    <body>
      <div id="rich-content">$contentHtml</div>
    </body>
    </html>
    """.trimIndent()
  }

  val lineCount = text.lines().size.coerceAtLeast(1)
  val defaultEstimatedHeight = (lineCount * 22 + 20).coerceIn(36, 500)
  val finalHeight = (measuredHeightDp ?: defaultEstimatedHeight).coerceIn(30, 600)

  AndroidView(
    modifier = modifier
      .fillMaxWidth()
      .height(finalHeight.dp)
      .animateContentSize(),
    factory = { ctx ->
      WebView(ctx).apply {
        setBackgroundColor(AndroidColor.TRANSPARENT)
        settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = false
          allowFileAccess = true
          allowContentAccess = false
          blockNetworkLoads = true
          blockNetworkImage = true
          cacheMode = WebSettings.LOAD_NO_CACHE
        }

        addJavascriptInterface(
          MathJaxJavascriptInterface { heightPx ->
            val heightDp = (heightPx / density.density).toInt()
            if (heightDp > 15) {
              measuredHeightDp = heightDp + 6
            }
          },
          "AndroidInterface"
        )

        webViewClient = object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            view?.setBackgroundColor(AndroidColor.TRANSPARENT)
          }
          override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            return true
          }
        }
        tag = formattedHtml
        loadDataWithBaseURL("file:///android_asset/", formattedHtml, "text/html", "UTF-8", null)
      }
    },
    update = { webView ->
      val currentTag = webView.tag as? String
      if (currentTag != formattedHtml) {
        webView.tag = formattedHtml
        webView.loadDataWithBaseURL("file:///android_asset/", formattedHtml, "text/html", "UTF-8", null)
      }
    }
  )
}

/**
 * Reusable Card displaying a collection of scientific formulas.
 * Uses full MathJax vector SVG typesetting by default for crisp formulas across lesson and exercise screens,
 * with a toggle to view native copyable text when desired.
 */
@Composable
fun MathJaxFormulaCardList(
  title: String? = null,
  formulas: List<String>,
  modifier: Modifier = Modifier,
  badgeText: String = "MathJax"
) {
  var showWebViewMathJax by remember { mutableStateOf(true) }
  val clipboardManager = LocalClipboardManager.current
  var copiedIndex by remember { mutableStateOf<Int?>(null) }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    )
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Header row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            Icons.Default.Functions,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
          )
          if (title != null) {
            Text(
              title,
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }

        // Toggle badge (MathJax SVG vs Plain Text)
        Surface(
          onClick = { showWebViewMathJax = !showWebViewMathJax },
          color = if (showWebViewMathJax) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("btn_toggle_mathjax_mode")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              if (showWebViewMathJax) Icons.Default.Visibility else Icons.Default.VisibilityOff,
              contentDescription = null,
              modifier = Modifier.size(13.dp),
              tint = MaterialTheme.colorScheme.primary
            )
            Text(
              if (showWebViewMathJax) "MathJax (SVG)" else "Texte simple",
              style = MaterialTheme.typography.labelSmall,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }

      if (showWebViewMathJax) {
        // Full MathJax vector SVG WebView typesetting
        MathJaxFormulaList(
          formulas = formulas,
          textColor = MaterialTheme.colorScheme.onSurface,
          fontSizeSp = 15
        )
      } else {
        // High-performance Native Compose rendering fallback
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          formulas.forEachIndexed { index, formula ->
            Surface(
              color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .padding(horizontal = 12.dp, vertical = 8.dp)
                  .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.weight(1f)
                ) {
                  Text(
                    "•",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(end = 8.dp)
                  )
                  NativeMathText(
                    formula = formula,
                    fontSizeSp = 15,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    isItalic = false
                  )
                }

                IconButton(
                  onClick = {
                    clipboardManager.setText(AnnotatedString(formula))
                    copiedIndex = index
                  },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(
                    Icons.Default.ContentCopy,
                    contentDescription = "Copier formule",
                    tint = if (copiedIndex == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(14.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

/**
 * Individual MathJax Formula Card.
 */
@Composable
fun MathFormulaCard(
  title: String? = null,
  latexFormula: String,
  modifier: Modifier = Modifier,
  badgeText: String = "MathJax"
) {
  MathJaxFormulaCardList(
    title = title,
    formulas = listOf(latexFormula),
    modifier = modifier,
    badgeText = badgeText
  )
}

/**
 * Direct single-formula composable using MathJax WebView.
 */
@Composable
fun MathJaxFormula(
  latex: String,
  modifier: Modifier = Modifier,
  isBlock: Boolean = false,
  textColor: Color = MaterialTheme.colorScheme.onSurface,
  fontSizeSp: Int = 15
) {
  MathJaxView(
    formula = latex,
    modifier = modifier,
    isDisplayMode = isBlock,
    fontSizeSp = fontSizeSp,
    textColor = textColor
  )
}

/**
 * High-performance Native Mathematical Text composable for symbols and single expressions.
 * Renders exponents, subscripts, and Greek symbols in 0ms without spawning Chromium WebViews.
 */
@Composable
fun NativeMathText(
  formula: String,
  modifier: Modifier = Modifier,
  fontSizeSp: Int = 16,
  fontWeight: FontWeight = FontWeight.SemiBold,
  color: Color = MaterialTheme.colorScheme.onSurface,
  isItalic: Boolean = true
) {
  val cleanText = remember(formula) {
    formatLatexToNativeString(formula)
  }

  Text(
    text = cleanText,
    modifier = modifier,
    style = MaterialTheme.typography.bodyLarge.copy(
      fontFamily = FontFamily.Serif,
      fontStyle = if (isItalic) FontStyle.Italic else FontStyle.Normal,
      fontWeight = fontWeight,
      fontSize = fontSizeSp.sp,
      color = color
    )
  )
}

/**
 * Converts common LaTeX math expressions and raw scientific strings to formatted AnnotatedString
 * with accurate subscripts, superscripts, Greek letters, and chemical symbols.
 */
fun formatLatexToNativeString(raw: String): AnnotatedString {
  // Helper to safely strip LaTeX commands like \text{...}, \mathrm{...}, etc. without dropping braces elsewhere
  fun stripMacro(input: String, macro: String): String {
    var cur = input
    val prefix = "$macro{"
    while (cur.contains(prefix)) {
      val start = cur.indexOf(prefix)
      var depth = 1
      var end = -1
      for (k in (start + prefix.length) until cur.length) {
        if (cur[k] == '{') depth++
        else if (cur[k] == '}') {
          depth--
          if (depth == 0) {
            end = k
            break
          }
        }
      }
      if (end != -1) {
        val inner = cur.substring(start + prefix.length, end)
        cur = cur.substring(0, start) + inner + cur.substring(end + 1)
      } else {
        break
      }
    }
    return cur
  }

  var s = raw.trim()
    .replace("$$", "")
    .replace("$", "")
    .replace("\\,", " ")
    .replace("\\quad", "  ")
    .replace("\\qquad", "    ")
    .replace("\\cdot", " · ")
    .replace("\\times", " × ")
    .replace("\\approx", " ≈ ")
    .replace("\\le", " ≤ ")
    .replace("\\leq", " ≤ ")
    .replace("\\ge", " ≥ ")
    .replace("\\geq", " ≥ ")
    .replace("\\ne", " ≠ ")
    .replace("\\neq", " ≠ ")
    .replace("\\pm", " ± ")
    .replace("\\mp", " ∓ ")
    .replace("\\iff", " ⟺ ")
    .replace("\\implies", " ⟹ ")
    .replace("\\to", " → ")
    .replace("\\rightarrow", " → ")
    .replace("\\longrightarrow", " ⟶ ")
    .replace("\\rightleftharpoons", " ⇌ ")
    .replace("\\Delta", "Δ")
    .replace("\\delta", "δ")
    .replace("\\tau", "τ")
    .replace("\\lambda", "λ")
    .replace("\\Lambda", "Λ")
    .replace("\\theta", "θ")
    .replace("\\nu", "ν")
    .replace("\\mu", "μ")
    .replace("\\sigma", "σ")
    .replace("\\rho", "ρ")
    .replace("\\alpha", "α")
    .replace("\\beta", "β")
    .replace("\\gamma", "γ")
    .replace("\\varphi", "φ")
    .replace("\\phi", "φ")
    .replace("\\pi", "π")
    .replace("\\omega", "ω")
    .replace("\\Omega", "Ω")
    .replace("\\xi", "ξ")
    .replace("\\infty", "∞")
    .replace("\\cos", "cos")
    .replace("\\sin", "sin")
    .replace("\\tan", "tan")
    .replace("\\ln", "ln")
    .replace("\\log", "log")
    .replace("\\exp", "exp")
    .replace("\\sum", "∑")
    .replace("\\int", "∫")
    .replace("\\partial", "∂")
    .replace("\\vec{f}", "f⃗")
    .replace("\\vec{P}", "P⃗")
    .replace("\\vec{v}", "v⃗")
    .replace("\\vec{a}", "a⃗")
    .replace("\\vec{F}", "F⃗")
    .replace("\\vec{i}", "i⃗")
    .replace("\\vec{j}", "j⃗")
    .replace("\\vec{k}", "k⃗")
    .replace("\\dot{\\theta}", "θ̇")
    .replace("\\ddot{\\theta}", "θ̈")
    .replace("\\left(", "(")
    .replace("\\right)", ")")
    .replace("\\left[", "[")
    .replace("\\right]", "]")
    .replace("\\left\\{", "{")
    .replace("\\right\\}", "}")
    .replace("\\{", "{")
    .replace("\\}", "}")
    .replace("\\left", "")
    .replace("\\right", "")
    .replace("^\\circ", "°")
    .replace("\\circ", "°")
    // Safe macro un-wrapping
    s = stripMacro(s, "\\text")
    s = stripMacro(s, "\\mathrm")
    s = stripMacro(s, "\\mathbf")
    s = stripMacro(s, "\\boldsymbol")
    s = stripMacro(s, "\\underline")

  // Chemical formulas and ions
  s = s
    .replace("H3O+", "H₃O⁺")
    .replace("HO-", "HO⁻")
    .replace("CH3COOH", "CH₃COOH")
    .replace("CH3COO-", "CH₃COO⁻")
    .replace("H2O", "H₂O")
    .replace("CO2", "CO₂")
    .replace("O2", "O₂")
    .replace("H2", "H₂")
    .replace("N2", "N₂")
    .replace("Cl2", "Cl₂")
    .replace("Br2", "Br₂")
    .replace("I2", "I₂")
    .replace("MnO4-", "MnO₄⁻")
    .replace("Mn2+", "Mn²⁺")
    .replace("Cr2O7^2-", "Cr₂O₇²⁻")
    .replace("Cr2O7^{2-}", "Cr₂O₇²⁻")
    .replace("Cr3+", "Cr³⁺")
    .replace("S2O8^2-", "S₂O₈²⁻")
    .replace("S2O8^{2-}", "S₂O₈²⁻")
    .replace("S4O6^2-", "S₄O₆²⁻")
    .replace("S4O6^{2-}", "S₄O₆²⁻")
    .replace("S2O3^2-", "S₂O₃²⁻")
    .replace("S2O3^{2-}", "S₂O₃²⁻")
    .replace("SO4^2-", "SO₄²⁻")
    .replace("SO4^{2-}", "SO₄²⁻")
    .replace("Fe2+", "Fe²⁺")
    .replace("Fe3+", "Fe³⁺")
    .replace("Cu2+", "Cu²⁺")
    .replace("Zn2+", "Zn²⁺")
    .replace("Ag+", "Ag⁺")
    .replace("Al3+", "Al³⁺")
    .replace("Na+", "Na⁺")
    .replace("K+", "K⁺")
    .replace("Cl-", "Cl⁻")
    .replace("Br-", "Br⁻")
    .replace("I-", "I⁻")
    .replace("NO3-", "NO₃⁻")
    .replace("t_1/2", "t₁⸝₂")
    .replace("t_{1/2}", "t₁⸝₂")
    .replace("x_{\\max}", "xₘₐₓ")
    .replace("x_{max}", "xₘₐₓ")
    .replace("x_max", "xₘₐₓ")
    .replace("x_{\\text{éq}}", "xₑ_q")
    .replace("x_{éq}", "xₑ_q")
    .replace("x_{eq}", "xₑ_q")
    .replace("x_eq", "xₑ_q")
    .replace("kOhm", "kΩ")
    .replace("microfarad", "µF")
    .replace("microampères", "µA")

  // Simplify \frac{num}{den} to (num / den)
  while (s.contains("\\frac{")) {
    val startIndex = s.indexOf("\\frac{")
    var depth = 1
    var numEnd = -1
    for (idx in (startIndex + 6) until s.length) {
      if (s[idx] == '{') depth++
      else if (s[idx] == '}') {
        depth--
        if (depth == 0) {
          numEnd = idx
          break
        }
      }
    }
    if (numEnd != -1 && numEnd + 1 < s.length && s[numEnd + 1] == '{') {
      val num = s.substring(startIndex + 6, numEnd)
      depth = 1
      var denEnd = -1
      for (idx in (numEnd + 2) until s.length) {
        if (s[idx] == '{') depth++
        else if (s[idx] == '}') {
          depth--
          if (depth == 0) {
            denEnd = idx
            break
          }
        }
      }
      if (denEnd != -1) {
        val den = s.substring(numEnd + 2, denEnd)
        s = s.substring(0, startIndex) + "($num / $den)" + s.substring(denEnd + 1)
      } else {
        break
      }
    } else {
      break
    }
  }

  // Simplify \sqrt{x} to √(x)
  while (s.contains("\\sqrt{")) {
    val startIndex = s.indexOf("\\sqrt{")
    var depth = 1
    var end = -1
    for (idx in (startIndex + 6) until s.length) {
      if (s[idx] == '{') depth++
      else if (s[idx] == '}') {
        depth--
        if (depth == 0) {
          end = idx
          break
        }
      }
    }
    if (end != -1) {
      val inner = s.substring(startIndex + 6, end)
      s = s.substring(0, startIndex) + "√($inner)" + s.substring(end + 1)
    } else {
      break
    }
  }

  // Pre-replace common superscript tokens
  s = s
    .replace("^{-1}", "⁻¹")
    .replace("^{-2}", "⁻²")
    .replace("^{-3}", "⁻³")
    .replace("^{-4}", "⁻⁴")
    .replace("^{-14}", "⁻¹⁴")
    .replace("^{-19}", "⁻¹⁹")
    .replace("^2", "²")
    .replace("^3", "³")
    .replace("^0", "⁰")
    .replace("^1", "¹")
    .replace("^4", "⁴")
    .replace("^5", "⁵")
    .replace("^6", "⁶")
    .replace("^7", "⁷")
    .replace("^8", "⁸")
    .replace("^9", "⁹")
    .replace("^+", "⁺")
    .replace("^-", "⁻")

  // Pre-replace common subscript tokens
  s = s
    .replace("_0", "₀")
    .replace("_1", "₁")
    .replace("_2", "₂")
    .replace("_3", "₃")
    .replace("_{bE}", "_{bE}")
    .replace("_{BE}", "_{BE}")

  return buildAnnotatedString {
    var i = 0
    while (i < s.length) {
      when {
        s[i] == '^' && i + 1 < s.length -> {
          i++
          val isBraced = s[i] == '{'
          if (isBraced) i++
          val start = i
          while (i < s.length && if (isBraced) s[i] != '}' else (s[i].isLetterOrDigit() || s[i] == '-' || s[i] == '+')) {
            i++
          }
          val exp = s.substring(start, i)
          if (isBraced && i < s.length && s[i] == '}') i++
          withStyle(SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = 11.sp)) {
            append(exp)
          }
        }
        s[i] == '_' && i + 1 < s.length -> {
          i++
          val isBraced = s[i] == '{'
          if (isBraced) i++
          val start = i
          while (i < s.length && if (isBraced) s[i] != '}' else (s[i].isLetterOrDigit() || s[i] == '-')) {
            i++
          }
          val sub = s.substring(start, i)
          if (isBraced && i < s.length && s[i] == '}') i++
          withStyle(SpanStyle(baselineShift = BaselineShift.Subscript, fontSize = 11.sp)) {
            append(sub)
          }
        }
        else -> {
          append(s[i])
          i++
        }
      }
    }
  }
}

/**
 * Formats a raw step string into styled HTML with subscripts, superscripts, chemical equations,
 * and mathematical arrows.
 */
fun formatSolutionStepToHtml(raw: String): String {
  var s = raw
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\n", "<br/>")

  // Chemical formulas and ions
  s = s
    .replace("CH3COOH", "CH<sub>3</sub>COOH")
    .replace("CH3COO-", "CH<sub>3</sub>COO<sup>−</sup>")
    .replace("H3O+", "H<sub>3</sub>O<sup>+</sup>")
    .replace("HO-", "HO<sup>−</sup>")
    .replace("H2O", "H<sub>2</sub>O")
    .replace("MnO4-", "MnO<sub>4</sub><sup>−</sup>")
    .replace("S2O8^2-", "S<sub>2</sub>O<sub>8</sub><sup>2−</sup>")
    .replace("SO4^2-", "SO<sub>4</sub><sup>2−</sup>")
    .replace("Fe2+", "Fe<sup>2+</sup>")
    .replace("Fe3+", "Fe<sup>3+</sup>")
    .replace("Cu2+", "Cu<sup>2+</sup>")
    .replace("Zn2+", "Zn<sup>2+</sup>")
    .replace("Ag+", "Ag<sup>+</sup>")
    .replace("Na+", "Na<sup>+</sup>")
    .replace("Cl-", "Cl<sup>−</sup>")
    .replace("Br-", "Br<sup>−</sup>")
    .replace("I-", "I<sup>−</sup>")
    .replace("I2", "I<sub>2</sub>")
    .replace("O2", "O<sub>2</sub>")
    .replace("H2", "H<sub>2</sub>")
    .replace("CO2", "CO<sub>2</sub>")
    .replace("t_1/2", "t<sub>1/2</sub>")
    .replace("t_{1/2}", "t<sub>1/2</sub>")
    .replace("x_max", "x<sub>max</sub>")
    .replace("V_bE", "V<sub>bE</sub>")
    .replace("pH_E", "pH<sub>E</sub>")
    .replace("C_a", "C<sub>a</sub>")
    .replace("V_a", "V<sub>a</sub>")
    .replace("C_b", "C<sub>b</sub>")
    .replace("V_b", "V<sub>b</sub>")
    .replace("u_C", "u<sub>C</sub>")
    .replace("u_R", "u<sub>R</sub>")
    .replace("u_L", "u<sub>L</sub>")
    .replace("A_0", "A<sub>0</sub>")
    .replace("N_0", "N<sub>0</sub>")
    .replace("t_1", "t<sub>1</sub>")
    .replace("x_F", "x<sub>F</sub>")
    .replace("pKa", "pK<sub>a</sub>")
    .replace(" -&gt; ", " → ")
    .replace(" &lt;=&gt; ", " ⟺ ")
    .replace(" &lt;=&gt; ", " ⟺ ")

  // Powers of 10
  s = s.replace(Regex("""10\^\((-?\d+)\)"""), "10<sup>$1</sup>")
  s = s.replace(Regex("""10\^(-?\d+)"""), "10<sup>$1</sup>")

  return s
}

/**
 * Universal Composable that formats scientific & mathematical text with clean subscripts,
 * superscripts, Greek letters, and chemical symbols.
 */
@Composable
fun MathFormattedText(
  text: String,
  modifier: Modifier = Modifier,
  style: androidx.compose.ui.text.TextStyle = LocalTextStyle.current,
  color: Color = Color.Unspecified,
  maxLines: Int = Int.MAX_VALUE,
  overflow: TextOverflow = TextOverflow.Clip
) {
  Text(
    text = remember(text) { formatLatexToNativeString(text) },
    modifier = modifier,
    style = style,
    color = color,
    maxLines = maxLines,
    overflow = overflow
  )
}


/**
 * Reusable Composable that renders all step-by-step solution steps and teacher methodology tips
 * inside a single, unified MathJax WebView.
 *
 * Major performance benefits:
 * - 1 single WebView instance per exercise instead of 5-8 separate WebViews
 * - Drastically eliminates memory overhead and scroll jank in LazyColumn
 * - Elegant pedagogical card presentation with step badges and teacher remarks
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MathJaxSolutionSteps(
  steps: List<String>,
  tips: String? = null,
  modifier: Modifier = Modifier,
  fontSizeSp: Int = 14,
  textColor: Color = MaterialTheme.colorScheme.onSurface,
  primaryColor: Color = MaterialTheme.colorScheme.primary
) {
  val density = LocalDensity.current
  var measuredHeightDp by remember { mutableStateOf<Int?>(null) }

  val hexColor = remember(textColor) {
    val argb = textColor.toArgb()
    String.format("#%06X", 0xFFFFFF and argb)
  }

  val hexPrimary = remember(primaryColor) {
    val argb = primaryColor.toArgb()
    String.format("#%06X", 0xFFFFFF and argb)
  }

  val combinedHtml = remember(steps, tips, hexColor, hexPrimary, fontSizeSp) {
    val stepsHtml = steps.mapIndexed { index, step ->
      val formattedStep = formatSolutionStepToHtml(step)

      """
      <div class="step-card">
        <div class="step-header">
          <span class="step-badge">Étape ${index + 1}</span>
        </div>
        <div class="step-content">$formattedStep</div>
      </div>
      """.trimIndent()
    }.joinToString("\n")

    val tipHtml = if (!tips.isNullOrBlank()) {
      val formattedTip = formatSolutionStepToHtml(tips)
      """
      <div class="tip-card">
        <div class="tip-header">💡 Remarque & Conseil du Professeur :</div>
        <div class="tip-content">$formattedTip</div>
      </div>
      """.trimIndent()
    } else ""

    """
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <style>
        * {
          box-sizing: border-box;
          -webkit-user-select: text;
        }
        html, body {
          margin: 0;
          padding: 2px 4px;
          background-color: transparent;
          color: $hexColor;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          font-size: ${fontSizeSp}px;
          line-height: 1.5;
          width: 100%;
          overflow-x: auto;
          overflow-y: hidden;
        }
        #solution-wrapper {
          width: 100%;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .step-card {
          background: rgba(128, 128, 128, 0.08);
          border: 1px solid rgba(128, 128, 128, 0.2);
          border-left: 4px solid $hexPrimary;
          border-radius: 8px;
          padding: 10px 12px;
          margin-bottom: 8px;
        }
        .step-header {
          margin-bottom: 6px;
        }
        .step-badge {
          display: inline-block;
          background: $hexPrimary;
          color: #ffffff;
          font-size: 11px;
          font-weight: bold;
          padding: 2px 8px;
          border-radius: 4px;
          letter-spacing: 0.5px;
        }
        .step-content {
          font-size: ${fontSizeSp}px;
          line-height: 1.55;
        }
        .tip-card {
          background: rgba(46, 125, 50, 0.12);
          border: 1px solid rgba(46, 125, 50, 0.3);
          border-radius: 8px;
          padding: 10px 12px;
          margin-top: 4px;
        }
        .tip-header {
          color: #2E7D32;
          font-weight: bold;
          font-size: 12px;
          margin-bottom: 4px;
        }
        .tip-content {
          font-size: ${fontSizeSp - 1}px;
          color: $hexColor;
        }
        mjx-container {
          color: $hexColor !important;
          outline: none !important;
          margin: 3px 0 !important;
        }
        mjx-container svg {
          fill: $hexColor !important;
          stroke: $hexColor !important;
        }
      </style>
      <script>
        window.MathJax = {
          tex: {
            inlineMath: [['$', '$'], ['\\(', '\\)']],
            displayMath: [['$$', '$$'], ['\\[', '\\]']],
            processEscapes: true
          },
          svg: {
            fontCache: 'local',
            scale: 1.03
          },
          options: {
            enableMenu: false
          },
          startup: {
            typeset: true,
            ready: () => {
              MathJax.startup.defaultReady();
              MathJax.startup.promise.then(() => {
                reportHeight();
                setTimeout(reportHeight, 100);
                setTimeout(reportHeight, 300);
              });
            }
          }
        };

        function reportHeight() {
          if (window.AndroidInterface && window.AndroidInterface.onHeightChanged) {
            var container = document.getElementById('solution-wrapper');
            var h = container ? container.scrollHeight : document.body.scrollHeight;
            window.AndroidInterface.onHeightChanged(h);
          }
        }
        window.addEventListener('resize', reportHeight);
      </script>
      <script type="text/javascript" id="MathJax-script" async
        src="file:///android_asset/mathjax/tex-svg.js">
      </script>
    </head>
    <body>
      <div id="solution-wrapper">
        $stepsHtml
        $tipHtml
      </div>
    </body>
    </html>
    """.trimIndent()
  }

  val estimatedDefaultHeight = (steps.size * 90 + if (!tips.isNullOrBlank()) 60 else 0).coerceIn(120, 1500)
  val finalHeight = (measuredHeightDp ?: estimatedDefaultHeight).coerceIn(80, 2000)

  AndroidView(
    modifier = modifier
      .fillMaxWidth()
      .height(finalHeight.dp)
      .animateContentSize(),
    factory = { ctx ->
      WebView(ctx).apply {
        setBackgroundColor(AndroidColor.TRANSPARENT)
        settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = false
          allowFileAccess = true
          allowContentAccess = false
          setGeolocationEnabled(false)
          databaseEnabled = false
          blockNetworkLoads = true
          blockNetworkImage = true
          if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            safeBrowsingEnabled = false
          }
          cacheMode = WebSettings.LOAD_NO_CACHE
          loadWithOverviewMode = true
          useWideViewPort = false
          builtInZoomControls = false
          displayZoomControls = false
        }

        addJavascriptInterface(
          MathJaxJavascriptInterface { heightPx ->
            val heightDp = (heightPx / density.density).toInt()
            if (heightDp > 20) {
              measuredHeightDp = heightDp + 10
            }
          },
          "AndroidInterface"
        )

        webViewClient = object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            view?.setBackgroundColor(AndroidColor.TRANSPARENT)
          }
          override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {}
          override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            return true
          }
        }
        tag = combinedHtml
        loadDataWithBaseURL("file:///android_asset/", combinedHtml, "text/html", "UTF-8", null)
      }
    },
    update = { webView ->
      val currentTag = webView.tag as? String
      if (currentTag != combinedHtml) {
        webView.tag = combinedHtml
        webView.loadDataWithBaseURL("file:///android_asset/", combinedHtml, "text/html", "UTF-8", null)
      }
    }
  )
}
