package com.example.ui.screens

import androidx.compose.runtime.Composable
import com.example.data.UserRole

/**
 * Forwarding wrapper to [LoginScreen] for backward compatibility.
 */
@Composable
fun AuthScreen(
  onLoginSuccess: (role: UserRole, userName: String, userClass: String) -> Unit,
  onBackToIntro: () -> Unit
) {
  LoginScreen(
    onLoginSuccess = onLoginSuccess,
    onBackToIntro = onBackToIntro
  )
}
