package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.data.CurriculumData
import com.example.data.FirebaseSafetyManager
import com.example.data.GoogleAuthManager
import com.example.data.SessionManager
import com.example.data.UserRole
import com.example.ui.theme.ScienceGreen
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private const val TAG = "LoginScreen"

/**
 * Composant de bouton de connexion Google interactif avec Credential Manager.
 * Tolérant aux pannes si Firebase ou google-services.json est manquant.
 */
@Composable
fun GoogleSignInButton(
  modifier: Modifier = Modifier,
  buttonText: String = "Sign in with Google",
  onAuthSuccess: () -> Unit,
  onAuthError: (String) -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val credentialManager = remember { CredentialManager.create(context) }
  var isLoading by remember { mutableStateOf(false) }

  Button(
    onClick = {
      isLoading = true
      onGoogleSignInClicked(
        context = context,
        credentialManager = credentialManager,
        onAuthSuccess = {
          isLoading = false
          onAuthSuccess()
        },
        onAuthError = { errorMsg ->
          isLoading = false
          onAuthError(errorMsg)
        },
        scope = coroutineScope,
        onAuthCancelled = {
          isLoading = false
        }
      )
    },
    enabled = !isLoading,
    modifier = modifier.testTag("google_sign_in_button"),
    shape = RoundedCornerShape(14.dp)
  ) {
    if (isLoading) {
      CircularProgressIndicator(
        modifier = Modifier.size(24.dp),
        color = MaterialTheme.colorScheme.onPrimary,
        strokeWidth = 2.dp
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text("Connexion en cours...")
    } else {
      Icon(
        imageVector = Icons.Default.AccountCircle,
        contentDescription = "Google Logo",
        modifier = Modifier.size(22.dp)
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = buttonText,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp
      )
    }
  }
}

/**
 * Déclenche la connexion interactive Google Sign-In via Jetpack Credential Manager.
 * Sécurisé pour ne jamais lever d'exception fatale.
 */
fun onGoogleSignInClicked(
  context: Context,
  credentialManager: CredentialManager,
  onAuthSuccess: () -> Unit,
  onAuthError: (String) -> Unit,
  scope: CoroutineScope,
  onAuthCancelled: () -> Unit = {}
) {
  val activity = context as? Activity
  if (activity == null) {
    onAuthError("Contexte Activity invalide pour l'affichage de Google Sign-In.")
    return
  }

  if (!FirebaseSafetyManager.isFirebaseAvailable(context)) {
    // Mode local transparent sans blocage
    onAuthSuccess()
    return
  }

  val clientId = FirebaseSafetyManager.resolveWebClientId(context)
  if (clientId.isNullOrBlank()) {
    onAuthError("Configuration Google Sign-In absente (google-services.json non ajouté). Vous pouvez continuer en mode autonome.")
    return
  }

  val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
  val request = GetCredentialRequest.Builder()
    .addCredentialOption(signInOption)
    .build()

  scope.launch {
    try {
      val result = credentialManager.getCredential(activity, request)
      val credential = result.credential
      if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
        Firebase.auth.signInWithCredential(authCredential).await()
        onAuthSuccess()
      } else {
        onAuthError("Type d'identifiant inattendu reçu de Google Credential Manager")
      }
    } catch (e: GetCredentialCancellationException) {
      Log.w(TAG, "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
      onAuthCancelled()
    } catch (e: Throwable) {
      Log.e(TAG, "Google Sign-In failed", e)
      onAuthError(e.localizedMessage ?: "Échec de connexion Google")
    }
  }
}

/**
 * Composable LoginScreen principal utilisant Firebase Auth et Google Credential Manager,
 * avec une résilience complète : si google-services.json ou la clé Gemini est absente,
 * l'application s'ouvre normalement en mode local autonome sans afficher d'erreur bloquante.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
  onSignInSuccess: () -> Unit = {},
  onLoginSuccess: ((role: UserRole, userName: String, userClass: String) -> Unit)? = null,
  onBackToIntro: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val credentialManager = remember { CredentialManager.create(context) }

  val systemStatus = remember { FirebaseSafetyManager.getStatusSummary(context) }
  val isCloudReady = remember { FirebaseSafetyManager.isCloudReady(context) }

  var selectedRoleTab by remember { mutableIntStateOf(0) } // 0 = Élève, 1 = Professeur
  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  // Student metadata
  var studentNameInput by remember { mutableStateOf("") }
  var studentClass by remember { mutableStateOf("2ème Bac Sciences Physiques 1") }
  val classOptions = listOf(
    "2ème Bac Sciences Physiques 1",
    "2ème Bac Sciences Physiques 2",
    "2ème Bac Sciences Mathématiques A",
    "2ème Bac Sciences de la Vie et de la Terre"
  )
  var classDropdownExpanded by remember { mutableStateOf(false) }

  // Teacher metadata
  var teacherPasscode by remember { mutableStateOf("") }
  var teacherPasscodeVisible by remember { mutableStateOf(false) }
  val teacherDefaultName = CurriculumData.teacherName

  // Silent auto sign-in sécurisé (n'est exécuté que si Firebase est actif)
  LaunchedEffect(Unit) {
    if (!isCloudReady) {
      Log.d(TAG, "Lancement en mode local autonome (Firebase/Google Services non configurés).")
      return@LaunchedEffect
    }

    try {
      if (FirebaseSafetyManager.isFirebaseAvailable(context)) {
        val user = GoogleAuthManager.getCurrentUser()
        if (user != null) {
          val session = SessionManager.getInstance(context)
          onSignInSuccess()
          onLoginSuccess?.invoke(session.userRole, user.displayName ?: session.userName, session.userClass)
          return@LaunchedEffect
        }
      }

      val clientId = FirebaseSafetyManager.resolveWebClientId(context)
      if (!clientId.isNullOrBlank()) {
        val googleIdOption = GetGoogleIdOption.Builder()
          .setFilterByAuthorizedAccounts(true)
          .setServerClientId(clientId)
          .setAutoSelectEnabled(true)
          .build()

        val silentRequest = GetCredentialRequest.Builder()
          .addCredentialOption(googleIdOption)
          .build()

        val result = credentialManager.getCredential(context, silentRequest)
        val credential = result.credential
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
          val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
          val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
          val authResult = Firebase.auth.signInWithCredential(authCredential).await()
          val user = authResult.user
          if (user != null) {
            val session = SessionManager.getInstance(context)
            onSignInSuccess()
            onLoginSuccess?.invoke(session.userRole, user.displayName ?: session.userName, session.userClass)
          }
        }
      }
    } catch (t: Throwable) {
      Log.d(TAG, "Silent auto-sign-in non actif : ${t.message}")
    }
  }

  Scaffold(
    modifier = modifier.testTag("login_screen"),
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "Connexion & Accès",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        },
        navigationIcon = {
          if (onBackToIntro != null) {
            IconButton(
              onClick = onBackToIntro,
              modifier = Modifier.testTag("btn_login_back")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Retour"
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header Hero
      Box(
        modifier = Modifier
          .size(64.dp)
          .background(
            color = if (selectedRoleTab == 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
            shape = CircleShape
          ),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (selectedRoleTab == 0) Icons.Default.School else Icons.Default.CoPresent,
          contentDescription = null,
          tint = if (selectedRoleTab == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
          modifier = Modifier.size(36.dp)
        )
      }

      Text(
        text = if (selectedRoleTab == 0) "Espace Élève 2BAC" else "Espace Enseignant",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center
      )

      Text(
        text = "Physique-Chimie 2ème Année Baccalauréat • Pr. Mohammed SBAI",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )

      // Bannière d'information sur la disponibilité du mode autonome / hors-ligne
      Surface(
        color = if (isCloudReady) ScienceGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Icon(
            imageVector = if (isCloudReady) Icons.Default.CloudDone else Icons.Default.OfflinePin,
            contentDescription = null,
            tint = if (isCloudReady) ScienceGreen else MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
          )
          Column {
            Text(
              text = if (isCloudReady) "Mode Cloud & Synchronisation Actif" else "Mode Autonome Local Actif",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = if (isCloudReady) ScienceGreen else MaterialTheme.colorScheme.primary
            )
            Text(
              text = if (isCloudReady)
                "Authentification Google et base Firestore connectées."
              else
                "Tous les cours (P1-P16, C1-C10), exercices corrigés, calculatrices et annales 2015-2026 sont 100% disponibles sans configuration requise.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Message d'erreur éventuel non bloquant
      AnimatedVisibility(
        visible = errorMessage != null,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        Surface(
          color = MaterialTheme.colorScheme.errorContainer,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("login_error_banner")
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Info,
              contentDescription = "Info",
              tint = MaterialTheme.colorScheme.error
            )
            Text(
              text = errorMessage ?: "",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onErrorContainer
            )
          }
        }
      }

      // Role Tabs
      TabRow(
        selectedTabIndex = selectedRoleTab,
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp)),
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        divider = {}
      ) {
        Tab(
          selected = selectedRoleTab == 0,
          onClick = {
            selectedRoleTab = 0
            errorMessage = null
          },
          modifier = Modifier.testTag("tab_login_student"),
          text = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp))
              Text("Élève", fontWeight = if (selectedRoleTab == 0) FontWeight.Bold else FontWeight.Normal)
            }
          }
        )
        Tab(
          selected = selectedRoleTab == 1,
          onClick = {
            selectedRoleTab = 1
            errorMessage = null
          },
          modifier = Modifier.testTag("tab_login_teacher"),
          text = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(16.dp))
              Text("Professeur", fontWeight = if (selectedRoleTab == 1) FontWeight.Bold else FontWeight.Normal)
            }
          }
        )
      }

      // Role Content Card
      ElevatedCard(
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          if (selectedRoleTab == 0) {
            // Student Settings
            Text(
              text = "Informations de l'élève :",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
              value = studentNameInput,
              onValueChange = { studentNameInput = it },
              label = { Text("Nom et Prénom de l'élève") },
              placeholder = { Text("Ex: Yassine El Amrani") },
              leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
              singleLine = true,
              modifier = Modifier
                .fillMaxWidth()
                .testTag("input_login_student_name")
            )

            ExposedDropdownMenuBox(
              expanded = classDropdownExpanded,
              onExpandedChange = { classDropdownExpanded = !classDropdownExpanded },
              modifier = Modifier.fillMaxWidth()
            ) {
              OutlinedTextField(
                value = studentClass,
                onValueChange = {},
                readOnly = true,
                label = { Text("Classe") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = classDropdownExpanded) },
                leadingIcon = { Icon(Icons.Default.Class, contentDescription = null) },
                modifier = Modifier
                  .menuAnchor()
                  .fillMaxWidth()
                  .testTag("dropdown_login_student_class")
              )

              ExposedDropdownMenu(
                expanded = classDropdownExpanded,
                onDismissRequest = { classDropdownExpanded = false }
              ) {
                classOptions.forEach { option ->
                  DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                      studentClass = option
                      classDropdownExpanded = false
                    }
                  )
                }
              }
            }

            Surface(
              color = ScienceGreen.copy(alpha = 0.12f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Icon(Icons.Default.MenuBook, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(20.dp))
                Text(
                  text = "Accès direct aux 16 cours de Physique, 10 cours de Chimie, contrôles continus et exercices corrigés.",
                  style = MaterialTheme.typography.labelSmall
                )
              }
            }
          } else {
            // Teacher Settings
            Text(
              text = "Session Enseignant Officiel :",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.secondary
            )

            Surface(
              color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                Column {
                  Text(
                    text = teacherDefaultName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "Enseignant Agrégé de Physique-Chimie",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }

            Surface(
              color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text(
                  text = "L'espace professeur sera disponible après activation d'une authentification sécurisée vérifiée par le serveur. Aucun code local n'est accepté.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onErrorContainer
                )
              }
            }
          }

          // Bouton Principal 1 : Entrée immédiate (Mode Autonome / Hors-ligne)
          Button(
            onClick = {
              if (selectedRoleTab == 1) {
                errorMessage = "L'accès professeur nécessite désormais une authentification vérifiée par le serveur. Cette fonction sera réactivée après configuration de Firebase Authentication et des rôles enseignants."
                return@Button
              }

              val role = if (selectedRoleTab == 0) UserRole.ELEVE else UserRole.PROFESSEUR
              val name = if (selectedRoleTab == 0) {
                studentNameInput.trim().ifEmpty { "Élève 2BAC" }
              } else teacherDefaultName
              val cls = if (selectedRoleTab == 0) studentClass else "2ème Bac (Toutes classes)"

              // Sauvegarde immédiate et lancement
              SessionManager.getInstance(context).saveSession(role, name, cls)
              onSignInSuccess()
              onLoginSuccess?.invoke(role, name, cls)
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("sign_in_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (selectedRoleTab == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
            )
          ) {
            Icon(
              imageVector = Icons.Default.RocketLaunch,
              contentDescription = null,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = if (selectedRoleTab == 0) "Accéder aux Cours & Outils (Élève)" else "Accéder au Tableau Enseignant",
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp
            )
          }

          // Bouton 2 : Connexion Google Credential Manager (si souhaitée pour synchroniser)
          OutlinedButton(
            onClick = {
              if (selectedRoleTab == 1) {
                errorMessage = "La connexion professeur sécurisée n'est pas encore configurée. Utilisez un compte enseignant vérifié lorsque le service sera activé."
                return@OutlinedButton
              }

              val activity = context as? Activity
              if (activity == null) {
                errorMessage = "Contexte Activity indisponible."
                return@OutlinedButton
              }

              isLoading = true
              errorMessage = null

              coroutineScope.launch {
                val targetRole = if (selectedRoleTab == 0) UserRole.ELEVE else UserRole.PROFESSEUR
                val targetClass = if (selectedRoleTab == 0) studentClass else "2ème Bac (Toutes classes)"

                val result = GoogleAuthManager.signInWithGoogle(
                  activity = activity,
                  requestedRole = targetRole,
                  requestedClass = targetClass
                )

                isLoading = false
                result.onSuccess { profile ->
                  onSignInSuccess()
                  onLoginSuccess?.invoke(profile.role, profile.displayName, profile.userClass)
                }.onFailure { err ->
                  if (err is GetCredentialCancellationException) {
                    Log.w(TAG, "Google Sign-In annulé")
                  } else {
                    errorMessage = "Synchronisation Google : ${err.localizedMessage ?: "Non disponible actuellement."} Vous pouvez utiliser l'accès autonome ci-dessus."
                  }
                }
              }
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("btn_google_signin_optional"),
            shape = RoundedCornerShape(14.dp),
            enabled = !isLoading
          ) {
            if (isLoading) {
              CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp
              )
              Spacer(modifier = Modifier.width(10.dp))
              Text("Vérification Google...", fontSize = 13.sp)
            } else {
              Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Synchroniser avec un compte Google (Optionnel)",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }
      }
    }
  }
}
