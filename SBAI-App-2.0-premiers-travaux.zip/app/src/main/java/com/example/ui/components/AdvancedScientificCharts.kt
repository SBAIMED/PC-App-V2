package com.example.ui.components

import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.*

/**
 * Advanced scientific diagrams & curves for 2BAC Physics & Chemistry:
 * - Courbe d'Aston (Noyaux, masse et énergie)
 * - Modulation d'amplitude AM & Trapèze (Mode XY)
 * - Lois de Newton (Graphe cinématique v(t) & accélération)
 * - Mouvement des satellites & 3ème loi de Kepler
 * - Rotation d'un solide autour d'un axe fixe
 * - Oscillateurs mécaniques & Résonance (Pendule élastique x(t))
 * - Aspects énergétiques des oscillateurs (E_pe, E_c, E_m)
 */

internal fun DrawScope.drawCourbeAston(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 50f
  val padRight = 20f
  val padTop = 30f
  val padBottom = 40f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  // Millimeter grid
  val xTicks = 12
  for (i in 0..xTicks) {
    val x = padLeft + chartW * (i / xTicks.toFloat())
    drawLine(color = gridSubColor, start = Offset(x, padTop), end = Offset(x, padTop + chartH), strokeWidth = 1f)
  }
  val yTicks = 9
  for (i in 0..yTicks) {
    val y = padTop + chartH * (i / yTicks.toFloat())
    drawLine(color = gridSubColor, start = Offset(padLeft, y), end = Offset(padLeft + chartW, y), strokeWidth = 1f)
  }

  // Axes: X = A (0 à 240), Y = -E_ℓ/A (0 en haut à -9.0 MeV/nucléon en bas)
  drawLine(color = onSurfaceColor, start = Offset(padLeft, padTop), end = Offset(padLeft + chartW, padTop), strokeWidth = 2.5f)
  drawLine(color = onSurfaceColor, start = Offset(padLeft, padTop), end = Offset(padLeft, padTop + chartH), strokeWidth = 2.5f)

  // Fusion & Fission Zones shading
  // Zone Fusion (A < 25)
  val fusionW = chartW * (25f / 240f)
  drawRect(
    color = Color(0xFF4CAF50).copy(alpha = 0.12f),
    topLeft = Offset(padLeft, padTop),
    size = Size(fusionW, chartH)
  )
  // Zone Fission (A > 190)
  val fissionStart = padLeft + chartW * (190f / 240f)
  drawRect(
    color = Color(0xFFFF9800).copy(alpha = 0.12f),
    topLeft = Offset(fissionStart, padTop),
    size = Size(chartW * (50f / 240f), chartH)
  )

  // Aston Curve function: maps A to -E_l/A (in MeV)
  fun astonEnergy(a: Float): Float {
    if (a <= 1f) return 0f
    if (a <= 4f) return -1.1f - (a - 1f) * 2.0f // steep drop to -7.1 for He-4
    if (a <= 16f) return -7.1f - (a - 4f) * 0.075f
    if (a <= 56f) {
      val t = (a - 16f) / 40f
      return -8.0f - 0.8f * sin(t * Math.PI.toFloat() * 0.5f)
    }
    // from 56 to 240: gently rises from -8.8 to -7.5
    val t = (a - 56f) / 184f
    return -8.8f + 1.3f * t
  }

  val pathAston = Path()
  val steps = 140
  for (i in 0..steps) {
    val a = 1f + (i / steps.toFloat()) * 239f
    val energy = astonEnergy(a) // between 0 and -9.0
    val normY = -energy / 9.0f // 0 at top, 1.0 at -9.0
    val px = padLeft + chartW * ((a - 1f) / 239f)
    val py = padTop + chartH * normY
    if (i == 0) pathAston.moveTo(px, py) else pathAston.lineTo(px, py)
  }
  drawPath(path = pathAston, color = Color(0xFF1E88E5), style = Stroke(width = 4f))

  // Notable points: Fe-56 (minimum), He-4, U-235
  if (showNotablePoints) {
    val aFe = 56f
    val pxFe = padLeft + chartW * ((aFe - 1f) / 239f)
    val pyFe = padTop + chartH * (-astonEnergy(aFe) / 9.0f)
    drawCircle(color = Color(0xFFD32F2F), radius = 6f, center = Offset(pxFe, pyFe))
    drawCircle(color = Color.White, radius = 3f, center = Offset(pxFe, pyFe))

    val aHe = 4f
    val pxHe = padLeft + chartW * ((aHe - 1f) / 239f)
    val pyHe = padTop + chartH * (-astonEnergy(aHe) / 9.0f)
    drawCircle(color = Color(0xFF388E3C), radius = 5f, center = Offset(pxHe, pyHe))

    val aU = 235f
    val pxU = padLeft + chartW * ((aU - 1f) / 239f)
    val pyU = padTop + chartH * (-astonEnergy(aU) / 9.0f)
    drawCircle(color = Color(0xFFFF9800), radius = 5f, center = Offset(pxU, pyU))
  }

  // Native Canvas Labels
  drawContext.canvas.nativeCanvas.apply {
    val paint = Paint().apply {
      isAntiAlias = true
      typeface = Typeface.DEFAULT_BOLD
      textSize = 19f
    }

    paint.color = AndroidColor.rgb(30, 136, 229)
    drawText("Nombre de masse A", padLeft + chartW * 0.65f, padTop + 24f, paint)

    paint.color = AndroidColor.BLACK
    paint.textSize = 17f
    drawText("-E_ℓ / A (MeV/nucléon)", padLeft + 8f, padTop + chartH - 8f, paint)

    // Tick labels
    paint.textSize = 15f
    paint.typeface = Typeface.DEFAULT
    drawText("0", padLeft - 18f, padTop + 5f, paint)
    drawText("-8.8", padLeft - 36f, padTop + chartH * (8.8f / 9.0f) + 5f, paint)
    drawText("56 (²⁶Fe)", padLeft + chartW * (55f / 240f) - 25f, padTop + chartH + 20f, paint)
    drawText("235 (U)", padLeft + chartW * (234f / 240f) - 30f, padTop + chartH + 20f, paint)

    // Zone labels
    paint.typeface = Typeface.DEFAULT_BOLD
    paint.textSize = 16f
    paint.color = AndroidColor.rgb(46, 125, 50)
    drawText("FUSION (A < 20)", padLeft + 6f, padTop + chartH * 0.45f, paint)

    paint.color = AndroidColor.rgb(230, 81, 0)
    drawText("FISSION (A > 200)", fissionStart + 6f, padTop + chartH * 0.45f, paint)

    paint.color = AndroidColor.rgb(198, 40, 40)
    drawText("Maximum de stabilité : Fe-56 (-8.8 MeV)", padLeft + chartW * 0.18f, padTop + chartH * 0.95f, paint)
  }

  // Touch Cursor Probe
  drawTouchCursorHelper(touchNormX, padLeft, padTop, chartW, chartH, Color(0xFF1E88E5)) { normX ->
    val a = 1f + normX * 239f
    val energy = astonEnergy(a)
    -energy / 9.0f
  }
}

internal fun DrawScope.drawModulationAM(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padRight = 15f
  val padTop = 25f
  val padBottom = 35f
  val totalW = size.width - padLeft - padRight
  val totalH = size.height - padTop - padBottom

  val waveW = totalW * 0.65f
  val trapW = totalW * 0.30f
  val trapLeft = padLeft + waveW + totalW * 0.05f

  // Millimeter grid for wave
  for (i in 0..10) {
    val x = padLeft + waveW * (i / 10f)
    drawLine(color = gridSubColor, start = Offset(x, padTop), end = Offset(x, padTop + totalH), strokeWidth = 1f)
  }
  for (i in 0..6) {
    val y = padTop + totalH * (i / 6f)
    drawLine(color = gridSubColor, start = Offset(padLeft, y), end = Offset(padLeft + waveW, y), strokeWidth = 1f)
  }

  val centerY = padTop + totalH * 0.5f

  // Axes
  drawLine(color = onSurfaceColor, start = Offset(padLeft, centerY), end = Offset(padLeft + waveW, centerY), strokeWidth = 2f)
  drawLine(color = onSurfaceColor, start = Offset(padLeft, padTop), end = Offset(padLeft, padTop + totalH), strokeWidth = 2f)

  // AM signal parameters: m = 0.50, U0 = 4V, Sm = 2V => Umax = 6V, Umin = 2V
  // Envelope paths (upper and lower in dashed red)
  val envUpper = Path()
  val envLower = Path()
  val wavePath = Path()
  val steps = 200

  for (i in 0..steps) {
    val norm = i / steps.toFloat()
    val t = norm * 4f // 4 periods of LF audio
    val env = 1f + 0.5f * cos(2f * Math.PI.toFloat() * t) // varies from 0.5 to 1.5 (scaled)
    val carrier = cos(2f * Math.PI.toFloat() * t * 12f) // HF carrier (12x higher)

    val yEnvUpper = centerY - totalH * 0.28f * env
    val yEnvLower = centerY + totalH * 0.28f * env
    val yWave = centerY - totalH * 0.28f * env * carrier
    val px = padLeft + waveW * norm

    if (i == 0) {
      envUpper.moveTo(px, yEnvUpper)
      envLower.moveTo(px, yEnvLower)
      wavePath.moveTo(px, yWave)
    } else {
      envUpper.lineTo(px, yEnvUpper)
      envLower.lineTo(px, yEnvLower)
      wavePath.lineTo(px, yWave)
    }
  }

  // Draw HF carrier inside
  drawPath(path = wavePath, color = primaryColor, style = Stroke(width = 1.8f))

  // Draw envelopes
  drawPath(
    path = envUpper,
    color = Color(0xFFD32F2F),
    style = Stroke(width = 2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
  )
  drawPath(
    path = envLower,
    color = Color(0xFFD32F2F),
    style = Stroke(width = 2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
  )

  // Trapezoid (Mode XY) on the right side
  // Background card for Mode XY
  drawRoundRect(
    color = Color(0xFF263238).copy(alpha = 0.08f),
    topLeft = Offset(trapLeft, padTop),
    size = Size(trapW, totalH),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
  )

  // Trapezoid vertices
  val trapCenterY = padTop + totalH * 0.5f
  val tHMax = totalH * 0.42f
  val tHMin = totalH * 0.14f
  val trapPath = Path().apply {
    moveTo(trapLeft + trapW * 0.15f, trapCenterY - tHMin)
    lineTo(trapLeft + trapW * 0.85f, trapCenterY - tHMax)
    lineTo(trapLeft + trapW * 0.85f, trapCenterY + tHMax)
    lineTo(trapLeft + trapW * 0.15f, trapCenterY + tHMin)
    close()
  }
  drawPath(path = trapPath, color = Color(0xFF388E3C).copy(alpha = 0.25f))
  drawPath(path = trapPath, color = Color(0xFF2E7D32), style = Stroke(width = 3.5f))

  // Native Canvas annotations
  drawContext.canvas.nativeCanvas.apply {
    val paint = Paint().apply {
      isAntiAlias = true
      typeface = Typeface.DEFAULT_BOLD
      textSize = 17f
      color = AndroidColor.rgb(211, 47, 47)
    }
    drawText("U_max = 6.0 V", padLeft + 15f, centerY - totalH * 0.40f, paint)
    drawText("U_min = 2.0 V", padLeft + waveW * 0.35f, centerY - totalH * 0.16f, paint)

    paint.color = AndroidColor.rgb(46, 125, 50)
    paint.textSize = 16f
    drawText("Mode XY : Trapèze", trapLeft + 10f, padTop + 22f, paint)

    paint.typeface = Typeface.DEFAULT
    paint.textSize = 14f
    paint.color = AndroidColor.BLACK
    drawText("m = (Umax - Umin)/(Umax + Umin)", trapLeft + 5f, padTop + totalH - 24f, paint)
    paint.typeface = Typeface.DEFAULT_BOLD
    drawText("m = 0.50 < 1 (Bonne modulation)", trapLeft + 5f, padTop + totalH - 6f, paint)
  }

  // Touch Cursor on waveform
  drawTouchCursorHelper(touchNormX, padLeft, padTop, waveW, totalH, primaryColor) { normX ->
    val t = normX * 4f
    val env = 1f + 0.5f * cos(2f * Math.PI.toFloat() * t)
    0.5f + 0.28f * env
  }
}

internal fun DrawScope.drawNewtonCinematique(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padRight = 20f
  val padTop = 30f
  val padBottom = 40f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  // Millimeter grid
  val xTicks = 10
  for (i in 0..xTicks) {
    val x = padLeft + chartW * (i / xTicks.toFloat())
    drawLine(color = gridSubColor, start = Offset(x, padTop), end = Offset(x, padTop + chartH), strokeWidth = 1f)
  }
  val yTicks = 6
  for (i in 0..yTicks) {
    val y = padTop + chartH * (i / yTicks.toFloat())
    drawLine(color = gridSubColor, start = Offset(padLeft, y), end = Offset(padLeft + chartW, y), strokeWidth = 1f)
  }

  // Axes: t in [0, 10 s], v in [0, 12 m/s]
  drawLine(color = onSurfaceColor, start = Offset(padLeft, padTop + chartH), end = Offset(padLeft + chartW, padTop + chartH), strokeWidth = 2.5f)
  drawLine(color = onSurfaceColor, start = Offset(padLeft, padTop), end = Offset(padLeft, padTop + chartH), strokeWidth = 2.5f)

  // Speed profile function:
  // Phase 1 (0 to 4s): acceleration a1 = 2.5 m/s² (0 -> 10 m/s)
  // Phase 2 (4 to 7s): MRU v = 10 m/s
  // Phase 3 (7 to 9s): deceleration a3 = -5.0 m/s² (10 -> 0 m/s)
  // Phase 4 (9 to 10s): v = 0 m/s
  fun getVelocity(t: Float): Float {
    return when {
      t <= 4f -> 2.5f * t
      t <= 7f -> 10f
      t <= 9f -> 10f - 5.0f * (t - 7f)
      else -> 0f
    }
  }

  // Shaded area under curve (distance traveled d = 20 + 30 + 10 = 60 m)
  val areaPath = Path().apply {
    moveTo(padLeft, padTop + chartH)
    val steps = 80
    for (i in 0..steps) {
      val t = (i / steps.toFloat()) * 10f
      val v = getVelocity(t)
      val px = padLeft + chartW * (t / 10f)
      val py = padTop + chartH * (1f - v / 12f)
      lineTo(px, py)
    }
    lineTo(padLeft + chartW * (9f / 10f), padTop + chartH)
    close()
  }
  drawPath(path = areaPath, color = primaryColor.copy(alpha = 0.15f))

  // Main velocity line
  val vLine = Path().apply {
    moveTo(padLeft, padTop + chartH)
    lineTo(padLeft + chartW * (4f / 10f), padTop + chartH * (1f - 10f / 12f))
    lineTo(padLeft + chartW * (7f / 10f), padTop + chartH * (1f - 10f / 12f))
    lineTo(padLeft + chartW * (9f / 10f), padTop + chartH)
    lineTo(padLeft + chartW, padTop + chartH)
  }
  drawPath(path = vLine, color = primaryColor, style = Stroke(width = 4f))

  // Notable points and slope tangent markers
  if (showNotablePoints) {
    val p1 = Offset(padLeft + chartW * (4f / 10f), padTop + chartH * (1f - 10f / 12f))
    val p2 = Offset(padLeft + chartW * (7f / 10f), padTop + chartH * (1f - 10f / 12f))
    val p3 = Offset(padLeft + chartW * (9f / 10f), padTop + chartH)

    drawCircle(color = Color(0xFF2E7D32), radius = 6f, center = p1)
    drawCircle(color = Color(0xFF1565C0), radius = 6f, center = p2)
    drawCircle(color = Color(0xFFD32F2F), radius = 6f, center = p3)
  }

  drawContext.canvas.nativeCanvas.apply {
    val paint = Paint().apply {
      isAntiAlias = true
      typeface = Typeface.DEFAULT_BOLD
      textSize = 18f
      color = AndroidColor.rgb(21, 101, 192)
    }
    drawText("v (m·s⁻¹)", padLeft + 10f, padTop + 20f, paint)
    drawText("t (s)", padLeft + chartW - 35f, padTop + chartH - 10f, paint)

    paint.textSize = 15f
    paint.color = AndroidColor.BLACK
    paint.typeface = Typeface.DEFAULT
    drawText("10", padLeft - 24f, padTop + chartH * (1f - 10f / 12f) + 6f, paint)
    drawText("4s", padLeft + chartW * 0.4f - 12f, padTop + chartH + 20f, paint)
    drawText("7s", padLeft + chartW * 0.7f - 12f, padTop + chartH + 20f, paint)
    drawText("9s", padLeft + chartW * 0.9f - 12f, padTop + chartH + 20f, paint)

    // Phase annotations
    paint.typeface = Typeface.DEFAULT_BOLD
    paint.textSize = 16f
    paint.color = AndroidColor.rgb(46, 125, 50)
    drawText("Phase 1 : a₁ = +2.5 m·s⁻²", padLeft + chartW * 0.06f, padTop + chartH * 0.50f, paint)

    paint.color = AndroidColor.rgb(21, 101, 192)
    drawText("Phase 2 : a₂ = 0", padLeft + chartW * 0.44f, padTop + chartH * 0.12f, paint)

    paint.color = AndroidColor.rgb(198, 40, 40)
    drawText("Phase 3 : a₃ = -5.0 m·s⁻²", padLeft + chartW * 0.64f, padTop + chartH * 0.50f, paint)

    paint.color = AndroidColor.rgb(66, 66, 66)
    drawText("Distance totale = Aire = 60 m", padLeft + chartW * 0.32f, padTop + chartH * 0.78f, paint)
  }

  drawTouchCursorHelper(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 10f
    getVelocity(t) / 12f
  }
}

internal fun DrawScope.drawSatelliteKepler(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color
) {
  val cx = size.width * 0.42f
  val cy = size.height * 0.50f
  val rEarth = 38f
  val rGeo = 115f
  val rLeo = 58f

  // Equatorial reference plane
  drawLine(
    color = onSurfaceColor.copy(alpha = 0.3f),
    start = Offset(cx - rGeo - 30f, cy),
    end = Offset(cx + rGeo + 30f, cy),
    strokeWidth = 1.5f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
  )

  // Geostationary orbit circle
  drawCircle(
    color = Color(0xFF1E88E5),
    radius = rGeo,
    center = Offset(cx, cy),
    style = Stroke(width = 2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)))
  )

  // LEO orbit circle
  drawCircle(
    color = Color(0xFF78909C),
    radius = rLeo,
    center = Offset(cx, cy),
    style = Stroke(width = 1.5f)
  )

  // Earth drawing
  drawCircle(color = Color(0xFF1976D2), radius = rEarth, center = Offset(cx, cy))
  drawCircle(color = Color(0xFF43A047), radius = rEarth * 0.65f, center = Offset(cx - 8f, cy - 6f))
  drawCircle(color = Color.White.copy(alpha = 0.35f), radius = rEarth, center = Offset(cx, cy), style = Stroke(width = 2f))

  // Satellite position on geostationary orbit
  val satAngle = -Math.PI.toFloat() * 0.35f
  val satX = cx + rGeo * cos(satAngle)
  val satY = cy + rGeo * sin(satAngle)

  // Gravitational force vector (centripetal, towards Earth center)
  val dirX = (cx - satX) / rGeo
  val dirY = (cy - satY) / rGeo
  val forceLen = 42f
  drawLine(
    color = Color(0xFFD32F2F),
    start = Offset(satX, satY),
    end = Offset(satX + dirX * forceLen, satY + dirY * forceLen),
    strokeWidth = 3.5f
  )

  // Frenet vector u (tangential velocity)
  val tanX = -dirY
  val tanY = dirX
  val vLen = 35f
  drawLine(
    color = Color(0xFF2E7D32),
    start = Offset(satX, satY),
    end = Offset(satX + tanX * vLen, satY + tanY * vLen),
    strokeWidth = 3f
  )

  // Satellite body
  drawCircle(color = Color(0xFFFFB300), radius = 7f, center = Offset(satX, satY))
  drawCircle(color = Color.Black, radius = 2f, center = Offset(satX, satY))
  // Solar panels
  drawLine(
    color = Color(0xFF0288D1),
    start = Offset(satX - dirY * 12f, satY + dirX * 12f),
    end = Offset(satX + dirY * 12f, satY - dirX * 12f),
    strokeWidth = 3f
  )

  // Inset panel for 3rd law of Kepler
  val panelLeft = size.width * 0.70f
  val panelTop = size.height * 0.12f
  val panelW = size.width * 0.28f
  val panelH = size.height * 0.76f

  drawRoundRect(
    color = Color(0xFFECEFF1),
    topLeft = Offset(panelLeft, panelTop),
    size = Size(panelW, panelH),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
  )

  drawContext.canvas.nativeCanvas.apply {
    val paint = Paint().apply {
      isAntiAlias = true
      typeface = Typeface.DEFAULT_BOLD
      textSize = 16f
      color = AndroidColor.rgb(21, 101, 192)
    }
    drawText("Terre (M_T, R_T)", cx - 45f, cy + rEarth + 18f, paint)

    paint.color = AndroidColor.rgb(198, 40, 40)
    drawText("Force F_g", satX - 60f, satY - 10f, paint)

    paint.color = AndroidColor.rgb(46, 125, 50)
    drawText("Vitesse v", satX + 10f, satY - 20f, paint)

    paint.color = AndroidColor.rgb(2, 136, 209)
    paint.textSize = 15f
    drawText("Orbite géostationnaire", cx - 70f, cy - rGeo - 8f, paint)
    drawText("(h ≈ 36 000 km)", cx - 45f, cy - rGeo + 12f, paint)

    // Kepler panel content
    paint.color = AndroidColor.BLACK
    paint.typeface = Typeface.DEFAULT_BOLD
    paint.textSize = 15f
    drawText("3ème Loi de Kepler", panelLeft + 8f, panelTop + 24f, paint)

    paint.typeface = Typeface.DEFAULT
    paint.textSize = 13.5f
    drawText("T² / r³ = 4π²/(G·M_T)", panelLeft + 8f, panelTop + 50f, paint)
    drawText("= Constante", panelLeft + 8f, panelTop + 70f, paint)

    paint.color = AndroidColor.rgb(69, 90, 100)
    drawText("v = √(G·M_T / r)", panelLeft + 8f, panelTop + 105f, paint)
    drawText("T = 86 164 s (1 j)", panelLeft + 8f, panelTop + 130f, paint)
    drawText("Plan équatorial", panelLeft + 8f, panelTop + 155f, paint)
  }
}

internal fun DrawScope.drawRotationSolide(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val totalW = size.width
  val totalH = size.height

  // Left side: Schematic of pulley + falling mass (40% width)
  val schW = totalW * 0.40f
  val schCx = schW * 0.48f
  val schCy = totalH * 0.38f
  val rPulley = 45f

  // Pulley disk
  drawCircle(color = Color(0xFF78909C), radius = rPulley, center = Offset(schCx, schCy))
  drawCircle(color = Color(0xFFCFD8DC), radius = rPulley * 0.75f, center = Offset(schCx, schCy))
  drawCircle(color = Color(0xFF37474F), radius = 6f, center = Offset(schCx, schCy)) // rotation axis (Δ)

  // Thread hanging from the right rim of pulley
  val threadX = schCx + rPulley
  val massTop = schCy + 60f
  val massW = 32f
  val massH = 26f
  drawLine(color = Color(0xFF455A64), start = Offset(threadX, schCy), end = Offset(threadX, massTop), strokeWidth = 2.5f)

  // Suspended solid (S)
  drawRoundRect(
    color = Color(0xFFFFB300),
    topLeft = Offset(threadX - massW * 0.5f, massTop),
    size = Size(massW, massH),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
  )

  // Force vectors
  // Weight P downwards
  val arrowP = 36f
  val massCenter = Offset(threadX, massTop + massH * 0.5f)
  drawLine(color = Color(0xFFD32F2F), start = massCenter, end = Offset(massCenter.x, massCenter.y + arrowP), strokeWidth = 3f)

  // Right side: Graph of angular velocity ω(t) = θ'' · t (60% width)
  val padLeft = schW + 35f
  val padRight = 15f
  val padTop = 30f
  val padBottom = 40f
  val chartW = totalW - padLeft - padRight
  val chartH = totalH - padTop - padBottom

  // Millimeter grid for ω(t)
  for (i in 0..8) {
    val x = padLeft + chartW * (i / 8f)
    drawLine(color = gridSubColor, start = Offset(x, padTop), end = Offset(x, padTop + chartH), strokeWidth = 1f)
  }
  for (i in 0..5) {
    val y = padTop + chartH * (i / 5f)
    drawLine(color = gridSubColor, start = Offset(padLeft, y), end = Offset(padLeft + chartW, y), strokeWidth = 1f)
  }

  // Axes
  drawLine(color = onSurfaceColor, start = Offset(padLeft, padTop + chartH), end = Offset(padLeft + chartW, padTop + chartH), strokeWidth = 2.5f)
  drawLine(color = onSurfaceColor, start = Offset(padLeft, padTop), end = Offset(padLeft, padTop + chartH), strokeWidth = 2.5f)

  // Linear graph ω = θ'' · t with θ'' = 43.6 rad/s² over t in [0, 2.5 s], ω in [0, 110 rad/s]
  val pathOmega = Path().apply {
    moveTo(padLeft, padTop + chartH)
    val steps = 40
    for (i in 0..steps) {
      val t = (i / steps.toFloat()) * 2.5f
      val omega = 43.56f * t
      val px = padLeft + chartW * (t / 2.5f)
      val py = padTop + chartH * (1f - omega / 110f)
      lineTo(px, py)
    }
  }
  drawPath(path = pathOmega, color = Color(0xFF1E88E5), style = Stroke(width = 4f))

  drawContext.canvas.nativeCanvas.apply {
    val paint = Paint().apply {
      isAntiAlias = true
      typeface = Typeface.DEFAULT_BOLD
      textSize = 17f
      color = AndroidColor.rgb(30, 136, 229)
    }
    drawText("Poulie (J_Δ, R)", schCx - 40f, schCy - rPulley - 10f, paint)
    drawText("Solide (S)", threadX + 20f, massTop + 18f, paint)

    paint.color = AndroidColor.rgb(198, 40, 40)
    drawText("P = m·g", threadX + 6f, massCenter.y + arrowP + 5f, paint)

    paint.color = AndroidColor.rgb(21, 101, 192)
    drawText("ω (rad·s⁻¹)", padLeft + 10f, padTop + 20f, paint)
    drawText("t (s)", padLeft + chartW - 30f, padTop + chartH - 10f, paint)

    paint.textSize = 15f
    paint.color = AndroidColor.BLACK
    drawText("87.1", padLeft - 34f, padTop + chartH * (1f - 87.1f / 110f) + 5f, paint)
    drawText("2.0 s", padLeft + chartW * (2f / 2.5f) - 15f, padTop + chartH + 20f, paint)

    paint.color = AndroidColor.rgb(46, 125, 50)
    paint.typeface = Typeface.DEFAULT_BOLD
    paint.textSize = 15f
    drawText("θ'' = (m·g·R)/(J_Δ + mR²)", padLeft + 15f, padTop + chartH * 0.42f, paint)
    drawText("θ'' = 43.6 rad·s⁻² (Cte)", padLeft + 15f, padTop + chartH * 0.54f, paint)
  }

  drawTouchCursorHelper(touchNormX, padLeft, padTop, chartW, chartH, Color(0xFF1E88E5)) { normX ->
    val t = normX * 2.5f
    (43.56f * t) / 110f
  }
}

internal fun DrawScope.drawOscillateurPendule(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val totalW = size.width
  val totalH = size.height

  val curveW = totalW * 0.62f
  val resW = totalW * 0.32f
  val resLeft = curveW + totalW * 0.05f

  val padLeft = 45f
  val padTop = 30f
  val padBottom = 35f
  val chartH = totalH - padTop - padBottom

  // Millimeter grid for x(t)
  for (i in 0..10) {
    val x = padLeft + (curveW - padLeft) * (i / 10f)
    drawLine(color = gridSubColor, start = Offset(x, padTop), end = Offset(x, padTop + chartH), strokeWidth = 1f)
  }
  for (i in 0..6) {
    val y = padTop + chartH * (i / 6f)
    drawLine(color = gridSubColor, start = Offset(padLeft, y), end = Offset(curveW, y), strokeWidth = 1f)
  }

  val centerY = padTop + chartH * 0.5f

  // Axes for x(t)
  drawLine(color = onSurfaceColor, start = Offset(padLeft, centerY), end = Offset(curveW, centerY), strokeWidth = 2f)
  drawLine(color = onSurfaceColor, start = Offset(padLeft, padTop), end = Offset(padLeft, padTop + chartH), strokeWidth = 2f)

  // Sinusoidal curve: x(t) = Xm · cos(2π t / T0), Xm = 4 cm, T0 = 0.40 s (show 2.5 periods)
  val pathX = Path()
  val steps = 120
  val plotW = curveW - padLeft

  for (i in 0..steps) {
    val norm = i / steps.toFloat()
    val t = norm * 1.0f // 1.0 second = 2.5 periods of 0.40s
    val xVal = 4f * cos(2f * Math.PI.toFloat() * t / 0.40f) // varies in [-4, 4] cm
    val px = padLeft + plotW * norm
    val py = centerY - (chartH * 0.40f) * (xVal / 4f)
    if (i == 0) pathX.moveTo(px, py) else pathX.lineTo(px, py)
  }
  drawPath(path = pathX, color = Color(0xFF1E88E5), style = Stroke(width = 3.5f))

  // Amplitude limits +Xm and -Xm
  val yMax = centerY - chartH * 0.40f
  val yMin = centerY + chartH * 0.40f
  drawLine(
    color = Color(0xFFD32F2F),
    start = Offset(padLeft, yMax),
    end = Offset(curveW, yMax),
    strokeWidth = 1.5f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
  )
  drawLine(
    color = Color(0xFFD32F2F),
    start = Offset(padLeft, yMin),
    end = Offset(curveW, yMin),
    strokeWidth = 1.5f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
  )

  // Resonance curve on the right
  drawRoundRect(
    color = Color(0xFFF5F5F5),
    topLeft = Offset(resLeft, padTop),
    size = Size(resW, chartH),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
  )

  // Resonance peak path
  val resPath = Path()
  val rSteps = 60
  for (i in 0..rSteps) {
    val norm = i / rSteps.toFloat()
    val f = 1f + norm * 3f // freq in [1, 4 Hz], peak at f0 = 2.5 Hz
    val deltaF = f - 2.5f
    val amp = 1f / (1f + 16f * deltaF * deltaF) // resonance bell curve
    val px = resLeft + resW * norm
    val py = padTop + chartH * (1f - amp * 0.85f)
    if (i == 0) resPath.moveTo(px, py) else resPath.lineTo(px, py)
  }
  drawPath(path = resPath, color = Color(0xFF2E7D32), style = Stroke(width = 3f))

  drawContext.canvas.nativeCanvas.apply {
    val paint = Paint().apply {
      isAntiAlias = true
      typeface = Typeface.DEFAULT_BOLD
      textSize = 17f
      color = AndroidColor.rgb(30, 136, 229)
    }
    drawText("x(t) (cm)", padLeft + 10f, padTop + 20f, paint)

    paint.color = AndroidColor.rgb(211, 47, 47)
    paint.textSize = 15f
    drawText("+X_m = 4 cm", padLeft + plotW * 0.45f, yMax - 8f, paint)
    drawText("-X_m = -4 cm", padLeft + plotW * 0.45f, yMin + 20f, paint)

    paint.color = AndroidColor.rgb(46, 125, 50)
    paint.textSize = 16f
    drawText("Résonance", resLeft + 10f, padTop + 22f, paint)

    paint.typeface = Typeface.DEFAULT
    paint.textSize = 14f
    paint.color = AndroidColor.BLACK
    drawText("Pic à f₀ = 2.5 Hz", resLeft + 10f, padTop + 45f, paint)
    drawText("T₀ = 2π√(m/K) = 0.40s", resLeft + 5f, padTop + chartH - 10f, paint)
  }

  drawTouchCursorHelper(touchNormX, padLeft, padTop, plotW, chartH, Color(0xFF1E88E5)) { normX ->
    val t = normX * 1.0f
    val xVal = 4f * cos(2f * Math.PI.toFloat() * t / 0.40f)
    0.5f + 0.40f * (xVal / 4f)
  }
}

internal fun DrawScope.drawOscillateurEnergie(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padRight = 20f
  val padTop = 30f
  val padBottom = 40f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  // Millimeter grid
  val xTicks = 10
  for (i in 0..xTicks) {
    val x = padLeft + chartW * (i / xTicks.toFloat())
    drawLine(color = gridSubColor, start = Offset(x, padTop), end = Offset(x, padTop + chartH), strokeWidth = 1f)
  }
  val yTicks = 6
  for (i in 0..yTicks) {
    val y = padTop + chartH * (i / yTicks.toFloat())
    drawLine(color = gridSubColor, start = Offset(padLeft, y), end = Offset(padLeft + chartW, y), strokeWidth = 1f)
  }

  val centerX = padLeft + chartW * 0.5f
  val bottomY = padTop + chartH

  // Axes: X = élongation x in [-4, +4 cm], Y = Énergie in [0, 25 mJ]
  drawLine(color = onSurfaceColor, start = Offset(padLeft, bottomY), end = Offset(padLeft + chartW, bottomY), strokeWidth = 2.5f)
  drawLine(color = onSurfaceColor, start = Offset(centerX, padTop), end = Offset(centerX, bottomY), strokeWidth = 2f)

  val emJ = 20f // Em = 20 mJ = cte
  val yEm = padTop + chartH * (1f - emJ / 25f)

  // Curve 1: Mechanical energy Em = constant line (green)
  drawLine(
    color = Color(0xFF2E7D32),
    start = Offset(padLeft + chartW * 0.10f, yEm),
    end = Offset(padLeft + chartW * 0.90f, yEm),
    strokeWidth = 3.5f
  )

  // Curve 2: Potential energy E_pe(x) = 1/2 K x² (parabola opening UP)
  val pathEpe = Path()
  // Curve 3: Kinetic energy E_c(x) = Em - 1/2 K x² (parabola opening DOWN)
  val pathEc = Path()

  val steps = 100
  val xSpan = chartW * 0.80f
  val startX = padLeft + chartW * 0.10f

  for (i in 0..steps) {
    val norm = (i / steps.toFloat()) * 2f - 1f // in [-1, +1]
    val epe = emJ * norm * norm // 0 at center, Em at ±Xm
    val ec = emJ * (1f - norm * norm)

    val px = centerX + (xSpan * 0.5f) * norm
    val pyEpe = padTop + chartH * (1f - epe / 25f)
    val pyEc = padTop + chartH * (1f - ec / 25f)

    if (i == 0) {
      pathEpe.moveTo(px, pyEpe)
      pathEc.moveTo(px, pyEc)
    } else {
      pathEpe.lineTo(px, pyEpe)
      pathEc.lineTo(px, pyEc)
    }
  }

  drawPath(path = pathEpe, color = Color(0xFFD32F2F), style = Stroke(width = 3.5f))
  drawPath(path = pathEc, color = Color(0xFF1976D2), style = Stroke(width = 3.5f))

  // Equipartition points: E_c = E_pe = Em / 2 at x = ± Xm / √2 ≈ ± 0.707 Xm
  if (showNotablePoints) {
    val yHalf = padTop + chartH * (1f - (emJ * 0.5f) / 25f)
    val xPos1 = centerX - (xSpan * 0.5f) * 0.707f
    val xPos2 = centerX + (xSpan * 0.5f) * 0.707f

    drawCircle(color = Color(0xFFFF9800), radius = 6f, center = Offset(xPos1, yHalf))
    drawCircle(color = Color(0xFFFF9800), radius = 6f, center = Offset(xPos2, yHalf))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xPos1, yHalf))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xPos2, yHalf))
  }

  drawContext.canvas.nativeCanvas.apply {
    val paint = Paint().apply {
      isAntiAlias = true
      typeface = Typeface.DEFAULT_BOLD
      textSize = 17f
    }

    paint.color = AndroidColor.rgb(46, 125, 50)
    drawText("E_m = 20 mJ (Constante)", centerX - 70f, yEm - 10f, paint)

    paint.color = AndroidColor.rgb(211, 47, 47)
    drawText("E_pe(x) = ½ K x²", centerX + 30f, padTop + chartH * 0.62f, paint)

    paint.color = AndroidColor.rgb(25, 118, 210)
    drawText("E_c(x) = ½ m v²", centerX - 120f, padTop + chartH * 0.38f, paint)

    paint.color = AndroidColor.BLACK
    paint.textSize = 15f
    paint.typeface = Typeface.DEFAULT
    drawText("-X_m", startX - 15f, bottomY + 22f, paint)
    drawText("0", centerX - 5f, bottomY + 22f, paint)
    drawText("+X_m", startX + xSpan - 15f, bottomY + 22f, paint)
    drawText("x (cm)", padLeft + chartW - 25f, bottomY - 8f, paint)

    paint.color = AndroidColor.rgb(230, 81, 0)
    paint.typeface = Typeface.DEFAULT_BOLD
    drawText("Équipartition : x = ± X_m / √2", centerX - 90f, bottomY - 10f, paint)
  }

  drawTouchCursorHelper(touchNormX, padLeft, padTop, chartW, chartH, Color(0xFF2E7D32)) { normX ->
    // normX in [0, 1] maps to [-1, 1] relative to center
    val norm = (normX - 0.5f) * 2f
    val epe = emJ * norm * norm
    epe / 25f
  }
}

private fun DrawScope.drawTouchCursorHelper(
  touchNormX: Float?,
  padLeft: Float,
  padTop: Float,
  chartW: Float,
  chartH: Float,
  color: Color,
  normYCalculator: (Float) -> Float
) {
  if (touchNormX == null) return

  val cx = padLeft + chartW * touchNormX
  val cyNorm = normYCalculator(touchNormX).coerceIn(0f, 1f)
  val cy = padTop + chartH * (1f - cyNorm)

  drawLine(
    color = color.copy(alpha = 0.7f),
    start = Offset(cx, padTop),
    end = Offset(cx, padTop + chartH),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
  )
  drawLine(
    color = color.copy(alpha = 0.7f),
    start = Offset(padLeft, cy),
    end = Offset(padLeft + chartW, cy),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
  )

  drawCircle(color = color.copy(alpha = 0.35f), radius = 12f, center = Offset(cx, cy))
  drawCircle(color = color, radius = 6f, center = Offset(cx, cy))
  drawCircle(color = Color.White, radius = 2.5f, center = Offset(cx, cy))
}
