package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SubjectType
import com.example.ui.theme.ScienceGreen
import kotlin.math.roundToInt

data class TopicMasteryItem(
  val id: String,
  val name: String,
  val subject: SubjectType,
  val masteryRate: Float, // 0.0 to 1.0
  val chaptersCount: Int,
  val quizAverage: Double,
  val icon: androidx.compose.ui.graphics.vector.ImageVector
)

data class EvaluationScorePoint(
  val label: String,
  val topic: String,
  val score: Double,
  val maxScore: Double = 20.0,
  val date: String
)

data class ChapterMasteryStatus(
  val id: String,
  val title: String,
  val subject: SubjectType,
  val scorePercent: Int, // 0..100
  val exercisesDone: Int,
  val exercisesTotal: Int
)

/**
 * Visual Analytics Dashboard for student progression through the Moroccan 2BAC curriculum.
 * Features:
 * 1. Native Compose Multi-Ring Circular Progression Gauge (Global, Physics, Chemistry)
 * 2. Mastered Topics Breakdown with comparative visual bars vs. national objectives
 * 3. Interactive Quiz & Evaluation Score Evolution Curve (Canvas Line + Area Gradient with Touch Probe)
 * 4. 25-Chapter Curriculum Mastery Heatmap Matrix
 */
@Composable
fun VisualAnalyticsDashboard(
  modifier: Modifier = Modifier,
  studentName: String = "Élève 2BAC",
  physicsCompleted: Int = 12,
  chemistryCompleted: Int = 8,
  totalCompleted: Int = 20,
  quizAverage: Double = 17.75,
  onNavigateToCourses: () -> Unit = {},
  onNavigateToExercises: () -> Unit = {}
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("Vue d'Ensemble", "Thèmes & Domaines", "Courbe des Notes", "Matrice 26 Chapitres (P1-P16, C1-C10)")

  // Mastered topics data
  val topicItems = remember {
    listOf(
      TopicMasteryItem("top_ondes", "Ondes Mécaniques & Lumineuses", SubjectType.PHYSIQUE, 0.90f, 3, 18.0, Icons.Default.Waves),
      TopicMasteryItem("top_nucl", "Transformations Nucléaires", SubjectType.PHYSIQUE, 0.95f, 2, 19.0, Icons.Default.Biotech),
      TopicMasteryItem("top_elec", "Électricité (RC, RL, RLC)", SubjectType.PHYSIQUE, 0.85f, 4, 17.0, Icons.Default.Bolt),
      TopicMasteryItem("top_meca", "Mécanique de Newton & Satellites", SubjectType.PHYSIQUE, 0.72f, 7, 14.5, Icons.Default.Speed),
      TopicMasteryItem("top_cin", "Cinétique & Suivi Temporel", SubjectType.CHIMIE, 0.88f, 2, 17.5, Icons.Default.HourglassBottom),
      TopicMasteryItem("top_eq", "Équilibre & Sens d'Évolution", SubjectType.CHIMIE, 0.82f, 2, 16.5, Icons.Default.CompareArrows),
      TopicMasteryItem("top_acbas", "Titrage, pH-métrie & Piles", SubjectType.CHIMIE, 0.80f, 3, 16.0, Icons.Default.Science),
      TopicMasteryItem("top_org", "Chimie Organique (Esters)", SubjectType.CHIMIE, 0.70f, 2, 14.0, Icons.Default.LocalFlorist)
    )
  }

  // Quiz & Test Scores Evolution data
  val scoreHistory = remember {
    listOf(
      EvaluationScorePoint("CC1", "Cinétique / Ondes", 16.5, 20.0, "Octobre"),
      EvaluationScorePoint("CC2", "Nucléaire / RC", 17.0, 20.0, "Novembre"),
      EvaluationScorePoint("CC3", "Équilibre / RLC", 18.0, 20.0, "Décembre"),
      EvaluationScorePoint("CC4", "Titrage / Newton", 17.5, 20.0, "Février"),
      EvaluationScorePoint("CC5", "Piles / Pendules", 18.5, 20.0, "Mars"),
      EvaluationScorePoint("CC6", "Esters / Synthèse", 19.0, 20.0, "Avril"),
      EvaluationScorePoint("Blanc 1", "Examen Blanc Régional", 17.25, 20.0, "Mai"),
      EvaluationScorePoint("Blanc 2", "Examen Blanc National", 18.5, 20.0, "Juin")
    )
  }

  // 25-Chapter Mastery Statuses
  val chapterMasteries = remember {
    listOf(
      ChapterMasteryStatus("P1", "Ondes progressives", SubjectType.PHYSIQUE, 92, 4, 4),
      ChapterMasteryStatus("P2", "Ondes périodiques", SubjectType.PHYSIQUE, 88, 3, 3),
      ChapterMasteryStatus("P3", "Propagation lumineuse", SubjectType.PHYSIQUE, 90, 4, 4),
      ChapterMasteryStatus("P4", "Décroissance radioactive", SubjectType.PHYSIQUE, 96, 5, 5),
      ChapterMasteryStatus("P5", "Noyaux, masse & énergie", SubjectType.PHYSIQUE, 94, 3, 3),
      ChapterMasteryStatus("P6", "Dipôle RC", SubjectType.PHYSIQUE, 90, 4, 4),
      ChapterMasteryStatus("P7", "Dipôle RL", SubjectType.PHYSIQUE, 85, 3, 4),
      ChapterMasteryStatus("P8", "Oscillations RLC", SubjectType.PHYSIQUE, 80, 3, 4),
      ChapterMasteryStatus("P9", "Ondes électromagnétiques", SubjectType.PHYSIQUE, 75, 2, 3),
      ChapterMasteryStatus("P10", "Modulation d'amplitude", SubjectType.PHYSIQUE, 70, 2, 3),
      ChapterMasteryStatus("P11", "Lois de Newton", SubjectType.PHYSIQUE, 82, 3, 4),
      ChapterMasteryStatus("P12", "Chute verticale", SubjectType.PHYSIQUE, 78, 3, 4),
      ChapterMasteryStatus("P13", "Mouvements plans", SubjectType.PHYSIQUE, 74, 2, 4),
      ChapterMasteryStatus("P14", "Satellites & planètes", SubjectType.PHYSIQUE, 70, 2, 3),
      ChapterMasteryStatus("P15", "Systèmes oscillants", SubjectType.PHYSIQUE, 68, 2, 4),
      ChapterMasteryStatus("P16", "Aspect énergétique", SubjectType.PHYSIQUE, 65, 2, 4),
      ChapterMasteryStatus("C1", "Suivi temporel cinétique", SubjectType.CHIMIE, 90, 4, 4),
      ChapterMasteryStatus("C2", "Vitesse volumique", SubjectType.CHIMIE, 86, 3, 4),
      ChapterMasteryStatus("C3", "Transformations non totales", SubjectType.CHIMIE, 85, 3, 4),
      ChapterMasteryStatus("C4", "Quotient de réaction", SubjectType.CHIMIE, 82, 3, 4),
      ChapterMasteryStatus("C5", "Dosage acido-basique", SubjectType.CHIMIE, 88, 4, 4),
      ChapterMasteryStatus("C6", "Évolution spontanée", SubjectType.CHIMIE, 80, 3, 4),
      ChapterMasteryStatus("C7", "Piles électrochimiques", SubjectType.CHIMIE, 78, 3, 4),
      ChapterMasteryStatus("C8", "Électrolyse forcée", SubjectType.CHIMIE, 75, 2, 3),
      ChapterMasteryStatus("C9", "Anhydrides & savons", SubjectType.CHIMIE, 74, 3, 3),
      ChapterMasteryStatus("C10", "Catalyse & sélectivité", SubjectType.CHIMIE, 70, 2, 3)
    )
  }

  ElevatedCard(
    modifier = modifier
      .fillMaxWidth()
      .testTag("visual_analytics_dashboard"),
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Header Banner
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.Analytics,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(24.dp)
            )
          }
          Column {
            Text(
              "Tableau de Bord Visuel & Analytics",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              "Progression du programme, maîtrise des thèmes & moyenne QCM",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Surface(
          color = ScienceGreen.copy(alpha = 0.15f),
          shape = RoundedCornerShape(8.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(14.dp))
            Text(
              "Moyenne : ${"%.2f".format(quizAverage)}/20",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = ScienceGreen
            )
          }
        }
      }

      // Tab selector for analytics
      ScrollableTabRow(
        selectedTabIndex = selectedTab,
        edgePadding = 0.dp,
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        modifier = Modifier.clip(RoundedCornerShape(12.dp)),
        divider = {}
      ) {
        tabs.forEachIndexed { index, tabTitle ->
          Tab(
            selected = selectedTab == index,
            onClick = { selectedTab = index },
            text = {
              Text(
                tabTitle,
                fontSize = 12.sp,
                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium
              )
            },
            modifier = Modifier.testTag("analytics_tab_$index")
          )
        }
      }

      // Tab content
      when (selectedTab) {
        0 -> OverviewProgressionTab(
          overallProgress = (totalCompleted.toFloat() / 26f).coerceIn(0f, 1f),
          physicsProgress = (physicsCompleted.toFloat() / 16f).coerceIn(0f, 1f),
          chemistryProgress = (chemistryCompleted.toFloat() / 10f).coerceIn(0f, 1f),
          totalChapters = 26,
          completedChapters = totalCompleted,
          physicsCompleted = physicsCompleted,
          chemistryCompleted = chemistryCompleted,
          onNavigateToCourses = onNavigateToCourses
        )
        1 -> MasteredTopicsTab(topics = topicItems)
        2 -> QuizScoresEvolutionTab(scoreHistory = scoreHistory)
        3 -> ChapterMasteryHeatmapTab(chapters = chapterMasteries)
      }
    }
  }
}

/**
 * Tab 1: Concentric multi-ring circular chart & curriculum summary.
 */
@Composable
private fun OverviewProgressionTab(
  overallProgress: Float,
  physicsProgress: Float,
  chemistryProgress: Float,
  totalChapters: Int,
  completedChapters: Int,
  physicsCompleted: Int,
  chemistryCompleted: Int,
  onNavigateToCourses: () -> Unit
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceAround
    ) {
      // Concentric Multi-Ring Canvas Chart
      val primaryColor = MaterialTheme.colorScheme.primary
      val secondaryColor = MaterialTheme.colorScheme.secondary
      val tertiaryColor = MaterialTheme.colorScheme.tertiary
      val trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)

      Box(
        modifier = Modifier
          .size(150.dp)
          .testTag("concentric_progress_rings"),
        contentAlignment = Alignment.Center
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val strokeWidth = 10.dp.toPx()
          val center = Offset(size.width / 2f, size.height / 2f)

          // Outer Ring: Overall
          val outerRadius = (size.minDimension / 2f) - (strokeWidth / 2f)
          drawCircle(color = trackColor, radius = outerRadius, center = center, style = Stroke(strokeWidth))
          drawArc(
            color = primaryColor,
            startAngle = -90f,
            sweepAngle = overallProgress * 360f,
            useCenter = false,
            topLeft = Offset(center.x - outerRadius, center.y - outerRadius),
            size = Size(outerRadius * 2, outerRadius * 2),
            style = Stroke(strokeWidth, cap = StrokeCap.Round)
          )

          // Middle Ring: Physique
          val midRadius = outerRadius - strokeWidth - 4.dp.toPx()
          drawCircle(color = trackColor, radius = midRadius, center = center, style = Stroke(strokeWidth))
          drawArc(
            color = secondaryColor,
            startAngle = -90f,
            sweepAngle = physicsProgress * 360f,
            useCenter = false,
            topLeft = Offset(center.x - midRadius, center.y - midRadius),
            size = Size(midRadius * 2, midRadius * 2),
            style = Stroke(strokeWidth, cap = StrokeCap.Round)
          )

          // Inner Ring: Chimie
          val innerRadius = midRadius - strokeWidth - 4.dp.toPx()
          drawCircle(color = trackColor, radius = innerRadius, center = center, style = Stroke(strokeWidth))
          drawArc(
            color = tertiaryColor,
            startAngle = -90f,
            sweepAngle = chemistryProgress * 360f,
            useCenter = false,
            topLeft = Offset(center.x - innerRadius, center.y - innerRadius),
            size = Size(innerRadius * 2, innerRadius * 2),
            style = Stroke(strokeWidth, cap = StrokeCap.Round)
          )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "${(overallProgress * 100).roundToInt()}%",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "Programme",
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      // Progress Legends
      Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.widthIn(max = 180.dp)
      ) {
        RingLegendItem(
          label = "Global (2BAC)",
          value = "$completedChapters / $totalChapters (${(overallProgress * 100).roundToInt()}%)",
          color = MaterialTheme.colorScheme.primary
        )
        RingLegendItem(
          label = "Physique (P1..P16)",
          value = "$physicsCompleted / 16 (${(physicsProgress * 100).roundToInt()}%)",
          color = MaterialTheme.colorScheme.secondary
        )
        RingLegendItem(
          label = "Chimie (C1..C10)",
          value = "$chemistryCompleted / 10 (${(chemistryProgress * 100).roundToInt()}%)",
          color = MaterialTheme.colorScheme.tertiary
        )

        FilledTonalButton(
          onClick = onNavigateToCourses,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Poursuivre les cours", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // Key Performance Indicators Row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      KpiStatCard(
        title = "Chapitres Maîtrisés",
        value = "19 / 25",
        subtitle = "76% du cadre officiel",
        icon = Icons.Default.CheckCircle,
        tint = ScienceGreen,
        modifier = Modifier.weight(1f)
      )
      KpiStatCard(
        title = "Moyenne des Quiz",
        value = "17.75 / 20",
        subtitle = "Mention Très Bien",
        icon = Icons.Default.Quiz,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.weight(1f)
      )
      KpiStatCard(
        title = "Exercices Résolus",
        value = "23 / 25",
        subtitle = "92% d'annales faites",
        icon = Icons.Default.EditNote,
        tint = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.weight(1f)
      )
    }
  }
}

@Composable
private fun RingLegendItem(
  label: String,
  value: String,
  color: Color
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Box(
      modifier = Modifier
        .size(10.dp)
        .background(color, CircleShape)
    )
    Column {
      Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
      Text(value, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@Composable
private fun KpiStatCard(
  title: String,
  value: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  tint: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier,
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
    shape = RoundedCornerShape(14.dp)
  ) {
    Column(
      modifier = Modifier.padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
        Text(title, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
      Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = tint, fontWeight = FontWeight.SemiBold)
    }
  }
}

/**
 * Tab 2: Mastered Topics & Domains breakdown with comparative bars.
 */
@Composable
private fun MasteredTopicsTab(
  topics: List<TopicMasteryItem>
) {
  var selectedSubjectFilter by remember { mutableStateOf(SubjectType.ALL) }

  val filteredTopics = remember(selectedSubjectFilter, topics) {
    if (selectedSubjectFilter == SubjectType.ALL) topics
    else topics.filter { it.subject == selectedSubjectFilter }
  }

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        "Niveau de Maîtrise par Domaine :",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold
      )

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(
          selected = selectedSubjectFilter == SubjectType.ALL,
          onClick = { selectedSubjectFilter = SubjectType.ALL },
          label = { Text("Tous (8)", fontSize = 10.sp) }
        )
        FilterChip(
          selected = selectedSubjectFilter == SubjectType.PHYSIQUE,
          onClick = { selectedSubjectFilter = SubjectType.PHYSIQUE },
          label = { Text("Physique (4)", fontSize = 10.sp) }
        )
        FilterChip(
          selected = selectedSubjectFilter == SubjectType.CHIMIE,
          onClick = { selectedSubjectFilter = SubjectType.CHIMIE },
          label = { Text("Chimie (4)", fontSize = 10.sp) }
        )
      }
    }

    filteredTopics.forEach { topic ->
      TopicProgressRow(topic = topic)
    }
  }
}

@Composable
private fun TopicProgressRow(topic: TopicMasteryItem) {
  val percent = (topic.masteryRate * 100).roundToInt()
  val statusColor = when {
    topic.masteryRate >= 0.85f -> ScienceGreen
    topic.masteryRate >= 0.75f -> MaterialTheme.colorScheme.primary
    else -> MaterialTheme.colorScheme.tertiary
  }
  val statusText = when {
    topic.masteryRate >= 0.85f -> "Excellente maîtrise"
    topic.masteryRate >= 0.75f -> "Bien acquis"
    else -> "En progression"
  }

  Surface(
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(topic.icon, contentDescription = null, tint = statusColor, modifier = Modifier.size(18.dp))
          Text(topic.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Surface(
            color = statusColor.copy(alpha = 0.15f),
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              statusText,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = statusColor,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              fontSize = 10.sp
            )
          }

          Text(
            "$percent%",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = statusColor
          )
        }
      }

      // Progress bar
      LinearProgressIndicator(
        progress = { topic.masteryRate },
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = statusColor,
        trackColor = MaterialTheme.colorScheme.surfaceVariant
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          "${topic.chaptersCount} chapitres du programme",
          style = MaterialTheme.typography.labelSmall,
          fontSize = 10.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          "Moyenne QCM : ${topic.quizAverage}/20",
          style = MaterialTheme.typography.labelSmall,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

/**
 * Tab 3: Interactive Quiz & Evaluation Score Evolution Curve (Canvas line chart with area fill).
 */
@Composable
private fun QuizScoresEvolutionTab(
  scoreHistory: List<EvaluationScorePoint>
) {
  var selectedIndex by remember { mutableStateOf<Int?>(scoreHistory.lastIndex) }
  val activePoint = selectedIndex?.let { scoreHistory.getOrNull(it) } ?: scoreHistory.last()

  val averageScore = remember(scoreHistory) { scoreHistory.map { it.score }.average() }

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header Info
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          "Courbe d'Évolution des Notes (CC & Examens Blancs) :",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          "Toucher la courbe pour afficher le détail de l'épreuve",
          style = MaterialTheme.typography.bodySmall,
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.primary
        )
      }

      Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(8.dp)
      ) {
        Text(
          "Moyenne : ${"%.2f".format(averageScore)}/20",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
      }
    }

    // Interactive Curve Canvas
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface

    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(180.dp)
        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
        .pointerInput(scoreHistory) {
          detectTapGestures { offset ->
            val padL = 40f
            val padR = 20f
            val w = size.width - padL - padR
            if (w > 0 && offset.x >= padL && offset.x <= size.width - padR) {
              val fraction = ((offset.x - padL) / w).coerceIn(0f, 1f)
              val idx = (fraction * (scoreHistory.size - 1)).roundToInt()
              selectedIndex = idx.coerceIn(0, scoreHistory.lastIndex)
            }
          }
        }
        .pointerInput(scoreHistory) {
          detectDragGestures { change, _ ->
            val padL = 40f
            val padR = 20f
            val w = size.width - padL - padR
            if (w > 0) {
              val fraction = ((change.position.x - padL) / w).coerceIn(0f, 1f)
              val idx = (fraction * (scoreHistory.size - 1)).roundToInt()
              selectedIndex = idx.coerceIn(0, scoreHistory.lastIndex)
            }
          }
        }
        .testTag("quiz_scores_trend_canvas")
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val padL = 40f
        val padR = 20f
        val padT = 20f
        val padB = 30f
        val chartW = size.width - padL - padR
        val chartH = size.height - padT - padB

        if (chartW <= 0 || chartH <= 0 || scoreHistory.isEmpty()) return@Canvas

        val minScore = 12.0
        val maxScore = 20.0
        val scoreRange = maxScore - minScore

        // Horizontal Grid Lines for 14, 16, 18, 20
        listOf(14.0, 16.0, 18.0, 20.0).forEach { scoreVal ->
          val y = padT + chartH * (1f - ((scoreVal - minScore) / scoreRange).toFloat())
          drawLine(
            color = if (scoreVal == 16.0) ScienceGreen.copy(alpha = 0.5f) else gridColor,
            start = Offset(padL, y),
            end = Offset(size.width - padR, y),
            strokeWidth = if (scoreVal == 16.0) 1.5f else 1f,
            pathEffect = if (scoreVal == 16.0) PathEffect.dashPathEffect(floatArrayOf(10f, 10f)) else null
          )
        }

        // Calculate point coordinates
        val points = scoreHistory.mapIndexed { i, pt ->
          val x = padL + i * (chartW / (scoreHistory.size - 1).coerceAtLeast(1))
          val y = padT + chartH * (1f - ((pt.score - minScore) / scoreRange).toFloat())
          Offset(x, y)
        }

        // Build Area & Line Path
        val linePath = Path()
        val areaPath = Path()

        points.forEachIndexed { i, pt ->
          if (i == 0) {
            linePath.moveTo(pt.x, pt.y)
            areaPath.moveTo(pt.x, padT + chartH)
            areaPath.lineTo(pt.x, pt.y)
          } else {
            val prev = points[i - 1]
            val cx = (prev.x + pt.x) / 2f
            linePath.cubicTo(cx, prev.y, cx, pt.y, pt.x, pt.y)
            areaPath.cubicTo(cx, prev.y, cx, pt.y, pt.x, pt.y)
          }
        }
        areaPath.lineTo(points.last().x, padT + chartH)
        areaPath.close()

        // Draw area gradient
        drawPath(
          path = areaPath,
          brush = Brush.verticalGradient(
            colors = listOf(primaryColor.copy(alpha = 0.35f), Color.Transparent),
            startY = padT,
            endY = padT + chartH
          )
        )

        // Draw smooth line
        drawPath(
          path = linePath,
          color = primaryColor,
          style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Draw points
        points.forEachIndexed { i, pt ->
          val isSelected = i == selectedIndex
          drawCircle(
            color = if (isSelected) secondaryColor else primaryColor,
            radius = if (isSelected) 6.dp.toPx() else 4.dp.toPx(),
            center = pt
          )
          drawCircle(
            color = Color.White,
            radius = if (isSelected) 3.dp.toPx() else 2.dp.toPx(),
            center = pt
          )
        }

        // Target Threshold Label
        val thresholdY = padT + chartH * (1f - ((16.0 - minScore) / scoreRange).toFloat())
        drawLine(
          color = ScienceGreen,
          start = Offset(size.width - padR - 35f, thresholdY),
          end = Offset(size.width - padR, thresholdY),
          strokeWidth = 2f
        )
      }
    }

    // Selected Point Callout Tooltip Card
    Surface(
      color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            "${activePoint.label} · ${activePoint.topic}",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer
          )
          Text(
            "Session de ${activePoint.date} • Coefficient 7",
            style = MaterialTheme.typography.bodySmall,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
          )
        }

        Surface(
          color = MaterialTheme.colorScheme.surface,
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            "${activePoint.score} / 20",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = if (activePoint.score >= 16.0) ScienceGreen else MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
      }
    }
  }
}

/**
 * Tab 4: 25-Chapter Curriculum Mastery Heatmap Matrix.
 */
@Composable
private fun ChapterMasteryHeatmapTab(
  chapters: List<ChapterMasteryStatus>
) {
  var selectedChapter by remember { mutableStateOf<ChapterMasteryStatus?>(chapters.firstOrNull()) }
  var filterCategory by remember { mutableStateOf("Tous") }

  val filteredChapters = remember(filterCategory, chapters) {
    when (filterCategory) {
      "Physique" -> chapters.filter { it.subject == SubjectType.PHYSIQUE }
      "Chimie" -> chapters.filter { it.subject == SubjectType.CHIMIE }
      "Maîtrisé" -> chapters.filter { it.scorePercent >= 80 }
      "À réviser" -> chapters.filter { it.scorePercent < 80 }
      else -> chapters
    }
  }

  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Filter chips
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      listOf("Tous (25)", "Physique", "Chimie", "Maîtrisé (≥80%)", "À réviser").forEach { opt ->
        val cleanLabel = opt.substringBefore(" ")
        FilterChip(
          selected = filterCategory == cleanLabel || (cleanLabel == "Tous" && filterCategory == "Tous"),
          onClick = { filterCategory = cleanLabel },
          label = { Text(opt, fontSize = 10.sp) }
        )
      }
    }

    // Heatmap Grid
    Column(
      modifier = Modifier.fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Text(
        "Cartographie des 25 Chapitres (Toucher pour inspecter) :",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold
      )

      // Chunk chapters in rows of 5
      filteredChapters.chunked(5).forEach { rowChapters ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          rowChapters.forEach { ch ->
            val isSelected = selectedChapter?.id == ch.id
            val chipColor = when {
              ch.scorePercent >= 85 -> ScienceGreen
              ch.scorePercent >= 75 -> MaterialTheme.colorScheme.primary
              else -> MaterialTheme.colorScheme.tertiary
            }

            Surface(
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .clickable { selectedChapter = ch }
                .testTag("heatmap_chip_${ch.id}"),
              color = if (isSelected) chipColor else chipColor.copy(alpha = 0.15f),
              shape = RoundedCornerShape(8.dp),
              border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.onSurface) else BorderStroke(1.dp, chipColor.copy(alpha = 0.4f))
            ) {
              Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
              ) {
                Text(
                  ch.id,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = if (isSelected) Color.White else chipColor
                )
                Text(
                  "${ch.scorePercent}%",
                  fontSize = 9.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
          // Pad empty slots if chunk is less than 5
          repeat(5 - rowChapters.size) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }
    }

    // Detail Callout for selected chapter
    selectedChapter?.let { ch ->
      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  ch.id,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
              Text(ch.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }

            Text(
              "${ch.scorePercent}% Maîtrisé",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = if (ch.scorePercent >= 80) ScienceGreen else MaterialTheme.colorScheme.primary
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              "Exercices faits : ${ch.exercisesDone} / ${ch.exercisesTotal}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              "Matière : ${ch.subject.label}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }
  }
}
