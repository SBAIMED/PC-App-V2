package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CurriculumData
import com.example.data.EvaluationContinuous
import com.example.data.SessionManager
import com.example.data.repository.AppLocalRepository
import com.example.ui.theme.ScienceGreen
import kotlinx.coroutines.launch

@Composable
fun EvaluationsScreen(
  onEvaluationCompleted: (String, Double) -> Unit = { _, _ -> }
) {
  val context = LocalContext.current
  val repository = remember { AppLocalRepository.getInstance(context) }
  val coroutineScope = rememberCoroutineScope()

  var selectedSemester by remember { mutableIntStateOf(1) }
  var activeExamId by remember { mutableStateOf<String?>("cc_s1_c1") }
  val completedEvals = remember { mutableStateMapOf<String, Double>() }
  val attempts by repository.recentQuizAttempts.collectAsStateWithLifecycle(initialValue = emptyList())

  LaunchedEffect(attempts) {
    attempts.forEach { att ->
      completedEvals[att.quizId] = att.score
    }
  }

  val filteredEvaluations = remember(selectedSemester) {
    CurriculumData.evaluations.filter { it.semester == selectedSemester }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("evaluations_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Banner
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        shape = RoundedCornerShape(16.dp)
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Icon(
            Icons.Default.Assessment,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.size(36.dp)
          )
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "Volet 5 : Évaluations Continues",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onTertiaryContainer
            )
            Text(
              "3 Contrôles continus par semestre (6 contrôles par an) avec notation automatique et barèmes ministériels",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
            )
          }
        }
      }
    }

    // Semester Switcher
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        listOf(1, 2).forEach { sem ->
          FilterChip(
            selected = selectedSemester == sem,
            onClick = { selectedSemester = sem },
            label = { Text("Semestre $sem (Contrôles 1, 2, 3)") },
            leadingIcon = if (selectedSemester == sem) {
              { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
            } else null,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // List of the 3 controls of the semester
    items(filteredEvaluations, key = { it.id }) { eval ->
      val isExpanded = activeExamId == eval.id
      val recordedGrade = completedEvals[eval.id]

      EvaluationItemCard(
        evaluation = eval,
        isExpanded = isExpanded,
        recordedGrade = recordedGrade,
        onToggle = { activeExamId = if (isExpanded) null else eval.id },
        onSubmitEvaluation = { grade ->
          completedEvals[eval.id] = grade
          onEvaluationCompleted(eval.id, grade)
          coroutineScope.launch {
            val subj = if (eval.chaptersCovered.any { it.startsWith("P") }) "PHYSIQUE" else "CHIMIE"
            val currentStudentName = SessionManager.getInstance(context).userName.ifBlank { "Élève 2BAC" }
            repository.recordQuizAttempt(
              quizId = eval.id,
              quizTitle = eval.title,
              subject = subj,
              score = grade,
              maxScore = 20.0,
              studentName = currentStudentName
            )
          }
        }
      )
    }
  }
}

@Composable
fun EvaluationItemCard(
  evaluation: EvaluationContinuous,
  isExpanded: Boolean,
  recordedGrade: Double?,
  onToggle: () -> Unit,
  onSubmitEvaluation: (Double) -> Unit
) {
  // Answers tracking for the evaluation
  val selectedAnswers = remember { mutableStateMapOf<String, Int>() }
  var isSubmitted by remember { mutableStateOf(recordedGrade != null) }
  var calculatedGrade by remember { mutableDoubleStateOf(recordedGrade ?: 0.0) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("eval_card_${evaluation.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onToggle() },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Surface(
              color = MaterialTheme.colorScheme.primaryContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                "S${evaluation.semester} • CC${evaluation.number}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
              )
            }
            if (isSubmitted) {
              Surface(
                color = ScienceGreen.copy(alpha = 0.2f),
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  "Note : ${"%.1f".format(calculatedGrade)} / 20",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = ScienceGreen,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(4.dp))
          Text(
            evaluation.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            "Durée officielle : ${evaluation.durationMinutes} min (2h) • Barème /20",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(onClick = onToggle) {
          Icon(if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
        }
      }

      // Chapters covered
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        evaluation.chaptersCovered.forEach { ch ->
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              ch,
              style = MaterialTheme.typography.labelSmall,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }

      AnimatedVisibility(visible = isExpanded) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Rubric details
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp)
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
              Text(
                evaluation.teacherRubric,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          // Questions inside this evaluation
          evaluation.questions.forEachIndexed { qIdx, question ->
            val selOpt = selectedAnswers[question.id]
            val isOptCorrect = selOpt == question.correctOptionIndex

            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                com.example.ui.components.MathFormattedText(
                  text = "Question ${qIdx + 1} : ${question.question}",
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )

                question.options.forEachIndexed { optIdx, optText ->
                  val isSelected = selOpt == optIdx
                  Surface(
                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                      .fillMaxWidth()
                      .clickable(enabled = !isSubmitted) {
                        selectedAnswers[question.id] = optIdx
                      }
                  ) {
                    Row(
                      modifier = Modifier.padding(8.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                      RadioButton(
                        selected = isSelected,
                        onClick = { if (!isSubmitted) selectedAnswers[question.id] = optIdx },
                        enabled = !isSubmitted
                      )
                      com.example.ui.components.MathFormattedText(
                        text = optText,
                        style = MaterialTheme.typography.bodySmall
                      )
                    }
                  }
                }
              }
            }
          }

          // Submission button or result
          if (!isSubmitted) {
            Button(
              onClick = {
                var correctCount = 0
                evaluation.questions.forEach { q ->
                  if (selectedAnswers[q.id] == q.correctOptionIndex) correctCount++
                }
                val grade = if (evaluation.questions.isNotEmpty()) {
                  (correctCount.toDouble() / evaluation.questions.size) * 20.0
                } else 0.0
                calculatedGrade = grade
                isSubmitted = true
                onSubmitEvaluation(grade)
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("submit_eval_${evaluation.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
              Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Valider et soumettre ma copie d'évaluation")
            }
          } else {
            Surface(
              color = ScienceGreen.copy(alpha = 0.15f),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Storage, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(16.dp))
                    Text("Évaluation Corrigée & Notée", fontWeight = FontWeight.Bold, color = ScienceGreen)
                  }
                  Text("Note enregistrée en base locale Room (SQLite)", style = MaterialTheme.typography.bodySmall)
                }
                Text(
                  "${"%.1f".format(calculatedGrade)} / 20",
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = ScienceGreen
                )
              }
            }
          }
        }
      }
    }
  }
}
