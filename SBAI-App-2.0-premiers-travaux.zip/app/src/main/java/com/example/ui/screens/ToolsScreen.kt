package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurriculumData
import com.example.data.PhysicalConstant

@Composable
fun ToolsScreen() {
  var selectedTab by remember { mutableIntStateOf(0) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .testTag("tools_screen")
  ) {
    ScrollableTabRow(
      selectedTabIndex = selectedTab,
      edgePadding = 12.dp
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = { Text("Formulaire") },
        icon = { Icon(Icons.Default.Functions, contentDescription = null, modifier = Modifier.size(18.dp)) }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = { Text("Constantes") },
        icon = { Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(18.dp)) }
      )
      Tab(
        selected = selectedTab == 2,
        onClick = { selectedTab = 2 },
        text = { Text("Calculatrice") },
        icon = { Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(18.dp)) }
      )
      Tab(
        selected = selectedTab == 3,
        onClick = { selectedTab = 3 },
        text = { Text("Assistant IA") },
        icon = { Icon(Icons.Default.Psychology, contentDescription = null, modifier = Modifier.size(18.dp)) }
      )
    }

    when (selectedTab) {
      0 -> FormulaSheetTab()
      1 -> ConstantsTab()
      2 -> ScientificCalculatorTab()
      3 -> AiAssistantTab()
    }
  }
}

@Composable
fun FormulaSheetTab() {
  val formulasByUnit = listOf(
    "Ondes & Optique" to listOf(
      "v = \\frac{d}{\\Delta t} = \\lambda \\cdot N \\quad (\\text{Célérité})",
      "\\tau = \\frac{SM}{v} \\quad (\\text{Retard temporel})",
      "y_M(t) = y_S(t - \\tau) \\quad (\\text{Élongation})",
      "\\theta = \\frac{\\lambda}{a} \\quad (\\text{Diffraction par fente})",
      "L = \\frac{2 \\lambda D}{a} \\quad (\\text{Largeur tache centrale})"
    ),
    "Physique Nucléaire" to listOf(
      "N(t) = N_0 \\cdot e^{-\\lambda t} \\quad (\\text{Décroissance})",
      "t_{1/2} = \\frac{\\ln(2)}{\\lambda} \\approx \\frac{0.693}{\\lambda} \\quad (\\text{Demi-vie})",
      "A(t) = \\lambda N(t) = A_0 e^{-\\lambda t} \\quad (\\text{Activité en Bq})",
      "\\Delta m = [Z m_p + (A-Z) m_n] - m(X)",
      "E_\\ell = \\Delta m \\cdot c^2 \\quad (\\text{Énergie de liaison})"
    ),
    "Électricité & Circuit RLC" to listOf(
      "u_C(t) + R \\cdot C \\frac{du_C}{dt} = E \\quad (\\text{Dipôle RC})",
      "\\tau = R \\cdot C \\quad (\\text{Constante de temps})",
      "u_L(t) = L \\frac{di}{dt} + r \\cdot i \\quad (\\text{Dipôle RL})",
      "T_0 = 2\\pi \\sqrt{L \\cdot C} \\quad (\\text{Période propre RLC})",
      "E_T = \\frac{1}{2} C u_C^2 + \\frac{1}{2} L i^2 \\quad (\\text{Énergie totale})"
    ),
    "Chimie Générale & pH" to listOf(
      "C = \\frac{n}{V} = \\frac{m}{M \\cdot V} \\quad (\\text{Concentration})",
      "\\text{pH} = -\\log[H_3O^+] \\iff [H_3O^+] = 10^{-\\text{pH}}",
      "\\tau = \\frac{x_f}{x_{\\max}} \\quad (\\text{Taux d'avancement})",
      "\\text{pH} = \\text{pK}_a + \\log\\left(\\frac{[A^-]}{[AH]}\\right)",
      "C_a V_a = C_b V_{bE} \\quad (\\text{Équivalence acido-basique})"
    ),
    "Mécanique de Newton" to listOf(
      "\\sum \\vec{F}_{\\text{ext}} = m \\cdot \\vec{a}_G \\quad (\\text{2ème Loi de Newton})",
      "\\vec{a} = \\frac{d\\vec{v}}{dt} = \\frac{d^2\\vec{r}}{dt^2} \\quad (\\text{Accélération})",
      "y(x) = -\\frac{g}{2 v_0^2 \\cos^2(\\alpha)} x^2 + \\tan(\\alpha) x",
      "x_P = \\frac{v_0^2 \\sin(2\\alpha)}{g} \\quad (\\text{Portée maximale})",
      "T_0 = 2\\pi \\sqrt{\\frac{m}{k}} \\quad (\\text{Pendule élastique})"
    )
  )

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    items(formulasByUnit) { (unitName, formulas) ->
      com.example.ui.components.MathJaxFormulaCardList(
        title = unitName,
        formulas = formulas
      )
    }
  }
}

@Composable
fun ConstantsTab() {
  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text("Constantes Fondamentales Officielles", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
          Text("Données conformes aux épreuves du Baccalauréat marocain", style = MaterialTheme.typography.bodySmall)
        }
      }
    }

    items(CurriculumData.physicalConstants) { constItem ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(constItem.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Text("Symbole :", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              com.example.ui.components.NativeMathText(
                formula = constItem.symbol,
                fontSizeSp = 15,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
          Column(horizontalAlignment = Alignment.End) {
            Text(constItem.value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            com.example.ui.components.MathFormattedText(constItem.unit, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }
  }
}

@Composable
fun ScientificCalculatorTab() {
  var displayValue by remember { mutableStateOf("0") }
  var pendingOperator by remember { mutableStateOf<String?>(null) }
  var operand1 by remember { mutableDoubleStateOf(0.0) }
  var clearOnNextDigit by remember { mutableStateOf(false) }

  fun onDigit(d: String) {
    if (clearOnNextDigit || displayValue == "0") {
      displayValue = d
      clearOnNextDigit = false
    } else {
      displayValue += d
    }
  }

  fun onOperator(op: String) {
    operand1 = displayValue.toDoubleOrNull() ?: 0.0
    pendingOperator = op
    clearOnNextDigit = true
  }

  fun onCalculate() {
    val operand2 = displayValue.toDoubleOrNull() ?: 0.0
    val res = when (pendingOperator) {
      "+" -> operand1 + operand2
      "-" -> operand1 - operand2
      "×" -> operand1 * operand2
      "÷" -> if (operand2 != 0.0) operand1 / operand2 else Double.NaN
      "^" -> Math.pow(operand1, operand2)
      else -> operand2
    }
    displayValue = if (res.isNaN()) "Erreur" else "%.4f".format(res).trimEnd('0').trimEnd('.').trimEnd(',')
    pendingOperator = null
    clearOnNextDigit = true
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Screen
    Surface(
      color = Color(0xFF0F172A),
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(100.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          pendingOperator?.let { "$operand1 $it" } ?: "Calculatrice Scientifique",
          color = Color.White.copy(alpha = 0.6f),
          fontSize = 12.sp
        )
        Text(
          displayValue,
          color = Color(0xFF38BDF8),
          fontSize = 32.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.End,
          maxLines = 1
        )
      }
    }

    // Keypad Grid
    val buttons = listOf(
      listOf("C", "ln", "log", "÷"),
      listOf("7", "8", "9", "×"),
      listOf("4", "5", "6", "-"),
      listOf("1", "2", "3", "+"),
      listOf("0", ".", "10^x", "=")
    )

    buttons.forEach { row ->
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        row.forEach { btn ->
          val isOperator = btn in listOf("+", "-", "×", "÷", "=")
          val isAction = btn in listOf("C", "ln", "log", "10^x")

          Surface(
            modifier = Modifier
              .weight(1f)
              .height(54.dp)
              .clickable {
                when (btn) {
                  "C" -> {
                    displayValue = "0"
                    pendingOperator = null
                    operand1 = 0.0
                  }
                  "=" -> onCalculate()
                  in listOf("+", "-", "×", "÷") -> onOperator(btn)
                  "ln" -> {
                    val v = displayValue.toDoubleOrNull() ?: 0.0
                    displayValue = if (v > 0) "%.4f".format(kotlin.math.ln(v)) else "Erreur"
                    clearOnNextDigit = true
                  }
                  "log" -> {
                    val v = displayValue.toDoubleOrNull() ?: 0.0
                    displayValue = if (v > 0) "%.4f".format(kotlin.math.log10(v)) else "Erreur"
                    clearOnNextDigit = true
                  }
                  "10^x" -> {
                    val v = displayValue.toDoubleOrNull() ?: 0.0
                    displayValue = "%.4f".format(Math.pow(10.0, v))
                    clearOnNextDigit = true
                  }
                  "." -> if (!displayValue.contains(".")) displayValue += "."
                  else -> onDigit(btn)
                }
              },
            color = when {
              btn == "=" -> MaterialTheme.colorScheme.primary
              isOperator -> MaterialTheme.colorScheme.primaryContainer
              isAction -> MaterialTheme.colorScheme.secondaryContainer
              else -> MaterialTheme.colorScheme.surfaceVariant
            },
            shape = RoundedCornerShape(12.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(
                btn,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = when {
                  btn == "=" -> Color.White
                  isOperator -> MaterialTheme.colorScheme.onPrimaryContainer
                  isAction -> MaterialTheme.colorScheme.onSecondaryContainer
                  else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun AiAssistantTab() {
  val context = androidx.compose.ui.platform.LocalContext.current
  val hasGeminiKey = remember { com.example.data.FirebaseSafetyManager.isGeminiKeyConfigured() }
  var searchQuery by remember { mutableStateOf("") }

  val predefinedQA = listOf(
    "Comment déterminer le taux d'avancement final ?" to
      "\\tau = \\frac{x_f}{x_{\\max}} \\quad (\\text{Réaction totale : } \\tau = 1, \\text{ Équilibre : } \\tau < 1)",
    "Quelle est la méthode des tangentes pour le circuit RC ?" to
      "u_C(\\tau) = 0{,}63 \\cdot E \\quad \\text{avec } \\tau = R \\cdot C",
    "Comment calculer l'énergie de liaison par nucléon ?" to
      "\\mathcal{E} = \\frac{E_\\ell}{A} = \\frac{\\Delta m \\cdot c^2}{A}",
    "Comment appliquer la 2ème loi de Newton sur un plan incliné ?" to
      "\\vec{P} + \\vec{R} + \\vec{f} = m \\cdot \\vec{a}_G \\implies a_x = g \\cdot \\sin(\\alpha) - \\frac{f}{m}"
  )

  val filteredQA = remember(searchQuery) {
    if (searchQuery.isBlank()) predefinedQA
    else predefinedQA.filter { it.first.contains(searchQuery, ignoreCase = true) || it.second.contains(searchQuery, ignoreCase = true) }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Surface(
        color = if (hasGeminiKey) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Icon(
            imageVector = if (hasGeminiKey) Icons.Default.AutoAwesome else Icons.Default.Info,
            contentDescription = null,
            tint = if (hasGeminiKey) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
          )
          Column {
            Text(
              text = if (hasGeminiKey) "Assistant Pédagogique Gemini IA (En ligne)" else "Mode Local : Base Pédagogique Intégrée",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = if (hasGeminiKey)
                "Clé API Gemini configurée via les Secrets."
              else
                "Clé Gemini optionnelle non requise : toutes les résolutions méthodologiques types et questions pièges du bac sont disponibles en local.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        label = { Text("Rechercher une méthode ou formule clé...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Close, contentDescription = "Effacer")
            }
          }
        },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
      )
    }

    items(filteredQA) { (question, answer) ->
      ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.HelpOutline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(
              text = question,
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
          HorizontalDivider()
          com.example.ui.components.MathJaxView(
            formula = answer,
            modifier = Modifier.fillMaxWidth()
          )
        }
      }
    }
  }
}

