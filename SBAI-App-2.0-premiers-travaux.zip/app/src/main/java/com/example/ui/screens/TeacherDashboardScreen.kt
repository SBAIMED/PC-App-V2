package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CurriculumData
import com.example.data.StudentRecord
import com.example.data.local.entity.StudentRecordEntity
import com.example.data.repository.AppLocalRepository
import com.example.ui.theme.ScienceGreen
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun TeacherDashboardScreen(
  onSendAnnouncement: (String) -> Unit = {}
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val repository = remember { AppLocalRepository.getInstance(context) }
  val dbStudents by repository.allStudentRecords.collectAsStateWithLifecycle(initialValue = emptyList())

  val studentsList = remember(dbStudents) {
    if (dbStudents.isNotEmpty()) {
      dbStudents.map { entity ->
        StudentRecord(
          id = entity.id,
          name = entity.name,
          classGroup = entity.classGroup,
          s1c1 = entity.s1c1,
          s1c2 = entity.s1c2,
          s1c3 = entity.s1c3,
          s2c1 = entity.s2c1,
          s2c2 = entity.s2c2,
          s2c3 = entity.s2c3,
          interactiveScore = entity.interactiveScore,
          exercisesDone = entity.exercisesDone,
          badges = listOf("Élève assidu", "Physique 2BAC")
        )
      }
    } else {
      CurriculumData.initialStudents
    }
  }

  var selectedStudentForEdit by remember { mutableStateOf<StudentRecord?>(null) }
  var showExportDialog by remember { mutableStateOf(false) }
  var exportStatusMessage by remember { mutableStateOf<String?>(null) }
  var announcementText by remember { mutableStateOf("") }

  // Class statistics
  val classAverage = remember(studentsList) {
    studentsList.map { it.overallAverage }.average()
  }
  val passRate = remember(studentsList) {
    val passedCount = studentsList.count { it.overallAverage >= 10.0 }
    (passedCount.toDouble() / studentsList.size) * 100.0
  }
  val highestGrade = remember(studentsList) {
    studentsList.maxOfOrNull { it.overallAverage } ?: 0.0
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("teacher_dashboard_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Banner
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(16.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .background(MaterialTheme.colorScheme.primary, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.School, contentDescription = null, tint = Color.White)
            }
            Column {
              Text(
                "Espace Professeur : Pr. SBAI Mohammed",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
              Text(
                "Tableau de bord de la classe 2ème Bac • Gestion des notes & synchronisation",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
              )
            }
          }
        }
      }
    }

    // Key Stats Row
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Average Card
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text("Moyenne Générale", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "${"%.2f".format(classAverage)} / 20",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }

        // Pass Rate Card
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text("Taux de Réussite", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "${"%.0f".format(passRate)} %",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = ScienceGreen
            )
          }
        }

        // Top Grade Card
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text("Note Maximale", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "${"%.2f".format(highestGrade)} / 20",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.tertiary
            )
          }
        }
      }
    }

    // Cloud Export & Action Buttons
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            "Outils de Gestion & Synchronisation Cloud :",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { showExportDialog = true },
              modifier = Modifier.weight(1f).testTag("btn_export_sheets"),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
              Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Exporter Sheets")
            }

            OutlinedButton(
              onClick = {
                exportStatusMessage = "Google Drive n'est pas encore connecté : aucune donnée n'a été synchronisée."
              },
              modifier = Modifier.weight(1f).testTag("btn_sync_drive")
            ) {
              Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Synchroniser Drive")
            }
          }

          if (exportStatusMessage != null) {
            Surface(
              color = ScienceGreen.copy(alpha = 0.15f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(18.dp))
                Text(exportStatusMessage!!, style = MaterialTheme.typography.bodySmall, color = ScienceGreen)
              }
            }
          }
        }
      }
    }

    // Quick Announcement Publisher
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Diffuser une annonce / consigne à la classe :",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
          )
          OutlinedTextField(
            value = announcementText,
            onValueChange = { announcementText = it },
            placeholder = { Text("Ex: Rappel pour le TP de demain, apportez la calculatrice...") },
            modifier = Modifier.fillMaxWidth().testTag("teacher_announcement_input"),
            maxLines = 3
          )
          Button(
            onClick = {
              if (announcementText.isNotBlank()) {
                onSendAnnouncement(announcementText)
                announcementText = ""
                exportStatusMessage = "Annonce publiée et ajoutée au centre de notifications !"
              }
            },
            enabled = announcementText.isNotBlank(),
            modifier = Modifier.align(Alignment.End).testTag("btn_publish_announcement")
          ) {
            Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Publier l'annonce")
          }
        }
      }
    }

    // Student Gradebook Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          "Carnet de Notes des Élèves (${studentsList.size})",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold
        )
        Text(
          "Cliquez pour modifier les notes",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Student list
    items(studentsList, key = { it.id }) { student ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { selectedStudentForEdit = student }
          .testTag("student_row_${student.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(student.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(
              "S1: ${"%.1f".format(student.averageS1)} | S2: ${"%.1f".format(student.averageS2)} • Score QCM: ${student.interactiveScore} pts",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Surface(
            color = if (student.overallAverage >= 16.0) ScienceGreen.copy(alpha = 0.2f)
            else if (student.overallAverage >= 12.0) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              "${"%.2f".format(student.overallAverage)} / 20",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = if (student.overallAverage >= 16.0) ScienceGreen else MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }
    }
  }

  // Edit Student Notes Dialog
  if (selectedStudentForEdit != null) {
    val student = selectedStudentForEdit!!
    var s1c1Text by remember { mutableStateOf(student.s1c1.toString()) }
    var s1c2Text by remember { mutableStateOf(student.s1c2.toString()) }
    var s1c3Text by remember { mutableStateOf(student.s1c3.toString()) }
    var s2c1Text by remember { mutableStateOf(student.s2c1.toString()) }
    var s2c2Text by remember { mutableStateOf(student.s2c2.toString()) }
    var s2c3Text by remember { mutableStateOf(student.s2c3.toString()) }

    AlertDialog(
      onDismissRequest = { selectedStudentForEdit = null },
      title = { Text("Modifier les notes : ${student.name}") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Semestre 1 (Contrôles 1, 2, 3) :", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
              value = s1c1Text,
              onValueChange = { s1c1Text = it },
              label = { Text("CC1") },
              modifier = Modifier.weight(1f),
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
              value = s1c2Text,
              onValueChange = { s1c2Text = it },
              label = { Text("CC2") },
              modifier = Modifier.weight(1f),
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
              value = s1c3Text,
              onValueChange = { s1c3Text = it },
              label = { Text("CC3") },
              modifier = Modifier.weight(1f),
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
          }

          Text("Semestre 2 (Contrôles 1, 2, 3) :", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
              value = s2c1Text,
              onValueChange = { s2c1Text = it },
              label = { Text("CC1") },
              modifier = Modifier.weight(1f),
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
              value = s2c2Text,
              onValueChange = { s2c2Text = it },
              label = { Text("CC2") },
              modifier = Modifier.weight(1f),
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
              value = s2c3Text,
              onValueChange = { s2c3Text = it },
              label = { Text("CC3") },
              modifier = Modifier.weight(1f),
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val updated = student.copy(
              s1c1 = s1c1Text.toDoubleOrNull() ?: student.s1c1,
              s1c2 = s1c2Text.toDoubleOrNull() ?: student.s1c2,
              s1c3 = s1c3Text.toDoubleOrNull() ?: student.s1c3,
              s2c1 = s2c1Text.toDoubleOrNull() ?: student.s2c1,
              s2c2 = s2c2Text.toDoubleOrNull() ?: student.s2c2,
              s2c3 = s2c3Text.toDoubleOrNull() ?: student.s2c3
            )
            coroutineScope.launch {
              repository.saveStudentRecord(
                StudentRecordEntity(
                  id = updated.id,
                  name = updated.name,
                  classGroup = updated.classGroup,
                  s1c1 = updated.s1c1,
                  s1c2 = updated.s1c2,
                  s1c3 = updated.s1c3,
                  s2c1 = updated.s2c1,
                  s2c2 = updated.s2c2,
                  s2c3 = updated.s2c3,
                  interactiveScore = updated.interactiveScore,
                  exercisesDone = updated.exercisesDone
                )
              )
            }
            selectedStudentForEdit = null
            exportStatusMessage = "Notes de ${student.name} enregistrées en base locale Room avec succès !"
          }
        ) {
          Text("Enregistrer les notes")
        }
      },
      dismissButton = {
        TextButton(onClick = { selectedStudentForEdit = null }) { Text("Annuler") }
      }
    )
  }

  // Google Sheets Export Dialog
  if (showExportDialog) {
    AlertDialog(
      onDismissRequest = { showExportDialog = false },
      title = { Text("Export Google Sheets & MENFP") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Le relevé de notes officiel de la classe 2ème Bac PC sera exporté au format Google Sheets (CSV) avec calcul automatique des moyennes des semestres S1 et S2.",
            style = MaterialTheme.typography.bodySmall
          )
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("Fichier : notes_physique_2bac_sbai.csv", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
              Text("Colonnes : Nom, S1C1, S1C2, S1C3, Moy_S1, S2C1, S2C2, S2C3, Moy_S2, Moy_Generale", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            runCatching {
              val file = File(context.filesDir, "notes_physique_2bac_sbai.csv")
              val csvContent = buildString {
                appendLine("ID,Nom,Classe,S1C1,S1C2,S1C3,Moy_S1,S2C1,S2C2,S2C3,Moy_S2,Moy_Generale")
                studentsList.forEach { s ->
                  appendLine("${s.id},\"${s.name}\",\"${s.classGroup}\",${s.s1c1},${s.s1c2},${s.s1c3},${"%.2f".format(s.averageS1)},${s.s2c1},${s.s2c2},${s.s2c3},${"%.2f".format(s.averageS2)},${"%.2f".format(s.overallAverage)}")
                }
              }
              file.writeText(csvContent)
              exportStatusMessage = "Relevé officiel généré dans ${file.name} (${file.length()} octets) !"
            }.onFailure { error ->
              exportStatusMessage = "Échec de l'export : ${error.localizedMessage ?: "erreur d'écriture"}"
            }
            showExportDialog = false
          }
        ) {
          Text("Confirmer l'export")
        }
      },
      dismissButton = {
        TextButton(onClick = { showExportDialog = false }) { Text("Fermer") }
      }
    )
  }
}
