package com.example.ui.simulations

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberTertiaryLight
import com.example.ui.theme.CyanSecondaryLight
import com.example.ui.theme.ScienceGreen
import com.example.ui.theme.ScienceRed
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

@Composable
fun CircuitRCSimulation() {
  var resistanceKOhms by remember { mutableFloatStateOf(2.0f) } // 2 kΩ
  var capacitanceMicroF by remember { mutableFloatStateOf(5.0f) } // 5 µF
  var generatorVoltage by remember { mutableFloatStateOf(6.0f) } // 6 V
  var isCharging by remember { mutableStateOf(true) }
  var inspectTimeMs by remember { mutableFloatStateOf(10.0f) }

  // tau = R * C (in ms)
  val tauMs = resistanceKOhms * capacitanceMicroF
  val maxTimeMs = tauMs * 5f
  val currentTimeMs = inspectTimeMs.coerceIn(0f, maxTimeMs)

  // u_C(t)
  val currentVoltage = if (isCharging) {
    generatorVoltage * (1.0f - exp(-currentTimeMs / tauMs))
  } else {
    generatorVoltage * exp(-currentTimeMs / tauMs)
  }

  // Energy in mJ: 1/2 C U^2
  val maxEnergyMilliJoules = 0.5f * (capacitanceMicroF * 1e-6f) * (generatorVoltage * generatorVoltage) * 1000f

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("simulation_circuit_rc"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    shape = RoundedCornerShape(16.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            "Circuit RC : Charge & Décharge",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            "Simulation interactive du dipôle RC",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        FilterChip(
          selected = isCharging,
          onClick = { isCharging = !isCharging },
          label = { Text(if (isCharging) "Mode : Charge" else "Mode : Décharge") },
          leadingIcon = {
            Icon(
              if (isCharging) Icons.Default.Bolt else Icons.Default.BatteryChargingFull,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
          }
        )
      }

      // Graph Canvas
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(180.dp)
          .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
          .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
          .padding(8.dp)
      ) {
        val primaryColor = MaterialTheme.colorScheme.primary
        val outlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        val amberColor = AmberTertiaryLight

        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height
          val padding = 30f

          // Axis
          drawLine(
            color = outlineColor,
            start = Offset(padding, h - padding),
            end = Offset(w, h - padding),
            strokeWidth = 2f
          )
          drawLine(
            color = outlineColor,
            start = Offset(padding, padding),
            end = Offset(padding, h - padding),
            strokeWidth = 2f
          )

          // Grid lines
          val stepCount = 5
          for (i in 1..stepCount) {
            val yPos = (h - padding) - (i.toFloat() / stepCount) * (h - 2 * padding)
            drawLine(
              color = outlineColor.copy(alpha = 0.2f),
              start = Offset(padding, yPos),
              end = Offset(w, yPos),
              strokeWidth = 1f
            )
          }

          // Asymptote line for charge
          if (isCharging) {
            val asymptoteY = padding
            drawLine(
              color = amberColor.copy(alpha = 0.6f),
              start = Offset(padding, asymptoteY),
              end = Offset(w, asymptoteY),
              strokeWidth = 2f
            )
          }

          // Curve u_C(t)
          val curvePath = Path()
          val numPoints = 120
          for (i in 0..numPoints) {
            val tRatio = i.toFloat() / numPoints
            val t = tRatio * maxTimeMs
            val uVal = if (isCharging) {
              generatorVoltage * (1.0f - exp(-t / tauMs))
            } else {
              generatorVoltage * exp(-t / tauMs)
            }
            val x = padding + tRatio * (w - padding - 10f)
            val y = (h - padding) - (uVal / generatorVoltage) * (h - 2 * padding)
            if (i == 0) curvePath.moveTo(x, y) else curvePath.lineTo(x, y)
          }

          drawPath(
            path = curvePath,
            color = primaryColor,
            style = Stroke(width = 4f)
          )

          // Tau marker
          val tauX = padding + (tauMs / maxTimeMs) * (w - padding - 10f)
          val tauU = if (isCharging) generatorVoltage * 0.632f else generatorVoltage * 0.368f
          val tauY = (h - padding) - (tauU / generatorVoltage) * (h - 2 * padding)
          drawCircle(
            color = amberColor,
            radius = 6f,
            center = Offset(tauX, tauY)
          )

          // Current cursor
          val cursorX = padding + (currentTimeMs / maxTimeMs) * (w - padding - 10f)
          val cursorY = (h - padding) - (currentVoltage / generatorVoltage) * (h - 2 * padding)
          drawCircle(
            color = ScienceGreen,
            radius = 8f,
            center = Offset(cursorX, cursorY)
          )
        }

        // Legend overlay
        Row(
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = "τ = ${"%.1f".format(tauMs)} ms",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = AmberTertiaryLight,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = "u_C = ${"%.2f".format(currentVoltage)} V",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = ScienceGreen,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }

      // Sliders
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Résistance R : ${"%.1f".format(resistanceKOhms)} kΩ", style = MaterialTheme.typography.bodySmall)
          Text("Capacité C : ${"%.1f".format(capacitanceMicroF)} µF", style = MaterialTheme.typography.bodySmall)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          Slider(
            value = resistanceKOhms,
            onValueChange = { resistanceKOhms = it },
            valueRange = 0.5f..10.0f,
            modifier = Modifier.weight(1f)
          )
          Slider(
            value = capacitanceMicroF,
            onValueChange = { capacitanceMicroF = it },
            valueRange = 1.0f..20.0f,
            modifier = Modifier.weight(1f)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Tension E : ${"%.1f".format(generatorVoltage)} V", style = MaterialTheme.typography.bodySmall)
          Text("Instant t : ${"%.1f".format(currentTimeMs)} ms", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        }
        Slider(
          value = inspectTimeMs,
          onValueChange = { inspectTimeMs = it },
          valueRange = 0f..maxTimeMs,
          modifier = Modifier.fillMaxWidth()
        )
      }

      // Live metrics row
      Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(10.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Constante τ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${"%.2f".format(tauMs)} ms", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Tension u_C(t)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${"%.2f".format(currentVoltage)} V", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ScienceGreen)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Énergie Max E_e", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${"%.3f".format(maxEnergyMilliJoules)} mJ", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun TitrageSimulation() {
  var volumeAddedMl by remember { mutableFloatStateOf(10.0f) }
  var indicatorChoice by remember { mutableStateOf("BBT (Bleu de bromothymol)") }

  val vEquivalence = 15.0f
  val cAcid = 0.075f
  val vAcid = 20.0f

  // Approximate pH model for titration curve of weak acid with strong base
  val calculatedPh = remember(volumeAddedMl) {
    when {
      volumeAddedMl < 0.2f -> 2.87f
      volumeAddedMl < vEquivalence -> {
        val ratio = volumeAddedMl / (vEquivalence - volumeAddedMl + 0.01f)
        (4.8f + kotlin.math.log10(ratio.coerceAtLeast(0.001f))).coerceIn(2.9f, 6.5f)
      }
      volumeAddedMl in (vEquivalence - 0.2f)..(vEquivalence + 0.2f) -> 8.75f // Equivalence point jump
      else -> {
        val excessBase = (volumeAddedMl - vEquivalence) * 0.1f / (vAcid + volumeAddedMl)
        (14.0f + kotlin.math.log10(excessBase.coerceAtLeast(1e-7f))).coerceIn(8.8f, 12.8f)
      }
    }
  }

  // Solution color according to pH and chosen indicator
  val solutionColor = remember(calculatedPh, indicatorChoice) {
    if (indicatorChoice.startsWith("BBT")) {
      when {
        calculatedPh < 6.0f -> Color(0xFFFACC15) // Yellow (Acid)
        calculatedPh in 6.0f..7.6f -> Color(0xFF10B981) // Green (Neutral)
        else -> Color(0xFF2563EB) // Blue (Basic)
      }
    } else { // Phénolphtaléine
      when {
        calculatedPh < 8.2f -> Color(0xFFF1F5F9).copy(alpha = 0.6f) // Incolore
        else -> Color(0xFFEC4899) // Rose fuchsia
      }
    }
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("simulation_titrage"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    shape = RoundedCornerShape(16.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            "Titrage Acido-Basique & pH-métrie",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            "Acide acétique CH3COOH par NaOH (Soude)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Text(
          "V_bE = ${"%.1f".format(vEquivalence)} mL",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
      }

      // Visual Lab: Burette + Beaker + pH-meter
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
          .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Digital pH-Meter
        Surface(
          color = Color(0xFF0F172A),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.padding(end = 8.dp)
        ) {
          Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("pH-MÈTRE", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(
              text = "%.2f".format(calculatedPh),
              color = Color(0xFF38BDF8),
              fontSize = 24.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold
            )
          }
        }

        // Beaker representation with dynamic liquid color
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Bécher de réaction", style = MaterialTheme.typography.labelSmall)
          Spacer(modifier = Modifier.height(4.dp))
          Box(
            modifier = Modifier
              .width(70.dp)
              .height(60.dp)
              .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
              .background(solutionColor.copy(alpha = 0.85f), RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)),
            contentAlignment = Alignment.Center
          ) {
            Text(
              "V = ${"%.1f".format(vAcid + volumeAddedMl)} mL",
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = if (calculatedPh > 8.2f && !indicatorChoice.startsWith("BBT")) Color.White else Color(0xFF0F172A)
            )
          }
        }

        // Equivalence detector badge
        Column(horizontalAlignment = Alignment.End) {
          if (volumeAddedMl in (vEquivalence - 0.4f)..(vEquivalence + 0.4f)) {
            Badge(containerColor = AmberTertiaryLight) {
              Text("ÉQUIVALENCE ATTEINTE !", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
            }
          } else if (volumeAddedMl < vEquivalence) {
            Text("Avant équivalence (V_b < V_bE)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          } else {
            Text("Après équivalence (V_b > V_bE)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
          }
          Text(
            if (indicatorChoice.startsWith("BBT")) {
              if (calculatedPh < 6f) "Couleur : Jaune (Acide)" else if (calculatedPh <= 7.6f) "Couleur : Verte (Neutre)" else "Couleur : Bleue (Basique)"
            } else {
              if (calculatedPh < 8.2f) "Couleur : Incolore" else "Couleur : Rose vif"
            },
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium
          )
        }
      }

      // Burette Volume Slider
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Volume de soude versé V_b", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
          Text("${"%.1f".format(volumeAddedMl)} mL", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = CyanSecondaryLight)
        }
        Slider(
          value = volumeAddedMl,
          onValueChange = { volumeAddedMl = it },
          valueRange = 0.0f..30.0f,
          modifier = Modifier.fillMaxWidth()
        )
      }

      // Choice of Indicator
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Indicateur coloré :", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FilterChip(
            selected = indicatorChoice.startsWith("BBT"),
            onClick = { indicatorChoice = "BBT (Bleu de bromothymol)" },
            label = { Text("BBT") }
          )
          FilterChip(
            selected = indicatorChoice.startsWith("Phénol"),
            onClick = { indicatorChoice = "Phénolphtaléine" },
            label = { Text("Phénolphtaléine") }
          )
        }
      }
    }
  }
}

@Composable
fun OndesSimulation() {
  var frequencyHz by remember { mutableFloatStateOf(40f) }
  var celerityMPerS by remember { mutableFloatStateOf(20f) }
  var amplitudeCm by remember { mutableFloatStateOf(2.5f) }
  var probeDistanceM by remember { mutableFloatStateOf(0.5f) }

  // lambda = v / f
  val lambdaM = celerityMPerS / frequencyHz
  val periodS = 1f / frequencyHz
  val delayS = probeDistanceM / celerityMPerS

  val isPhaseState = remember(probeDistanceM, lambdaM) {
    val ratio = probeDistanceM / lambdaM
    val diff = kotlin.math.abs(ratio - kotlin.math.round(ratio))
    diff < 0.12f
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("simulation_ondes"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    shape = RoundedCornerShape(16.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            "Ondes Mécaniques Progressives",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            "Oscillogramme sinusoïdal & longueur d'onde λ",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer,
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            "λ = ${"%.2f".format(lambdaM * 100)} cm",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      // Wave canvas
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(150.dp)
          .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
          .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
          .padding(8.dp)
      ) {
        val primaryColor = MaterialTheme.colorScheme.primary
        val outlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        val amberColor = AmberTertiaryLight

        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height
          val midY = h / 2f
          val padding = 20f

          // Axis
          drawLine(
            color = outlineColor,
            start = Offset(padding, midY),
            end = Offset(w, midY),
            strokeWidth = 2f
          )

          // Draw Sinusoid
          val wavePath = Path()
          val maxDistM = 1.0f
          val points = 150
          for (i in 0..points) {
            val distRatio = i.toFloat() / points
            val dist = distRatio * maxDistM
            val waveY = amplitudeCm * sin(2.0 * PI * (dist / lambdaM)).toFloat()
            val x = padding + distRatio * (w - padding - 10f)
            val y = midY - (waveY / 5.0f) * (midY - 10f)
            if (i == 0) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
          }

          drawPath(path = wavePath, color = primaryColor, style = Stroke(width = 3.5f))

          // Draw probe marker at probeDistanceM
          val probeX = padding + (probeDistanceM / maxDistM) * (w - padding - 10f)
          val probeY = midY - (amplitudeCm * sin(2.0 * PI * (probeDistanceM / lambdaM)).toFloat() / 5.0f) * (midY - 10f)
          drawCircle(color = if (isPhaseState) ScienceGreen else ScienceRed, radius = 7f, center = Offset(probeX, probeY))
        }

        // State badge
        Surface(
          modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp),
          color = if (isPhaseState) ScienceGreen.copy(alpha = 0.2f) else ScienceRed.copy(alpha = 0.2f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            if (isPhaseState) "Point M en Phase avec la Source" else "Point M en Déphasage",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (isPhaseState) ScienceGreen else ScienceRed,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      // Controls
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Fréquence N : ${frequencyHz.toInt()} Hz", style = MaterialTheme.typography.bodySmall)
          Text("Célérité v : ${celerityMPerS.toInt()} m/s", style = MaterialTheme.typography.bodySmall)
        }
        Slider(
          value = frequencyHz,
          onValueChange = { frequencyHz = it },
          valueRange = 10f..100f
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Position du point M (d = SM)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
          Text("${"%.2f".format(probeDistanceM * 100)} cm (Retard τ = ${"%.2f".format(delayS * 1000)} ms)", style = MaterialTheme.typography.bodySmall)
        }
        Slider(
          value = probeDistanceM,
          onValueChange = { probeDistanceM = it },
          valueRange = 0.1f..1.0f
        )
      }
    }
  }
}

@Composable
fun RadioactiveSimulation() {
  var halfLifeYears by remember { mutableFloatStateOf(5730f) } // C14 default
  var elapsedYears by remember { mutableFloatStateOf(5730f) }

  val lambda = 0.6931f / halfLifeYears
  val remainingFraction = exp(-lambda * elapsedYears).coerceIn(0.01f, 1.0f)
  val remainingPercent = (remainingFraction * 100f)

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("simulation_radioactive"),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    shape = RoundedCornerShape(16.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("Décroissance Radioactive & Datation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Text("Loi N(t) = N_0 · exp(-λ·t)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Surface(
          color = MaterialTheme.colorScheme.tertiaryContainer,
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            "t_1/2 = ${halfLifeYears.toInt()} ans",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onTertiaryContainer,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      // Visual particles grid
      Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Noyaux Radioactifs Actifs vs Désintégrés (Échantillon de 100 noyaux)",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          // 10x10 particle matrix representation
          val activeCount = (remainingPercent).toInt().coerceIn(0, 100)
          Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            for (row in 0 until 5) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
              ) {
                for (col in 0 until 20) {
                  val idx = row * 20 + col
                  val isActive = idx < activeCount
                  Box(
                    modifier = Modifier
                      .size(10.dp)
                      .background(
                        color = if (isActive) Color(0xFFEF4444) else Color(0xFF94A3B8).copy(alpha = 0.35f),
                        shape = CircleShape
                      )
                  )
                }
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("N(t) restant : ${"%.1f".format(remainingPercent)} %", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
            Text("Désintégrés : ${"%.1f".format(100f - remainingPercent)} %", color = Color(0xFF64748B), style = MaterialTheme.typography.bodySmall)
          }
        }
      }

      // Sliders
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Temps écoulé t", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
          Text("${elapsedYears.toInt()} ans (${"%.2f".format(elapsedYears / halfLifeYears)} × t_1/2)", style = MaterialTheme.typography.bodySmall)
        }
        Slider(
          value = elapsedYears,
          onValueChange = { elapsedYears = it },
          valueRange = 0f..(halfLifeYears * 4f)
        )
      }
    }
  }
}
