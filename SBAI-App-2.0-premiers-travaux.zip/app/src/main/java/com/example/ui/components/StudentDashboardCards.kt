package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.data.repository.AppLocalRepository
import com.example.ui.theme.ScienceGreen
import kotlinx.coroutines.launch

/**
 * Material 3 Student Progress Dashboard Card
 * Visualizes curriculum progress for 2BAC PC across Physics & Chemistry,
 * domain masteries, and exercises completed.
 */
@Composable
fun StudentProgressDashboardCard(
  overallProgress: Float = 0.76f, // 76%
  physicsCompleted: Int = 12,
  physicsTotal: Int = 16,
  chemistryCompleted: Int = 7,
  chemistryTotal: Int = 9,
  exercisesDone: Int = 14,
  exercisesTotal: Int = 18,
  quizScore: Int = 480,
  modifier: Modifier = Modifier,
  onContinueRevisionClick: () -> Unit = {}
) {
  var showDetails by remember { mutableStateOf(false) }
  val animatedOverallProgress by animateFloatAsState(
    targetValue = overallProgress,
    animationSpec = tween(durationMillis = 800),
    label = "overallProgress"
  )

  ElevatedCard(
    modifier = modifier
      .fillMaxWidth()
      .testTag("student_progress_dashboard_card"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.elevatedCardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header with badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.TrendingUp,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(22.dp)
            )
          }
          Column {
            Text(
              "Progression du Programme",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              "2ème Bac Sciences Physiques",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Surface(
          color = MaterialTheme.colorScheme.primaryContainer,
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(
            text = "${(animatedOverallProgress * 100).toInt()}% Maîtrisé",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
          )
        }
      }

      // Circular gauge + Summary Stats
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
          .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceAround
      ) {
        // Circular Progress Ring
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier.size(80.dp)
        ) {
          CircularProgressIndicator(
            progress = { animatedOverallProgress },
            modifier = Modifier.fillMaxSize(),
            strokeWidth = 8.dp,
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              "${(animatedOverallProgress * 100).toInt()}%",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.primary
            )
            Text(
              "Global",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // Fast Stats Column
        Column(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.padding(start = 8.dp)
        ) {
          QuickMetricRow(
            icon = Icons.Default.MenuBook,
            label = "Chapitres vus",
            value = "${physicsCompleted + chemistryCompleted} / ${physicsTotal + chemistryTotal}",
            tint = MaterialTheme.colorScheme.primary
          )
          QuickMetricRow(
            icon = Icons.Default.EditNote,
            label = "Exercices résolus",
            value = "$exercisesDone / $exercisesTotal",
            tint = MaterialTheme.colorScheme.secondary
          )
          QuickMetricRow(
            icon = Icons.Default.Quiz,
            label = "Points QCM acquis",
            value = "$quizScore pts",
            tint = ScienceGreen
          )
        }
      }

      // Subject Progress Bars (Physique & Chimie)
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SubjectProgressBar(
          subject = "Physique",
          completed = physicsCompleted,
          total = physicsTotal,
          color = MaterialTheme.colorScheme.primary,
          icon = Icons.Default.Bolt
        )

        SubjectProgressBar(
          subject = "Chimie",
          completed = chemistryCompleted,
          total = chemistryTotal,
          color = MaterialTheme.colorScheme.secondary,
          icon = Icons.Default.Science
        )
      }

      // Expandable Domain Breakdown
      AnimatedVisibility(visible = showDetails) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          HorizontalDivider()
          Text(
            "Maîtrise par Domaine Pédagogique :",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          DomainSkillRow("Ondes Mécaniques & Lumineuses", 0.90f, "90%", MaterialTheme.colorScheme.primary)
          DomainSkillRow("Physique Nucléaire (Radioactivité)", 0.95f, "95%", ScienceGreen)
          DomainSkillRow("Électricité (Dipôles RC, RL, RLC)", 0.85f, "85%", MaterialTheme.colorScheme.secondary)
          DomainSkillRow("Mécanique de Newton & Satellites", 0.72f, "72%", MaterialTheme.colorScheme.tertiary)
          DomainSkillRow("Cinétique & Suivi Temporel", 0.88f, "88%", MaterialTheme.colorScheme.primary)
          DomainSkillRow("Titrage, pH-métrie & Piles", 0.82f, "82%", MaterialTheme.colorScheme.secondary)
        }
      }

      // Actions bottom row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        TextButton(
          onClick = { showDetails = !showDetails },
          modifier = Modifier.testTag("btn_toggle_progress_details")
        ) {
          Icon(
            if (showDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(if (showDetails) "Masquer le détail" else "Détail par domaine")
        }

        FilledTonalButton(
          onClick = onContinueRevisionClick,
          modifier = Modifier.testTag("btn_continue_revision"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Reprendre")
        }
      }
    }
  }
}

@Composable
private fun QuickMetricRow(
  icon: ImageVector,
  label: String,
  value: String,
  tint: Color
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
    Text(
      "$label :",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Text(
      value,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
private fun SubjectProgressBar(
  subject: String,
  completed: Int,
  total: Int,
  color: Color,
  icon: ImageVector
) {
  val ratio = if (total > 0) completed.toFloat() / total.toFloat() else 0f
  val percent = (ratio * 100).toInt()

  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        Text(
          subject,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.SemiBold
        )
      }
      Text(
        "$completed / $total chapitres ($percent%)",
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    LinearProgressIndicator(
      progress = { ratio },
      modifier = Modifier
        .fillMaxWidth()
        .height(10.dp)
        .clip(RoundedCornerShape(5.dp)),
      color = color,
      trackColor = MaterialTheme.colorScheme.surfaceVariant
    )
  }
}

@Composable
private fun DomainSkillRow(
  title: String,
  progress: Float,
  label: String,
  color: Color
) {
  Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        title,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        label,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = color
      )
    }
    LinearProgressIndicator(
      progress = { progress },
      modifier = Modifier
        .fillMaxWidth()
        .height(6.dp)
        .clip(RoundedCornerShape(3.dp)),
      color = color,
      trackColor = MaterialTheme.colorScheme.surfaceVariant
    )
  }
}

/**
 * Material 3 Test Scores Overview Card
 * Displays continuous controls (CC1 to CC6) scores, average GPA / 20,
 * Moroccan Baccalauréat honors mention, and visual grade bars.
 */
@Composable
fun TestScoresOverviewCard(
  s1Scores: List<Pair<String, Double>> = listOf(
    "CC1 (Cinétique/Ondes)" to 16.5,
    "CC2 (Nucléaire/RC)" to 17.0,
    "CC3 (Équilibre/RLC)" to 18.0
  ),
  s2Scores: List<Pair<String, Double>> = listOf(
    "CC1 (Titrage/Newton)" to 17.5,
    "CC2 (Piles/Pendules)" to 18.5,
    "CC3 (Esters/Synthèse)" to 19.0
  ),
  modifier: Modifier = Modifier,
  onOpenEvaluationsClick: () -> Unit = {}
) {
  var selectedSemester by remember { mutableIntStateOf(1) }

  val activeScores = if (selectedSemester == 1) s1Scores else s2Scores
  val s1Avg = s1Scores.map { it.second }.average()
  val s2Avg = s2Scores.map { it.second }.average()
  val globalAvg = (s1Avg + s2Avg) / 2.0

  val mention = when {
    globalAvg >= 16.0 -> "Très Bien (>= 16)"
    globalAvg >= 14.0 -> "Bien (>= 14)"
    globalAvg >= 12.0 -> "Assez Bien (>= 12)"
    globalAvg >= 10.0 -> "Passable (>= 10)"
    else -> "À perfectionner"
  }

  ElevatedCard(
    modifier = modifier
      .fillMaxWidth()
      .testTag("test_scores_overview_card"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.elevatedCardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.Assessment,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(22.dp)
            )
          }
          Column {
            Text(
              "Notes & Contrôles Continus",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              "6 Évaluations Annuelles • Coeff. 7",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // Mention Badge
        Surface(
          color = ScienceGreen.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(1.dp, ScienceGreen.copy(alpha = 0.4f)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(Icons.Default.Star, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(14.dp))
            Text(
              mention,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = ScienceGreen
            )
          }
        }
      }

      // GPA Highlight Banner
      Card(
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              "Moyenne Générale Physique-Chimie",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.Bottom) {
              Text(
                "%.2f".format(globalAvg),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                " / 20",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                modifier = Modifier.padding(bottom = 4.dp, start = 2.dp)
              )
            }
          }

          Column(horizontalAlignment = Alignment.End) {
            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = RoundedCornerShape(8.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(12.dp))
                Text(
                  "+1.16 pt ce semestre",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = ScienceGreen
                )
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "Points d'avance Bac : +54.2 pts",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
            )
          }
        }
      }

      // Semester Selector Tabs
      TabRow(
        selectedTabIndex = selectedSemester - 1,
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        modifier = Modifier.clip(RoundedCornerShape(12.dp)),
        divider = {}
      ) {
        Tab(
          selected = selectedSemester == 1,
          onClick = { selectedSemester = 1 },
          text = {
            Text(
              "Semestre 1 (Moy : ${"%.2f".format(s1Avg)})",
              fontWeight = if (selectedSemester == 1) FontWeight.Bold else FontWeight.Normal,
              fontSize = 12.sp
            )
          },
          modifier = Modifier.testTag("tab_semester_1")
        )
        Tab(
          selected = selectedSemester == 2,
          onClick = { selectedSemester = 2 },
          text = {
            Text(
              "Semestre 2 (Moy : ${"%.2f".format(s2Avg)})",
              fontWeight = if (selectedSemester == 2) FontWeight.Bold else FontWeight.Normal,
              fontSize = 12.sp
            )
          },
          modifier = Modifier.testTag("tab_semester_2")
        )
      }

      // Visual Bar Chart for Continuous Controls
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
          .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          "Graphique des Notes au ${if (selectedSemester == 1) "1er" else "2ème"} Semestre :",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(110.dp),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.Bottom
        ) {
          activeScores.forEachIndexed { index, (label, score) ->
            ScoreBarColumn(
              title = "CC${index + 1}",
              subLabel = label.substringAfter("(").substringBefore(")"),
              score = score,
              maxScore = 20.0
            )
          }
        }
      }

      // Action button
      OutlinedButton(
        onClick = onOpenEvaluationsClick,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("btn_view_all_evaluations"),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Passer les évaluations & examens blancs")
      }
    }
  }
}

@Composable
private fun ScoreBarColumn(
  title: String,
  subLabel: String,
  score: Double,
  maxScore: Double = 20.0
) {
  val heightFraction = (score / maxScore).toFloat().coerceIn(0.1f, 1f)
  val barColor = when {
    score >= 16.0 -> ScienceGreen
    score >= 14.0 -> MaterialTheme.colorScheme.primary
    score >= 10.0 -> MaterialTheme.colorScheme.tertiary
    else -> MaterialTheme.colorScheme.error
  }

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Bottom,
    modifier = Modifier.width(80.dp)
  ) {
    // Score Badge
    Text(
      text = "${score}/20",
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold,
      color = barColor
    )
    Spacer(modifier = Modifier.height(4.dp))

    // Animated Bar
    Box(
      modifier = Modifier
        .width(36.dp)
        .height((65 * heightFraction).dp)
        .background(barColor, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
    )

    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = title,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = subLabel,
      style = MaterialTheme.typography.bodySmall,
      fontSize = 9.sp,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}

/**
 * Material 3 Upcoming Study Reminders Card
 * Interactive reminders for tests, review deadlines, and the National Exam countdown.
 */
@Composable
fun UpcomingStudyRemindersCard(
  initialReminders: List<StudyReminder> = CurriculumData.initialStudyReminders,
  modifier: Modifier = Modifier,
  onReminderClick: (StudyReminder) -> Unit = {}
) {
  val context = LocalContext.current
  val repository = remember { AppLocalRepository.getInstance(context) }
  val coroutineScope = rememberCoroutineScope()
  val dbReminders by repository.allReminders.collectAsStateWithLifecycle(initialValue = emptyList())

  val reminders = remember(dbReminders) {
    if (dbReminders.isNotEmpty()) {
      dbReminders.map { entity ->
        StudyReminder(
          id = entity.id,
          title = entity.title,
          subject = try { SubjectType.valueOf(entity.subject) } catch (_: Exception) { SubjectType.ALL },
          dueDate = entity.dueDate,
          priority = try { ReminderPriority.valueOf(entity.priority) } catch (_: Exception) { ReminderPriority.IMPORTANT },
          chapterOrTheme = entity.chapterOrTheme,
          estimatedMinutes = entity.estimatedMinutes,
          isDone = entity.isDone
        )
      }
    } else {
      initialReminders
    }
  }

  var showAddDialog by remember { mutableStateOf(false) }
  var filterSubject by remember { mutableStateOf(SubjectType.ALL) }

  val filteredReminders = remember(reminders, filterSubject) {
    if (filterSubject == SubjectType.ALL) reminders
    else reminders.filter { it.subject == filterSubject }
  }

  val activeCount = reminders.count { !it.isDone }

  ElevatedCard(
    modifier = modifier
      .fillMaxWidth()
      .testTag("upcoming_study_reminders_card"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.elevatedCardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .background(MaterialTheme.colorScheme.tertiaryContainer, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.Alarm,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.tertiary,
              modifier = Modifier.size(22.dp)
            )
          }
          Column {
            Text(
              "Rappels & Révisions",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              "$activeCount tâche${if (activeCount > 1) "s" else ""} en attente",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        IconButton(
          onClick = { showAddDialog = true },
          modifier = Modifier.testTag("btn_add_reminder_icon")
        ) {
          Icon(Icons.Default.AddCircle, contentDescription = "Ajouter un rappel", tint = MaterialTheme.colorScheme.primary)
        }
      }

      // National Exam Countdown Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
        )
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Icon(
            Icons.Default.HourglassTop,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.size(28.dp)
          )
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "Examen National 2BAC (Session Juin 2026)",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onTertiaryContainer
            )
            Text(
              "J-48 jours • Épreuve de Physique-Chimie (3h00)",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.85f)
            )
          }
          Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              "J-48",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.tertiary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      // Filter Chips (Tous / Physique / Chimie)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = filterSubject == SubjectType.ALL,
          onClick = { filterSubject = SubjectType.ALL },
          label = { Text("Tous (${reminders.size})", fontSize = 11.sp) },
          modifier = Modifier.testTag("filter_reminder_all")
        )
        FilterChip(
          selected = filterSubject == SubjectType.PHYSIQUE,
          onClick = { filterSubject = SubjectType.PHYSIQUE },
          label = { Text("Physique (${reminders.count { it.subject == SubjectType.PHYSIQUE }})", fontSize = 11.sp) },
          modifier = Modifier.testTag("filter_reminder_physique")
        )
        FilterChip(
          selected = filterSubject == SubjectType.CHIMIE,
          onClick = { filterSubject = SubjectType.CHIMIE },
          label = { Text("Chimie (${reminders.count { it.subject == SubjectType.CHIMIE }})", fontSize = 11.sp) },
          modifier = Modifier.testTag("filter_reminder_chimie")
        )
      }

      // Checklist of Reminders
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        filteredReminders.forEach { reminder ->
          ReminderItemRow(
            reminder = reminder,
            onToggleDone = { done ->
              coroutineScope.launch {
                repository.toggleReminderDone(reminder.id, reminder.isDone)
              }
            },
            onClick = { onReminderClick(reminder) }
          )
        }
      }

      // Add Reminder Button
      Button(
        onClick = { showAddDialog = true },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("btn_add_reminder"),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Ajouter un rappel de révision personnalisé")
      }
    }
  }

  // Dialog to Add a New Reminder
  if (showAddDialog) {
    AddStudyReminderDialog(
      onDismiss = { showAddDialog = false },
      onConfirm = { newReminder ->
        coroutineScope.launch {
          repository.addStudyReminder(
            title = newReminder.title,
            subject = newReminder.subject.name,
            dueDate = newReminder.dueDate,
            priority = newReminder.priority.name,
            chapterOrTheme = newReminder.chapterOrTheme,
            estimatedMinutes = newReminder.estimatedMinutes
          )
        }
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun ReminderItemRow(
  reminder: StudyReminder,
  onToggleDone: (Boolean) -> Unit,
  onClick: () -> Unit
) {
  val priorityColor = when (reminder.priority) {
    ReminderPriority.URGENT -> MaterialTheme.colorScheme.error
    ReminderPriority.IMPORTANT -> MaterialTheme.colorScheme.tertiary
    ReminderPriority.CONSEILLE -> ScienceGreen
  }

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .clickable { onClick() }
      .testTag("reminder_row_${reminder.id}"),
    color = if (reminder.isDone) {
      MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
    } else {
      MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    },
    shape = RoundedCornerShape(12.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Checkbox
      Checkbox(
        checked = reminder.isDone,
        onCheckedChange = { onToggleDone(it) },
        modifier = Modifier
          .size(36.dp)
          .testTag("checkbox_reminder_${reminder.id}")
      )

      Column(modifier = Modifier.weight(1f)) {
        Text(
          reminder.title,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = if (reminder.isDone) FontWeight.Normal else FontWeight.SemiBold,
          textDecoration = if (reminder.isDone) TextDecoration.LineThrough else TextDecoration.None,
          color = if (reminder.isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(2.dp))

        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Subject badge
          Surface(
            color = if (reminder.subject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              reminder.subject.label,
              style = MaterialTheme.typography.labelSmall,
              fontSize = 10.sp,
              color = if (reminder.subject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          // Due Date Chip
          Text(
            "• ${reminder.dueDate}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          // Est. time
          Text(
            "(${reminder.estimatedMinutes} min)",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      // Priority Pill
      Surface(
        color = priorityColor.copy(alpha = 0.15f),
        shape = RoundedCornerShape(6.dp)
      ) {
        Text(
          reminder.priority.label,
          style = MaterialTheme.typography.labelSmall,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          color = priorityColor,
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
        )
      }
    }
  }
}

/**
 * Material 3 Dialog to create a custom study reminder
 */
@Composable
fun AddStudyReminderDialog(
  onDismiss: () -> Unit,
  onConfirm: (StudyReminder) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var subject by remember { mutableStateOf(SubjectType.PHYSIQUE) }
  var priority by remember { mutableStateOf(ReminderPriority.IMPORTANT) }
  var dueDate by remember { mutableStateOf("Demain") }
  var durationMinutes by remember { mutableIntStateOf(45) }

  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.testTag("dialog_add_reminder"),
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(Icons.Default.AddAlarm, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text("Nouveau Rappel de Révision")
      }
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Titre / Thème de révision") },
          placeholder = { Text("Ex: Revoir le dosage pH-métrique") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_reminder_title"),
          singleLine = true
        )

        // Subject selector
        Text("Matière :", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(SubjectType.PHYSIQUE, SubjectType.CHIMIE).forEach { subj ->
            FilterChip(
              selected = subject == subj,
              onClick = { subject = subj },
              label = { Text(subj.label) }
            )
          }
        }

        // Priority selector
        Text("Priorité :", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          ReminderPriority.values().forEach { prio ->
            FilterChip(
              selected = priority == prio,
              onClick = { priority = prio },
              label = { Text(prio.label) }
            )
          }
        }

        // Due date selector
        Text("Échéance :", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          listOf("Aujourd'hui", "Demain", "Dans 3j", "Ce week-end").forEach { dateOpt ->
            FilterChip(
              selected = dueDate == dateOpt,
              onClick = { dueDate = dateOpt },
              label = { Text(dateOpt, fontSize = 11.sp) }
            )
          }
        }

        // Duration
        Text("Durée estimée : $durationMinutes minutes", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Slider(
          value = durationMinutes.toFloat(),
          onValueChange = { durationMinutes = it.toInt() },
          valueRange = 15f..120f,
          steps = 6,
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            val newReminder = StudyReminder(
              id = "custom_rem_${System.currentTimeMillis()}",
              title = title.trim(),
              subject = subject,
              dueDate = dueDate,
              priority = priority,
              estimatedMinutes = durationMinutes,
              isDone = false
            )
            onConfirm(newReminder)
          }
        },
        enabled = title.isNotBlank(),
        modifier = Modifier.testTag("btn_confirm_add_reminder")
      ) {
        Text("Enregistrer")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Annuler")
      }
    }
  )
}

/**
 * Composite Dashboard component that renders the 3 Material 3 cards together
 * with student profile and quick links.
 */
@Composable
fun StudentDashboardComponent(
  modifier: Modifier = Modifier,
  currentQuizScore: Int = 480,
  onNavigateToExercises: () -> Unit = {},
  onNavigateToEvaluations: () -> Unit = {},
  onNavigateToCourses: () -> Unit = {}
) {
  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Progress Card
    StudentProgressDashboardCard(
      overallProgress = 0.76f,
      physicsCompleted = 12,
      physicsTotal = 16,
      chemistryCompleted = 7,
      chemistryTotal = 9,
      exercisesDone = 14,
      exercisesTotal = 18,
      quizScore = currentQuizScore,
      onContinueRevisionClick = onNavigateToCourses
    )

    // 2. Test Scores Card
    TestScoresOverviewCard(
      onOpenEvaluationsClick = onNavigateToEvaluations
    )

    // 3. Upcoming Study Reminders Card
    UpcomingStudyRemindersCard(
      onReminderClick = { reminder ->
        if (reminder.subject == SubjectType.PHYSIQUE || reminder.subject == SubjectType.CHIMIE) {
          onNavigateToCourses()
        }
      }
    )
  }
}
