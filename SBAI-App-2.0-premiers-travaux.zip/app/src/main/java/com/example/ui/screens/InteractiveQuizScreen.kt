package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurriculumData
import com.example.data.Difficulty
import com.example.data.InteractiveQuestion
import com.example.data.SubjectType
import com.example.ui.theme.ScienceGreen
import com.example.ui.theme.ScienceRed

@Composable
fun InteractiveQuizScreen(
  onScoreUpdated: (Int) -> Unit = {}
) {
  var selectedDifficulty by remember { mutableStateOf<Difficulty?>(null) }
  var selectedSubject by remember { mutableStateOf(SubjectType.ALL) }

  // State of user answers: questionId -> selectedOptionIndex
  val userAnswers = remember { mutableStateMapOf<String, Int>() }
  var scorePoints by remember { mutableIntStateOf(0) }
  var streakCount by remember { mutableIntStateOf(0) }

  val filteredQuestions = remember(selectedDifficulty, selectedSubject) {
    var list = CurriculumData.interactiveQuizzes
    if (selectedDifficulty != null) {
      list = list.filter { it.difficulty == selectedDifficulty }
    }
    if (selectedSubject != SubjectType.ALL) {
      list = list.filter { it.subject == selectedSubject }
    }
    list
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("interactive_quiz_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Score Bar
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        shape = RoundedCornerShape(16.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              "Volet 3 : Tests Interactifs",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onTertiaryContainer
            )
            Text(
              "Gradient de difficulté avec correction instantanée",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
            )
          }

          // Live score & streak
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = RoundedCornerShape(10.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(Icons.Default.Stars, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(16.dp))
                Text(
                  "$scorePoints pts",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold
                )
              }
            }
            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = RoundedCornerShape(10.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                Text(
                  "x$streakCount",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }
    }

    // Gradient Selector Chips
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          "Gradient de difficulté :",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FilterChip(
            selected = selectedDifficulty == null,
            onClick = { selectedDifficulty = null },
            label = { Text("Tous niveaux") }
          )
          Difficulty.values().forEach { diff ->
            FilterChip(
              selected = selectedDifficulty == diff,
              onClick = { selectedDifficulty = diff },
              label = { Text("${diff.stars} ${diff.label}") }
            )
          }
        }
      }
    }

    // Questions List
    itemsIndexed(filteredQuestions, key = { _, q -> q.id }) { index, question ->
      val answeredIndex = userAnswers[question.id]
      val isAnswered = answeredIndex != null
      val isCorrect = answeredIndex == question.correctOptionIndex

      QuestionCard(
        index = index + 1,
        question = question,
        selectedIndex = answeredIndex,
        isAnswered = isAnswered,
        isCorrect = isCorrect,
        onSelectOption = { optIdx ->
          if (!isAnswered) {
            userAnswers[question.id] = optIdx
            if (optIdx == question.correctOptionIndex) {
              scorePoints += question.difficulty.points
              streakCount += 1
              onScoreUpdated(scorePoints)
            } else {
              streakCount = 0
            }
          }
        }
      )
    }
  }
}

@Composable
fun QuestionCard(
  index: Int,
  question: InteractiveQuestion,
  selectedIndex: Int?,
  isAnswered: Boolean,
  isCorrect: Boolean,
  onSelectOption: (Int) -> Unit
) {
  val diffColor = when (question.difficulty) {
    Difficulty.FACILE -> ScienceGreen
    Difficulty.MOYEN -> MaterialTheme.colorScheme.primary
    Difficulty.DIFFICILE -> Color(0xFFEF4444)
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("question_card_${question.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Tags
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Surface(
            color = diffColor.copy(alpha = 0.15f),
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              "${question.difficulty.stars} ${question.difficulty.label}",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = diffColor,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }

          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              question.chapterTitle,
              style = MaterialTheme.typography.labelSmall,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
        }

        Text(
          "+${question.difficulty.points} pts",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.tertiary
        )
      }

      // Question Title
      Text(
        text = "Q$index. ${question.question}",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold
      )

      // Options
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        question.options.forEachIndexed { optIdx, optionText ->
          val isThisSelected = selectedIndex == optIdx
          val isThisCorrect = optIdx == question.correctOptionIndex

          val backgroundColor = when {
            !isAnswered && isThisSelected -> MaterialTheme.colorScheme.primaryContainer
            isAnswered && isThisCorrect -> ScienceGreen.copy(alpha = 0.2f)
            isAnswered && isThisSelected && !isThisCorrect -> ScienceRed.copy(alpha = 0.2f)
            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
          }

          val borderColor = when {
            isAnswered && isThisCorrect -> ScienceGreen
            isAnswered && isThisSelected && !isThisCorrect -> ScienceRed
            else -> Color.Transparent
          }

          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .border(if (borderColor != Color.Transparent) 1.5.dp else 0.dp, borderColor, RoundedCornerShape(10.dp))
              .clickable(enabled = !isAnswered) { onSelectOption(optIdx) }
              .testTag("option_${question.id}_$optIdx"),
            color = backgroundColor,
            shape = RoundedCornerShape(10.dp)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(24.dp)
                  .background(
                    if (isAnswered && isThisCorrect) ScienceGreen
                    else if (isAnswered && isThisSelected && !isThisCorrect) ScienceRed
                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                    CircleShape
                  ),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  "${('A' + optIdx)}",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isAnswered && (isThisCorrect || isThisSelected)) Color.White else MaterialTheme.colorScheme.onSurface
                )
              }

              Text(
                optionText,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isThisCorrect && isAnswered) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.weight(1f)
              )

              if (isAnswered && isThisCorrect) {
                Icon(Icons.Default.Check, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(18.dp))
              } else if (isAnswered && isThisSelected && !isThisCorrect) {
                Icon(Icons.Default.Close, contentDescription = null, tint = ScienceRed, modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }

      // Explanation when answered
      AnimatedVisibility(visible = isAnswered) {
        Surface(
          color = if (isCorrect) ScienceGreen.copy(alpha = 0.12f) else ScienceRed.copy(alpha = 0.12f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              Icon(
                if (isCorrect) Icons.Default.CheckCircle else Icons.Default.Info,
                contentDescription = null,
                tint = if (isCorrect) ScienceGreen else ScienceRed,
                modifier = Modifier.size(16.dp)
              )
              Text(
                if (isCorrect) "Excellente réponse !" else "Explication pédagogique :",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isCorrect) ScienceGreen else ScienceRed
              )
            }
            Text(
              question.explanation,
              style = MaterialTheme.typography.bodySmall
            )
          }
        }
      }
    }
  }
}
