package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ScienceGreen
import kotlin.math.*

/**
 * Écran 1 — Introduction (Splash screen et Bienvenue)
 * - Logo app animé
 * - Particules lumineuses et trajectoires scientifiques
 * - 2 engrenages qui commencent à tourner (Physique/Mécanique)
 * - Ballon à fond rond en remplissage aux 2/3 avec un fluide animé (Chimie)
 * - Apparition progressive du slogan : "La réussite à portée de main"
 * - Bouton « Commencer l'expérience »
 */
@Composable
fun IntroSplashScreen(
  onStartExperience: () -> Unit
) {
  val infiniteTransition = rememberInfiniteTransition(label = "intro_infinite")

  // 1. Rotation des deux engrenages (rapport 1:1 meshed, sens opposés)
  val gear1Angle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 6000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "gear1Angle"
  )

  val gear2Angle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = -360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 6000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "gear2Angle"
  )

  // 2. Trajectoires et particules lumineuses
  val particlePhase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 2f * PI.toFloat(),
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 4000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "particlePhase"
  )

  // 3. Remplissage progressif du ballon à fond rond jusqu'aux 2/3 (0f -> 0.67f)
  var fluidTarget by remember { mutableFloatStateOf(0f) }
  LaunchedEffect(Unit) {
    kotlinx.coroutines.delay(400)
    fluidTarget = 0.67f // Remplissage aux 2/3
  }
  val fluidFillProgress by animateFloatAsState(
    targetValue = fluidTarget,
    animationSpec = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
    label = "fluidFillProgress"
  )

  // 4. Oscillation de surface du fluide (vaguelettes)
  val wavePhase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 2f * PI.toFloat(),
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1800, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "wavePhase"
  )

  // 5. Apparition progressive du slogan
  var showSlogan by remember { mutableStateOf(false) }
  var showButton by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    kotlinx.coroutines.delay(900)
    showSlogan = true
    kotlinx.coroutines.delay(600)
    showButton = true
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(
            MaterialTheme.colorScheme.surface,
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
          )
        )
      )
      .testTag("screen_intro_splash"),
    contentAlignment = Alignment.Center
  ) {
    // Background scientific particles & wave trajectories
    ScientificBackgroundCanvas(particlePhase = particlePhase)

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 24.dp, vertical = 32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Spacer(modifier = Modifier.height(16.dp))

      // Logo App Animé
      AppLogoAnimated(gear1Angle = gear1Angle)

      Spacer(modifier = Modifier.height(20.dp))

      // Science Laboratory Illustration Canvas: 2 Engrenages tournants + Ballon à fond rond en remplissage 2/3
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier
          .fillMaxWidth()
          .height(230.dp)
          .padding(horizontal = 8.dp)
      ) {
        ScientificApparatusCanvas(
          gear1Angle = gear1Angle,
          gear2Angle = gear2Angle,
          fluidFill = fluidFillProgress,
          wavePhase = wavePhase,
          particlePhase = particlePhase,
          modifier = Modifier.fillMaxSize()
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // App Title
      Text(
        text = "Physique & Chimie",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.ExtraBold,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.primary
      )

      Text(
        text = "2ème Année Baccalauréat • Sciences Physiques",
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(6.dp))

      Surface(
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
        shape = RoundedCornerShape(8.dp)
      ) {
        Text(
          text = "Conforme au Cadre de Référence Officiel • Pr. SBAI Mohammed",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Medium,
          color = MaterialTheme.colorScheme.onSecondaryContainer,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Apparition progressive du slogan : "La réussite à portée de main"
      AnimatedVisibility(
        visible = showSlogan,
        enter = fadeIn(animationSpec = tween(durationMillis = 1000)) + scaleIn(initialScale = 0.85f)
      ) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = ScienceGreen.copy(alpha = 0.12f)
          ),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = ScienceGreen,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "« La réussite à portée de main »",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Serif,
              color = ScienceGreen,
              textAlign = TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Bouton « Commencer l'expérience »
      AnimatedVisibility(
        visible = showButton,
        enter = fadeIn(animationSpec = tween(durationMillis = 800)) + scaleIn(initialScale = 0.9f)
      ) {
        Button(
          onClick = onStartExperience,
          modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .shadow(8.dp, RoundedCornerShape(16.dp))
            .testTag("btn_start_experience"),
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary
          )
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Icon(
              Icons.Default.RocketLaunch,
              contentDescription = null,
              modifier = Modifier.size(22.dp)
            )
            Text(
              text = "Commencer l'expérience",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp
            )
            Icon(
              Icons.Default.ArrowForward,
              contentDescription = null,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Plateforme pédagogique interactive : Cours, Labo virtuel, Exercices P1-P16 & C1-C9, Examens Nationaux",
        style = MaterialTheme.typography.labelSmall,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
      )
    }
  }
}

/**
 * Animated Logo with pulsing atomic orbit rings and scientific beaker/gear badge
 */
@Composable
private fun AppLogoAnimated(gear1Angle: Float) {
  Box(
    modifier = Modifier
      .size(90.dp)
      .clip(CircleShape)
      .background(
        Brush.radialGradient(
          colors = listOf(
            MaterialTheme.colorScheme.primaryContainer,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
          )
        )
      ),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val center = Offset(size.width / 2f, size.height / 2f)
      val radius = size.minDimension / 2f - 4.dp.toPx()

      // Outer pulsing orbit
      drawCircle(
        color = Color(0xFF0284C7).copy(alpha = 0.35f),
        radius = radius,
        style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), gear1Angle))
      )

      // Inner atom orbit
      drawCircle(
        color = Color(0xFF10B981).copy(alpha = 0.45f),
        radius = radius * 0.75f,
        style = Stroke(width = 1.5.dp.toPx())
      )
    }

    Box(
      modifier = Modifier
        .size(54.dp)
        .background(MaterialTheme.colorScheme.primary, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        Icons.Default.Science,
        contentDescription = "Logo Physique-Chimie",
        tint = Color.White,
        modifier = Modifier.size(32.dp)
      )
    }
  }
}

/**
 * Background glowing particles and scientific wave paths
 */
@Composable
private fun ScientificBackgroundCanvas(particlePhase: Float) {
  val primaryColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
  val secondaryColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f)
  val greenColor = ScienceGreen.copy(alpha = 0.12f)

  Canvas(modifier = Modifier.fillMaxSize()) {
    val w = size.width
    val h = size.height

    // Draw sinusoidal wave path
    val wavePath = Path()
    wavePath.moveTo(0f, h * 0.25f)
    var x = 0f
    while (x <= w) {
      val y = h * 0.25f + sin(x * 0.015f + particlePhase) * 25f
      wavePath.lineTo(x, y)
      x += 10f
    }
    drawPath(
      path = wavePath,
      color = primaryColor,
      style = Stroke(width = 2.dp.toPx())
    )

    // Wave 2
    val wavePath2 = Path()
    wavePath2.moveTo(0f, h * 0.78f)
    x = 0f
    while (x <= w) {
      val y = h * 0.78f + cos(x * 0.012f + particlePhase * 1.2f) * 28f
      wavePath2.lineTo(x, y)
      x += 10f
    }
    drawPath(
      path = wavePath2,
      color = secondaryColor,
      style = Stroke(width = 2.dp.toPx())
    )

    // Floating glowing particles along quantum orbits
    for (i in 0..12) {
      val angle = particlePhase + i * (2f * PI.toFloat() / 13f)
      val orbitX = (w * 0.5f) + cos(angle) * (w * 0.42f)
      val orbitY = (h * 0.5f) + sin(angle * 1.5f + i) * (h * 0.40f)
      val color = if (i % 2 == 0) primaryColor else greenColor
      val particleRadius = 3f + (i % 4) * 1.5f

      drawCircle(
        color = color.copy(alpha = 0.28f),
        radius = particleRadius * 2f,
        center = Offset(orbitX, orbitY)
      )
      drawCircle(
        color = Color.White.copy(alpha = 0.45f),
        radius = particleRadius,
        center = Offset(orbitX, orbitY)
      )
    }
  }
}

/**
 * Apparatus Canvas:
 * Left: Two meshed rotating gears (Physics & Mechanics)
 * Right: Round-bottom flask (Ballon à fond rond) filling 2/3 with bubbling animated fluid (Chemistry)
 */
@Composable
private fun ScientificApparatusCanvas(
  gear1Angle: Float,
  gear2Angle: Float,
  fluidFill: Float,
  wavePhase: Float,
  particlePhase: Float,
  modifier: Modifier = Modifier
) {
  val gearColor = MaterialTheme.colorScheme.primary
  val gearColor2 = Color(0xFFD97706) // Warm mechanical brass/amber
  val glassColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
  val liquidGradient = Brush.verticalGradient(
    colors = listOf(
      Color(0xFF06B6D4), // Cyan/Turquoise top
      Color(0xFF0284C7), // Science Blue
      Color(0xFF0369A1)  // Deep Blue bottom
    )
  )

  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height

    // -------------------------------------------------------------
    // SECTION 1 (GAUCHE) : DEUX ENGRENAGES QUI TOURNENT (PHYSIQUE)
    // -------------------------------------------------------------
    val gear1Center = Offset(w * 0.26f, h * 0.42f)
    val gear1Radius = min(w, h) * 0.22f

    val gear2Center = Offset(w * 0.26f + gear1Radius * 1.6f, h * 0.68f)
    val gear2Radius = gear1Radius * 0.72f

    // Draw connecting axis line between gears
    drawLine(
      color = Color.LightGray.copy(alpha = 0.35f),
      start = gear1Center,
      end = gear2Center,
      strokeWidth = 2.dp.toPx()
    )

    // Gear 1 (Main gear, rotating clockwise)
    drawGear(
      center = gear1Center,
      outerRadius = gear1Radius,
      innerRadius = gear1Radius * 0.72f,
      teethCount = 10,
      rotationAngle = gear1Angle,
      color = gearColor
    )

    // Gear 2 (Meshed secondary gear, rotating counter-clockwise)
    drawGear(
      center = gear2Center,
      outerRadius = gear2Radius,
      innerRadius = gear2Radius * 0.68f,
      teethCount = 7,
      rotationAngle = gear2Angle,
      color = gearColor2
    )

    // Label for Physics / Mechanics
    // -------------------------------------------------------------
    // SECTION 2 (DROITE) : BALLON À FOND ROND REMPLISSAGE 2/3 (CHIMIE)
    // -------------------------------------------------------------
    val flaskCenterX = w * 0.76f
    val flaskCenterY = h * 0.62f
    val bulbRadius = min(w, h) * 0.26f
    val neckWidth = bulbRadius * 0.46f
    val neckHeight = bulbRadius * 0.95f
    val neckTopY = flaskCenterY - bulbRadius - neckHeight * 0.55f

    // Complete Flask Path (Spherical bulb + vertical neck + lip)
    val flaskPath = Path().apply {
      // Start top lip left
      val leftNeckX = flaskCenterX - neckWidth / 2f
      val rightNeckX = flaskCenterX + neckWidth / 2f

      moveTo(leftNeckX - 4f, neckTopY)
      lineTo(rightNeckX + 4f, neckTopY) // lip top
      lineTo(rightNeckX, neckTopY + 8f)  // lip right
      lineTo(rightNeckX, flaskCenterY - bulbRadius * 0.65f) // neck right down to bulb

      // Arc for spherical bottom
      arcTo(
        rect = Rect(
          left = flaskCenterX - bulbRadius,
          top = flaskCenterY - bulbRadius,
          right = flaskCenterX + bulbRadius,
          bottom = flaskCenterY + bulbRadius
        ),
        startAngleDegrees = -50f,
        sweepAngleDegrees = 280f,
        forceMoveTo = false
      )

      lineTo(leftNeckX, neckTopY + 8f)
      lineTo(leftNeckX - 4f, neckTopY)
      close()
    }

    // Clip to flask interior to draw filling fluid up to 2/3
    clipPath(flaskPath) {
      if (fluidFill > 0.01f) {
        val totalFlaskBottom = flaskCenterY + bulbRadius
        val maxFillHeight = (bulbRadius * 2f + neckHeight) * 0.67f // 2/3 height
        val currentFillHeight = maxFillHeight * fluidFill
        val liquidSurfaceY = totalFlaskBottom - currentFillHeight

        // Fluid body
        val fluidPath = Path().apply {
          moveTo(flaskCenterX - bulbRadius * 1.5f, totalFlaskBottom + 20f)
          lineTo(flaskCenterX + bulbRadius * 1.5f, totalFlaskBottom + 20f)
          lineTo(flaskCenterX + bulbRadius * 1.5f, liquidSurfaceY)

          // Fluid wavy surface
          var fx = flaskCenterX + bulbRadius * 1.5f
          while (fx >= flaskCenterX - bulbRadius * 1.5f) {
            val waveY = liquidSurfaceY + sin(fx * 0.06f + wavePhase) * 4f
            lineTo(fx, waveY)
            fx -= 8f
          }
          close()
        }

        // Draw fluid fill with vibrant gradient
        drawPath(
          path = fluidPath,
          brush = liquidGradient
        )

        // Fluid surface highlight
        drawLine(
          color = Color.White.copy(alpha = 0.6f),
          start = Offset(flaskCenterX - bulbRadius * 0.8f, liquidSurfaceY),
          end = Offset(flaskCenterX + bulbRadius * 0.8f, liquidSurfaceY),
          strokeWidth = 2.dp.toPx()
        )

        // Effervescent bubbles rising in the liquid
        val bubbleCount = 7
        for (b in 0 until bubbleCount) {
          val bx = flaskCenterX - bulbRadius * 0.45f + ((b * 37) % (bulbRadius * 0.9f).toInt())
          val travelProgress = ((particlePhase * 1.2f + b * 1.1f) % (2f * PI.toFloat())) / (2f * PI.toFloat())
          val by = totalFlaskBottom - 10f - (currentFillHeight - 12f) * travelProgress
          val bRadius = 2.5f + (b % 3) * 1.5f

          if (by > liquidSurfaceY && by < totalFlaskBottom) {
            drawCircle(
              color = Color.White.copy(alpha = 0.55f),
              radius = bRadius,
              center = Offset(bx, by),
              style = Stroke(width = 1.2.dp.toPx())
            )
            drawCircle(
              color = Color.White.copy(alpha = 0.25f),
              radius = bRadius * 0.6f,
              center = Offset(bx, by)
            )
          }
        }
      }
    }

    // Draw Flask Glass Contour
    drawPath(
      path = flaskPath,
      color = glassColor,
      style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
    )

    // Glass reflection curve
    val reflectionPath = Path().apply {
      arcTo(
        rect = Rect(
          left = flaskCenterX - bulbRadius * 0.85f,
          top = flaskCenterY - bulbRadius * 0.85f,
          right = flaskCenterX + bulbRadius * 0.85f,
          bottom = flaskCenterY + bulbRadius * 0.85f
        ),
        startAngleDegrees = 135f,
        sweepAngleDegrees = 65f,
        forceMoveTo = false
      )
    }
    drawPath(
      path = reflectionPath,
      color = Color.White.copy(alpha = 0.55f),
      style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
    )

    // Graduations lines (100 mL, 200 mL, 250 mL)
    val gradY1 = flaskCenterY + bulbRadius * 0.1f
    val gradY2 = flaskCenterY - bulbRadius * 0.25f
    drawLine(
      color = glassColor.copy(alpha = 0.5f),
      start = Offset(flaskCenterX - bulbRadius * 0.6f, gradY1),
      end = Offset(flaskCenterX - bulbRadius * 0.4f, gradY1),
      strokeWidth = 1.5.dp.toPx()
    )
    drawLine(
      color = glassColor.copy(alpha = 0.5f),
      start = Offset(flaskCenterX - bulbRadius * 0.55f, gradY2),
      end = Offset(flaskCenterX - bulbRadius * 0.35f, gradY2),
      strokeWidth = 1.5.dp.toPx()
    )
  }
}

/**
 * Helper to draw a detailed mechanical gear with teeth and axle
 */
private fun DrawScope.drawGear(
  center: Offset,
  outerRadius: Float,
  innerRadius: Float,
  teethCount: Int,
  rotationAngle: Float,
  color: Color
) {
  val gearPath = Path()
  val angleStep = (2f * PI / teethCount).toFloat()
  val rotRad = Math.toRadians(rotationAngle.toDouble()).toFloat()

  for (i in 0 until teethCount) {
    val a0 = rotRad + i * angleStep
    val a1 = a0 + angleStep * 0.3f
    val a2 = a0 + angleStep * 0.5f
    val a3 = a0 + angleStep * 0.8f

    // Inner point
    val p0 = Offset(center.x + innerRadius * cos(a0), center.y + innerRadius * sin(a0))
    // Tooth rise
    val p1 = Offset(center.x + outerRadius * cos(a1), center.y + outerRadius * sin(a1))
    // Tooth top
    val p2 = Offset(center.x + outerRadius * cos(a2), center.y + outerRadius * sin(a2))
    // Tooth descent
    val p3 = Offset(center.x + innerRadius * cos(a3), center.y + innerRadius * sin(a3))

    if (i == 0) {
      gearPath.moveTo(p0.x, p0.y)
    } else {
      gearPath.lineTo(p0.x, p0.y)
    }
    gearPath.lineTo(p1.x, p1.y)
    gearPath.lineTo(p2.x, p2.y)
    gearPath.lineTo(p3.x, p3.y)
  }
  gearPath.close()

  // Fill gear body
  drawPath(
    path = gearPath,
    color = color.copy(alpha = 0.85f)
  )

  // Gear contour
  drawPath(
    path = gearPath,
    color = color,
    style = Stroke(width = 2.dp.toPx())
  )

  // Center axle hub
  drawCircle(
    color = Color.White.copy(alpha = 0.9f),
    radius = innerRadius * 0.35f,
    center = center
  )
  drawCircle(
    color = color,
    radius = innerRadius * 0.18f,
    center = center
  )
}
