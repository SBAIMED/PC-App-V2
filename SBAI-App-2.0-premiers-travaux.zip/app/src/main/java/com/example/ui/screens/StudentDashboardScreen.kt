package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.AppLocalRepository
import com.example.ui.components.StudentProgressDashboardCard
import com.example.ui.components.TestScoresOverviewCard
import com.example.ui.components.UpcomingStudyRemindersCard
import com.example.ui.components.VisualAnalyticsDashboard
import com.example.ui.theme.ScienceGreen

@Composable
fun StudentDashboardScreen(
  studentName: String = "Élève 2BAC",
  studentClass: String = "2ème Bac Sciences Physiques • Lycée Qualifiant",
  currentQuizScore: Int = 320,
  userCompletedEvals: Map<String, Double> = emptyMap(),
  onNavigateToCourses: () -> Unit = {},
  onNavigateToEvaluations: () -> Unit = {},
  onNavigateToExercises: () -> Unit = {}
) {
  val context = LocalContext.current
  val repository = remember { AppLocalRepository.getInstance(context) }
  val physicsDone by repository.physicsCompletedCount.collectAsStateWithLifecycle(initialValue = 12)
  val chemistryDone by repository.chemistryCompletedCount.collectAsStateWithLifecycle(initialValue = 8)
  val totalDone by repository.totalCompletedCount.collectAsStateWithLifecycle(initialValue = 20)
  val attempts by repository.recentQuizAttempts.collectAsStateWithLifecycle(initialValue = emptyList())
  val totalChapters = 26
  val computedProgress = (totalDone.toFloat() / totalChapters.toFloat()).coerceIn(0f, 1f)

  // Student metrics wired to completed evaluations or realistic benchmarks
  val cc1S1 = userCompletedEvals["eval_s1_cc1"] ?: 16.5
  val cc2S1 = userCompletedEvals["eval_s1_cc2"] ?: 17.0
  val cc3S1 = userCompletedEvals["eval_s1_cc3"] ?: 18.0
  val s1ScoresList = listOf(
    "CC1 (Cinétique/Ondes)" to cc1S1,
    "CC2 (Nucléaire/RC)" to cc2S1,
    "CC3 (Équilibre/RLC)" to cc3S1
  )

  val cc1S2 = userCompletedEvals["eval_s2_cc1"] ?: 17.5
  val cc2S2 = userCompletedEvals["eval_s2_cc2"] ?: 18.5
  val cc3S2 = userCompletedEvals["eval_s2_cc3"] ?: 19.0
  val s2ScoresList = listOf(
    "CC1 (Titrage/Newton)" to cc1S2,
    "CC2 (Piles/Pendules)" to cc2S2,
    "CC3 (Esters/Synthèse)" to cc3S2
  )

  val s1Average = s1ScoresList.map { it.second }.average()
  val s2Average = s2ScoresList.map { it.second }.average()
  val globalAverage = (s1Average + s2Average) / 2.0
  val avgScore = if (attempts.isNotEmpty()) attempts.map { it.score }.average() else globalAverage

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("student_dashboard_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Profile Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        shape = RoundedCornerShape(20.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Box(
              modifier = Modifier
                .size(48.dp)
                .background(MaterialTheme.colorScheme.secondary, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(
                studentName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
              )
              Text(
                studentClass,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
              )
            }

            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = RoundedCornerShape(10.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                Text(
                  "Rang : 2e / 34",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.secondary
                )
              }
            }
          }
        }
      }
    }

    // 1. Dashboard Visuel Analytique Complet (Anneaux M3, Courbe des Notes, Domaines & Matrice 26 Chapitres)
    item {
      VisualAnalyticsDashboard(
        studentName = studentName,
        physicsCompleted = physicsDone,
        chemistryCompleted = chemistryDone,
        totalCompleted = totalDone,
        quizAverage = avgScore,
        onNavigateToCourses = onNavigateToCourses,
        onNavigateToExercises = onNavigateToExercises
      )
    }

    // 2. Material 3 Student Progress Quick Dashboard Card (Persisté en BDD Room)
    item {
      StudentProgressDashboardCard(
        overallProgress = computedProgress,
        physicsCompleted = physicsDone,
        physicsTotal = 16,
        chemistryCompleted = chemistryDone,
        chemistryTotal = 10,
        exercisesDone = (totalDone * 0.8).toInt(),
        exercisesTotal = 26,
        quizScore = currentQuizScore,
        onContinueRevisionClick = onNavigateToCourses
      )
    }

    // 3. Material 3 Test Scores Overview Card
    item {
      TestScoresOverviewCard(
        s1Scores = s1ScoresList,
        s2Scores = s2ScoresList,
        onOpenEvaluationsClick = onNavigateToEvaluations
      )
    }

    // 3. Material 3 Upcoming Study Reminders Card
    item {
      UpcomingStudyRemindersCard(
        onReminderClick = {
          onNavigateToCourses()
        }
      )
    }

    // 4. Earned Badges & Trophies
    item {
      ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Icon(Icons.Default.MilitaryTech, contentDescription = null, tint = Color(0xFFEAB308), modifier = Modifier.size(24.dp))
            Text(
              "Badges de Réussite & Trophées :",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
          ) {
            BadgeItem("Major Physique", Icons.Default.MilitaryTech, Color(0xFFEAB308))
            BadgeItem("As du Circuit RC", Icons.Default.Bolt, Color(0xFF3B82F6))
            BadgeItem("Expert Bac 2025", Icons.Default.WorkspacePremium, Color(0xFF10B981))
          }
        }
      }
    }

    // 5. Baccalaureate Simulator & Projection
    item {
      ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(
              "Simulateur de Mention au Baccalauréat :",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
          }
          Text(
            "Avec une moyenne actuelle en Physique-Chimie de ${"%.2f".format(globalAverage)}/20 (Coefficient 7), vous êtes sur la trajectoire idéale pour décrocher la Mention Très Bien à l'Examen National (session de juin 2026).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}

@Composable
fun BadgeItem(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
  Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
    Box(
      modifier = Modifier
        .size(50.dp)
        .background(color.copy(alpha = 0.15f), CircleShape)
        .border(1.5.dp, color, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(26.dp))
    }
    Text(title, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
  }
}
