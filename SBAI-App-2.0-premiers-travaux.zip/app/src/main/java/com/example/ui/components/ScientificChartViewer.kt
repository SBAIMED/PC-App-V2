package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ScientificChartType
import kotlin.math.*

/**
 * High-precision scientific chart and diagram viewer for Physics & Chemistry.
 * Features:
 * - Millimeter/oscilloscope grid
 * - Accurate experimental curves
 * - Tangents, asymptotes, and notable points for graphical exploitation
 * - Interactive touch probe to read coordinates (x, y) anywhere on the curve
 * - Pedagogical reading guide for students
 */
@Composable
fun ScientificChartViewer(
  chartType: ScientificChartType,
  title: String? = null,
  exploitationGuide: String? = null,
  modifier: Modifier = Modifier
) {
  if (chartType == ScientificChartType.NONE) return

  var showTangents by remember { mutableStateOf(true) }
  var showNotablePoints by remember { mutableStateOf(true) }
  var showGuide by remember { mutableStateOf(true) }
  var touchNormalizedX by remember { mutableStateOf<Float?>(null) }
  var zoomScale by remember { mutableFloatStateOf(1.0f) }
  var panOffset by remember { mutableStateOf(Offset.Zero) }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("scientific_chart_${chartType.name}"),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    shape = RoundedCornerShape(16.dp),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Header with Title & Badges
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.weight(1f)
        ) {
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(
              imageVector = if (chartType == ScientificChartType.MONTAGE_CIRCUIT_RC || chartType == ScientificChartType.MONTAGE_TITRAGE || chartType == ScientificChartType.DIFFRACTION_FENTE)
                Icons.Default.Biotech else Icons.Default.ShowChart,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(6.dp).size(20.dp)
            )
          }
          Column {
            MathFormattedText(
              text = title ?: getChartDefaultTitle(chartType),
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "Graphique exploitable · Toucher pour mesurer",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }

        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer,
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = "Échelle exacte",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.secondary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      // Graph interactive toggles & Zoom Controls
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (isCurveType(chartType)) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(
              selected = showTangents,
              onClick = { showTangents = !showTangents },
              label = { Text("Tangentes", style = MaterialTheme.typography.labelSmall) },
              leadingIcon = if (showTangents) {
                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
              } else null
            )

            FilterChip(
              selected = showNotablePoints,
              onClick = { showNotablePoints = !showNotablePoints },
              label = { Text("Points clés", style = MaterialTheme.typography.labelSmall) },
              leadingIcon = if (showNotablePoints) {
                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
              } else null
            )
          }
        } else {
          Spacer(modifier = Modifier.width(1.dp))
        }

        // Zoom in/out/reset controls
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          if (zoomScale > 1.05f || panOffset != Offset.Zero) {
            FilledTonalButton(
              onClick = {
                zoomScale = 1.0f
                panOffset = Offset.Zero
              },
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
              modifier = Modifier.height(30.dp)
            ) {
              Text("${"%.1f".format(zoomScale)}x Reset", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          IconButton(
            onClick = {
              zoomScale = (zoomScale - 0.25f).coerceAtLeast(1.0f)
              if (zoomScale == 1.0f) panOffset = Offset.Zero
            },
            modifier = Modifier.size(32.dp),
            enabled = zoomScale > 1.0f
          ) {
            Icon(Icons.Default.ZoomOut, contentDescription = "Dézoomer", modifier = Modifier.size(18.dp))
          }

          IconButton(
            onClick = {
              zoomScale = (zoomScale + 0.25f).coerceAtMost(3.0f)
            },
            modifier = Modifier.size(32.dp),
            enabled = zoomScale < 3.0f
          ) {
            Icon(Icons.Default.ZoomIn, contentDescription = "Zoomer", modifier = Modifier.size(18.dp))
          }
        }
      }

      // Main Interactive Canvas
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(260.dp)
          .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
          .pointerInput(chartType) {
            detectTransformGestures { _, pan, zoom, _ ->
              val newScale = (zoomScale * zoom).coerceIn(1.0f, 3.5f)
              zoomScale = newScale
              panOffset = if (newScale > 1.0f) {
                Offset(
                  (panOffset.x + pan.x).coerceIn(-250f * (newScale - 1f), 250f * (newScale - 1f)),
                  (panOffset.y + pan.y).coerceIn(-150f * (newScale - 1f), 150f * (newScale - 1f))
                )
              } else Offset.Zero
            }
          }
          .pointerInput(chartType) {
            detectTapGestures(
              onTap = { offset ->
                val padLeft = 45f
                val padRight = 20f
                val chartW = size.width - padLeft - padRight
                if (chartW > 0 && offset.x >= padLeft && offset.x <= size.width - padRight) {
                  touchNormalizedX = ((offset.x - padLeft) / chartW).coerceIn(0f, 1f)
                }
              }
            )
          }
          .pointerInput(chartType) {
            detectDragGestures { change, _ ->
              val padLeft = 45f
              val padRight = 20f
              val chartW = size.width - padLeft - padRight
              if (chartW > 0) {
                touchNormalizedX = ((change.position.x - padLeft) / chartW).coerceIn(0f, 1f)
              }
            }
          }
      ) {
        val primaryColor = MaterialTheme.colorScheme.primary
        val secondaryColor = MaterialTheme.colorScheme.secondary
        val tertiaryColor = MaterialTheme.colorScheme.tertiary
        val onSurfaceColor = MaterialTheme.colorScheme.onSurface
        val surfaceColor = MaterialTheme.colorScheme.surface
        val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
        val gridSubColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)

        Canvas(modifier = Modifier.fillMaxSize()) {
          withTransform({
            scale(zoomScale, zoomScale, center)
            translate(panOffset.x, panOffset.y)
          }) {
          when (chartType) {
            ScientificChartType.RC_CHARGE -> drawRCCharge(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.RC_DECHARGE -> drawRCDecharge(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.RL_ETABLISSEMENT -> drawRLEtablissement(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.RLC_AMORTI -> drawRLCAmorti(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.TITRAGE_PH -> drawTitragePH(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.CINETIQUE_AVANCEMENT -> drawCinetiqueAvancement(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.DECROISSANCE_RADIOACTIVE -> drawDecroissanceRadioactive(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.ONDE_CORDE_ASPECT -> drawOndeCordeAspect(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.ONDE_ELONGATION_TEMPS -> drawOndeElongationTemps(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.DIFFRACTION_FENTE -> drawDiffractionFigure(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor
            )
            ScientificChartType.CHUTE_VERTICALE -> drawChuteVerticale(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.PROJECTILE_PARABOLE -> drawProjectileParabole(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.MONTAGE_CIRCUIT_RC -> drawMontageCircuitRC(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, surfaceColor
            )
            ScientificChartType.MONTAGE_TITRAGE -> drawMontageTitrage(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor
            )
            ScientificChartType.FACTEURS_CINETIQUES_TEMPERATURE -> drawFacteursCinetiquesTemperature(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.FACTEURS_CINETIQUES_CONCENTRATION -> drawFacteursCinetiquesConcentration(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.MONTAGE_PRESSIOMETRIE -> drawMontagePressiometrie(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor
            )
            ScientificChartType.ECHELLE_PH_PREDOMINANCE -> drawEchellePHPredominance(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor
            )
            ScientificChartType.DIAGRAMME_DISTRIBUTION_PKA -> drawDiagrammeDistributionPKa(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.MONTAGE_PILE_DANIELL -> drawMontagePileDaniell(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor
            )
            ScientificChartType.MONTAGE_ELECTROLYSE -> drawMontageElectrolyse(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor
            )
            ScientificChartType.MONTAGE_CHAUFFAGE_REFLUX -> drawMontageChauffageReflux(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor
            )
            ScientificChartType.CINETIQUE_ESTERIFICATION_HYDROLYSE -> drawCinetiqueEsterificationHydrolyse(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showTangents, showNotablePoints, touchNormalizedX
            )
            ScientificChartType.COURBE_ASTON_ENERGIE -> drawCourbeAston(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showNotablePoints, touchNormalizedX
            )
            ScientificChartType.MODULATION_AM_TRAPEZE -> drawModulationAM(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showNotablePoints, touchNormalizedX
            )
            ScientificChartType.NEWTON_CINEMATIQUE_VT -> drawNewtonCinematique(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showNotablePoints, touchNormalizedX
            )
            ScientificChartType.SATELLITE_ORBITE_KEPLER -> drawSatelliteKepler(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor
            )
            ScientificChartType.ROTATION_SOLIDE_VITESSE -> drawRotationSolide(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showNotablePoints, touchNormalizedX
            )
            ScientificChartType.OSCILLATEUR_PENDULE_XT -> drawOscillateurPendule(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showNotablePoints, touchNormalizedX
            )
            ScientificChartType.OSCILLATEUR_ENERGIE_EP_EC -> drawOscillateurEnergie(
              primaryColor, secondaryColor, tertiaryColor, onSurfaceColor, gridColor, gridSubColor,
              showNotablePoints, touchNormalizedX
            )
            ScientificChartType.NONE -> {}
          }
        }
      }

        // Floating Clear Touch readout badge
        if (touchNormalizedX != null && isCurveType(chartType)) {
          val readout = getCurveReadout(chartType, touchNormalizedX!!)
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(20.dp),
            shadowElevation = 3.dp,
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(8.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
              Text(
                text = readout,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
            }
          }
        }
      }

      // Exploitation guide for the student
      val guide = exploitationGuide ?: getDefaultExploitationGuide(chartType)
      if (guide.isNotBlank()) {
        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(
                  Icons.Default.Insights,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                  tint = MaterialTheme.colorScheme.secondary
                )
                Text(
                  "Données exploitables sur ce graphique :",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.secondary
                )
              }
              IconButton(
                onClick = { showGuide = !showGuide },
                modifier = Modifier.size(24.dp)
              ) {
                Icon(
                  if (showGuide) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp)
                )
              }
            }

            AnimatedVisibility(visible = showGuide) {
              MathFormattedText(
                text = guide,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }
  }
}

private fun isCurveType(type: ScientificChartType): Boolean {
  return when (type) {
    ScientificChartType.MONTAGE_CIRCUIT_RC,
    ScientificChartType.MONTAGE_TITRAGE,
    ScientificChartType.DIFFRACTION_FENTE,
    ScientificChartType.MONTAGE_PRESSIOMETRIE,
    ScientificChartType.ECHELLE_PH_PREDOMINANCE,
    ScientificChartType.MONTAGE_PILE_DANIELL,
    ScientificChartType.MONTAGE_ELECTROLYSE,
    ScientificChartType.MONTAGE_CHAUFFAGE_REFLUX,
    ScientificChartType.SATELLITE_ORBITE_KEPLER,
    ScientificChartType.NONE -> false
    else -> true
  }
}

private fun getChartDefaultTitle(type: ScientificChartType): String {
  return when (type) {
    ScientificChartType.RC_CHARGE -> "Courbe de charge du dipôle RC : u_C(t)"
    ScientificChartType.RC_DECHARGE -> "Courbe de décharge du condensateur : u_C(t)"
    ScientificChartType.RL_ETABLISSEMENT -> "Établissement du courant dans le dipôle RL : i(t)"
    ScientificChartType.RLC_AMORTI -> "Régime pseudo-périodique du dipôle RLC : u_C(t)"
    ScientificChartType.TITRAGE_PH -> "Courbe de titrage pH-métrique : pH = f(V_b)"
    ScientificChartType.CINETIQUE_AVANCEMENT -> "Suivi cinétique de la réaction : x = f(t)"
    ScientificChartType.DECROISSANCE_RADIOACTIVE -> "Loi de décroissance radioactive : A = f(t)"
    ScientificChartType.ONDE_CORDE_ASPECT -> "Aspect de la corde à la date t_1 : y = f(x)"
    ScientificChartType.ONDE_ELONGATION_TEMPS -> "Élongation du point M : y_M = f(t)"
    ScientificChartType.DIFFRACTION_FENTE -> "Dispositif et figure de diffraction de la lumière"
    ScientificChartType.CHUTE_VERTICALE -> "Chute verticale avec frottement fluide : v = f(t)"
    ScientificChartType.PROJECTILE_PARABOLE -> "Trajectoire parabolique du projectile : y = f(x)"
    ScientificChartType.MONTAGE_CIRCUIT_RC -> "Schéma de montage RC avec oscilloscope"
    ScientificChartType.MONTAGE_TITRAGE -> "Dispositif expérimental du dosage pH-métrique"
    ScientificChartType.FACTEURS_CINETIQUES_TEMPERATURE -> "Facteur cinétique température : x = f(t) à T₂ > T₁"
    ScientificChartType.FACTEURS_CINETIQUES_CONCENTRATION -> "Facteur cinétique concentration : x = f(t) à C₂ > C₁"
    ScientificChartType.MONTAGE_PRESSIOMETRIE -> "Montage expérimental du suivi par pressiométrie (P·V = n·R·T)"
    ScientificChartType.ECHELLE_PH_PREDOMINANCE -> "Échelle de pH et diagramme de prédominance (Couple HA / A⁻)"
    ScientificChartType.DIAGRAMME_DISTRIBUTION_PKA -> "Diagramme de distribution des espèces : α(HA) et α(A⁻) = f(pH)"
    ScientificChartType.MONTAGE_PILE_DANIELL -> "Schéma expérimental de la pile Daniell (Zn - Cu) avec pont salin"
    ScientificChartType.MONTAGE_ELECTROLYSE -> "Dispositif expérimental d'électrolyse (Transformations forcées)"
    ScientificChartType.MONTAGE_CHAUFFAGE_REFLUX -> "Dispositif expérimental du chauffage à reflux avec réfrigérant à boules"
    ScientificChartType.CINETIQUE_ESTERIFICATION_HYDROLYSE -> "Cinétiques comparées de l'estérification et de l'hydrolyse : n = f(t)"
    ScientificChartType.COURBE_ASTON_ENERGIE -> "Courbe d'Aston : Énergie de liaison par nucléon -E_ℓ/A = f(A)"
    ScientificChartType.MODULATION_AM_TRAPEZE -> "Signal modulé AM u_s(t) et trapèze en mode XY"
    ScientificChartType.NEWTON_CINEMATIQUE_VT -> "Graphe cinématique v = f(t) et calcul d'accélération"
    ScientificChartType.SATELLITE_ORBITE_KEPLER -> "Mouvement des satellites et 3ème loi de Kepler"
    ScientificChartType.ROTATION_SOLIDE_VITESSE -> "Rotation d'un solide autour d'un axe fixe : ω = f(t)"
    ScientificChartType.OSCILLATEUR_PENDULE_XT -> "Oscillations du pendule élastique x(t) et résonance"
    ScientificChartType.OSCILLATEUR_ENERGIE_EP_EC -> "Diagramme énergétique de l'oscillateur : E_pe, E_c et E_m"
    ScientificChartType.NONE -> "Graphique"
  }
}

private fun getDefaultExploitationGuide(type: ScientificChartType): String {
  return when (type) {
    ScientificChartType.RC_CHARGE ->
      "• Tangente à l'origine (t = 0) : coupe l'asymptote u_C = E = 6.0 V à l'abscisse t = τ = 4.7 ms.\n" +
      "• Méthode des 63% : à t = τ = 4.7 ms, la tension atteint 63% de sa valeur max : u_C(τ) = 0.63 × 6.0 V = 3.78 V.\n" +
      "• Régime permanent atteint à t ≥ 5τ ≈ 23.5 ms."

    ScientificChartType.RC_DECHARGE ->
      "• Tangente à t = 0 : coupe l'axe des abscisses à t = τ = 4.7 ms.\n" +
      "• Méthode des 37% : à t = τ, u_C(τ) = 0.37 × E = 2.22 V."

    ScientificChartType.RL_ETABLISSEMENT ->
      "• Asymptote horizontale : intensité maximale I_0 = E / (R + r) = 50 mA.\n" +
      "• Tangente à t = 0 : coupe I_0 à t = τ = L / (R + r) = 2.5 ms.\n" +
      "• À t = τ : i(τ) = 0.63 × I_0 = 31.5 mA."

    ScientificChartType.RLC_AMORTI ->
      "• Pseudo-période T : durée séparant deux maxima successifs (T ≈ 1.25 ms).\n" +
      "• En faible amortissement, T ≈ T_0 = 2π√(L·C)."

    ScientificChartType.TITRAGE_PH ->
      "• Méthode des tangentes parallèles : les deux tangentes parallèles aux deux courbures et leur équidistante déterminent le point d'équivalence E(V_bE = 15.0 mL ; pH_E = 8.75).\n" +
      "• Demi-équivalence : pour V_b = V_bE / 2 = 7.5 mL, lecture directe du pH = pKa = 4.8.\n" +
      "• Courbe dérivée dpH/dV_b (en vert) : présente son pic maximal exactement à V_b = V_bE."

    ScientificChartType.CINETIQUE_AVANCEMENT ->
      "• Avancement final / maximal : asymptote x_max = 2.0 mmol.\n" +
      "• Temps de demi-réaction t_1/2 : abscisse correspondant à x(t_1/2) = x_max / 2 = 1.0 mmol, soit t_1/2 = 6.0 min.\n" +
      "• Vitesse volumique de réaction v(t) = (1/V)·(dx/dt) : proportionnelle à la pente de la tangente à la date considérée (la vitesse diminue au cours du temps)."

    ScientificChartType.FACTEURS_CINETIQUES_TEMPERATURE ->
      "• Même avancement final : x_f = 2.0 mmol pour les deux températures (la température n'affecte pas l'état d'équilibre).\n" +
      "• Pente initiale à t=0 : la pente de la courbe à T₂ = 45°C (orange) est 2.5× plus forte que celle à T₁ = 20°C (bleue).\n" +
      "• Temps de demi-réaction : t_1/2(T₂) = 2.5 min contre t_1/2(T₁) = 6.0 min. L'élévation de température accélère l'évolution temporelle."

    ScientificChartType.FACTEURS_CINETIQUES_CONCENTRATION ->
      "• Augmentation de la vitesse initiale : la pente à t=0 pour C₂ = 2·C₁ est deux fois plus élevée.\n" +
      "• Modification de l'état final : comme le réactif est limitant, x_f2 = 2.0 mmol est le double de x_f1 = 1.0 mmol."

    ScientificChartType.MONTAGE_PRESSIOMETRIE ->
      "• Loi des gaz parfaits : P·V = n(gaz)·R·T avec V volume de la phase gazeuse (V = 500 mL) et T = 298 K.\n" +
      "• Relation avancement - pression : x(t) = (ΔP(t) · V) / (R · T).\n" +
      "• À chaque instant, la surpression ΔP(t) = P(t) - P₀ mesurée par le capteur est directement proportionnelle à l'avancement x(t)."

    ScientificChartType.ECHELLE_PH_PREDOMINANCE ->
      "• Échelle de pH : Milieu acide (0 ≤ pH < 7), Milieu neutre (pH = 7 à 25°C), Milieu basique (7 < pH ≤ 14).\n" +
      "• Couple acido-basique (HA / A⁻) avec pKa = 4.8 :\n" +
      "  - Si pH < pKa : [HA] > [A⁻] (l'espèce acide HA prédomine).\n" +
      "  - Si pH = pKa : [HA] = [A⁻] (égalité des concentrations).\n" +
      "  - Si pH > pKa : [A⁻] > [HA] (l'espèce basique A⁻ prédomine)."

    ScientificChartType.DIAGRAMME_DISTRIBUTION_PKA ->
      "• Pourcentages d'espèces : α(HA) = [HA]/C × 100% et α(A⁻) = [A⁻]/C × 100% avec α(HA) + α(A⁻) = 100%.\n" +
      "• Point de croisement : à l'intersection des deux courbes où α(HA) = α(A⁻) = 50%, la projection sur l'axe des abscisses donne directement le pKa = 4.8 du couple."

    ScientificChartType.MONTAGE_PILE_DANIELL ->
      "• Pôle négatif (-) = Anode : électrode de Zinc plongeant dans Zn²⁺ (siège de l'oxydation : Zn → Zn²⁺ + 2e⁻).\n" +
      "• Pôle positif (+) = Cathode : électrode de Cuivre plongeant dans Cu²⁺ (siège de la réduction : Cu²⁺ + 2e⁻ → Cu).\n" +
      "• Pont salin : assure la neutralité électrique par migration des cations (K⁺) vers la cathode et des anions (NO₃⁻) vers l'anode.\n" +
      "• Courant électrique I du (+) vers le (-), circulation des électrons e⁻ en sens opposé du (-) vers le (+)."

    ScientificChartType.MONTAGE_ELECTROLYSE ->
      "• Transformation forcée : imposée par un générateur de tension continue G (sens inverse de l'évolution spontanée).\n" +
      "• Anode (reliée au pôle + du générateur) : siège de l'oxydation (2Br⁻ → Br₂ + 2e⁻, dégagement de dibrome).\n" +
      "• Cathode (reliée au pôle - du générateur) : siège de la réduction (Cu²⁺ + 2e⁻ → Cu, dépôt de cuivre métallique rouge).\n" +
      "• Bilan quantitatif : quantité d'électricité Q = I · Δt = n(e⁻) · F."

    ScientificChartType.MONTAGE_CHAUFFAGE_REFLUX ->
      "• Chauffe-ballon & support élévateur : permet d'augmenter la température pour accélérer la réaction chimique.\n" +
      "• Réfrigérant à boules : condense les vapeurs de réactifs et produits qui retombent sous forme liquide dans le ballon.\n" +
      "• Rôle fondamental : accélérer la réaction chimique sans aucune perte de matière !"

    ScientificChartType.CINETIQUE_ESTERIFICATION_HYDROLYSE ->
      "• Réactions inverses : Estérification (Acide + Alcool ⇌ Ester + Eau) et Hydrolyse (Ester + Eau ⇌ Acide + Alcool).\n" +
      "• Rendement à l'équilibre pour un mélange équimolaire d'acide et d'alcool primaire : r = 67% (n_ester = 0.67 mol).\n" +
      "• Caractéristiques : réactions très lentes, limitées et athermiques (la constante K = 4 ne dépend pas de la température)."

    ScientificChartType.DECROISSANCE_RADIOACTIVE ->
      "• Activité initiale : A_0 = 0.25 Bq/g.\n" +
      "• Demi-vie t_1/2 : pour A = A_0 / 2 = 0.125 Bq/g, l'abscisse donne t_1/2 = 5730 ans.\n" +
      "• Pour A = 0.18 Bq/g (échantillon de l'exercice), lecture directe : t ≈ 2716 ans."

    ScientificChartType.ONDE_CORDE_ASPECT ->
      "• Longueur d'onde λ : distance entre deux crêtes consécutives : λ = 40 cm.\n" +
      "• Position du front d'onde à t_1 = 40 ms : x_F = 80 cm.\n" +
      "• Célérité de l'onde : v = x_F / t_1 = 0.80 m / 0.04 s = 20 m/s."

    ScientificChartType.ONDE_ELONGATION_TEMPS ->
      "• Période temporelle T : durée d'un cycle complet : T = 20 ms (N = 1/T = 50 Hz).\n" +
      "• Retard temporel τ du point M : début du mouvement à t = τ = 40 ms."

    ScientificChartType.CHUTE_VERTICALE ->
      "• Vitesse limite v_lim : asymptote horizontale à v = 12.0 m/s.\n" +
      "• Tangente à t = 0 : pente égale à l'accélération initiale a_0 = g = 9.8 m/s².\n" +
      "• Temps caractéristique τ : intersection de la tangente avec v_lim à t = τ = 1.22 s."

    ScientificChartType.PROJECTILE_PARABOLE ->
      "• Sommet de la trajectoire (Flèche F) : hauteur maximale y_F = 4.5 m atteinte à x = 7.8 m.\n" +
      "• Portée P : distance au point de chute au sol (y = 0) : x_P = 15.6 m."

    ScientificChartType.COURBE_ASTON_ENERGIE ->
      "• Minimum de la courbe à -8.8 MeV/nucléon correspondant au Fer 56 (²⁶Fe), noyau le plus stable.\n" +
      "• Zone de fusion nucléaire pour A < 20 : l'union de noyaux légers libère de l'énergie en formant des noyaux plus stables.\n" +
      "• Zone de fission nucléaire pour A > 200 : la scission d'un noyau lourd libère une énergie colossale."

    ScientificChartType.MODULATION_AM_TRAPEZE ->
      "• Taux de modulation : m = (U_max - U_min) / (U_max + U_min) = (6.0 - 2.0) / (6.0 + 2.0) = 0.50.\n" +
      "• Condition de bonne modulation : m < 1 et F_p >> f_s (au moins 10×).\n" +
      "• Trapèze régulier en mode XY confirmant l'absence de surmodulation et restitution fidèle du signal."

    ScientificChartType.NEWTON_CINEMATIQUE_VT ->
      "• Pente de la droite : accélération instantanée a = dv/dt.\n" +
      "• Aire sous la courbe : distance totale parcourue d = ∫ v(t) dt = 60 m.\n" +
      "• Phase 1 (MRUV accéléré : a = 2.5 m/s²), Phase 2 (MRU : a = 0), Phase 3 (décélération : a = -5.0 m/s²)."

    ScientificChartType.SATELLITE_ORBITE_KEPLER ->
      "• Force centripète dirigée vers le centre de la Terre : F = G·M_T·m / r².\n" +
      "• 3ème loi de Kepler : T² / r³ = 4π² / (G·M_T) = constante universelle.\n" +
      "• Vitesse orbitale : v = √(G·M_T / r).\n" +
      "• Satellite géostationnaire : orbite équatoriale à h ≈ 36 000 km, même sens et période T = 86 164 s."

    ScientificChartType.ROTATION_SOLIDE_VITESSE ->
      "• Accélération angulaire constante θ'' = 43.6 rad·s⁻².\n" +
      "• Vitesse angulaire linéaire : ω(t) = θ'' · t.\n" +
      "• Relation fondamentale en rotation : Σ M_Δ = J_Δ · θ''."

    ScientificChartType.OSCILLATEUR_PENDULE_XT ->
      "• Période propre : T_0 = 2π √(m/K) = 0.40 s (fréquence propre f_0 = 2.5 Hz).\n" +
      "• Amplitude maximale : X_m = 4.0 cm en régime libre non amorti.\n" +
      "• Résonance mécanique : amplitude maximale lorsque la fréquence de l'excitateur f = f_0."

    ScientificChartType.OSCILLATEUR_ENERGIE_EP_EC ->
      "• Énergie mécanique totale conservée : E_m = 20 mJ = Constante.\n" +
      "• Énergie potentielle élastique : parabole E_pe(x) = 1/2 K x².\n" +
      "• Énergie cinétique : parabole inversée E_c(x) = E_m - 1/2 K x².\n" +
      "• Équipartition de l'énergie (E_c = E_pe = 10 mJ) pour x = ± X_m / √2 = ± 2.83 cm."

    else -> ""
  }
}

private fun getCurveReadout(type: ScientificChartType, normX: Float): String {
  return when (type) {
    ScientificChartType.RC_CHARGE -> {
      val t = normX * 25.0f // 0 à 25 ms
      val tau = 4.7f
      val e = 6.0f
      val uc = e * (1f - exp(-t / tau))
      String.format("t = %.1f ms | u_C = %.2f V", t, uc)
    }
    ScientificChartType.RC_DECHARGE -> {
      val t = normX * 25.0f
      val tau = 4.7f
      val e = 6.0f
      val uc = e * exp(-t / tau)
      String.format("t = %.1f ms | u_C = %.2f V", t, uc)
    }
    ScientificChartType.RL_ETABLISSEMENT -> {
      val t = normX * 15.0f // ms
      val tau = 2.5f
      val i0 = 50.0f // mA
      val i = i0 * (1f - exp(-t / tau))
      String.format("t = %.1f ms | i = %.1f mA", t, i)
    }
    ScientificChartType.RLC_AMORTI -> {
      val t = normX * 6.0f // ms
      val e = 6.0f
      val uc = e * exp(-t * 0.7f) * cos(2 * Math.PI.toFloat() * t / 1.25f)
      String.format("t = %.2f ms | u_C = %.2f V", t, uc)
    }
    ScientificChartType.TITRAGE_PH -> {
      val vb = normX * 25.0f // mL
      val vbe = 15.0f
      val pka = 4.8f
      val ph = if (vb < vbe) {
        (pka + log10((vb + 0.1f) / (vbe - vb + 0.1f))).coerceIn(2.5f, 7.5f)
      } else if (abs(vb - vbe) <= 0.2f) {
        8.75f
      } else {
        (14f + log10((vb - vbe) * 0.1f / (35f + vb))).coerceIn(8.8f, 12.5f)
      }
      String.format("V_b = %.1f mL | pH = %.2f", vb, ph)
    }
    ScientificChartType.CINETIQUE_AVANCEMENT -> {
      val t = normX * 30.0f // min
      val xMax = 2.0f // mmol
      val k = 0.1155f // ln(2)/6
      val xVal = xMax * (1f - exp(-k * t))
      String.format("t = %.1f min | x = %.2f mmol", t, xVal)
    }
    ScientificChartType.FACTEURS_CINETIQUES_TEMPERATURE -> {
      val t = normX * 30.0f // min
      val xT2 = 2.0f * (1f - exp(-0.28f * t))
      val xT1 = 2.0f * (1f - exp(-0.1155f * t))
      String.format("t = %.1f min | x(T₂) = %.2f | x(T₁) = %.2f mmol", t, xT2, xT1)
    }
    ScientificChartType.FACTEURS_CINETIQUES_CONCENTRATION -> {
      val t = normX * 30.0f // min
      val xC2 = 2.0f * (1f - exp(-0.18f * t))
      val xC1 = 1.0f * (1f - exp(-0.10f * t))
      String.format("t = %.1f min | x(C₂) = %.2f | x(C₁) = %.2f mmol", t, xC2, xC1)
    }
    ScientificChartType.DIAGRAMME_DISTRIBUTION_PKA -> {
      val ph = normX * 10.0f // 0 à 10
      val pka = 4.8f
      val ratio = 10.0.pow((ph - pka).toDouble()).toFloat()
      val alphaBase = (ratio / (1f + ratio)) * 100f
      val alphaAcide = 100f - alphaBase
      String.format("pH = %.2f | α(HA) = %.1f%% | α(A⁻) = %.1f%%", ph, alphaAcide, alphaBase)
    }
    ScientificChartType.CINETIQUE_ESTERIFICATION_HYDROLYSE -> {
      val t = normX * 300.0f // min
      val nEst = 0.67f * (1f - exp(-t / 60.0f))
      val nHyd = 1.0f - 0.33f * (1f - exp(-t / 60.0f))
      String.format("t = %.0f min | n_ester = %.2f mol | Rendement = %.0f%%", t, nEst, nEst * 100f)
    }
    ScientificChartType.DECROISSANCE_RADIOACTIVE -> {
      val t = normX * 18000.0f // ans
      val tHalf = 5730.0f
      val a0 = 0.25f
      val aVal = a0 * (0.5f.pow(t / tHalf))
      String.format("t = %.0f ans | A = %.3f Bq/g", t, aVal)
    }
    ScientificChartType.ONDE_CORDE_ASPECT -> {
      val x = normX * 100.0f // cm
      val lambda = 40.0f
      val y = if (x <= 80f) (5.0f * sin(2 * Math.PI.toFloat() * (80f - x) / lambda)) else 0f
      String.format("x = %.1f cm | y = %.1f mm", x, y)
    }
    ScientificChartType.ONDE_ELONGATION_TEMPS -> {
      val t = normX * 100.0f // ms
      val tau = 40.0f
      val period = 20.0f
      val y = if (t >= tau) (5.0f * sin(2 * Math.PI.toFloat() * (t - tau) / period)) else 0f
      String.format("t = %.1f ms | y_M = %.1f mm", t, y)
    }
    ScientificChartType.CHUTE_VERTICALE -> {
      val t = normX * 5.0f // s
      val tau = 1.22f
      val vLim = 12.0f // m/s
      val v = vLim * (1f - exp(-t / tau))
      String.format("t = %.2f s | v = %.2f m/s", t, v)
    }
    ScientificChartType.PROJECTILE_PARABOLE -> {
      val x = normX * 16.0f // m
      val y = (-0.074f * x * x + 1.155f * x).coerceAtLeast(0f)
      String.format("x = %.1f m | y = %.2f m", x, y)
    }
    ScientificChartType.COURBE_ASTON_ENERGIE -> {
      val a = 1f + normX * 239f
      val energy = when {
        a <= 1f -> 0f
        a <= 4f -> -1.1f - (a - 1f) * 2.0f
        a <= 16f -> -7.1f - (a - 4f) * 0.075f
        a <= 56f -> -8.0f - 0.8f * sin(((a - 16f) / 40f) * Math.PI.toFloat() * 0.5f)
        else -> -8.8f + 1.3f * ((a - 56f) / 184f)
      }
      String.format("A = %.0f nucléo. | -E_ℓ/A = %.2f MeV/nucléon", a, energy)
    }
    ScientificChartType.MODULATION_AM_TRAPEZE -> {
      val t = normX * 4.0f // ms
      val env = 4.0f * (1f + 0.5f * cos(2f * Math.PI.toFloat() * t))
      String.format("t = %.2f ms | U_env = %.2f V | m = 0.50", t, env)
    }
    ScientificChartType.NEWTON_CINEMATIQUE_VT -> {
      val t = normX * 10.0f // s
      val v = when {
        t <= 4f -> 2.5f * t
        t <= 7f -> 10f
        t <= 9f -> 10f - 5f * (t - 7f)
        else -> 0f
      }
      val a = when {
        t < 4f -> "+2.5 m/s²"
        t in 4f..7f -> "0 m/s²"
        t in 7f..9f -> "-5.0 m/s²"
        else -> "0 m/s²"
      }
      String.format("t = %.1f s | v = %.1f m/s | a = %s", t, v, a)
    }
    ScientificChartType.ROTATION_SOLIDE_VITESSE -> {
      val t = normX * 2.5f // s
      val omega = 43.56f * t
      String.format("t = %.2f s | ω = %.1f rad/s | θ'' = 43.6 rad/s²", t, omega)
    }
    ScientificChartType.OSCILLATEUR_PENDULE_XT -> {
      val t = normX * 1.0f // s
      val xVal = 4.0f * cos(2f * Math.PI.toFloat() * t / 0.40f)
      String.format("t = %.2f s | x = %.2f cm | T₀ = 0.40 s", t, xVal)
    }
    ScientificChartType.OSCILLATEUR_ENERGIE_EP_EC -> {
      val x = (normX - 0.5f) * 8.0f // in [-4, +4 cm]
      val epe = 0.5f * 25f * (x / 100f).pow(2) * 1000f // in mJ
      val ec = (20.0f - epe).coerceAtLeast(0f)
      String.format("x = %.1f cm | E_pe = %.1f mJ | E_c = %.1f mJ | E_m = 20 mJ", x, epe, ec)
    }
    else -> ""
  }
}

// ---------------------------------------------------------------------------
// DRAWING IMPLEMENTATIONS (CANVAS SCIENTIFIQUE)
// ---------------------------------------------------------------------------

private fun DrawScope.drawGridAndAxes(
  gridColor: Color,
  gridSubColor: Color,
  onSurfaceColor: Color,
  xLabel: String,
  yLabel: String,
  xTicks: List<Pair<Float, String>>,
  yTicks: List<Pair<Float, String>>,
  padLeft: Float = 45f,
  padBottom: Float = 30f,
  padTop: Float = 20f,
  padRight: Float = 20f
) {
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  // Minor millimeter grid (5 divisions between major ticks)
  for (i in 0..25) {
    val gx = padLeft + (chartW * i / 25f)
    drawLine(
      color = gridSubColor,
      start = Offset(gx, padTop),
      end = Offset(gx, padTop + chartH),
      strokeWidth = 1f
    )
  }
  for (j in 0..20) {
    val gy = padTop + (chartH * j / 20f)
    drawLine(
      color = gridSubColor,
      start = Offset(padLeft, gy),
      end = Offset(padLeft + chartW, gy),
      strokeWidth = 1f
    )
  }

  // Major grid lines
  for (i in 0..5) {
    val gx = padLeft + (chartW * i / 5f)
    drawLine(
      color = gridColor,
      start = Offset(gx, padTop),
      end = Offset(gx, padTop + chartH),
      strokeWidth = 1.5f
    )
  }
  for (j in 0..5) {
    val gy = padTop + (chartH * j / 5f)
    drawLine(
      color = gridColor,
      start = Offset(padLeft, gy),
      end = Offset(padLeft + chartW, gy),
      strokeWidth = 1.5f
    )
  }

  // X & Y Axes
  drawLine(
    color = onSurfaceColor,
    start = Offset(padLeft, padTop + chartH),
    end = Offset(size.width - 5f, padTop + chartH),
    strokeWidth = 2.5f
  )
  // X Arrow
  drawPath(
    path = Path().apply {
      moveTo(size.width - 5f, padTop + chartH)
      lineTo(size.width - 15f, padTop + chartH - 4f)
      lineTo(size.width - 15f, padTop + chartH + 4f)
      close()
    },
    color = onSurfaceColor
  )

  drawLine(
    color = onSurfaceColor,
    start = Offset(padLeft, padTop + chartH),
    end = Offset(padLeft, 5f),
    strokeWidth = 2.5f
  )
  // Y Arrow
  drawPath(
    path = Path().apply {
      moveTo(padLeft, 5f)
      lineTo(padLeft - 4f, 15f)
      lineTo(padLeft + 4f, 15f)
      close()
    },
    color = onSurfaceColor
  )

  // Native labels via android paint
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      color = android.graphics.Color.argb(
        (onSurfaceColor.alpha * 255).toInt(),
        (onSurfaceColor.red * 255).toInt(),
        (onSurfaceColor.green * 255).toInt(),
        (onSurfaceColor.blue * 255).toInt()
      )
      textSize = 28f
      isAntiAlias = true
      typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
    }

    // X Axis Label
    drawText(xLabel, size.width - 80f, padTop + chartH + 26f, paint)
    // Y Axis Label
    drawText(yLabel, padLeft + 8f, 22f, paint)

    paint.textSize = 22f
    paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL)

    // X Ticks
    xTicks.forEach { (normX, text) ->
      val tx = padLeft + chartW * normX
      drawText(text, tx - 10f, padTop + chartH + 22f, paint)
    }

    // Y Ticks
    yTicks.forEach { (normY, text) ->
      val ty = padTop + chartH * (1f - normY)
      drawText(text, 6f, ty + 8f, paint)
    }
  }
}

// 1. RC CHARGE
private fun DrawScope.drawRCCharge(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (ms)", yLabel = "u_C (V)",
    xTicks = listOf(0f to "0", 0.188f to "4.7", 0.4f to "10", 0.6f to "15", 0.8f to "20", 1.0f to "25"),
    yTicks = listOf(0f to "0", 0.33f to "2", 0.63f to "3.8", 1.0f to "6.0 (E)")
  )

  // Asymptote u_C = E = 6 V
  val yAsymptote = padTop
  drawLine(
    color = onSurfaceColor.copy(alpha = 0.6f),
    start = Offset(padLeft, yAsymptote),
    end = Offset(padLeft + chartW, yAsymptote),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
  )

  // Tangent at t = 0 (extends from (0,0) to (tau = 4.7 ms, E = 6 V))
  val tauNormX = 4.7f / 25.0f
  val xTauPx = padLeft + chartW * tauNormX

  if (showTangents) {
    drawLine(
      color = tertiaryColor,
      start = Offset(padLeft, padTop + chartH),
      end = Offset(xTauPx + (chartW * 0.1f), yAsymptote - (chartH * 0.1f)),
      strokeWidth = 2.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 6f))
    )

    // Intersection point of tangent and asymptote
    drawCircle(color = tertiaryColor, radius = 5f, center = Offset(xTauPx, yAsymptote))
  }

  // Curve: u_C(t) = E * (1 - exp(-t / tau))
  val curvePath = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 25.0f
    val uc = 6.0f * (1f - exp(-t / 4.7f))
    val normY = uc / 6.0f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }

  drawPath(
    path = curvePath,
    color = primaryColor,
    style = Stroke(width = 4f)
  )

  // Notable point: t = tau, u_C = 0.63 E = 3.78 V
  if (showNotablePoints) {
    val yTauPx = padTop + chartH * (1f - 0.63f)
    // Projection lines
    drawLine(
      color = secondaryColor,
      start = Offset(xTauPx, padTop + chartH),
      end = Offset(xTauPx, yTauPx),
      strokeWidth = 2f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
    )
    drawLine(
      color = secondaryColor,
      start = Offset(padLeft, yTauPx),
      end = Offset(xTauPx, yTauPx),
      strokeWidth = 2f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
    )
    drawCircle(color = secondaryColor, radius = 6f, center = Offset(xTauPx, yTauPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xTauPx, yTauPx))
  }

  // Touch Cursor
  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 25.0f
    val uc = 6.0f * (1f - exp(-t / 4.7f))
    uc / 6.0f
  }
}

// 2. RC DECHARGE
private fun DrawScope.drawRCDecharge(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (ms)", yLabel = "u_C (V)",
    xTicks = listOf(0f to "0", 0.188f to "4.7", 0.4f to "10", 0.6f to "15", 0.8f to "20", 1.0f to "25"),
    yTicks = listOf(0f to "0", 0.37f to "2.2", 0.66f to "4", 1.0f to "6.0")
  )

  val tauNormX = 4.7f / 25.0f
  val xTauPx = padLeft + chartW * tauNormX

  if (showTangents) {
    // Tangent at t = 0 goes from (0, 6V) to (tau = 4.7 ms, 0V)
    drawLine(
      color = tertiaryColor,
      start = Offset(padLeft, padTop),
      end = Offset(xTauPx, padTop + chartH),
      strokeWidth = 2.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 6f))
    )
    drawCircle(color = tertiaryColor, radius = 5f, center = Offset(xTauPx, padTop + chartH))
  }

  val curvePath = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 25.0f
    val uc = 6.0f * exp(-t / 4.7f)
    val normY = uc / 6.0f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }

  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  if (showNotablePoints) {
    val yTauPx = padTop + chartH * (1f - 0.37f)
    drawLine(
      color = secondaryColor,
      start = Offset(xTauPx, padTop + chartH),
      end = Offset(xTauPx, yTauPx),
      strokeWidth = 2f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
    )
    drawLine(
      color = secondaryColor,
      start = Offset(padLeft, yTauPx),
      end = Offset(xTauPx, yTauPx),
      strokeWidth = 2f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
    )
    drawCircle(color = secondaryColor, radius = 6f, center = Offset(xTauPx, yTauPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xTauPx, yTauPx))
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 25.0f
    val uc = 6.0f * exp(-t / 4.7f)
    uc / 6.0f
  }
}

// 3. RL ETABLISSEMENT
private fun DrawScope.drawRLEtablissement(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (ms)", yLabel = "i (mA)",
    xTicks = listOf(0f to "0", 0.166f to "2.5", 0.33f to "5", 0.66f to "10", 1.0f to "15"),
    yTicks = listOf(0f to "0", 0.4f to "20", 0.63f to "31.5", 1.0f to "50 (I_0)")
  )

  val yAsymptote = padTop
  drawLine(
    color = onSurfaceColor.copy(alpha = 0.6f),
    start = Offset(padLeft, yAsymptote),
    end = Offset(padLeft + chartW, yAsymptote),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
  )

  val tauNormX = 2.5f / 15.0f
  val xTauPx = padLeft + chartW * tauNormX

  if (showTangents) {
    drawLine(
      color = tertiaryColor,
      start = Offset(padLeft, padTop + chartH),
      end = Offset(xTauPx + (chartW * 0.1f), yAsymptote - (chartH * 0.1f)),
      strokeWidth = 2.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 6f))
    )
    drawCircle(color = tertiaryColor, radius = 5f, center = Offset(xTauPx, yAsymptote))
  }

  val curvePath = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 15.0f
    val iVal = 50.0f * (1f - exp(-t / 2.5f))
    val normY = iVal / 50.0f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }

  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  if (showNotablePoints) {
    val yTauPx = padTop + chartH * (1f - 0.63f)
    drawLine(color = secondaryColor, start = Offset(xTauPx, padTop + chartH), end = Offset(xTauPx, yTauPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawLine(color = secondaryColor, start = Offset(padLeft, yTauPx), end = Offset(xTauPx, yTauPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawCircle(color = secondaryColor, radius = 6f, center = Offset(xTauPx, yTauPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xTauPx, yTauPx))
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 15.0f
    val iVal = 50.0f * (1f - exp(-t / 2.5f))
    iVal / 50.0f
  }
}

// 4. RLC OSCILLATIONS AMORTIES
private fun DrawScope.drawRLCAmorti(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  // Zero is in the middle for alternating voltage
  val yZero = padTop + chartH * 0.5f

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (ms)", yLabel = "u_C (V)",
    xTicks = listOf(0f to "0", 0.208f to "T=1.25", 0.416f to "2.5", 0.625f to "3.75", 1.0f to "6"),
    yTicks = listOf(0f to "-6", 0.5f to "0", 1.0f to "+6")
  )

  // Zero axis line
  drawLine(
    color = onSurfaceColor.copy(alpha = 0.5f),
    start = Offset(padLeft, yZero),
    end = Offset(padLeft + chartW, yZero),
    strokeWidth = 1.5f
  )

  val curvePath = Path()
  val steps = 200
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 6.0f
    val uc = 6.0f * exp(-t * 0.7f) * cos(2 * Math.PI.toFloat() * t / 1.25f)
    val normY = (uc + 6f) / 12f // 0 to 1
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }

  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 3.5f))

  if (showNotablePoints) {
    // Two successive peaks to illustrate pseudo-period T
    val t1 = 0f
    val t2 = 1.25f
    val x1 = padLeft + chartW * (t1 / 6f)
    val x2 = padLeft + chartW * (t2 / 6f)
    val y1 = padTop
    val y2 = padTop + chartH * (1f - ((6f * exp(-1.25f * 0.7f) + 6f) / 12f))

    drawCircle(color = secondaryColor, radius = 5f, center = Offset(x1, y1))
    drawCircle(color = secondaryColor, radius = 5f, center = Offset(x2, y2))

    // Double arrow showing T
    drawLine(
      color = secondaryColor,
      start = Offset(x1, y2 - 15f),
      end = Offset(x2, y2 - 15f),
      strokeWidth = 2.5f
    )
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 6.0f
    val uc = 6.0f * exp(-t * 0.7f) * cos(2 * Math.PI.toFloat() * t / 1.25f)
    (uc + 6f) / 12f
  }
}

// 5. TITRAGE ACIDO-BASIQUE pH = f(V_b)
private fun DrawScope.drawTitragePH(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "V_b (mL)", yLabel = "pH",
    xTicks = listOf(0f to "0", 0.3f to "7.5", 0.6f to "15.0 (E)", 0.8f to "20", 1.0f to "25"),
    yTicks = listOf(0f to "0", 0.34f to "4.8", 0.5f to "7.0", 0.625f to "8.75", 1.0f to "14")
  )

  // Equivalence point coordinates
  val vbeNormX = 15.0f / 25.0f
  val phENormY = 8.75f / 14.0f
  val xEPx = padLeft + chartW * vbeNormX
  val yEPx = padTop + chartH * (1f - phENormY)

  // Draw main titration pH curve
  val curvePath = Path()
  val steps = 150
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val vb = normX * 25.0f
    val ph = if (vb < 14.9f) {
      (4.8f + log10((vb + 0.1f) / (15.0f - vb + 0.1f))).coerceIn(2.8f, 7.2f)
    } else if (vb <= 15.1f) {
      8.75f
    } else {
      (14f + log10((vb - 15.0f) * 0.1f / (35f + vb))).coerceIn(8.8f, 12.5f)
    }
    val normY = ph / 14.0f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }

  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  // Draw derivative curve dpH/dV_b in light green/teal (bell shaped)
  val derivPath = Path()
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val vb = normX * 25.0f
    // Gaussian peak at V_b = 15
    val deriv = 12f * exp(-((vb - 15f) * (vb - 15f)) / 0.8f)
    val normY = deriv / 14f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) derivPath.moveTo(px, py) else derivPath.lineTo(px, py)
  }
  drawPath(
    path = derivPath,
    color = Color(0xFF2E7D32),
    style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f)))
  )

  // Method of parallel tangents (Méthode des tangentes)
  if (showTangents) {
    val slope = -0.5f // visual slope
    val len = chartW * 0.35f

    // Tangent 1 (before jump, around pH 6)
    val t1X = padLeft + chartW * (13.5f / 25f)
    val t1Y = padTop + chartH * (1f - (6.0f / 14f))
    drawLine(
      color = tertiaryColor,
      start = Offset(t1X - len * 0.5f, t1Y - len * 0.5f * slope),
      end = Offset(t1X + len * 0.5f, t1Y + len * 0.5f * slope),
      strokeWidth = 2f
    )

    // Tangent 2 (after jump, around pH 11.5)
    val t2X = padLeft + chartW * (16.5f / 25f)
    val t2Y = padTop + chartH * (1f - (11.5f / 14f))
    drawLine(
      color = tertiaryColor,
      start = Offset(t2X - len * 0.5f, t2Y - len * 0.5f * slope),
      end = Offset(t2X + len * 0.5f, t2Y + len * 0.5f * slope),
      strokeWidth = 2f
    )

    // Equidistant median tangent line passing right through E
    drawLine(
      color = tertiaryColor,
      start = Offset(xEPx - len * 0.6f, yEPx - len * 0.6f * slope),
      end = Offset(xEPx + len * 0.6f, yEPx + len * 0.6f * slope),
      strokeWidth = 2.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 4f))
    )
  }

  // Notable points: E(VbE, pHE) and demi-équivalence (VbE/2, pKa)
  if (showNotablePoints) {
    // Equivalence E
    drawLine(color = secondaryColor, start = Offset(xEPx, padTop + chartH), end = Offset(xEPx, yEPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f)))
    drawLine(color = secondaryColor, start = Offset(padLeft, yEPx), end = Offset(xEPx, yEPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f)))
    drawCircle(color = secondaryColor, radius = 7f, center = Offset(xEPx, yEPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xEPx, yEPx))

    // Demi-équivalence: Vb = 7.5 mL, pH = 4.8 = pKa
    val xHalf = padLeft + chartW * (7.5f / 25f)
    val yHalf = padTop + chartH * (1f - (4.8f / 14f))
    drawLine(color = Color(0xFFE65100), start = Offset(xHalf, padTop + chartH), end = Offset(xHalf, yHalf), strokeWidth = 1.8f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f)))
    drawLine(color = Color(0xFFE65100), start = Offset(padLeft, yHalf), end = Offset(xHalf, yHalf), strokeWidth = 1.8f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f)))
    drawCircle(color = Color(0xFFE65100), radius = 5f, center = Offset(xHalf, yHalf))
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val vb = normX * 25.0f
    val ph = if (vb < 14.9f) {
      (4.8f + log10((vb + 0.1f) / (15.0f - vb + 0.1f))).coerceIn(2.8f, 7.2f)
    } else if (vb <= 15.1f) {
      8.75f
    } else {
      (14f + log10((vb - 15.0f) * 0.1f / (35f + vb))).coerceIn(8.8f, 12.5f)
    }
    ph / 14.0f
  }
}

// 6. SUIVI CINETIQUE x = f(t)
private fun DrawScope.drawCinetiqueAvancement(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (min)", yLabel = "x (mmol)",
    xTicks = listOf(0f to "0", 0.2f to "6 (t_1/2)", 0.4f to "12", 0.6f to "18", 1.0f to "30"),
    yTicks = listOf(0f to "0", 0.5f to "1.0", 1.0f to "2.0 (x_max)")
  )

  // Asymptote x_max = 2.0 mmol
  val yAsymptote = padTop
  drawLine(
    color = onSurfaceColor.copy(alpha = 0.6f),
    start = Offset(padLeft, yAsymptote),
    end = Offset(padLeft + chartW, yAsymptote),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
  )

  val tHalfNormX = 6.0f / 30.0f
  val xHalfPx = padLeft + chartW * tHalfNormX
  val yHalfPx = padTop + chartH * 0.5f

  if (showTangents) {
    // Tangent at t = 0 showing initial rate (v0)
    val slopeT0 = (chartH / chartW) * (30f / 8.6f)
    drawLine(
      color = tertiaryColor,
      start = Offset(padLeft, padTop + chartH),
      end = Offset(padLeft + (chartW * 0.35f), padTop + chartH - (chartW * 0.35f * slopeT0)),
      strokeWidth = 2.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 6f))
    )
  }

  // Curve x(t) = x_max * (1 - exp(-k * t)), k = ln(2)/6
  val k = 0.1155f
  val curvePath = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 30.0f
    val xVal = 2.0f * (1f - exp(-k * t))
    val normY = xVal / 2.0f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }
  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  if (showNotablePoints) {
    // t_1/2 where x = x_max / 2 = 1.0 mmol
    drawLine(color = secondaryColor, start = Offset(xHalfPx, padTop + chartH), end = Offset(xHalfPx, yHalfPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawLine(color = secondaryColor, start = Offset(padLeft, yHalfPx), end = Offset(xHalfPx, yHalfPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawCircle(color = secondaryColor, radius = 6f, center = Offset(xHalfPx, yHalfPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xHalfPx, yHalfPx))
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 30.0f
    val xVal = 2.0f * (1f - exp(-k * t))
    xVal / 2.0f
  }
}

// 7. DECROISSANCE RADIOACTIVE A = f(t)
private fun DrawScope.drawDecroissanceRadioactive(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (ans)", yLabel = "A (Bq/g)",
    xTicks = listOf(0f to "0", 0.318f to "5730", 0.636f to "11460", 0.955f to "17190"),
    yTicks = listOf(0f to "0", 0.25f to "A_0/4", 0.5f to "A_0/2", 0.72f to "0.18", 1.0f to "0.25 (A_0)")
  )

  val tHalfNormX = 5730f / 18000f
  val xHalfPx = padLeft + chartW * tHalfNormX
  val yHalfPx = padTop + chartH * 0.5f

  val curvePath = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 18000f
    val aVal = 0.25f * (0.5f.pow(t / 5730f))
    val normY = aVal / 0.25f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }
  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  if (showNotablePoints) {
    // t_1/2
    drawLine(color = secondaryColor, start = Offset(xHalfPx, padTop + chartH), end = Offset(xHalfPx, yHalfPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawLine(color = secondaryColor, start = Offset(padLeft, yHalfPx), end = Offset(xHalfPx, yHalfPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawCircle(color = secondaryColor, radius = 6f, center = Offset(xHalfPx, yHalfPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xHalfPx, yHalfPx))

    // Exercice value A = 0.18 Bq (t = 2716 ans)
    val xArch = padLeft + chartW * (2716f / 18000f)
    val yArch = padTop + chartH * (1f - (0.18f / 0.25f))
    drawLine(color = Color(0xFFE91E63), start = Offset(xArch, padTop + chartH), end = Offset(xArch, yArch), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f)))
    drawLine(color = Color(0xFFE91E63), start = Offset(padLeft, yArch), end = Offset(xArch, yArch), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f)))
    drawCircle(color = Color(0xFFE91E63), radius = 6f, center = Offset(xArch, yArch))
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 18000f
    val aVal = 0.25f * (0.5f.pow(t / 5730f))
    aVal / 0.25f
  }
}

// 8. ASPECT DE LA CORDE A t_1 : y = f(x)
private fun DrawScope.drawOndeCordeAspect(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom
  val yZero = padTop + chartH * 0.5f

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "x (cm)", yLabel = "y (mm)",
    xTicks = listOf(0f to "0", 0.4f to "40 (λ)", 0.8f to "80 (Front)", 1.0f to "100"),
    yTicks = listOf(0f to "-5", 0.5f to "0", 1.0f to "+5")
  )

  drawLine(color = onSurfaceColor.copy(alpha = 0.4f), start = Offset(padLeft, yZero), end = Offset(padLeft + chartW, yZero), strokeWidth = 1.5f)

  val curvePath = Path()
  val steps = 180
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val x = normX * 100.0f
    // Wave moves to the right, front is at x = 80 cm
    val y = if (x <= 80f) (5.0f * sin(2 * Math.PI.toFloat() * (80f - x) / 40.0f)) else 0f
    val normY = (y + 5f) / 10f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }
  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  if (showNotablePoints) {
    // Wavelength double arrow between x = 10 cm and x = 50 cm (peaks)
    val xPeak1 = padLeft + chartW * (10f / 100f)
    val xPeak2 = padLeft + chartW * (50f / 100f)
    val yPeaks = padTop
    drawCircle(color = secondaryColor, radius = 5f, center = Offset(xPeak1, yPeaks))
    drawCircle(color = secondaryColor, radius = 5f, center = Offset(xPeak2, yPeaks))
    drawLine(color = secondaryColor, start = Offset(xPeak1, yPeaks - 10f), end = Offset(xPeak2, yPeaks - 10f), strokeWidth = 2.5f)

    // Wavefront marker at x = 80 cm
    val xFront = padLeft + chartW * (80f / 100f)
    drawCircle(color = tertiaryColor, radius = 6f, center = Offset(xFront, yZero))
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val x = normX * 100.0f
    val y = if (x <= 80f) (5.0f * sin(2 * Math.PI.toFloat() * (80f - x) / 40.0f)) else 0f
    (y + 5f) / 10f
  }
}

// 9. ELONGATION DU POINT M y_M = f(t)
private fun DrawScope.drawOndeElongationTemps(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom
  val yZero = padTop + chartH * 0.5f

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (ms)", yLabel = "y_M (mm)",
    xTicks = listOf(0f to "0", 0.4f to "40 (τ)", 0.6f to "60", 0.8f to "80", 1.0f to "100"),
    yTicks = listOf(0f to "-5", 0.5f to "0", 1.0f to "+5")
  )

  drawLine(color = onSurfaceColor.copy(alpha = 0.4f), start = Offset(padLeft, yZero), end = Offset(padLeft + chartW, yZero), strokeWidth = 1.5f)

  val curvePath = Path()
  val steps = 180
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 100.0f
    // Delay tau = 40 ms
    val y = if (t >= 40f) (5.0f * sin(2 * Math.PI.toFloat() * (t - 40f) / 20.0f)) else 0f
    val normY = (y + 5f) / 10f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }
  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  if (showNotablePoints) {
    // Retard tau marker at t = 40 ms
    val xTau = padLeft + chartW * (40f / 100f)
    drawCircle(color = tertiaryColor, radius = 6f, center = Offset(xTau, yZero))

    // Period T = 20 ms
    val xP1 = padLeft + chartW * (45f / 100f)
    val xP2 = padLeft + chartW * (65f / 100f)
    drawLine(color = secondaryColor, start = Offset(xP1, padTop), end = Offset(xP2, padTop), strokeWidth = 2.5f)
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 100.0f
    val y = if (t >= 40f) (5.0f * sin(2 * Math.PI.toFloat() * (t - 40f) / 20.0f)) else 0f
    (y + 5f) / 10f
  }
}

// 10. CHUTE VERTICALE v = f(t)
private fun DrawScope.drawChuteVerticale(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (s)", yLabel = "v (m/s)",
    xTicks = listOf(0f to "0", 0.244f to "1.22 (τ)", 0.4f to "2", 0.6f to "3", 1.0f to "5"),
    yTicks = listOf(0f to "0", 0.33f to "4", 0.63f to "7.56", 1.0f to "12 (v_lim)")
  )

  // Asymptote v_lim = 12 m/s
  val yAsymptote = padTop
  drawLine(
    color = onSurfaceColor.copy(alpha = 0.6f),
    start = Offset(padLeft, yAsymptote),
    end = Offset(padLeft + chartW, yAsymptote),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
  )

  val tauNormX = 1.22f / 5.0f
  val xTauPx = padLeft + chartW * tauNormX

  if (showTangents) {
    // Tangent at t = 0 (a0 = g = 9.8 m/s^2)
    drawLine(
      color = tertiaryColor,
      start = Offset(padLeft, padTop + chartH),
      end = Offset(xTauPx + (chartW * 0.1f), yAsymptote - (chartH * 0.1f)),
      strokeWidth = 2.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 6f))
    )
    drawCircle(color = tertiaryColor, radius = 5f, center = Offset(xTauPx, yAsymptote))
  }

  val curvePath = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 5.0f
    val v = 12.0f * (1f - exp(-t / 1.22f))
    val normY = v / 12.0f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }
  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  if (showNotablePoints) {
    val yTauPx = padTop + chartH * (1f - 0.63f)
    drawLine(color = secondaryColor, start = Offset(xTauPx, padTop + chartH), end = Offset(xTauPx, yTauPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawLine(color = secondaryColor, start = Offset(padLeft, yTauPx), end = Offset(xTauPx, yTauPx), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawCircle(color = secondaryColor, radius = 6f, center = Offset(xTauPx, yTauPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(xTauPx, yTauPx))
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val t = normX * 5.0f
    val v = 12.0f * (1f - exp(-t / 1.22f))
    v / 12.0f
  }
}

// 11. TRAJECTOIRE PROJECTILE PARABOLE y = f(x)
private fun DrawScope.drawProjectileParabole(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "x (m)", yLabel = "y (m)",
    xTicks = listOf(0f to "0", 0.5f to "7.8 (x_F)", 1.0f to "15.6 (Portée P)"),
    yTicks = listOf(0f to "0", 0.5f to "2.25", 1.0f to "4.50 (Flèche)")
  )

  val curvePath = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val x = normX * 15.6f
    // Parabola: y = -0.074 x^2 + 1.155 x
    val y = (-0.074f * x * x + 1.155f * x).coerceAtLeast(0f)
    val normY = y / 4.5f
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
  }
  drawPath(path = curvePath, color = primaryColor, style = Stroke(width = 4f))

  if (showNotablePoints) {
    // Peak (Flèche) at x = 7.8 m, y = 4.5 m
    val xPeak = padLeft + chartW * 0.5f
    val yPeak = padTop
    drawLine(color = secondaryColor, start = Offset(xPeak, padTop + chartH), end = Offset(xPeak, yPeak), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawLine(color = secondaryColor, start = Offset(padLeft, yPeak), end = Offset(xPeak, yPeak), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
    drawCircle(color = secondaryColor, radius = 6f, center = Offset(xPeak, yPeak))

    // Portée P at x = 15.6 m, y = 0
    val xPortee = padLeft + chartW
    drawCircle(color = tertiaryColor, radius = 6f, center = Offset(xPortee, padTop + chartH))
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, primaryColor) { normX ->
    val x = normX * 15.6f
    val y = (-0.074f * x * x + 1.155f * x).coerceAtLeast(0f)
    y / 4.5f
  }
}

// 12. DIFFRACTION DE LA LUMIERE (FIGURE EXPERIMENTALE)
private fun DrawScope.drawDiffractionFigure(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color
) {
  val laserColor = Color(0xFFE53935)
  val w = size.width
  val h = size.height

  // 1. Laser source on the left
  drawRect(
    color = Color(0xFF424242),
    topLeft = Offset(20f, h * 0.42f),
    size = androidx.compose.ui.geometry.Size(60f, h * 0.16f)
  )

  // Laser beam (red line)
  drawLine(
    color = laserColor,
    start = Offset(80f, h * 0.5f),
    end = Offset(w * 0.42f, h * 0.5f),
    strokeWidth = 3f
  )

  // 2. Slit (Fente de largeur a)
  drawRect(
    color = Color(0xFF616161),
    topLeft = Offset(w * 0.42f, h * 0.15f),
    size = androidx.compose.ui.geometry.Size(12f, h * 0.3f)
  )
  drawRect(
    color = Color(0xFF616161),
    topLeft = Offset(w * 0.42f, h * 0.55f),
    size = androidx.compose.ui.geometry.Size(12f, h * 0.3f)
  )

  // Diffracted beams spreading to screen
  drawLine(color = laserColor.copy(alpha = 0.6f), start = Offset(w * 0.43f, h * 0.5f), end = Offset(w - 40f, h * 0.25f), strokeWidth = 1.5f)
  drawLine(color = laserColor.copy(alpha = 0.6f), start = Offset(w * 0.43f, h * 0.5f), end = Offset(w - 40f, h * 0.75f), strokeWidth = 1.5f)

  // 3. Screen (Écran à distance D)
  drawRect(
    color = Color(0xFFEEEEEE),
    topLeft = Offset(w - 35f, h * 0.1f),
    size = androidx.compose.ui.geometry.Size(14f, h * 0.8f)
  )

  // Central bright spot (Tache centrale de largeur L)
  drawRect(
    color = laserColor,
    topLeft = Offset(w - 37f, h * 0.38f),
    size = androidx.compose.ui.geometry.Size(18f, h * 0.24f)
  )
  // Secondary spots
  drawRect(color = laserColor.copy(alpha = 0.5f), topLeft = Offset(w - 36f, h * 0.22f), size = androidx.compose.ui.geometry.Size(16f, h * 0.09f))
  drawRect(color = laserColor.copy(alpha = 0.5f), topLeft = Offset(w - 36f, h * 0.69f), size = androidx.compose.ui.geometry.Size(16f, h * 0.09f))

  // Annotations native
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      color = android.graphics.Color.DKGRAY
      textSize = 24f
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    drawText("Laser", 24f, h * 0.40f, paint)
    drawText("Fente (a)", w * 0.38f, h * 0.12f, paint)
    drawText("Écran (D)", w - 90f, h * 0.08f, paint)
    drawText("Tache centrale (L)", w - 210f, h * 0.52f, paint)
    paint.textSize = 20f
    paint.typeface = android.graphics.Typeface.DEFAULT
    drawText("θ = λ / a", w * 0.48f, h * 0.42f, paint)
    drawText("L = 2·λ·D / a", w * 0.48f, h * 0.60f, paint)
  }
}

// 13. SCHÉMA DE MONTAGE CIRCUIT RC
private fun DrawScope.drawMontageCircuitRC(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  surfaceColor: Color
) {
  val w = size.width
  val h = size.height

  val left = 80f
  val right = w - 80f
  val top = 60f
  val bottom = h - 60f

  // Rectangle loop of wire
  drawLine(color = onSurfaceColor, start = Offset(left, top), end = Offset(right, top), strokeWidth = 3f)
  drawLine(color = onSurfaceColor, start = Offset(right, top), end = Offset(right, bottom), strokeWidth = 3f)
  drawLine(color = onSurfaceColor, start = Offset(right, bottom), end = Offset(left, bottom), strokeWidth = 3f)
  drawLine(color = onSurfaceColor, start = Offset(left, bottom), end = Offset(left, top), strokeWidth = 3f)

  // 1. Generator E on left wire
  val genY = (top + bottom) / 2f
  drawCircle(color = surfaceColor, radius = 22f, center = Offset(left, genY))
  drawCircle(color = onSurfaceColor, radius = 22f, center = Offset(left, genY), style = Stroke(width = 2.5f))

  // 2. Switch K on top wire
  val switchX = left + (right - left) * 0.28f
  drawCircle(color = onSurfaceColor, radius = 4f, center = Offset(switchX - 20f, top))
  drawCircle(color = onSurfaceColor, radius = 4f, center = Offset(switchX + 20f, top))
  drawLine(color = onSurfaceColor, start = Offset(switchX - 20f, top), end = Offset(switchX + 15f, top - 18f), strokeWidth = 3f)

  // 3. Resistor R on top wire
  val rX = left + (right - left) * 0.72f
  drawRect(color = surfaceColor, topLeft = Offset(rX - 35f, top - 14f), size = androidx.compose.ui.geometry.Size(70f, 28f))
  drawRect(color = onSurfaceColor, topLeft = Offset(rX - 35f, top - 14f), size = androidx.compose.ui.geometry.Size(70f, 28f), style = Stroke(width = 2.5f))

  // 4. Capacitor C on right wire
  val capY = (top + bottom) / 2f
  drawLine(color = surfaceColor, start = Offset(right, capY - 18f), end = Offset(right, capY + 18f), strokeWidth = 10f)
  // Two parallel plates
  drawLine(color = onSurfaceColor, start = Offset(right - 18f, capY - 18f), end = Offset(right + 18f, capY - 18f), strokeWidth = 4f)
  drawLine(color = onSurfaceColor, start = Offset(right - 18f, capY + 18f), end = Offset(right + 18f, capY + 18f), strokeWidth = 4f)

  // Oscilloscope Probes: Y1 on capacitor top, Mass on capacitor bottom
  drawCircle(color = primaryColor, radius = 7f, center = Offset(right + 40f, capY - 18f))
  drawLine(color = primaryColor, start = Offset(right + 18f, capY - 18f), end = Offset(right + 40f, capY - 18f), strokeWidth = 2f)

  drawCircle(color = Color.DarkGray, radius = 7f, center = Offset(right + 40f, capY + 18f))
  drawLine(color = Color.DarkGray, start = Offset(right + 18f, capY + 18f), end = Offset(right + 40f, capY + 18f), strokeWidth = 2f)

  // Native text annotations
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      color = android.graphics.Color.argb(255, 30, 136, 229)
      textSize = 24f
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    drawText("E", left - 35f, genY + 8f, paint)
    drawText("Interrupteur K", switchX - 50f, top - 25f, paint)
    drawText("R = 1.0 kΩ", rX - 40f, top + 38f, paint)
    drawText("C", right + 28f, capY + 6f, paint)
    drawText("Voie Y1 (u_C)", right + 50f, capY - 14f, paint)
    drawText("Masse ⏚", right + 50f, capY + 22f, paint)
  }
}

// 14. MONTAGE DE DOSAGE pH-METRIQUE
private fun DrawScope.drawMontageTitrage(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color
) {
  val w = size.width
  val h = size.height

  // Stand/Support on the left
  drawLine(color = Color.DarkGray, start = Offset(60f, h * 0.15f), end = Offset(60f, h * 0.88f), strokeWidth = 6f)
  drawLine(color = Color.DarkGray, start = Offset(30f, h * 0.88f), end = Offset(180f, h * 0.88f), strokeWidth = 8f)

  // Magnetic Stirrer base
  drawRoundRect(
    color = Color(0xFF78909C),
    topLeft = Offset(120f, h * 0.76f),
    size = androidx.compose.ui.geometry.Size(150f, h * 0.12f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
  )

  // Beaker on stirrer
  drawRect(
    color = Color(0xFFE0F7FA).copy(alpha = 0.6f),
    topLeft = Offset(140f, h * 0.52f),
    size = androidx.compose.ui.geometry.Size(110f, h * 0.24f)
  )
  drawRect(
    color = Color.DarkGray,
    topLeft = Offset(140f, h * 0.52f),
    size = androidx.compose.ui.geometry.Size(110f, h * 0.24f),
    style = Stroke(width = 2.5f)
  )

  // Liquid in beaker (acid solution)
  drawRect(
    color = Color(0xFFB2EBF2),
    topLeft = Offset(142f, h * 0.60f),
    size = androidx.compose.ui.geometry.Size(106f, h * 0.16f)
  )

  // Stir bar inside beaker
  drawRoundRect(
    color = Color.White,
    topLeft = Offset(175f, h * 0.73f),
    size = androidx.compose.ui.geometry.Size(40f, 8f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
  )

  // Burette above beaker
  drawRect(
    color = Color.DarkGray,
    topLeft = Offset(185f, h * 0.12f),
    size = androidx.compose.ui.geometry.Size(20f, h * 0.36f),
    style = Stroke(width = 2f)
  )
  // Graduations on burette
  for (i in 1..8) {
    val gy = h * 0.14f + i * (h * 0.035f)
    drawLine(color = Color.DarkGray, start = Offset(185f, gy), end = Offset(195f, gy), strokeWidth = 1.5f)
  }
  // Stopcock (robinet)
  drawCircle(color = Color.DarkGray, radius = 6f, center = Offset(195f, h * 0.48f))

  // pH sensor probe entering beaker
  drawLine(color = Color(0xFF1E88E5), start = Offset(225f, h * 0.35f), end = Offset(225f, h * 0.70f), strokeWidth = 5f)
  drawCircle(color = Color(0xFF0D47A1), radius = 6f, center = Offset(225f, h * 0.70f))

  // pH meter device on right
  drawRoundRect(
    color = Color(0xFF37474F),
    topLeft = Offset(w - 140f, h * 0.25f),
    size = androidx.compose.ui.geometry.Size(120f, h * 0.32f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
  )
  // Screen on pH meter
  drawRoundRect(
    color = Color(0xFF81C784),
    topLeft = Offset(w - 128f, h * 0.28f),
    size = androidx.compose.ui.geometry.Size(96f, h * 0.14f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
  )

  // Cable connecting probe to pH meter
  val cablePath = Path().apply {
    moveTo(225f, h * 0.35f)
    cubicTo(260f, h * 0.20f, w - 160f, h * 0.20f, w - 130f, h * 0.38f)
  }
  drawPath(path = cablePath, color = Color.Black, style = Stroke(width = 2.5f))

  // Annotations
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      color = android.graphics.Color.BLACK
      textSize = 22f
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    drawText("Burette graduée", 215f, h * 0.20f, paint)
    paint.textSize = 18f
    drawText("(Soude C_b = 0.1 M)", 215f, h * 0.24f, paint)

    paint.textSize = 22f
    drawText("Sonde pH-métrique", 240f, h * 0.44f, paint)
    drawText("Bécher (Acide V_a)", 255f, h * 0.65f, paint)
    drawText("Agitateur magnétique", 275f, h * 0.82f, paint)

    paint.color = android.graphics.Color.WHITE
    drawText("pH-mètre", w - 118f, h * 0.52f, paint)

    paint.color = android.graphics.Color.BLACK
    paint.textSize = 28f
    drawText("8.75", w - 105f, h * 0.37f, paint)
  }
}

// ---------------------------------------------------------------------------
// 15. FACTEURS CINÉTIQUES : TEMPÉRATURE (T2 > T1)
// ---------------------------------------------------------------------------
private fun DrawScope.drawFacteursCinetiquesTemperature(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (min)", yLabel = "x (mmol)",
    xTicks = listOf(0f to "0", 0.2f to "6", 0.4f to "12", 0.6f to "18", 0.8f to "24", 1.0f to "30"),
    yTicks = listOf(0f to "0", 0.4f to "1.0", 0.8f to "2.0", 1.0f to "2.5")
  )

  val yAsymptote = padTop + chartH * (1f - (2.0f / 2.5f))

  // Asymptote horizontale x_f = 2.0 mmol
  drawLine(
    color = onSurfaceColor.copy(alpha = 0.5f),
    start = Offset(padLeft, yAsymptote),
    end = Offset(padLeft + chartW, yAsymptote),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
  )

  // Tangentes à l'origine
  if (showTangents) {
    // Tangente T2 (forte pente)
    val tauT2NormX = (2.5f / 30.0f)
    val xTauT2Px = padLeft + chartW * tauT2NormX
    drawLine(
      color = Color(0xFFFF9800),
      start = Offset(padLeft, padTop + chartH),
      end = Offset(xTauT2Px + chartW * 0.05f, yAsymptote - chartH * 0.05f),
      strokeWidth = 2.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f))
    )

    // Tangente T1 (pente modérée)
    val tauT1NormX = (6.0f / 30.0f)
    val xTauT1Px = padLeft + chartW * tauT1NormX
    drawLine(
      color = primaryColor.copy(alpha = 0.8f),
      start = Offset(padLeft, padTop + chartH),
      end = Offset(xTauT1Px + chartW * 0.05f, yAsymptote - chartH * 0.05f),
      strokeWidth = 2.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f))
    )
  }

  // Courbe 1 : T2 = 45°C (orange, cinétique rapide)
  val pathT2 = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 30.0f
    val xVal = 2.0f * (1f - exp(-0.28f * t))
    val normY = (xVal / 2.5f).coerceIn(0f, 1f)
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) pathT2.moveTo(px, py) else pathT2.lineTo(px, py)
  }
  drawPath(path = pathT2, color = Color(0xFFFF9800), style = Stroke(width = 4f))

  // Courbe 2 : T1 = 20°C (bleue, cinétique plus lente)
  val pathT1 = Path()
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 30.0f
    val xVal = 2.0f * (1f - exp(-0.1155f * t))
    val normY = (xVal / 2.5f).coerceIn(0f, 1f)
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) pathT1.moveTo(px, py) else pathT1.lineTo(px, py)
  }
  drawPath(path = pathT1, color = primaryColor, style = Stroke(width = 3.5f))

  if (showNotablePoints) {
    val yHalfPx = padTop + chartH * (1f - (1.0f / 2.5f))
    val tHalfT2Px = padLeft + chartW * (2.5f / 30.0f)
    val tHalfT1Px = padLeft + chartW * (6.0f / 30.0f)

    // Ligne x_f / 2 = 1.0 mmol
    drawLine(
      color = secondaryColor.copy(alpha = 0.5f),
      start = Offset(padLeft, yHalfPx),
      end = Offset(padLeft + chartW * 0.35f, yHalfPx),
      strokeWidth = 1.5f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
    )

    // Points remarquables
    drawCircle(color = Color(0xFFFF9800), radius = 6f, center = Offset(tHalfT2Px, yHalfPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(tHalfT2Px, yHalfPx))

    drawCircle(color = primaryColor, radius = 6f, center = Offset(tHalfT1Px, yHalfPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(tHalfT1Px, yHalfPx))
  }

  // Légendes sur le graphique
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      textSize = 22f
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.color = android.graphics.Color.rgb(230, 100, 0)
    drawText("T₂ = 45°C (v₂ > v₁)", padLeft + chartW * 0.40f, padTop + chartH * 0.32f, paint)

    paint.color = android.graphics.Color.rgb(25, 118, 210)
    drawText("T₁ = 20°C", padLeft + chartW * 0.65f, padTop + chartH * 0.56f, paint)

    paint.color = android.graphics.Color.DKGRAY
    paint.textSize = 20f
    drawText("x_f = 2.0 mmol", padLeft + chartW * 0.68f, yAsymptote - 8f, paint)
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, Color(0xFFFF9800)) { normX ->
    val t = normX * 30.0f
    val xVal = 2.0f * (1f - exp(-0.28f * t))
    (xVal / 2.5f).coerceIn(0f, 1f)
  }
}

// ---------------------------------------------------------------------------
// 16. FACTEURS CINÉTIQUES : CONCENTRATION INITIALE (C2 > C1)
// ---------------------------------------------------------------------------
private fun DrawScope.drawFacteursCinetiquesConcentration(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (min)", yLabel = "x (mmol)",
    xTicks = listOf(0f to "0", 0.2f to "6", 0.4f to "12", 0.6f to "18", 0.8f to "24", 1.0f to "30"),
    yTicks = listOf(0f to "0", 0.4f to "1.0", 0.8f to "2.0", 1.0f to "2.5")
  )

  val yAsymptoteC2 = padTop + chartH * (1f - (2.0f / 2.5f))
  val yAsymptoteC1 = padTop + chartH * (1f - (1.0f / 2.5f))

  // Asymptote C2 : x_f2 = 2.0 mmol
  drawLine(
    color = Color(0xFFE91E63).copy(alpha = 0.6f),
    start = Offset(padLeft, yAsymptoteC2),
    end = Offset(padLeft + chartW, yAsymptoteC2),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
  )

  // Asymptote C1 : x_f1 = 1.0 mmol
  drawLine(
    color = primaryColor.copy(alpha = 0.6f),
    start = Offset(padLeft, yAsymptoteC1),
    end = Offset(padLeft + chartW, yAsymptoteC1),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
  )

  // Courbe C2 (forte concentration : vitesse plus grande et état final plus grand)
  val pathC2 = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 30.0f
    val xVal = 2.0f * (1f - exp(-0.18f * t))
    val normY = (xVal / 2.5f).coerceIn(0f, 1f)
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) pathC2.moveTo(px, py) else pathC2.lineTo(px, py)
  }
  drawPath(path = pathC2, color = Color(0xFFE91E63), style = Stroke(width = 4f))

  // Courbe C1 (faible concentration)
  val pathC1 = Path()
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 30.0f
    val xVal = 1.0f * (1f - exp(-0.10f * t))
    val normY = (xVal / 2.5f).coerceIn(0f, 1f)
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - normY)
    if (i == 0) pathC1.moveTo(px, py) else pathC1.lineTo(px, py)
  }
  drawPath(path = pathC1, color = primaryColor, style = Stroke(width = 3.5f))

  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      textSize = 22f
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.color = android.graphics.Color.rgb(216, 27, 96)
    drawText("C₂ = 2·C₁ (v₂ > v₁ et x_f2 > x_f1)", padLeft + chartW * 0.35f, yAsymptoteC2 - 10f, paint)

    paint.color = android.graphics.Color.rgb(25, 118, 210)
    drawText("C₁ (Réactif limitant)", padLeft + chartW * 0.45f, yAsymptoteC1 - 10f, paint)
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, Color(0xFFE91E63)) { normX ->
    val t = normX * 30.0f
    val xVal = 2.0f * (1f - exp(-0.18f * t))
    (xVal / 2.5f).coerceIn(0f, 1f)
  }
}

// ---------------------------------------------------------------------------
// 17. MONTAGE DE SUIVI MANOMÉTRIQUE (P·V = n·R·T)
// ---------------------------------------------------------------------------
private fun DrawScope.drawMontagePressiometrie(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color
) {
  val w = size.width
  val h = size.height

  // Base lab bench
  drawLine(color = Color.Gray, start = Offset(30f, h * 0.88f), end = Offset(w - 30f, h * 0.88f), strokeWidth = 4f)

  // Magnetic Stirrer
  drawRoundRect(
    color = Color(0xFF546E7A),
    topLeft = Offset(70f, h * 0.76f),
    size = androidx.compose.ui.geometry.Size(160f, h * 0.12f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
  )

  // Reaction Flask (Erlenmeyer)
  val flaskPath = Path().apply {
    moveTo(135f, h * 0.42f)
    lineTo(135f, h * 0.50f)
    lineTo(90f, h * 0.76f)
    lineTo(210f, h * 0.76f)
    lineTo(165f, h * 0.50f)
    lineTo(165f, h * 0.42f)
    close()
  }
  drawPath(path = flaskPath, color = Color(0xFFE1F5FE).copy(alpha = 0.6f))
  drawPath(path = flaskPath, color = Color.DarkGray, style = Stroke(width = 2.5f))

  // Liquid inside flask
  val liquidPath = Path().apply {
    moveTo(102f, h * 0.68f)
    lineTo(90f, h * 0.76f)
    lineTo(210f, h * 0.76f)
    lineTo(198f, h * 0.68f)
    close()
  }
  drawPath(path = liquidPath, color = Color(0xFF81D4FA))

  // Zinc granules in liquid
  drawCircle(color = Color.DarkGray, radius = 5f, center = Offset(130f, h * 0.74f))
  drawCircle(color = Color.DarkGray, radius = 4f, center = Offset(150f, h * 0.75f))
  drawCircle(color = Color.DarkGray, radius = 5f, center = Offset(170f, h * 0.73f))

  // H2 gas bubbles rising
  drawCircle(color = Color.White, radius = 3f, center = Offset(135f, h * 0.62f))
  drawCircle(color = Color.White, radius = 4f, center = Offset(155f, h * 0.58f))
  drawCircle(color = Color.White, radius = 3f, center = Offset(145f, h * 0.53f))

  // Airtight Rubber Stopper
  drawRect(
    color = Color(0xFF3E2723),
    topLeft = Offset(132f, h * 0.38f),
    size = androidx.compose.ui.geometry.Size(36f, h * 0.05f)
  )

  // Glass tube coming out of stopper
  val tubePath = Path().apply {
    moveTo(150f, h * 0.38f)
    lineTo(150f, h * 0.24f)
    cubicTo(150f, h * 0.16f, w * 0.55f, h * 0.16f, w * 0.55f, h * 0.36f)
  }
  drawPath(path = tubePath, color = Color(0xFF455A64), style = Stroke(width = 5f))

  // Digital Manometer Box on Right
  drawRoundRect(
    color = Color(0xFF263238),
    topLeft = Offset(w * 0.55f - 40f, h * 0.36f),
    size = androidx.compose.ui.geometry.Size(160f, h * 0.40f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
  )
  // Manometer LED Screen
  drawRoundRect(
    color = Color(0xFF00E676),
    topLeft = Offset(w * 0.55f - 24f, h * 0.40f),
    size = androidx.compose.ui.geometry.Size(128f, h * 0.18f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
  )

  // Annotations
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.color = android.graphics.Color.BLACK
    paint.textSize = 28f
    drawText("1142 hPa", w * 0.55f - 14f, h * 0.52f, paint)

    paint.textSize = 22f
    paint.color = android.graphics.Color.WHITE
    drawText("Capteur ΔP", w * 0.55f - 14f, h * 0.68f, paint)

    paint.color = android.graphics.Color.BLACK
    drawText("Ballon réactionnel", 80f, h * 0.34f, paint)
    paint.textSize = 18f
    drawText("(Zn(s) + 2H₃O⁺ → H₂(g) + Zn²⁺)", 50f, h * 0.38f, paint)

    paint.textSize = 22f
    paint.color = android.graphics.Color.rgb(0, 105, 92)
    drawText("ΔP(t) = (R·T / V) · x(t)", w * 0.50f, h * 0.85f, paint)
  }
}

// ---------------------------------------------------------------------------
// 18. ÉCHELLE DE pH & DIAGRAMME DE PRÉDOMINANCE
// ---------------------------------------------------------------------------
private fun DrawScope.drawEchellePHPredominance(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color
) {
  val w = size.width
  val h = size.height

  val padX = 50f
  val barW = w - 2 * padX
  val barH = 34f
  val barY = h * 0.22f

  // Gradient pH scale bar from 0 to 14
  val steps = 14
  for (i in 0 until steps) {
    val frac = i / 14f
    val nextFrac = (i + 1) / 14f
    val x1 = padX + barW * frac
    val x2 = padX + barW * nextFrac
    val col = when {
      i < 3 -> Color(0xFFE53935)
      i < 6 -> Color(0xFFFFB300)
      i == 6 || i == 7 -> Color(0xFF43A047)
      i < 11 -> Color(0xFF1E88E5)
      else -> Color(0xFF5E35B1)
    }
    drawRect(color = col, topLeft = Offset(x1, barY), size = androidx.compose.ui.geometry.Size(x2 - x1, barH))
  }
  drawRect(color = Color.DarkGray, topLeft = Offset(padX, barY), size = androidx.compose.ui.geometry.Size(barW, barH), style = Stroke(width = 2f))

  // Markers 0, 7, 14
  val xNeutre = padX + barW * 0.5f
  drawLine(color = Color.Black, start = Offset(xNeutre, barY - 8f), end = Offset(xNeutre, barY + barH + 8f), strokeWidth = 3f)

  // Predominance Axis below
  val axisY = h * 0.65f
  drawLine(color = onSurfaceColor, start = Offset(padX, axisY), end = Offset(w - padX + 20f, axisY), strokeWidth = 3f)
  // Arrow head
  val arrowPath = Path().apply {
    moveTo(w - padX + 20f, axisY)
    lineTo(w - padX + 5f, axisY - 8f)
    lineTo(w - padX + 5f, axisY + 8f)
    close()
  }
  drawPath(path = arrowPath, color = onSurfaceColor)

  // pKa marker at 4.8 (4.8 / 14 = 0.343)
  val xPka = padX + barW * (4.8f / 14f)
  drawLine(color = Color(0xFFE91E63), start = Offset(xPka, axisY - 30f), end = Offset(xPka, axisY + 30f), strokeWidth = 3.5f)

  // Shaded domains
  drawRect(
    color = Color(0xFFE53935).copy(alpha = 0.15f),
    topLeft = Offset(padX, axisY - 26f),
    size = androidx.compose.ui.geometry.Size(xPka - padX, 52f)
  )
  drawRect(
    color = Color(0xFF1E88E5).copy(alpha = 0.15f),
    topLeft = Offset(xPka, axisY - 26f),
    size = androidx.compose.ui.geometry.Size(barW - (xPka - padX), 52f)
  )

  // Annotations
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.textSize = 20f
    paint.color = android.graphics.Color.BLACK
    drawText("0", padX - 10f, barY - 10f, paint)
    drawText("pH = 7 (Neutre)", xNeutre - 60f, barY - 10f, paint)
    drawText("14", padX + barW - 10f, barY - 10f, paint)

    paint.color = android.graphics.Color.rgb(198, 40, 40)
    drawText("Milieu Acide", padX + 20f, barY + barH + 24f, paint)

    paint.color = android.graphics.Color.rgb(21, 101, 192)
    drawText("Milieu Basique", padX + barW - 140f, barY + barH + 24f, paint)

    // Predominance labels
    paint.textSize = 22f
    paint.color = android.graphics.Color.rgb(233, 30, 99)
    drawText("pKa = 4.8", xPka - 40f, axisY - 36f, paint)
    paint.textSize = 18f
    drawText("[HA] = [A⁻]", xPka - 45f, axisY + 48f, paint)

    paint.textSize = 20f
    paint.color = android.graphics.Color.rgb(183, 28, 28)
    drawText("CH₃COOH prédomine", padX + 15f, axisY - 6f, paint)
    paint.textSize = 16f
    drawText("[CH₃COOH] > [CH₃COO⁻]", padX + 15f, axisY + 18f, paint)

    paint.textSize = 20f
    paint.color = android.graphics.Color.rgb(13, 71, 161)
    drawText("CH₃COO⁻ prédomine", xPka + 30f, axisY - 6f, paint)
    paint.textSize = 16f
    drawText("[CH₃COO⁻] > [CH₃COOH]", xPka + 30f, axisY + 18f, paint)

    paint.textSize = 20f
    paint.color = android.graphics.Color.BLACK
    drawText("pH", w - padX + 25f, axisY + 6f, paint)
  }
}

// ---------------------------------------------------------------------------
// 19. DIAGRAMME DE DISTRIBUTION DES ESPÈCES α(HA) ET α(A⁻)
// ---------------------------------------------------------------------------
private fun DrawScope.drawDiagrammeDistributionPKa(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "pH", yLabel = "α (%)",
    xTicks = listOf(0f to "0", 0.2f to "2", 0.4f to "4", 0.48f to "4.8", 0.6f to "6", 0.8f to "8", 1.0f to "10"),
    yTicks = listOf(0f to "0", 0.2f to "20", 0.5f to "50", 0.8f to "80", 1.0f to "100")
  )

  val pka = 4.8f
  val xPkaPx = padLeft + chartW * (pka / 10.0f)
  val y50Px = padTop + chartH * 0.5f

  // Courbe 1 : alpha(HA) décroissante
  val pathHA = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val ph = normX * 10.0f
    val ratio = 10.0.pow((ph - pka).toDouble()).toFloat()
    val alphaA = ratio / (1f + ratio)
    val alphaHA = 1f - alphaA
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - alphaHA)
    if (i == 0) pathHA.moveTo(px, py) else pathHA.lineTo(px, py)
  }
  drawPath(path = pathHA, color = Color(0xFFE53935), style = Stroke(width = 4f))

  // Courbe 2 : alpha(A-) croissante
  val pathA = Path()
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val ph = normX * 10.0f
    val ratio = 10.0.pow((ph - pka).toDouble()).toFloat()
    val alphaA = ratio / (1f + ratio)
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - alphaA)
    if (i == 0) pathA.moveTo(px, py) else pathA.lineTo(px, py)
  }
  drawPath(path = pathA, color = Color(0xFF1E88E5), style = Stroke(width = 4f))

  // Intersection Point at (4.8, 50%)
  if (showNotablePoints) {
    drawLine(
      color = Color(0xFFE91E63),
      start = Offset(xPkaPx, padTop + chartH),
      end = Offset(xPkaPx, y50Px),
      strokeWidth = 2f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
    )
    drawLine(
      color = Color(0xFFE91E63),
      start = Offset(padLeft, y50Px),
      end = Offset(xPkaPx, y50Px),
      strokeWidth = 2f,
      pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
    )
    drawCircle(color = Color(0xFFE91E63), radius = 7f, center = Offset(xPkaPx, y50Px))
    drawCircle(color = Color.White, radius = 3.5f, center = Offset(xPkaPx, y50Px))
  }

  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.textSize = 22f
    paint.color = android.graphics.Color.rgb(211, 47, 47)
    drawText("α(HA)", padLeft + 25f, padTop + chartH * 0.15f, paint)

    paint.color = android.graphics.Color.rgb(25, 118, 210)
    drawText("α(A⁻)", padLeft + chartW * 0.82f, padTop + chartH * 0.15f, paint)

    paint.color = android.graphics.Color.rgb(233, 30, 99)
    paint.textSize = 20f
    drawText("pKa = 4.8", xPkaPx + 10f, y50Px - 10f, paint)
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, Color(0xFFE91E63)) { normX ->
    val ph = normX * 10.0f
    val ratio = 10.0.pow((ph - pka).toDouble()).toFloat()
    ratio / (1f + ratio)
  }
}

// ---------------------------------------------------------------------------
// 20. SCHÉMA VECTORIEL DE LA PILE DANIELL (Zn - Cu)
// ---------------------------------------------------------------------------
private fun DrawScope.drawMontagePileDaniell(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color
) {
  val w = size.width
  val h = size.height

  val beakerW = 120f
  val beakerH = h * 0.38f
  val beaker1X = w * 0.18f
  val beaker2X = w * 0.60f
  val beakerY = h * 0.50f

  // Left Beaker (Zn half-cell)
  drawRect(color = Color(0xFFECEFF1).copy(alpha = 0.5f), topLeft = Offset(beaker1X, beakerY), size = androidx.compose.ui.geometry.Size(beakerW, beakerH))
  drawRect(color = Color.DarkGray, topLeft = Offset(beaker1X, beakerY), size = androidx.compose.ui.geometry.Size(beakerW, beakerH), style = Stroke(width = 2.5f))
  drawRect(color = Color(0xFFCFD8DC), topLeft = Offset(beaker1X + 2f, beakerY + beakerH * 0.25f), size = androidx.compose.ui.geometry.Size(beakerW - 4f, beakerH * 0.75f))
  // Zinc electrode (gray)
  drawRect(color = Color(0xFF78909C), topLeft = Offset(beaker1X + beakerW * 0.35f, beakerY - 20f), size = androidx.compose.ui.geometry.Size(26f, beakerH * 0.85f))

  // Right Beaker (Cu half-cell)
  drawRect(color = Color(0xFFE1F5FE).copy(alpha = 0.5f), topLeft = Offset(beaker2X, beakerY), size = androidx.compose.ui.geometry.Size(beakerW, beakerH))
  drawRect(color = Color.DarkGray, topLeft = Offset(beaker2X, beakerY), size = androidx.compose.ui.geometry.Size(beakerW, beakerH), style = Stroke(width = 2.5f))
  drawRect(color = Color(0xFF81D4FA).copy(alpha = 0.7f), topLeft = Offset(beaker2X + 2f, beakerY + beakerH * 0.25f), size = androidx.compose.ui.geometry.Size(beakerW - 4f, beakerH * 0.75f))
  // Copper electrode (red-orange)
  drawRect(color = Color(0xFFD84315), topLeft = Offset(beaker2X + beakerW * 0.35f, beakerY - 20f), size = androidx.compose.ui.geometry.Size(26f, beakerH * 0.85f))

  // Salt Bridge (inverted U-tube)
  val bridgeW = (beaker2X + 25f) - (beaker1X + beakerW - 25f)
  val bridgePath = Path().apply {
    moveTo(beaker1X + beakerW - 25f, beakerY + beakerH * 0.75f)
    lineTo(beaker1X + beakerW - 25f, beakerY - 15f)
    lineTo(beaker2X + 25f, beakerY - 15f)
    lineTo(beaker2X + 25f, beakerY + beakerH * 0.75f)
  }
  drawPath(path = bridgePath, color = Color(0xFFFFF9C4), style = Stroke(width = 22f))
  drawPath(path = bridgePath, color = Color(0xFFFBC02D), style = Stroke(width = 2.5f))

  // Circuit wires & Voltmeter above
  val wirePath = Path().apply {
    moveTo(beaker1X + beakerW * 0.45f, beakerY - 20f)
    lineTo(beaker1X + beakerW * 0.45f, h * 0.18f)
    lineTo(w * 0.5f - 30f, h * 0.18f)
  }
  drawPath(path = wirePath, color = Color.Black, style = Stroke(width = 3f))

  val wirePath2 = Path().apply {
    moveTo(beaker2X + beakerW * 0.45f, beakerY - 20f)
    lineTo(beaker2X + beakerW * 0.45f, h * 0.18f)
    lineTo(w * 0.5f + 30f, h * 0.18f)
  }
  drawPath(path = wirePath2, color = Color.Black, style = Stroke(width = 3f))

  // Voltmeter Circle
  drawCircle(color = Color(0xFF37474F), radius = 34f, center = Offset(w * 0.5f, h * 0.18f))
  drawCircle(color = Color(0xFFECEFF1), radius = 28f, center = Offset(w * 0.5f, h * 0.18f))

  // Annotations
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.textSize = 24f
    paint.color = android.graphics.Color.BLACK
    drawText("V", w * 0.5f - 8f, h * 0.18f + 8f, paint)

    paint.textSize = 18f
    paint.color = android.graphics.Color.rgb(0, 150, 136)
    drawText("+1.10 V", w * 0.5f - 28f, h * 0.18f + 32f, paint)

    // Electron arrow e-
    paint.color = android.graphics.Color.rgb(198, 40, 40)
    drawText("e⁻ ⟶", w * 0.32f, h * 0.15f, paint)
    drawText("⟵ I", w * 0.65f, h * 0.15f, paint)

    // Left beaker labels
    paint.textSize = 20f
    paint.color = android.graphics.Color.DKGRAY
    drawText("Anode (-)", beaker1X + 10f, beakerY + beakerH + 24f, paint)
    paint.textSize = 16f
    drawText("Oxydation : Zn → Zn²⁺ + 2e⁻", beaker1X - 30f, beakerY + beakerH + 46f, paint)

    // Right beaker labels
    paint.textSize = 20f
    paint.color = android.graphics.Color.rgb(191, 54, 12)
    drawText("Cathode (+)", beaker2X + 5f, beakerY + beakerH + 24f, paint)
    paint.textSize = 16f
    drawText("Réduction : Cu²⁺ + 2e⁻ → Cu", beaker2X - 25f, beakerY + beakerH + 46f, paint)

    // Salt bridge label
    paint.textSize = 17f
    paint.color = android.graphics.Color.rgb(245, 127, 23)
    drawText("Pont salin (K⁺ / NO₃⁻)", w * 0.5f - 75f, beakerY - 24f, paint)
  }
}

// ---------------------------------------------------------------------------
// 21. MONTAGE D'ÉLECTROLYSE (TRANSFORMATIONS FORCÉES)
// ---------------------------------------------------------------------------
private fun DrawScope.drawMontageElectrolyse(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color
) {
  val w = size.width
  val h = size.height

  val tankW = w * 0.64f
  val tankH = h * 0.42f
  val tankX = (w - tankW) / 2f
  val tankY = h * 0.46f

  // Electrolysis Tank
  drawRoundRect(
    color = Color(0xFFE0F2F1),
    topLeft = Offset(tankX, tankY),
    size = androidx.compose.ui.geometry.Size(tankW, tankH),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
  )
  drawRoundRect(
    color = Color.DarkGray,
    topLeft = Offset(tankX, tankY),
    size = androidx.compose.ui.geometry.Size(tankW, tankH),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f),
    style = Stroke(width = 2.5f)
  )

  // Solution (Cu²⁺ + 2Br⁻)
  drawRect(
    color = Color(0xFF80CBC4).copy(alpha = 0.5f),
    topLeft = Offset(tankX + 4f, tankY + tankH * 0.25f),
    size = androidx.compose.ui.geometry.Size(tankW - 8f, tankH * 0.75f)
  )

  // Electrodes (Graphite)
  val elec1X = tankX + tankW * 0.22f
  val elec2X = tankX + tankW * 0.72f
  drawRect(color = Color(0xFF37474F), topLeft = Offset(elec1X, tankY - 15f), size = androidx.compose.ui.geometry.Size(24f, tankH * 0.90f))
  drawRect(color = Color(0xFF37474F), topLeft = Offset(elec2X, tankY - 15f), size = androidx.compose.ui.geometry.Size(24f, tankH * 0.90f))

  // Copper deposit on Cathode (elec2)
  drawRect(color = Color(0xFFD84315), topLeft = Offset(elec2X - 3f, tankY + tankH * 0.35f), size = androidx.compose.ui.geometry.Size(30f, tankH * 0.50f))

  // Br2 bubbles around Anode (elec1)
  drawCircle(color = Color(0xFFBF360C), radius = 4f, center = Offset(elec1X - 6f, tankY + tankH * 0.45f))
  drawCircle(color = Color(0xFFBF360C), radius = 5f, center = Offset(elec1X + 30f, tankY + tankH * 0.55f))
  drawCircle(color = Color(0xFFBF360C), radius = 4f, center = Offset(elec1X - 4f, tankY + tankH * 0.65f))

  // DC Power Supply (Générateur G)
  drawRoundRect(
    color = Color(0xFF455A64),
    topLeft = Offset(w * 0.5f - 60f, h * 0.12f),
    size = androidx.compose.ui.geometry.Size(120f, h * 0.18f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
  )
  drawCircle(color = Color(0xFFE53935), radius = 8f, center = Offset(w * 0.5f - 35f, h * 0.26f))
  drawCircle(color = Color(0xFF1E88E5), radius = 8f, center = Offset(w * 0.5f + 35f, h * 0.26f))

  // Connecting wires
  val wire1 = Path().apply {
    moveTo(w * 0.5f - 35f, h * 0.26f)
    lineTo(elec1X + 12f, h * 0.26f)
    lineTo(elec1X + 12f, tankY - 15f)
  }
  drawPath(path = wire1, color = Color(0xFFE53935), style = Stroke(width = 3f))

  val wire2 = Path().apply {
    moveTo(w * 0.5f + 35f, h * 0.26f)
    lineTo(elec2X + 12f, h * 0.26f)
    lineTo(elec2X + 12f, tankY - 15f)
  }
  drawPath(path = wire2, color = Color(0xFF1E88E5), style = Stroke(width = 3f))

  // Annotations
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.textSize = 26f
    paint.color = android.graphics.Color.WHITE
    drawText("G (DC)", w * 0.5f - 35f, h * 0.20f, paint)

    paint.textSize = 20f
    paint.color = android.graphics.Color.rgb(198, 40, 40)
    drawText("(+) Anode : Oxydation", tankX - 20f, tankY + tankH + 26f, paint)
    paint.textSize = 16f
    drawText("2Br⁻ → Br₂(aq) + 2e⁻", tankX - 20f, tankY + tankH + 48f, paint)

    paint.textSize = 20f
    paint.color = android.graphics.Color.rgb(21, 101, 192)
    drawText("(-) Cathode : Réduction", elec2X - 50f, tankY + tankH + 26f, paint)
    paint.textSize = 16f
    drawText("Cu²⁺ + 2e⁻ → Cu(s)", elec2X - 50f, tankY + tankH + 48f, paint)
  }
}

// ---------------------------------------------------------------------------
// 22. MONTAGE DE CHAUFFAGE À REFLUX (RÉFRIGÉRANT À BOULES)
// ---------------------------------------------------------------------------
private fun DrawScope.drawMontageChauffageReflux(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color
) {
  val w = size.width
  val h = size.height

  val centerX = w * 0.40f

  // Lab Jack (Support élévateur)
  drawRect(color = Color(0xFFB0BEC5), topLeft = Offset(centerX - 90f, h * 0.84f), size = androidx.compose.ui.geometry.Size(180f, h * 0.08f))

  // Heating Mantle (Chauffe-ballon)
  drawRoundRect(
    color = Color(0xFF5D4037),
    topLeft = Offset(centerX - 75f, h * 0.68f),
    size = androidx.compose.ui.geometry.Size(150f, h * 0.16f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
  )

  // Round Bottom Flask (Ballon)
  drawCircle(color = Color(0xFFE1F5FE).copy(alpha = 0.6f), radius = 55f, center = Offset(centerX, h * 0.62f))
  drawCircle(color = Color.DarkGray, radius = 55f, center = Offset(centerX, h * 0.62f), style = Stroke(width = 2.5f))
  // Reaction liquid
  drawCircle(color = Color(0xFFFFCC80), radius = 45f, center = Offset(centerX, h * 0.65f))
  // Boiling chips (pierres ponces)
  drawCircle(color = Color.White, radius = 4f, center = Offset(centerX - 15f, h * 0.68f))
  drawCircle(color = Color.White, radius = 3f, center = Offset(centerX + 12f, h * 0.69f))

  // Flask Neck
  drawRect(color = Color.DarkGray, topLeft = Offset(centerX - 16f, h * 0.45f), size = androidx.compose.ui.geometry.Size(32f, h * 0.12f), style = Stroke(width = 2.5f))

  // Allihn Condenser (Réfrigérant à boules)
  val condTop = h * 0.10f
  val condH = h * 0.35f
  drawRect(color = Color(0xFFE0F7FA).copy(alpha = 0.4f), topLeft = Offset(centerX - 24f, condTop), size = androidx.compose.ui.geometry.Size(48f, condH))
  drawRect(color = Color.DarkGray, topLeft = Offset(centerX - 24f, condTop), size = androidx.compose.ui.geometry.Size(48f, condH), style = Stroke(width = 2.5f))

  // Condenser bulbs inside
  for (i in 1..4) {
    val by = condTop + i * (condH * 0.20f)
    drawCircle(color = Color(0xFF80DEEA), radius = 12f, center = Offset(centerX, by))
  }

  // Water In (Bottom) & Water Out (Top)
  drawLine(color = Color(0xFF0288D1), start = Offset(centerX + 24f, condTop + condH * 0.85f), end = Offset(centerX + 65f, condTop + condH * 0.85f), strokeWidth = 5f)
  drawLine(color = Color(0xFF0288D1), start = Offset(centerX - 24f, condTop + condH * 0.15f), end = Offset(centerX - 65f, condTop + condH * 0.15f), strokeWidth = 5f)

  // Annotations
  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.textSize = 20f
    paint.color = android.graphics.Color.rgb(2, 136, 209)
    drawText("Entrée eau froide ⟵", centerX + 75f, condTop + condH * 0.88f, paint)
    drawText("⟶ Sortie eau tiède", centerX - 210f, condTop + condH * 0.18f, paint)

    paint.color = android.graphics.Color.BLACK
    paint.textSize = 22f
    drawText("Réfrigérant à boules", centerX + 60f, condTop + condH * 0.45f, paint)

    drawText("Ballon bicol", centerX + 75f, h * 0.62f, paint)
    paint.textSize = 17f
    drawText("(Acide + Alcool + H₂SO₄)", centerX + 75f, h * 0.66f, paint)

    paint.textSize = 20f
    drawText("Chauffe-ballon", centerX + 85f, h * 0.75f, paint)

    paint.color = android.graphics.Color.rgb(183, 28, 28)
    paint.textSize = 20f
    drawText("Accélérer la réaction sans perte de matière !", w * 0.15f, h * 0.96f, paint)
  }
}

// ---------------------------------------------------------------------------
// 23. CINÉTIQUES COMPARÉES ESTÉRIFICATION & HYDROLYSE
// ---------------------------------------------------------------------------
private fun DrawScope.drawCinetiqueEsterificationHydrolyse(
  primaryColor: Color,
  secondaryColor: Color,
  tertiaryColor: Color,
  onSurfaceColor: Color,
  gridColor: Color,
  gridSubColor: Color,
  showTangents: Boolean,
  showNotablePoints: Boolean,
  touchNormX: Float?
) {
  val padLeft = 45f
  val padBottom = 30f
  val padTop = 20f
  val padRight = 20f
  val chartW = size.width - padLeft - padRight
  val chartH = size.height - padTop - padBottom

  drawGridAndAxes(
    gridColor, gridSubColor, onSurfaceColor,
    xLabel = "t (min)", yLabel = "n (mol)",
    xTicks = listOf(0f to "0", 0.2f to "60", 0.4f to "120", 0.6f to "180", 0.8f to "240", 1.0f to "300"),
    yTicks = listOf(0f to "0", 0.33f to "0.33", 0.67f to "0.67", 1.0f to "1.00")
  )

  val yEqPx = padTop + chartH * (1f - 0.67f)

  // Ligne d'équilibre n_eq = 0.67 mol (Rendement 67% pour alcool primaire)
  drawLine(
    color = onSurfaceColor.copy(alpha = 0.6f),
    start = Offset(padLeft, yEqPx),
    end = Offset(padLeft + chartW, yEqPx),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
  )

  // Courbe 1 : Estérification n(ester) partant de 0 vers 0.67 mol
  val pathEst = Path()
  val steps = 120
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 300.0f
    val nVal = 0.67f * (1f - exp(-t / 60.0f))
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - nVal)
    if (i == 0) pathEst.moveTo(px, py) else pathEst.lineTo(px, py)
  }
  drawPath(path = pathEst, color = Color(0xFF2E7D32), style = Stroke(width = 4f))

  // Courbe 2 : Hydrolyse partant de 1.0 mol vers 0.67 mol
  val pathHyd = Path()
  for (i in 0..steps) {
    val normX = i / steps.toFloat()
    val t = normX * 300.0f
    val nVal = 1.0f - 0.33f * (1f - exp(-t / 60.0f))
    val px = padLeft + chartW * normX
    val py = padTop + chartH * (1f - nVal)
    if (i == 0) pathHyd.moveTo(px, py) else pathHyd.lineTo(px, py)
  }
  drawPath(path = pathHyd, color = Color(0xFFD32F2F), style = Stroke(width = 3.5f))

  if (showNotablePoints) {
    drawCircle(color = Color(0xFF2E7D32), radius = 6f, center = Offset(padLeft + chartW * 0.90f, yEqPx))
    drawCircle(color = Color.White, radius = 3f, center = Offset(padLeft + chartW * 0.90f, yEqPx))
  }

  drawContext.canvas.nativeCanvas.apply {
    val paint = android.graphics.Paint().apply {
      isAntiAlias = true
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    paint.textSize = 21f
    paint.color = android.graphics.Color.rgb(46, 125, 50)
    drawText("Estérification : n_ester(t)", padLeft + chartW * 0.40f, padTop + chartH * 0.44f, paint)

    paint.color = android.graphics.Color.rgb(211, 47, 47)
    drawText("Hydrolyse : n_ester(t)", padLeft + chartW * 0.40f, padTop + chartH * 0.22f, paint)

    paint.color = android.graphics.Color.BLACK
    paint.textSize = 20f
    drawText("Équilibre : n_éq = 0.67 mol (r = 67%, K = 4)", padLeft + 20f, yEqPx - 10f, paint)
  }

  drawTouchCursor(touchNormX, padLeft, padTop, chartW, chartH, Color(0xFF2E7D32)) { normX ->
    val t = normX * 300.0f
    0.67f * (1f - exp(-t / 60.0f))
  }
}

// ---------------------------------------------------------------------------
// TOUCH CURSOR PROBE HELPER
// ---------------------------------------------------------------------------

private fun DrawScope.drawTouchCursor(
  touchNormX: Float?,
  padLeft: Float,
  padTop: Float,
  chartW: Float,
  chartH: Float,
  color: Color,
  normYCalculator: (Float) -> Float
) {
  if (touchNormX == null) return

  val cx = padLeft + chartW * touchNormX
  val cyNorm = normYCalculator(touchNormX)
  val cy = padTop + chartH * (1f - cyNorm)

  // Vertical cursor line
  drawLine(
    color = color.copy(alpha = 0.7f),
    start = Offset(cx, padTop),
    end = Offset(cx, padTop + chartH),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
  )

  // Horizontal cursor line
  drawLine(
    color = color.copy(alpha = 0.7f),
    start = Offset(padLeft, cy),
    end = Offset(padLeft + chartW, cy),
    strokeWidth = 2f,
    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
  )

  // Glowing target circle on curve
  drawCircle(color = color.copy(alpha = 0.35f), radius = 12f, center = Offset(cx, cy))
  drawCircle(color = color, radius = 6f, center = Offset(cx, cy))
  drawCircle(color = Color.White, radius = 2.5f, center = Offset(cx, cy))
}
