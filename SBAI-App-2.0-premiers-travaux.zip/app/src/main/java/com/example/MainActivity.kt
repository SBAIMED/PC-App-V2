package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CurriculumData
import com.example.data.GoogleAuthManager
import com.example.data.NotificationItem
import com.example.data.SessionManager
import com.example.data.SubjectType
import com.example.data.UserRole
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ScienceGreen
import com.example.util.NotificationHelper
import kotlinx.coroutines.launch

enum class MainDestination(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  DASHBOARD("Tableau de Bord", Icons.Default.Dashboard),
  COURS("Cours", Icons.AutoMirrored.Filled.MenuBook),
  EXERCICES("Exercices", Icons.Default.EditNote),
  EXAMENS("Examens", Icons.Default.WorkspacePremium),
  EVALUATIONS("Évaluations", Icons.Default.Assessment)
}

enum class SecondaryDestination {
  NONE,
  QUIZ_BUILDER,
  INTERACTIVE_QUIZ,
  TEACHER_DASHBOARD,
  STUDENT_DASHBOARD,
  MESSAGING,
  TOOLS
}

enum class AppStage {
  INTRO_SPLASH,
  AUTH,
  MAIN_APP
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    // Initialisation tolérante aux pannes : garantit que l'absence de google-services.json ou de clé Gemini ne bloque jamais le démarrage
    try {
      com.example.data.FirebaseSafetyManager.isFirebaseAvailable(this)
    } catch (t: Throwable) {
      android.util.Log.w("MainActivity", "Safe launch fallback: ${t.message}")
    }
    setContent {
      var isDarkThemeCustom by remember { mutableStateOf<Boolean?>(null) }
      val systemInDark = isSystemInDarkTheme()
      val isDarkMode = isDarkThemeCustom ?: systemInDark

      MyApplicationTheme(darkTheme = isDarkMode) {
        PhysicsChemistryApp(
          isDarkMode = isDarkMode,
          onToggleDarkMode = {
            isDarkThemeCustom = !isDarkMode
          }
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhysicsChemistryApp(
  isDarkMode: Boolean,
  onToggleDarkMode: () -> Unit
) {
  val context = LocalContext.current
  val sessionManager = remember { SessionManager.getInstance(context) }

  var appStage by rememberSaveable {
    mutableStateOf(if (sessionManager.isLoggedIn) AppStage.MAIN_APP else AppStage.INTRO_SPLASH)
  }
  var currentUserRole by rememberSaveable { mutableStateOf(sessionManager.userRole) }
  var loggedInUserName by rememberSaveable { mutableStateOf(sessionManager.userName) }
  var loggedInUserClass by rememberSaveable { mutableStateOf(sessionManager.userClass) }

  var currentTab by rememberSaveable { mutableStateOf(MainDestination.DASHBOARD) }
  var secondaryScreen by rememberSaveable { mutableStateOf(SecondaryDestination.NONE) }
  var selectedCoursesSubject by rememberSaveable { mutableStateOf(SubjectType.PHYSIQUE) }
  var selectedExercisesSubject by rememberSaveable { mutableStateOf(SubjectType.PHYSIQUE) }
  var initialExerciseChapterFilter by rememberSaveable { mutableStateOf<String?>(null) }

  // App wide state
  var studentScore by rememberSaveable { mutableIntStateOf(sessionManager.studentScore) }
  val studentEvalsGrades = remember { mutableStateMapOf<String, Double>() }
  val notificationsList = remember { mutableStateListOf(*CurriculumData.initialNotifications.toTypedArray()) }
  var showNotificationsDialog by remember { mutableStateOf(false) }
  var showAboutDialog by remember { mutableStateOf(false) }
  var showCloudSyncSnackbar by remember { mutableStateOf(false) }
  var showTeacherPasscodeDialog by remember { mutableStateOf(false) }

  val repository = remember { com.example.data.repository.AppLocalRepository.getInstance(context) }
  LaunchedEffect(Unit) {
    repository.seedInitialDataIfNeeded()
  }

  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val coroutineScope = rememberCoroutineScope()

  when (appStage) {
    AppStage.INTRO_SPLASH -> {
      IntroSplashScreen(
        onStartExperience = {
          appStage = if (sessionManager.isLoggedIn) AppStage.MAIN_APP else AppStage.AUTH
        }
      )
    }
    AppStage.AUTH -> {
      LoginScreen(
        onLoginSuccess = { role, name, userClass ->
          currentUserRole = role
          loggedInUserName = name
          loggedInUserClass = userClass
          sessionManager.saveSession(role, name, userClass)
          appStage = AppStage.MAIN_APP
        },
        onBackToIntro = {
          appStage = AppStage.INTRO_SPLASH
        }
      )
    }
    AppStage.MAIN_APP -> {
      // Handle back button when in a subscreen
      BackHandler(enabled = secondaryScreen != SecondaryDestination.NONE) {
        secondaryScreen = SecondaryDestination.NONE
      }

      ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
          ModalDrawerSheet(
            modifier = Modifier.width(320.dp)
          ) {
            Column(
              modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              // Drawer Header
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp))
                  .padding(16.dp)
              ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  Text(
                    "Physique-Chimie 2nd Cycle",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                  )
                  Text(
                    "Pr. Mohammed SBAI • 2BAC PC",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                  )
                  Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                      Text(
                        "Session : ${currentUserRole.label} • $loggedInUserName",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                      )
                      if (currentUserRole == UserRole.ELEVE) {
                        Text(
                          loggedInUserClass,
                          style = MaterialTheme.typography.bodySmall,
                          fontSize = 10.sp,
                          color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                      }
                    }
                  }
                }
              }

              HorizontalDivider()

              // SECTION 1 : VUE D'ENSEMBLE
              Text(
                "TABLEAU DE BORD",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 12.dp, top = 4.dp)
              )

              NavigationDrawerItem(
                label = { Text(if (currentUserRole == UserRole.PROFESSEUR) "Tableau de bord de la classe" else "Tableau de Bord & Progression") },
                icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                selected = secondaryScreen == SecondaryDestination.NONE && currentTab == MainDestination.DASHBOARD,
                onClick = {
                  currentTab = MainDestination.DASHBOARD
                  secondaryScreen = SecondaryDestination.NONE
                  coroutineScope.launch { drawerState.close() }
                }
              )

              HorizontalDivider()

              // SECTION 2 : PHYSIQUE (P1-P16) — ACCÈS DÉDIÉ STRICT
              Text(
                "⚡ PHYSIQUE (P1 à P16)",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 12.dp, top = 4.dp)
              )

              NavigationDrawerItem(
                label = { Text("Cours de Physique (P1-P16)") },
                icon = { Icon(Icons.Default.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                selected = secondaryScreen == SecondaryDestination.NONE && currentTab == MainDestination.COURS && selectedCoursesSubject == SubjectType.PHYSIQUE,
                onClick = {
                  selectedCoursesSubject = SubjectType.PHYSIQUE
                  currentTab = MainDestination.COURS
                  secondaryScreen = SecondaryDestination.NONE
                  coroutineScope.launch { drawerState.close() }
                }
              )

              NavigationDrawerItem(
                label = { Text("Exercices de Physique (P1-P16)") },
                icon = { Icon(Icons.Default.EditNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                selected = secondaryScreen == SecondaryDestination.NONE && currentTab == MainDestination.EXERCICES && selectedExercisesSubject == SubjectType.PHYSIQUE,
                onClick = {
                  selectedExercisesSubject = SubjectType.PHYSIQUE
                  initialExerciseChapterFilter = null
                  currentTab = MainDestination.EXERCICES
                  secondaryScreen = SecondaryDestination.NONE
                  coroutineScope.launch { drawerState.close() }
                }
              )

              HorizontalDivider()

              // SECTION 3 : CHIMIE (C1-C10) — ACCÈS DÉDIÉ STRICT
              Text(
                "🧪 CHIMIE (C1 à C10)",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(start = 12.dp, top = 4.dp)
              )

              NavigationDrawerItem(
                label = { Text("Cours de Chimie (C1-C10)") },
                icon = { Icon(Icons.Default.Science, contentDescription = null, tint = MaterialTheme.colorScheme.secondary) },
                selected = secondaryScreen == SecondaryDestination.NONE && currentTab == MainDestination.COURS && selectedCoursesSubject == SubjectType.CHIMIE,
                onClick = {
                  selectedCoursesSubject = SubjectType.CHIMIE
                  currentTab = MainDestination.COURS
                  secondaryScreen = SecondaryDestination.NONE
                  coroutineScope.launch { drawerState.close() }
                }
              )

              NavigationDrawerItem(
                label = { Text("Exercices de Chimie (C1-C10)") },
                icon = { Icon(Icons.Default.Biotech, contentDescription = null, tint = MaterialTheme.colorScheme.secondary) },
                selected = secondaryScreen == SecondaryDestination.NONE && currentTab == MainDestination.EXERCICES && selectedExercisesSubject == SubjectType.CHIMIE,
                onClick = {
                  selectedExercisesSubject = SubjectType.CHIMIE
                  initialExerciseChapterFilter = null
                  currentTab = MainDestination.EXERCICES
                  secondaryScreen = SecondaryDestination.NONE
                  coroutineScope.launch { drawerState.close() }
                }
              )

              HorizontalDivider()

              // SECTION 4 : EXAMENS & ÉVALUATIONS
              Text(
                "ÉVALUATIONS & EXAMENS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.padding(start = 12.dp, top = 4.dp)
              )

              NavigationDrawerItem(
                label = { Text("Examens Nationaux (2015-2026)") },
                icon = { Icon(Icons.Default.WorkspacePremium, contentDescription = null) },
                selected = secondaryScreen == SecondaryDestination.NONE && currentTab == MainDestination.EXAMENS,
                onClick = {
                  currentTab = MainDestination.EXAMENS
                  secondaryScreen = SecondaryDestination.NONE
                  coroutineScope.launch { drawerState.close() }
                }
              )

              NavigationDrawerItem(
                label = { Text("Évaluations Continues (S1 & S2)") },
                icon = { Icon(Icons.Default.Assessment, contentDescription = null) },
                selected = secondaryScreen == SecondaryDestination.NONE && currentTab == MainDestination.EVALUATIONS,
                onClick = {
                  currentTab = MainDestination.EVALUATIONS
                  secondaryScreen = SecondaryDestination.NONE
                  coroutineScope.launch { drawerState.close() }
                }
              )

              HorizontalDivider()

              // SECTION 5 : OUTILS PÉDAGOGIQUES
              Text(
                "OUTILS PÉDAGOGIQUES",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 12.dp, top = 4.dp)
              )

              NavigationDrawerItem(
                label = { Text("Tests Interactifs (Par Niveau)") },
                icon = { Icon(Icons.Default.Extension, contentDescription = null) },
                selected = secondaryScreen == SecondaryDestination.INTERACTIVE_QUIZ,
                onClick = {
                  secondaryScreen = SecondaryDestination.INTERACTIVE_QUIZ
                  coroutineScope.launch { drawerState.close() }
                }
              )

              NavigationDrawerItem(
                label = { Text("Concepteur de Quiz (QCM)") },
                icon = { Icon(Icons.Default.Psychology, contentDescription = null) },
                selected = secondaryScreen == SecondaryDestination.QUIZ_BUILDER,
                onClick = {
                  secondaryScreen = SecondaryDestination.QUIZ_BUILDER
                  coroutineScope.launch { drawerState.close() }
                }
              )

              NavigationDrawerItem(
                label = { Text("Messagerie Professeur - Élèves") },
                icon = { Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null) },
                selected = secondaryScreen == SecondaryDestination.MESSAGING,
                onClick = {
                  secondaryScreen = SecondaryDestination.MESSAGING
                  coroutineScope.launch { drawerState.close() }
                }
              )

              NavigationDrawerItem(
                label = { Text("Formulaire & Calculatrice") },
                icon = { Icon(Icons.Default.Calculate, contentDescription = null) },
                selected = secondaryScreen == SecondaryDestination.TOOLS,
                onClick = {
                  secondaryScreen = SecondaryDestination.TOOLS
                  coroutineScope.launch { drawerState.close() }
                }
              )

              HorizontalDivider()

              // SECTION 6 : GESTION COMPTE
              NavigationDrawerItem(
                label = { Text("Changer d'utilisateur / Déconnexion") },
                icon = { Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null) },
                selected = false,
                onClick = {
                  coroutineScope.launch {
                    drawerState.close()
                    GoogleAuthManager.signOut(context)
                    appStage = AppStage.AUTH
                  }
                }
              )

              NavigationDrawerItem(
                label = { Text("Revoir l'introduction animée") },
                icon = { Icon(Icons.Default.Replay, contentDescription = null) },
                selected = false,
                onClick = {
                  coroutineScope.launch { drawerState.close() }
                  appStage = AppStage.INTRO_SPLASH
                }
              )

              // Mode hors-ligne info
              Surface(
                color = ScienceGreen.copy(alpha = 0.12f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Icon(Icons.Default.CloudDone, contentDescription = null, tint = ScienceGreen, modifier = Modifier.size(18.dp))
                  Column {
                    Text("Mode Hors-Ligne Actif", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = ScienceGreen)
                    Text("16 chapitres Physique & 10 Chimie intégrés", style = MaterialTheme.typography.labelSmall)
                  }
                }
              }

              // Statut Base de données Room (SQLite)
              Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Icon(Icons.Default.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                  Column {
                    Text("Base de Données Room (SQLite)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text("Notes, rappels, quiz & progrès persistés", style = MaterialTheme.typography.labelSmall)
                  }
                }
              }

              // About Button
              TextButton(
                onClick = {
                  showAboutDialog = true
                  coroutineScope.launch { drawerState.close() }
                },
                modifier = Modifier.fillMaxWidth()
              ) {
                Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("À propos du Pr. SBAI Mohammed")
              }
            }
          }
        }
      ) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      topBar = {
        val headerTitle = when {
          secondaryScreen == SecondaryDestination.QUIZ_BUILDER -> "Concepteur de Quiz (QCM)"
          secondaryScreen == SecondaryDestination.INTERACTIVE_QUIZ -> "Tests Interactifs (Par Niveau)"
          secondaryScreen == SecondaryDestination.MESSAGING -> "Messagerie Pr. SBAI"
          secondaryScreen == SecondaryDestination.TOOLS -> "Formulaire & Calculatrice"
          secondaryScreen == SecondaryDestination.TEACHER_DASHBOARD -> "Tableau de Bord Professeur"
          secondaryScreen == SecondaryDestination.STUDENT_DASHBOARD -> "Tableau de Bord & Progression"
          currentTab == MainDestination.DASHBOARD -> "Tableau de Bord & Progression"
          currentTab == MainDestination.COURS -> if (selectedCoursesSubject == SubjectType.PHYSIQUE) "Cours de Physique (P1-P16)" else "Cours de Chimie (C1-C10)"
          currentTab == MainDestination.EXERCICES -> if (selectedExercisesSubject == SubjectType.PHYSIQUE) "Exercices de Physique (P1-P16)" else "Exercices de Chimie (C1-C10)"
          currentTab == MainDestination.EXAMENS -> "Examens Nationaux (2015-2026)"
          currentTab == MainDestination.EVALUATIONS -> "Évaluations Continues (S1 & S2)"
          else -> "Physique-Chimie 2BAC"
        }

        TopAppBar(
          title = {
            Column {
              Text(
                headerTitle,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1
              )
              Text(
                "2BAC PC • Pr. Mohammed SBAI",
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          },
          navigationIcon = {
            if (secondaryScreen != SecondaryDestination.NONE) {
              IconButton(
                onClick = { secondaryScreen = SecondaryDestination.NONE },
                modifier = Modifier.testTag("btn_back_to_main")
              ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
              }
            } else {
              IconButton(
                onClick = { coroutineScope.launch { drawerState.open() } },
                modifier = Modifier.testTag("btn_drawer_open")
              ) {
                Icon(Icons.Default.Menu, contentDescription = "Menu Navigation")
              }
            }
          },
          actions = {
            // Quick Subject Toggle Chip when on COURS or EXERCICES
            if (secondaryScreen == SecondaryDestination.NONE && (currentTab == MainDestination.COURS || currentTab == MainDestination.EXERCICES)) {
              val activeSubject = if (currentTab == MainDestination.COURS) selectedCoursesSubject else selectedExercisesSubject
              AssistChip(
                onClick = {
                  val newSubject = if (activeSubject == SubjectType.PHYSIQUE) SubjectType.CHIMIE else SubjectType.PHYSIQUE
                  if (currentTab == MainDestination.COURS) {
                    selectedCoursesSubject = newSubject
                  } else {
                    selectedExercisesSubject = newSubject
                    initialExerciseChapterFilter = null
                  }
                },
                label = {
                  Text(
                    if (activeSubject == SubjectType.PHYSIQUE) "Physique" else "Chimie",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                  )
                },
                leadingIcon = {
                  Icon(
                    if (activeSubject == SubjectType.PHYSIQUE) Icons.Default.Bolt else Icons.Default.Science,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                  )
                },
                colors = AssistChipDefaults.assistChipColors(
                  containerColor = if (activeSubject == SubjectType.PHYSIQUE) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                ),
                modifier = Modifier.testTag("subject_quick_toggle_chip")
              )
            }

            // Role switcher chip
            AssistChip(
              onClick = {
                if (currentUserRole == UserRole.PROFESSEUR) {
                  currentUserRole = UserRole.ELEVE
                  val studentName = if (loggedInUserName == CurriculumData.teacherName) "Élève 2BAC" else loggedInUserName
                  sessionManager.saveSession(UserRole.ELEVE, studentName, sessionManager.userClass)
                } else {
                  showTeacherPasscodeDialog = true
                }
              },
              label = {
                Text(
                  currentUserRole.label,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp
                )
              },
              leadingIcon = {
                Icon(
                  if (currentUserRole == UserRole.PROFESSEUR) Icons.Default.School else Icons.Default.Person,
                  contentDescription = null,
                  modifier = Modifier.size(14.dp)
                )
              },
              colors = AssistChipDefaults.assistChipColors(
                containerColor = if (currentUserRole == UserRole.PROFESSEUR) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
              ),
              modifier = Modifier.testTag("role_switcher_chip")
            )

            // Notifications Bell
            IconButton(
              onClick = { showNotificationsDialog = true },
              modifier = Modifier.testTag("btn_notifications")
            ) {
              BadgedBox(
                badge = {
                  Badge { Text("${notificationsList.count { !it.isRead }}") }
                }
              ) {
                Icon(Icons.Default.Notifications, contentDescription = "Notifications")
              }
            }

            // Dark Mode Toggle
            IconButton(
              onClick = onToggleDarkMode,
              modifier = Modifier.testTag("btn_toggle_dark_mode")
            ) {
              Icon(
                if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                contentDescription = "Changer thème"
              )
            }
          },
          colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
          )
        )
      },
      bottomBar = {
        NavigationBar(
          modifier = Modifier.testTag("bottom_nav_bar")
        ) {
          MainDestination.values().forEach { dest ->
            val isSelected = secondaryScreen == SecondaryDestination.NONE && currentTab == dest
            NavigationBarItem(
              selected = isSelected,
              onClick = {
                currentTab = dest
                secondaryScreen = SecondaryDestination.NONE
              },
              icon = { Icon(dest.icon, contentDescription = dest.label) },
              label = { Text(dest.label, fontSize = 10.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
              modifier = Modifier.testTag("nav_item_${dest.name.lowercase()}")
            )
          }
        }
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        when (secondaryScreen) {
          SecondaryDestination.QUIZ_BUILDER -> {
            QuizBuilderScreen(
              currentUserRole = currentUserRole,
              onQuizSubmittedByStudent = { sub ->
                studentScore += sub.score.toInt() * 10
                sessionManager.studentScore = studentScore
              }
            )
          }
          SecondaryDestination.INTERACTIVE_QUIZ -> {
            InteractiveQuizScreen(
              onScoreUpdated = { pts ->
                studentScore += pts
                sessionManager.studentScore = studentScore
              }
            )
          }
          SecondaryDestination.TEACHER_DASHBOARD -> {
            TeacherDashboardScreen(
              onSendAnnouncement = { text ->
                NotificationHelper.sendNotification(context, "Nouvelle consigne du Pr. SBAI", text)
                notificationsList.add(
                  0,
                  NotificationItem(
                    id = "notif_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(4)}",
                    title = "Nouvelle consigne du Pr. SBAI",
                    message = text,
                    timeAgo = "À l'instant",
                    category = "Annonce"
                  )
                )
              }
            )
          }
          SecondaryDestination.STUDENT_DASHBOARD -> {
            StudentDashboardScreen(
              studentName = loggedInUserName,
              studentClass = loggedInUserClass,
              currentQuizScore = studentScore,
              userCompletedEvals = studentEvalsGrades,
              onNavigateToCourses = {
                secondaryScreen = SecondaryDestination.NONE
                currentTab = MainDestination.COURS
              },
              onNavigateToEvaluations = {
                secondaryScreen = SecondaryDestination.NONE
                currentTab = MainDestination.EVALUATIONS
              },
              onNavigateToExercises = {
                secondaryScreen = SecondaryDestination.NONE
                currentTab = MainDestination.EXERCICES
              }
            )
          }
          SecondaryDestination.MESSAGING -> {
            MessagingScreen(currentUserRole = currentUserRole)
          }
          SecondaryDestination.TOOLS -> {
            ToolsScreen()
          }
          SecondaryDestination.NONE -> {
            when (currentTab) {
              MainDestination.DASHBOARD -> {
                if (currentUserRole == UserRole.PROFESSEUR) {
                  TeacherDashboardScreen(
                    onSendAnnouncement = { text ->
                      NotificationHelper.sendNotification(context, "Nouvelle consigne du Pr. SBAI", text)
                      notificationsList.add(
                        0,
                        NotificationItem(
                          id = "notif_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(4)}",
                          title = "Nouvelle consigne du Pr. SBAI",
                          message = text,
                          timeAgo = "À l'instant",
                          category = "Annonce"
                        )
                      )
                    }
                  )
                } else {
                  StudentDashboardScreen(
                    studentName = loggedInUserName,
                    studentClass = loggedInUserClass,
                    currentQuizScore = studentScore,
                    userCompletedEvals = studentEvalsGrades,
                    onNavigateToCourses = {
                      currentTab = MainDestination.COURS
                    },
                    onNavigateToEvaluations = {
                      currentTab = MainDestination.EVALUATIONS
                    },
                    onNavigateToExercises = {
                      currentTab = MainDestination.EXERCICES
                    }
                  )
                }
              }
              MainDestination.COURS -> {
                CoursesScreen(
                  initialSubject = selectedCoursesSubject,
                  onNavigateToExercisesForChapter = { chId ->
                    initialExerciseChapterFilter = chId
                    selectedExercisesSubject = if (chId.startsWith("P", ignoreCase = true)) SubjectType.PHYSIQUE else SubjectType.CHIMIE
                    currentTab = MainDestination.EXERCICES
                  },
                  onOpenDashboard = {
                    currentTab = MainDestination.DASHBOARD
                  }
                )
              }
              MainDestination.EXERCICES -> {
                ExercisesScreen(
                  initialSubject = selectedExercisesSubject,
                  initialChapterFilter = initialExerciseChapterFilter
                )
              }
              MainDestination.EXAMENS -> {
                NationalExamsScreen()
              }
              MainDestination.EVALUATIONS -> {
                EvaluationsScreen(
                  onEvaluationCompleted = { evalId, grade ->
                    studentEvalsGrades[evalId] = grade
                  }
                )
              }
            }
          }
        }
      }
    }
  }

  // Notifications Dialog
  if (showNotificationsDialog) {
    AlertDialog(
      onDismissRequest = { showNotificationsDialog = false },
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Text("Notifications Pédagogiques")
        }
      },
      text = {
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          notificationsList.forEach { notif ->
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(notif.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                  Text(notif.timeAgo, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(notif.message, style = MaterialTheme.typography.bodySmall)
              }
            }
          }
        }
      },
      confirmButton = {
        Button(onClick = {
          notificationsList.forEach { it.isRead = true }
          showNotificationsDialog = false
        }) {
          Text("Marquer comme lues")
        }
      }
    )
  }

  // About Teacher Dialog
  if (showAboutDialog) {
    AlertDialog(
      onDismissRequest = { showAboutDialog = false },
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Text("À propos de l'application")
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            CurriculumData.teacherName,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            CurriculumData.teacherTitle,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            CurriculumData.teacherBio,
            style = MaterialTheme.typography.bodySmall
          )
          HorizontalDivider()
          Text(
            "Plateforme d'enseignement 2nd cycle qualifiant comprenant :",
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelMedium
          )
          Text("1. Cours & simulations interactives (RC, Titrage, Ondes, Nucléaire)\n2. Exercices d'application avec corrigés cachés pas-à-pas\n3. Tests interactifs avec gradient de difficulté (Facile, Moyen, Défi)\n4. Examens Nationaux marocains Sciences Physiques (2015-2026)\n5. Évaluations continues (3 contrôles / semestre = 6 par an)\n6. Concepteur de quiz sur-mesure (QCM, Vrai/Faux, Réponses courtes)\n7. Sessions Professeur & Élève avec synchronisation Google Drive & Sheets.",
            style = MaterialTheme.typography.bodySmall
          )
        }
      },
      confirmButton = {
        Button(onClick = { showAboutDialog = false }) {
          Text("Fermer")
        }
      }
    )
  }

  // Teacher access is intentionally locked until server-side authorization is configured.
  if (showTeacherPasscodeDialog) {
    AlertDialog(
      onDismissRequest = { showTeacherPasscodeDialog = false },
      title = { Text("Espace professeur") },
      text = {
        Text(
          "L'accès professeur sera réactivé après configuration d'une autorisation vérifiée côté serveur. Un code enregistré dans l'application ne constitue pas une protection suffisante.",
          style = MaterialTheme.typography.bodyMedium
        )
      },
      confirmButton = {
        Button(onClick = { showTeacherPasscodeDialog = false }) { Text("Compris") }
      }
    )
  }
    } // End of AppStage.MAIN_APP
  } // End of when (appStage)
} // End of fun PhysicsChemistryApp


